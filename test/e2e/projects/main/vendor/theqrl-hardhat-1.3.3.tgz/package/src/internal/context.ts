import { ConfigExtender, HardhatRuntimeEnvironment } from "../types";

import { ExtenderManager } from "./core/config/extenders";
import { HardhatError } from "./core/errors";
import { ERRORS } from "./core/errors-list";
import { TasksDSL } from "./core/tasks/dsl";

export type GlobalWithHardhatContext = NodeJS.Global & {
  __hardhatContext: HardhatContext;
};

export class HardhatContext {
  public static isCreated(): boolean {
    const globalWithHardhatContext = global as GlobalWithHardhatContext;
    return globalWithHardhatContext.__hardhatContext !== undefined;
  }

  public static createHardhatContext(): HardhatContext {
    if (this.isCreated()) {
      throw new HardhatError(ERRORS.GENERAL.CONTEXT_ALREADY_CREATED);
    }
    const globalWithHardhatContext = global as GlobalWithHardhatContext;
    const ctx = new HardhatContext();
    globalWithHardhatContext.__hardhatContext = ctx;
    return ctx;
  }

  public static getHardhatContext(): HardhatContext {
    const globalWithHardhatContext = global as GlobalWithHardhatContext;
    const ctx = globalWithHardhatContext.__hardhatContext;
    if (ctx === undefined) {
      throw new HardhatError(ERRORS.GENERAL.CONTEXT_NOT_CREATED);
    }
    return ctx;
  }

  public static deleteHardhatContext() {
    const globalAsAny = global as any;
    globalAsAny.__hardhatContext = undefined;
  }

  public readonly tasksDSL = new TasksDSL();
  public readonly extendersManager = new ExtenderManager();
  public environment?: HardhatRuntimeEnvironment;
  public readonly loadedPlugins: string[] = [];
  public readonly configExtenders: ConfigExtender[] = [];

  public setHardhatRuntimeEnvironment(env: HardhatRuntimeEnvironment) {
    if (this.environment !== undefined) {
      throw new HardhatError(ERRORS.GENERAL.CONTEXT_BRE_ALREADY_DEFINED);
    }
    this.environment = env;
  }

  public getHardhatRuntimeEnvironment(): HardhatRuntimeEnvironment {
    if (this.environment === undefined) {
      throw new HardhatError(ERRORS.GENERAL.CONTEXT_BRE_NOT_DEFINED);
    }
    return this.environment;
  }

  public setPluginAsLoaded(pluginName: string) {
    this.loadedPlugins.push(pluginName);
  }
}
