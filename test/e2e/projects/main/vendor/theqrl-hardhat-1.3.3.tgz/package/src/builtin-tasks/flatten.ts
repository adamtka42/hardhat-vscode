import { internalTask, task } from "../internal/core/config/config-env";
import { HardhatError } from "../internal/core/errors";
import { ERRORS } from "../internal/core/errors-list";
import { DependencyGraph } from "../internal/hyperion/dependencyGraph";
import { getImportDirectives } from "../internal/hyperion/imports";
import {
  ResolvedFile,
  ResolvedFilesMap,
  Resolver,
} from "../internal/hyperion/resolver";
import { getPackageJson } from "../internal/util/packageInfo";

import {
  TASK_COMPILE_GET_DEPENDENCY_GRAPH,
  TASK_FLATTEN,
  TASK_FLATTEN_GET_FLATTENED_SOURCE,
} from "./task-names";

function getSortedFiles(dependenciesGraph: DependencyGraph) {
  const tsort = require("tsort");
  const graph = tsort();

  const filesMap: ResolvedFilesMap = {};
  const resolvedFiles = dependenciesGraph.getResolvedFiles();
  resolvedFiles.forEach((f) => (filesMap[f.globalName] = f));

  for (const [from, deps] of dependenciesGraph.dependenciesPerFile.entries()) {
    for (const to of deps) {
      graph.add(to.globalName, from.globalName);
    }
  }

  try {
    const topologicalSortedNames: string[] = graph.sort();

    // If an entry has no dependency it won't be included in the graph, so we
    // add them and then dedup the array
    const withEntries = topologicalSortedNames.concat(
      resolvedFiles.map((f) => f.globalName)
    );

    const sortedNames = [...new Set(withEntries)];
    return sortedNames.map((n) => filesMap[n]);
  } catch (error) {
    if (error.toString().includes("Error: There is a cycle in the graph.")) {
      throw new HardhatError(ERRORS.BUILTIN_TASKS.FLATTEN_CYCLE, error);
    }

    // tslint:disable-next-line only-hardhat-error
    throw error;
  }
}

function getFileWithoutImports(resolvedFile: ResolvedFile) {
  // Remove EXACTLY the import directive ranges reported by the shared
  // lexer: multi-line imports disappear completely, and code sharing a
  // line with an import (e.g. `import "./A.hyp"; contract B {}`) survives.
  const content = resolvedFile.content;
  const directives = getImportDirectives(content);

  let withoutImports = "";
  let previousEnd = 0;
  for (const directive of directives) {
    withoutImports += content.slice(previousEnd, directive.start);
    previousEnd = directive.end;
  }
  withoutImports += content.slice(previousEnd);

  return withoutImports.trim();
}

export default function () {
  internalTask(
    TASK_FLATTEN_GET_FLATTENED_SOURCE,
    "Returns all contracts and their dependencies flattened"
  )
    .addOptionalVariadicPositionalParam(
      "files",
      "An optional list of files to flatten",
      []
    )
    .setAction(async ({ files }: { files: string[] }, { config, run }) => {
      let flattened = "";

      let graph: DependencyGraph;
      if (files.length === 0) {
        graph = await run(TASK_COMPILE_GET_DEPENDENCY_GRAPH);
      } else {
        const resolver = new Resolver(config.paths.root);
        const resolvedFiles = await Promise.all(
          files.map((file) => resolver.resolveProjectSourceFile(file))
        );
        graph = await DependencyGraph.createFromResolvedFiles(
          resolver,
          resolvedFiles
        );
      }
      if (graph.getResolvedFiles().length === 0) {
        return flattened;
      }

      const packageJson = await getPackageJson();
      flattened += `// Sources flattened with Hardhat v${packageJson.version}`;

      const sortedFiles = getSortedFiles(graph);

      for (const file of sortedFiles) {
        flattened += `\n\n// File ${file.getVersionedName()}\n`;
        flattened += `\n${getFileWithoutImports(file)}\n`;
      }

      return flattened.trim();
    });

  task(
    TASK_FLATTEN,
    "Flattens and prints all contracts and their dependencies"
  )
    .addOptionalVariadicPositionalParam(
      "files",
      "An optional list of files to flatten",
      []
    )
    .setAction(async ({ files }: { files: string[] }, { run }) => {
      console.log(await run(TASK_FLATTEN_GET_FLATTENED_SOURCE, { files }));
    });
}
