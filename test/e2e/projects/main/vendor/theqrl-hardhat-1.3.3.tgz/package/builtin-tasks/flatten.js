"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_env_1 = require("../internal/core/config/config-env");
const errors_1 = require("../internal/core/errors");
const errors_list_1 = require("../internal/core/errors-list");
const imports_1 = require("../internal/hyperion/imports");
const packageInfo_1 = require("../internal/util/packageInfo");
const task_names_1 = require("./task-names");
function getSortedFiles(dependenciesGraph) {
    const tsort = require("tsort");
    const graph = tsort();
    const filesMap = {};
    const resolvedFiles = dependenciesGraph.getResolvedFiles();
    resolvedFiles.forEach((f) => (filesMap[f.globalName] = f));
    for (const [from, deps] of dependenciesGraph.dependenciesPerFile.entries()) {
        for (const to of deps) {
            graph.add(to.globalName, from.globalName);
        }
    }
    try {
        const topologicalSortedNames = graph.sort();
        // If an entry has no dependency it won't be included in the graph, so we
        // add them and then dedup the array
        const withEntries = topologicalSortedNames.concat(resolvedFiles.map((f) => f.globalName));
        const sortedNames = [...new Set(withEntries)];
        return sortedNames.map((n) => filesMap[n]);
    }
    catch (error) {
        if (error.toString().includes("Error: There is a cycle in the graph.")) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.FLATTEN_CYCLE, error);
        }
        // tslint:disable-next-line only-hardhat-error
        throw error;
    }
}
function getFileWithoutImports(resolvedFile) {
    // Remove EXACTLY the import directive ranges reported by the shared
    // lexer: multi-line imports disappear completely, and code sharing a
    // line with an import (e.g. `import "./A.hyp"; contract B {}`) survives.
    const content = resolvedFile.content;
    const directives = imports_1.getImportDirectives(content);
    let withoutImports = "";
    let previousEnd = 0;
    for (const directive of directives) {
        withoutImports += content.slice(previousEnd, directive.start);
        previousEnd = directive.end;
    }
    withoutImports += content.slice(previousEnd);
    return withoutImports.trim();
}
function default_1() {
    config_env_1.internalTask(task_names_1.TASK_FLATTEN_GET_FLATTENED_SOURCE, "Returns all contracts and their dependencies flattened", async (_, { run }) => {
        let flattened = "";
        const graph = await run(task_names_1.TASK_COMPILE_GET_DEPENDENCY_GRAPH);
        if (graph.getResolvedFiles().length === 0) {
            return flattened;
        }
        const packageJson = await packageInfo_1.getPackageJson();
        flattened += `// Sources flattened with Hardhat v${packageJson.version}`;
        const sortedFiles = getSortedFiles(graph);
        for (const file of sortedFiles) {
            flattened += `\n\n// File ${file.getVersionedName()}\n`;
            flattened += `\n${getFileWithoutImports(file)}\n`;
        }
        return flattened.trim();
    });
    config_env_1.task(task_names_1.TASK_FLATTEN, "Flattens and prints all contracts and their dependencies", async (_, { run }) => {
        console.log(await run(task_names_1.TASK_FLATTEN_GET_FLATTENED_SOURCE));
    });
}
exports.default = default_1;
//# sourceMappingURL=flatten.js.map