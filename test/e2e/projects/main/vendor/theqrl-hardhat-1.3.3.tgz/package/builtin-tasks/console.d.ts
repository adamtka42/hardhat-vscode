export default function (): void;
//# sourceMappingURL=console.d.ts.map