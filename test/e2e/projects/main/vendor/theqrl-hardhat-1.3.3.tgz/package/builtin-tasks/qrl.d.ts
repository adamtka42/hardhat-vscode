export default function (): void;
//# sourceMappingURL=qrl.d.ts.map