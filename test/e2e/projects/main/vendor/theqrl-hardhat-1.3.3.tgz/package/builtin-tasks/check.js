"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_env_1 = require("../internal/core/config/config-env");
const task_names_1 = require("./task-names");
function default_1() {
    config_env_1.task(task_names_1.TASK_CHECK, "Check whatever you need", async () => { });
}
exports.default = default_1;
//# sourceMappingURL=check.js.map