export default function (): void;
//# sourceMappingURL=run.d.ts.map