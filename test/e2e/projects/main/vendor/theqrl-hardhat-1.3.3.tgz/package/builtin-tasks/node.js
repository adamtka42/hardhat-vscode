"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chalk_1 = __importDefault(require("chalk"));
const debug_1 = __importDefault(require("debug"));
const server_1 = require("../internal/buidler-evm/jsonrpc/server");
const constants_1 = require("../internal/constants");
const config_env_1 = require("../internal/core/config/config-env");
const errors_1 = require("../internal/core/errors");
const errors_list_1 = require("../internal/core/errors-list");
const construction_1 = require("../internal/core/providers/construction");
const lazy_1 = require("../internal/util/lazy");
const task_names_1 = require("./task-names");
const log = debug_1.default("buidler:core:tasks:node");
function _createHardhatQrlvmProvider(config) {
    log("Creating Hardhat QRLVM Provider");
    const networkName = constants_1.HARDHAT_QRLVM_NETWORK_NAME;
    const networkConfig = config.networks[networkName];
    return lazy_1.lazyObject(() => {
        log("Creating hardhatqrlvm provider for JSON-RPC server");
        return construction_1.createProvider(networkName, Object.assign({ loggingEnabled: true }, networkConfig), config.paths);
    });
}
function logHardhatQrlvmAccounts(networkConfig) {
    var _a;
    if (networkConfig.accounts === undefined) {
        return;
    }
    console.log("Accounts");
    console.log("========");
    // QRL account seeds must never be printed here.
    for (const [index, account] of networkConfig.accounts.entries()) {
        const address = account.address;
        const balance = (_a = account.balance) !== null && _a !== void 0 ? _a : "0";
        console.log(`Account #${index}: ${address} (${balance} wei)
`);
    }
}
function default_1() {
    config_env_1.task(task_names_1.TASK_NODE, "Starts a JSON-RPC server on top of the local QRL network")
        .addOptionalParam("hostname", "The host to which to bind to for new connections", "localhost", config_env_1.types.string)
        .addOptionalParam("port", "The port on which to listen for new connections", 8545, config_env_1.types.int)
        .setAction(async ({ hostname, port }, { network, hardhatArguments, config }) => {
        if (network.name !== constants_1.HARDHAT_QRLVM_NETWORK_NAME &&
            // We normally set the default network as hardhatArguments.network,
            // so this check isn't enough, and we add the next one. This has the
            // effect of `--network <defaultNetwork>` being a false negative, but
            // not a big deal.
            hardhatArguments.network !== undefined &&
            hardhatArguments.network !== config.defaultNetwork) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.JSONRPC_UNSUPPORTED_NETWORK);
        }
        try {
            const serverConfig = {
                hostname,
                port,
                provider: _createHardhatQrlvmProvider(config),
            };
            const server = new server_1.JsonRpcServer(serverConfig);
            const { port: actualPort, address } = await server.listen();
            console.log(chalk_1.default.green(`Started HTTP and WebSocket JSON-RPC server at http://${address}:${actualPort}/`));
            console.log();
            const networkConfig = config.networks[constants_1.HARDHAT_QRLVM_NETWORK_NAME];
            logHardhatQrlvmAccounts(networkConfig);
            // Graceful shutdown: close the HTTP/WS servers and exit cleanly.
            const shutdown = () => {
                server
                    .close()
                    .then(() => process.exit(0))
                    .catch(() => process.exit(1));
            };
            process.once("SIGINT", shutdown);
            process.once("SIGTERM", shutdown);
            await server.waitUntilClosed();
        }
        catch (error) {
            if (errors_1.HardhatError.isHardhatError(error)) {
                throw error;
            }
            throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.JSONRPC_SERVER_ERROR, {
                error: error.message,
            }, error);
        }
    });
}
exports.default = default_1;
//# sourceMappingURL=node.js.map