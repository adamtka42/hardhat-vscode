export default function (): void;
//# sourceMappingURL=clean.d.ts.map