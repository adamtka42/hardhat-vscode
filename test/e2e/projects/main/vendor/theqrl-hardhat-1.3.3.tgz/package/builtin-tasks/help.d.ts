export default function (): void;
//# sourceMappingURL=help.d.ts.map