"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_env_1 = require("../internal/core/config/config-env");
const helpers_1 = require("../internal/qrl/helpers");
function default_1() {
    config_env_1.extendEnvironment((env) => {
        env.qrl = helpers_1.createQrlRuntimeHelpers(env);
    });
}
exports.default = default_1;
//# sourceMappingURL=qrl.js.map