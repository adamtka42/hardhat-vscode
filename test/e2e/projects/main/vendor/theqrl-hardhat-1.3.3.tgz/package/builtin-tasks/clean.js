"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_extra_1 = __importDefault(require("fs-extra"));
const config_env_1 = require("../internal/core/config/config-env");
const task_names_1 = require("./task-names");
function default_1() {
    config_env_1.task(task_names_1.TASK_CLEAN, "Clears the cache and deletes all artifacts", async (_, { config }) => {
        await fs_extra_1.default.remove(config.paths.cache);
        await fs_extra_1.default.remove(config.paths.artifacts);
    });
}
exports.default = default_1;
//# sourceMappingURL=clean.js.map