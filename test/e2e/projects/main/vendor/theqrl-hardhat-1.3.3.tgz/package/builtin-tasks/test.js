"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const chalk_1 = __importDefault(require("chalk"));
const path_1 = __importDefault(require("path"));
const constants_1 = require("../internal/constants");
const config_env_1 = require("../internal/core/config/config-env");
const typescript_support_1 = require("../internal/core/typescript-support");
const glob_1 = require("../internal/util/glob");
const strings_1 = require("../internal/util/strings");
const task_names_1 = require("./task-names");
function default_1() {
    config_env_1.internalTask(task_names_1.TASK_TEST_GET_TEST_FILES)
        .addOptionalVariadicPositionalParam("testFiles", "An optional list of files to test", [])
        .setAction(async ({ testFiles }, { config }) => {
        if (testFiles.length !== 0) {
            return testFiles;
        }
        const jsFiles = await glob_1.glob(path_1.default.join(config.paths.tests, "**/*.js"));
        if (!typescript_support_1.isTypescriptSupported()) {
            return jsFiles;
        }
        const tsFiles = await glob_1.glob(path_1.default.join(config.paths.tests, "**/*.ts"));
        return [...jsFiles, ...tsFiles];
    });
    config_env_1.internalTask(task_names_1.TASK_TEST_SETUP_TEST_ENVIRONMENT, async () => { });
    config_env_1.internalTask(task_names_1.TASK_TEST_RUN_MOCHA_TESTS)
        .addOptionalVariadicPositionalParam("testFiles", "An optional list of files to test", [])
        .setAction(async ({ testFiles }, { config }) => {
        const { default: Mocha } = await Promise.resolve().then(() => __importStar(require("mocha")));
        const mocha = new Mocha(config.mocha);
        testFiles.forEach((file) => mocha.addFile(file));
        const runPromise = new Promise((resolve, _) => {
            mocha.run(resolve);
        });
        process.exitCode = await runPromise;
    });
    config_env_1.task(task_names_1.TASK_TEST, "Runs mocha tests")
        .addOptionalVariadicPositionalParam("testFiles", "An optional list of files to test", [])
        .addFlag("noCompile", "Don't compile before running this task")
        .setAction(async ({ testFiles, noCompile, }, { run, network }) => {
        if (!noCompile) {
            await run(task_names_1.TASK_COMPILE);
        }
        const files = await run(task_names_1.TASK_TEST_GET_TEST_FILES, { testFiles });
        await run(task_names_1.TASK_TEST_SETUP_TEST_ENVIRONMENT);
        await run(task_names_1.TASK_TEST_RUN_MOCHA_TESTS, { testFiles: files });
        if (network.name !== constants_1.HARDHAT_QRLVM_NETWORK_NAME) {
            return;
        }
        const failures = await network.provider.send("qrl_getStackTraceFailuresCount");
        if (failures === 0) {
            return;
        }
        console.warn(chalk_1.default.yellow(`Failed to generate ${failures} ${strings_1.pluralize(failures, "stack trace")}. Run Hardhat with --verbose to learn more.`));
    });
}
exports.default = default_1;
//# sourceMappingURL=test.js.map