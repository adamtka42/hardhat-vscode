"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_extra_1 = __importDefault(require("fs-extra"));
const isEqual_1 = __importDefault(require("lodash/isEqual"));
const path_1 = __importDefault(require("path"));
const constants_1 = require("../../internal/constants");
const glob_1 = require("../../internal/util/glob");
const packageInfo_1 = require("../../internal/util/packageInfo");
// Checks the earliest date of modification for compiled files against the latest date for source files (including libraries).
// Furthermore, cache is invalidated if Hardhat's version changes, a different
// compiler config is set in the config, or the resolved hypc binary changes
// (path, mtime, size or detected version — the config's `version` string
// alone cannot tell two local builds apart).
async function areArtifactsCached(sourceTimestamps, newHyperionConfig, paths, compilerIdentity) {
    // No resolvable hypc binary means nothing can be verified — never report
    // a cache hit (a legacy cache without a stored fingerprint would otherwise
    // compare equal to an undefined one). The compile itself then surfaces
    // the real "binary not found" error.
    if (compilerIdentity === undefined) {
        return false;
    }
    const oldConfig = await getLastUsedConfig(paths.cache);
    if (oldConfig === undefined ||
        !compareHyperionConfigs(oldConfig.hyperion, newHyperionConfig) ||
        !isEqual_1.default(oldConfig.compiler, compilerIdentity) ||
        !(await compareHardhatVersion(oldConfig.hardhatVersion))) {
        return false;
    }
    const maxSourceDate = getMaxSourceDate(sourceTimestamps);
    const minArtifactDate = await getMinArtifactDate(paths.artifacts);
    if (!(await fs_extra_1.default.pathExists(path_1.default.join(paths.cache, constants_1.COMPILER_INPUT_FILENAME)))) {
        return false;
    }
    if (!(await fs_extra_1.default.pathExists(path_1.default.join(paths.cache, constants_1.COMPILER_OUTPUT_FILENAME)))) {
        return false;
    }
    const lastConfigTimestamp = await getLastUsedConfigTimestamp(paths.cache);
    if (lastConfigTimestamp !== undefined &&
        lastConfigTimestamp > maxSourceDate) {
        return true;
    }
    return maxSourceDate < minArtifactDate;
}
exports.areArtifactsCached = areArtifactsCached;
async function getModificationDatesInDir(dir) {
    const pattern = path_1.default.join(dir, "**", "*");
    const files = await glob_1.glob(pattern);
    return Promise.all(files.map(async (file) => (await fs_extra_1.default.stat(file)).ctimeMs));
}
function getMaxSourceDate(sourceTimestamps) {
    return Math.max(...sourceTimestamps);
}
async function getMinArtifactDate(artifactsPath) {
    const timestamps = await getModificationDatesInDir(artifactsPath);
    if (timestamps.length === 0) {
        return 0;
    }
    return Math.min(...timestamps);
}
const LAST_CONFIG_USED_FILENAME = "last-compiler-config.json";
function getPathToCachedLastConfigPath(cachePath) {
    const pathToLastConfigUsed = path_1.default.join(cachePath, LAST_CONFIG_USED_FILENAME);
    return pathToLastConfigUsed;
}
async function getLastUsedConfig(cachePath) {
    const pathToConfig = getPathToCachedLastConfigPath(cachePath);
    if (!(await fs_extra_1.default.pathExists(pathToConfig))) {
        return undefined;
    }
    return fs_extra_1.default.readJson(pathToConfig);
}
async function getLastUsedConfigTimestamp(cachePath) {
    const pathToConfig = getPathToCachedLastConfigPath(cachePath);
    if (!(await fs_extra_1.default.pathExists(pathToConfig))) {
        return undefined;
    }
    return (await fs_extra_1.default.stat(pathToConfig)).ctimeMs;
}
async function cacheHardhatConfig(paths, config, compilerIdentity) {
    const pathToLastConfigUsed = getPathToCachedLastConfigPath(paths.cache);
    const newJson = {
        hyperion: config,
        hardhatVersion: await getCurrentHardhatVersion(),
        compiler: compilerIdentity,
    };
    await fs_extra_1.default.ensureDir(path_1.default.dirname(pathToLastConfigUsed));
    return fs_extra_1.default.writeFile(pathToLastConfigUsed, JSON.stringify(newJson, undefined, 2), "utf-8");
}
exports.cacheHardhatConfig = cacheHardhatConfig;
function compareHyperionConfigs(oldConfig, newConfig) {
    return isEqual_1.default(oldConfig, newConfig);
}
async function getCurrentHardhatVersion() {
    const packageJson = await packageInfo_1.getPackageJson();
    return packageJson.version;
}
async function compareHardhatVersion(lastHardhatVersion) {
    const currentVersion = await getCurrentHardhatVersion();
    return lastHardhatVersion === currentVersion;
}
//# sourceMappingURL=cache.js.map