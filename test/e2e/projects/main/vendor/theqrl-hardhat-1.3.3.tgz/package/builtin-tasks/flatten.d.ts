export default function (): void;
//# sourceMappingURL=flatten.d.ts.map