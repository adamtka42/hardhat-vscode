import { CompilerIdentity } from "../../internal/hyperion/compiler-types";
import { HyperionConfig, ProjectPaths } from "../../types";
export declare function areArtifactsCached(sourceTimestamps: number[], newHyperionConfig: HyperionConfig, paths: ProjectPaths, compilerIdentity?: CompilerIdentity): Promise<boolean>;
export declare function cacheHardhatConfig(paths: ProjectPaths, config: HyperionConfig, compilerIdentity?: CompilerIdentity): Promise<void>;
//# sourceMappingURL=cache.d.ts.map