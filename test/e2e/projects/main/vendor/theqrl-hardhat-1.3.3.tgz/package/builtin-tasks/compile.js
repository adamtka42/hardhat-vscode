"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chalk_1 = __importDefault(require("chalk"));
const debug_1 = __importDefault(require("debug"));
const fs_extra_1 = __importDefault(require("fs-extra"));
const path_1 = __importDefault(require("path"));
const artifacts_1 = require("../internal/artifacts");
const constants_1 = require("../internal/constants");
const config_env_1 = require("../internal/core/config/config-env");
const errors_1 = require("../internal/core/errors");
const errors_list_1 = require("../internal/core/errors-list");
const compiler_1 = require("../internal/hyperion/compiler");
const compiler_input_1 = require("../internal/hyperion/compiler-input");
const compiler_version_1 = require("../internal/hyperion/compiler-version");
const dependencyGraph_1 = require("../internal/hyperion/dependencyGraph");
const resolver_1 = require("../internal/hyperion/resolver");
const glob_1 = require("../internal/util/glob");
const strings_1 = require("../internal/util/strings");
const task_names_1 = require("./task-names");
const cache_1 = require("./utils/cache");
const log = debug_1.default("buidler:core:tasks:compile");
function createCompiler(config) {
    return new compiler_1.Compiler(config.hyperion, config.paths.root, config.paths.cache);
}
async function cacheCompilerJsonFiles(config, input, output) {
    await fs_extra_1.default.ensureDir(config.paths.cache);
    // TODO: This could be much better. It feels somewhat hardcoded
    await fs_extra_1.default.writeFile(path_1.default.join(config.paths.cache, constants_1.COMPILER_INPUT_FILENAME), JSON.stringify(input, undefined, 2), {
        encoding: "utf8",
    });
    await fs_extra_1.default.writeFile(path_1.default.join(config.paths.cache, constants_1.COMPILER_OUTPUT_FILENAME), JSON.stringify(output, undefined, 2), {
        encoding: "utf8",
    });
}
function isConsoleLogError(error) {
    return (error.type === "TypeError" &&
        typeof error.message === "string" &&
        error.message.includes("log") &&
        error.message.includes("type(library console)"));
}
function default_1() {
    config_env_1.internalTask(task_names_1.TASK_COMPILE_GET_SOURCE_PATHS, async (_, { config }) => {
        return glob_1.glob(path_1.default.join(config.paths.sources, "**/*.hyp"));
    });
    config_env_1.internalTask(task_names_1.TASK_COMPILE_GET_RESOLVED_SOURCES, async (_, { config, run }) => {
        const resolver = new resolver_1.Resolver(config.paths.root);
        const paths = await run(task_names_1.TASK_COMPILE_GET_SOURCE_PATHS);
        return Promise.all(paths.map((p) => resolver.resolveProjectSourceFile(p)));
    });
    config_env_1.internalTask(task_names_1.TASK_COMPILE_GET_DEPENDENCY_GRAPH, async (_, { config, run }) => {
        const resolver = new resolver_1.Resolver(config.paths.root);
        const localFiles = await run(task_names_1.TASK_COMPILE_GET_RESOLVED_SOURCES);
        return dependencyGraph_1.DependencyGraph.createFromResolvedFiles(resolver, localFiles);
    });
    config_env_1.internalTask(task_names_1.TASK_COMPILE_GET_COMPILER_INPUT, async (_, { config, run }) => {
        const dependencyGraph = await run(task_names_1.TASK_COMPILE_GET_DEPENDENCY_GRAPH);
        return compiler_input_1.getInputFromDependencyGraph(dependencyGraph, config.hyperion.optimizer);
    });
    config_env_1.internalTask(task_names_1.TASK_COMPILE_RUN_COMPILER)
        .addParam("input", "The compiler standard JSON input", undefined, config_env_1.types.json)
        .setAction(async ({ input, compiler }, { config }) => {
        return (compiler !== null && compiler !== void 0 ? compiler : createCompiler(config)).compile(input);
    });
    config_env_1.internalTask(task_names_1.TASK_COMPILE_COMPILE, async ({ compiler }, { config, run }) => {
        const selectedCompiler = compiler !== null && compiler !== void 0 ? compiler : createCompiler(config);
        const input = await run(task_names_1.TASK_COMPILE_GET_COMPILER_INPUT);
        console.log("Compiling...");
        const output = await run(task_names_1.TASK_COMPILE_RUN_COMPILER, {
            input,
            compiler: selectedCompiler,
        });
        let hasErrors = false;
        let hasConsoleLogErrors = false;
        if (output.errors) {
            for (const error of output.errors) {
                hasErrors = hasErrors || error.severity === "error";
                if (error.severity === "error") {
                    hasErrors = true;
                    if (isConsoleLogError(error)) {
                        hasConsoleLogErrors = true;
                    }
                    console.error(chalk_1.default.red(error.formattedMessage));
                }
                else {
                    console.log("\n");
                    console.warn(chalk_1.default.yellow(error.formattedMessage));
                }
            }
        }
        if (hasConsoleLogErrors) {
            console.error(chalk_1.default.red(`The console.log call you made isn’t supported. See the QRL Hardhat documentation for the list of supported methods.`));
            console.log();
        }
        if (hasErrors || !output.contracts) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.COMPILE_FAILURE);
        }
        await cacheCompilerJsonFiles(config, input, output);
        await cache_1.cacheHardhatConfig(config.paths, config.hyperion, (await selectedCompiler.getCompiler()).identity);
        return output;
    });
    config_env_1.internalTask(task_names_1.TASK_COMPILE_CHECK_CACHE, async ({ force, compiler }, { config, run }) => {
        if (force) {
            return false;
        }
        const selectedCompiler = compiler !== null && compiler !== void 0 ? compiler : createCompiler(config);
        // The dependency graph includes every transitively imported file, so
        // changes to imported libraries (e.g. under node_modules) also
        // invalidate the cache, not just changes to project-local sources.
        const dependencyGraph = await run(task_names_1.TASK_COMPILE_GET_DEPENDENCY_GRAPH);
        const sourceTimestamps = dependencyGraph
            .getResolvedFiles()
            .map((file) => file.lastModificationDate.getTime());
        return cache_1.areArtifactsCached(sourceTimestamps, config.hyperion, config.paths, (await selectedCompiler.getCompiler()).identity);
    });
    config_env_1.internalTask(task_names_1.TASK_BUILD_ARTIFACTS, async ({ force }, { config, run }) => {
        var _a;
        const sources = await run(task_names_1.TASK_COMPILE_GET_SOURCE_PATHS);
        if (sources.length === 0) {
            console.log("No Hyperion source file available.");
            return;
        }
        const compiler = createCompiler(config);
        const resolvedCompiler = await compiler.getCompiler();
        log("Resolved %s hypc %s at %s", resolvedCompiler.source, (_a = resolvedCompiler.longVersion) !== null && _a !== void 0 ? _a : "(version not detected)", resolvedCompiler.path);
        const versionWarning = compiler_version_1.getVersionMismatchWarning(config.hyperion.version, resolvedCompiler);
        if (versionWarning !== undefined) {
            console.warn(chalk_1.default.yellow(versionWarning));
        }
        const isCached = await run(task_names_1.TASK_COMPILE_CHECK_CACHE, {
            force,
            compiler,
        });
        if (isCached) {
            console.log("All contracts have already been compiled, skipping compilation.");
            return;
        }
        const compilationOutput = await run(task_names_1.TASK_COMPILE_COMPILE, { compiler });
        if (compilationOutput === undefined) {
            return;
        }
        await fs_extra_1.default.ensureDir(config.paths.artifacts);
        let numberOfContracts = 0;
        for (const file of Object.values(compilationOutput.contracts)) {
            for (const [contractName, contractOutput] of Object.entries(file)) {
                const artifact = artifacts_1.getArtifactFromContractOutput(contractName, contractOutput);
                numberOfContracts += 1;
                await artifacts_1.saveArtifact(config.paths.artifacts, artifact);
            }
        }
        console.log("Compiled", numberOfContracts, strings_1.pluralize(numberOfContracts, "contract"), "successfully");
    });
    config_env_1.task(task_names_1.TASK_COMPILE, "Compiles the entire project, building all artifacts")
        .addFlag("force", "Force compilation ignoring cache")
        .setAction(async ({ force: force }, { run }) => run(task_names_1.TASK_BUILD_ARTIFACTS, { force }));
}
exports.default = default_1;
//# sourceMappingURL=compile.js.map