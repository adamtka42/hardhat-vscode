export default function (): void;
//# sourceMappingURL=check.d.ts.map