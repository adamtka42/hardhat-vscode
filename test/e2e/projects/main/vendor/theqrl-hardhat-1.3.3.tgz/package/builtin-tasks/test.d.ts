export default function (): void;
//# sourceMappingURL=test.d.ts.map