export default function (): void;
//# sourceMappingURL=node.d.ts.map