var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// packages/block/node_modules/@noble/hashes/_u64.js
function fromBig(n, le = false) {
  if (le)
    return { h: Number(n & U32_MASK64), l: Number(n >> _32n & U32_MASK64) };
  return { h: Number(n >> _32n & U32_MASK64) | 0, l: Number(n & U32_MASK64) | 0 };
}
function split(lst, le = false) {
  const len = lst.length;
  let Ah = new Uint32Array(len);
  let Al = new Uint32Array(len);
  for (let i = 0; i < len; i++) {
    const { h, l } = fromBig(lst[i], le);
    [Ah[i], Al[i]] = [h, l];
  }
  return [Ah, Al];
}
var U32_MASK64, _32n, rotlSH, rotlSL, rotlBH, rotlBL;
var init_u64 = __esm({
  "packages/block/node_modules/@noble/hashes/_u64.js"() {
    U32_MASK64 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
    _32n = /* @__PURE__ */ BigInt(32);
    __name(fromBig, "fromBig");
    __name(split, "split");
    rotlSH = /* @__PURE__ */ __name((h, l, s) => h << s | l >>> 32 - s, "rotlSH");
    rotlSL = /* @__PURE__ */ __name((h, l, s) => l << s | h >>> 32 - s, "rotlSL");
    rotlBH = /* @__PURE__ */ __name((h, l, s) => l << s - 32 | h >>> 64 - s, "rotlBH");
    rotlBL = /* @__PURE__ */ __name((h, l, s) => h << s - 32 | l >>> 64 - s, "rotlBL");
  }
});

// packages/block/node_modules/@noble/hashes/utils.js
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function anumber(n, title = "") {
  if (!Number.isSafeInteger(n) || n < 0) {
    const prefix = title && `"${title}" `;
    throw new Error(`${prefix}expected integer >= 0, got ${n}`);
  }
}
function abytes(value, length, title = "") {
  const bytes = isBytes(value);
  const len = value?.length;
  const needsLen = length !== void 0;
  if (!bytes || needsLen && len !== length) {
    const prefix = title && `"${title}" `;
    const ofLen = needsLen ? ` of length ${length}` : "";
    const got = bytes ? `length=${len}` : `type=${typeof value}`;
    throw new Error(prefix + "expected Uint8Array" + ofLen + ", got " + got);
  }
  return value;
}
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput(out, instance) {
  abytes(out, void 0, "digestInto() output");
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error('"digestInto() output" expected to be of length >=' + min);
  }
}
function u32(arr) {
  return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function byteSwap(word) {
  return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
}
function byteSwap32(arr) {
  for (let i = 0; i < arr.length; i++) {
    arr[i] = byteSwap(arr[i]);
  }
  return arr;
}
function createHasher(hashCons, info = {}) {
  const hashC = /* @__PURE__ */ __name((msg, opts) => hashCons(opts).update(msg).digest(), "hashC");
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var isLE, swap32IfBE, oidNist;
var init_utils = __esm({
  "packages/block/node_modules/@noble/hashes/utils.js"() {
    __name(isBytes, "isBytes");
    __name(anumber, "anumber");
    __name(abytes, "abytes");
    __name(aexists, "aexists");
    __name(aoutput, "aoutput");
    __name(u32, "u32");
    __name(clean, "clean");
    isLE = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
    __name(byteSwap, "byteSwap");
    __name(byteSwap32, "byteSwap32");
    swap32IfBE = isLE ? (u) => u : byteSwap32;
    __name(createHasher, "createHasher");
    oidNist = /* @__PURE__ */ __name((suffix) => ({
      oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
    }), "oidNist");
  }
});

// packages/block/node_modules/@noble/hashes/sha3.js
var sha3_exports = {};
__export(sha3_exports, {
  Keccak: () => Keccak,
  keccakP: () => keccakP,
  keccak_224: () => keccak_224,
  keccak_256: () => keccak_256,
  keccak_384: () => keccak_384,
  keccak_512: () => keccak_512,
  sha3_224: () => sha3_224,
  sha3_256: () => sha3_256,
  sha3_384: () => sha3_384,
  sha3_512: () => sha3_512,
  shake128: () => shake128,
  shake128_32: () => shake128_32,
  shake256: () => shake256,
  shake256_64: () => shake256_64
});
function keccakP(s, rounds = 24) {
  const B = new Uint32Array(5 * 2);
  for (let round = 24 - rounds; round < 24; round++) {
    for (let x = 0; x < 10; x++)
      B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
    for (let x = 0; x < 10; x += 2) {
      const idx1 = (x + 8) % 10;
      const idx0 = (x + 2) % 10;
      const B0 = B[idx0];
      const B1 = B[idx0 + 1];
      const Th = rotlH(B0, B1, 1) ^ B[idx1];
      const Tl = rotlL(B0, B1, 1) ^ B[idx1 + 1];
      for (let y = 0; y < 50; y += 10) {
        s[x + y] ^= Th;
        s[x + y + 1] ^= Tl;
      }
    }
    let curH = s[2];
    let curL = s[3];
    for (let t = 0; t < 24; t++) {
      const shift = SHA3_ROTL[t];
      const Th = rotlH(curH, curL, shift);
      const Tl = rotlL(curH, curL, shift);
      const PI = SHA3_PI[t];
      curH = s[PI];
      curL = s[PI + 1];
      s[PI] = Th;
      s[PI + 1] = Tl;
    }
    for (let y = 0; y < 50; y += 10) {
      for (let x = 0; x < 10; x++)
        B[x] = s[y + x];
      for (let x = 0; x < 10; x++)
        s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
    }
    s[0] ^= SHA3_IOTA_H[round];
    s[1] ^= SHA3_IOTA_L[round];
  }
  clean(B);
}
var _0n, _1n, _2n, _7n, _256n, _0x71n, SHA3_PI, SHA3_ROTL, _SHA3_IOTA, IOTAS, SHA3_IOTA_H, SHA3_IOTA_L, rotlH, rotlL, Keccak, genKeccak, sha3_224, sha3_256, sha3_384, sha3_512, keccak_224, keccak_256, keccak_384, keccak_512, genShake, shake128, shake256, shake128_32, shake256_64;
var init_sha3 = __esm({
  "packages/block/node_modules/@noble/hashes/sha3.js"() {
    init_u64();
    init_utils();
    _0n = BigInt(0);
    _1n = BigInt(1);
    _2n = BigInt(2);
    _7n = BigInt(7);
    _256n = BigInt(256);
    _0x71n = BigInt(113);
    SHA3_PI = [];
    SHA3_ROTL = [];
    _SHA3_IOTA = [];
    for (let round = 0, R = _1n, x = 1, y = 0; round < 24; round++) {
      [x, y] = [y, (2 * x + 3 * y) % 5];
      SHA3_PI.push(2 * (5 * y + x));
      SHA3_ROTL.push((round + 1) * (round + 2) / 2 % 64);
      let t = _0n;
      for (let j = 0; j < 7; j++) {
        R = (R << _1n ^ (R >> _7n) * _0x71n) % _256n;
        if (R & _2n)
          t ^= _1n << (_1n << BigInt(j)) - _1n;
      }
      _SHA3_IOTA.push(t);
    }
    IOTAS = split(_SHA3_IOTA, true);
    SHA3_IOTA_H = IOTAS[0];
    SHA3_IOTA_L = IOTAS[1];
    rotlH = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBH(h, l, s) : rotlSH(h, l, s), "rotlH");
    rotlL = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBL(h, l, s) : rotlSL(h, l, s), "rotlL");
    __name(keccakP, "keccakP");
    Keccak = class _Keccak {
      static {
        __name(this, "Keccak");
      }
      state;
      pos = 0;
      posOut = 0;
      finished = false;
      state32;
      destroyed = false;
      blockLen;
      suffix;
      outputLen;
      enableXOF = false;
      rounds;
      // NOTE: we accept arguments in bytes instead of bits here.
      constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
        this.blockLen = blockLen;
        this.suffix = suffix;
        this.outputLen = outputLen;
        this.enableXOF = enableXOF;
        this.rounds = rounds;
        anumber(outputLen, "outputLen");
        if (!(0 < blockLen && blockLen < 200))
          throw new Error("only keccak-f1600 function is supported");
        this.state = new Uint8Array(200);
        this.state32 = u32(this.state);
      }
      clone() {
        return this._cloneInto();
      }
      keccak() {
        swap32IfBE(this.state32);
        keccakP(this.state32, this.rounds);
        swap32IfBE(this.state32);
        this.posOut = 0;
        this.pos = 0;
      }
      update(data) {
        aexists(this);
        abytes(data);
        const { blockLen, state } = this;
        const len = data.length;
        for (let pos = 0; pos < len; ) {
          const take = Math.min(blockLen - this.pos, len - pos);
          for (let i = 0; i < take; i++)
            state[this.pos++] ^= data[pos++];
          if (this.pos === blockLen)
            this.keccak();
        }
        return this;
      }
      finish() {
        if (this.finished)
          return;
        this.finished = true;
        const { state, suffix, pos, blockLen } = this;
        state[pos] ^= suffix;
        if ((suffix & 128) !== 0 && pos === blockLen - 1)
          this.keccak();
        state[blockLen - 1] ^= 128;
        this.keccak();
      }
      writeInto(out) {
        aexists(this, false);
        abytes(out);
        this.finish();
        const bufferOut = this.state;
        const { blockLen } = this;
        for (let pos = 0, len = out.length; pos < len; ) {
          if (this.posOut >= blockLen)
            this.keccak();
          const take = Math.min(blockLen - this.posOut, len - pos);
          out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
          this.posOut += take;
          pos += take;
        }
        return out;
      }
      xofInto(out) {
        if (!this.enableXOF)
          throw new Error("XOF is not possible for this instance");
        return this.writeInto(out);
      }
      xof(bytes) {
        anumber(bytes);
        return this.xofInto(new Uint8Array(bytes));
      }
      digestInto(out) {
        aoutput(out, this);
        if (this.finished)
          throw new Error("digest() was already called");
        this.writeInto(out);
        this.destroy();
        return out;
      }
      digest() {
        return this.digestInto(new Uint8Array(this.outputLen));
      }
      destroy() {
        this.destroyed = true;
        clean(this.state);
      }
      _cloneInto(to) {
        const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
        to ||= new _Keccak(blockLen, suffix, outputLen, enableXOF, rounds);
        to.state32.set(this.state32);
        to.pos = this.pos;
        to.posOut = this.posOut;
        to.finished = this.finished;
        to.rounds = rounds;
        to.suffix = suffix;
        to.outputLen = outputLen;
        to.enableXOF = enableXOF;
        to.destroyed = this.destroyed;
        return to;
      }
    };
    genKeccak = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher(() => new Keccak(blockLen, suffix, outputLen), info), "genKeccak");
    sha3_224 = /* @__PURE__ */ genKeccak(
      6,
      144,
      28,
      /* @__PURE__ */ oidNist(7)
    );
    sha3_256 = /* @__PURE__ */ genKeccak(
      6,
      136,
      32,
      /* @__PURE__ */ oidNist(8)
    );
    sha3_384 = /* @__PURE__ */ genKeccak(
      6,
      104,
      48,
      /* @__PURE__ */ oidNist(9)
    );
    sha3_512 = /* @__PURE__ */ genKeccak(
      6,
      72,
      64,
      /* @__PURE__ */ oidNist(10)
    );
    keccak_224 = /* @__PURE__ */ genKeccak(1, 144, 28);
    keccak_256 = /* @__PURE__ */ genKeccak(1, 136, 32);
    keccak_384 = /* @__PURE__ */ genKeccak(1, 104, 48);
    keccak_512 = /* @__PURE__ */ genKeccak(1, 72, 64);
    genShake = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher((opts = {}) => new Keccak(blockLen, suffix, opts.dkLen === void 0 ? outputLen : opts.dkLen, true), info), "genShake");
    shake128 = /* @__PURE__ */ genShake(31, 168, 16, /* @__PURE__ */ oidNist(11));
    shake256 = /* @__PURE__ */ genShake(31, 136, 32, /* @__PURE__ */ oidNist(12));
    shake128_32 = /* @__PURE__ */ genShake(31, 168, 32, /* @__PURE__ */ oidNist(11));
    shake256_64 = /* @__PURE__ */ genShake(31, 136, 64, /* @__PURE__ */ oidNist(12));
  }
});

// packages/block/dist/cjs/qrl/constants.js
var require_constants = __commonJS({
  "packages/block/dist/cjs/qrl/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRL_LOGS_BLOOM_BYTES = exports2.QRL_LOG_TOPIC_BYTES = exports2.QRL_HASH_BYTES = void 0;
    exports2.QRL_HASH_BYTES = 32;
    exports2.QRL_LOG_TOPIC_BYTES = 64;
    exports2.QRL_LOGS_BLOOM_BYTES = 256;
  }
});

// packages/rlp/dist/cjs/errors.js
var require_errors = __commonJS({
  "packages/rlp/dist/cjs/errors.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLJSError = exports2.DEFAULT_ERROR_CODE = void 0;
    exports2.QRLJSErrorWithoutCode = QRLJSErrorWithoutCode;
    exports2.DEFAULT_ERROR_CODE = "QRLJS_DEFAULT_ERROR_CODE";
    var QRLJSError = class extends Error {
      static {
        __name(this, "QRLJSError");
      }
      constructor(type, message, stack) {
        super(message ?? type.code);
        this.type = type;
        if (stack !== void 0)
          this.stack = stack;
      }
      getMetadata() {
        return this.type;
      }
      /**
       * Get the metadata and the stacktrace for the error.
       */
      toObject() {
        return {
          type: this.getMetadata(),
          message: this.message ?? "",
          stack: this.stack ?? "",
          className: this.constructor.name
        };
      }
    };
    exports2.QRLJSError = QRLJSError;
    function QRLJSErrorWithoutCode(message, stack) {
      return new QRLJSError({ code: exports2.DEFAULT_ERROR_CODE }, message, stack);
    }
    __name(QRLJSErrorWithoutCode, "QRLJSErrorWithoutCode");
  }
});

// packages/rlp/dist/cjs/index.js
var require_cjs = __commonJS({
  "packages/rlp/dist/cjs/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: /* @__PURE__ */ __name(function() {
          return m[k];
        }, "get") };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RLP = exports2.utils = void 0;
    exports2.hexToBytes = hexToBytes2;
    exports2.encode = encode;
    exports2.decode = decode;
    var errors_ts_1 = require_errors();
    __exportStar(require_errors(), exports2);
    function decodeLength(v) {
      if (v[0] === 0) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)("invalid RLP: extra zeros");
      }
      return parseHexByte(bytesToHex2(v));
    }
    __name(decodeLength, "decodeLength");
    function encodeLength(len, offset) {
      if (len < 56) {
        return Uint8Array.from([len + offset]);
      }
      const hexLength = numberToHex(len);
      const lLength = hexLength.length / 2;
      const firstByte = numberToHex(offset + 55 + lLength);
      return Uint8Array.from(hexToBytes2(firstByte + hexLength));
    }
    __name(encodeLength, "encodeLength");
    function safeSlice(input, start, end) {
      if (end > input.length) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)("invalid RLP (safeSlice): end slice of Uint8Array out-of-bounds");
      }
      return input.slice(start, end);
    }
    __name(safeSlice, "safeSlice");
    function _decode(input) {
      let length, lLength, data, innerRemainder, d;
      const decoded = [];
      const firstByte = input[0];
      if (firstByte <= 127) {
        return {
          data: input.slice(0, 1),
          remainder: input.subarray(1)
        };
      } else if (firstByte <= 183) {
        length = firstByte - 127;
        if (firstByte === 128) {
          data = Uint8Array.from([]);
        } else {
          data = safeSlice(input, 1, length);
        }
        if (length === 2 && data[0] < 128) {
          throw (0, errors_ts_1.QRLJSErrorWithoutCode)("invalid RLP encoding: invalid prefix, single byte < 0x80 are not prefixed");
        }
        return {
          data,
          remainder: input.subarray(length)
        };
      } else if (firstByte <= 191) {
        lLength = firstByte - 182;
        if (input.length - 1 < lLength) {
          throw (0, errors_ts_1.QRLJSErrorWithoutCode)("invalid RLP: not enough bytes for string length");
        }
        length = decodeLength(safeSlice(input, 1, lLength));
        if (length <= 55) {
          throw (0, errors_ts_1.QRLJSErrorWithoutCode)("invalid RLP: expected string length to be greater than 55");
        }
        data = safeSlice(input, lLength, length + lLength);
        return {
          data,
          remainder: input.subarray(length + lLength)
        };
      } else if (firstByte <= 247) {
        length = firstByte - 191;
        innerRemainder = safeSlice(input, 1, length);
        while (innerRemainder.length) {
          d = _decode(innerRemainder);
          decoded.push(d.data);
          innerRemainder = d.remainder;
        }
        return {
          data: decoded,
          remainder: input.subarray(length)
        };
      } else {
        lLength = firstByte - 246;
        length = decodeLength(safeSlice(input, 1, lLength));
        if (length < 56) {
          throw (0, errors_ts_1.QRLJSErrorWithoutCode)("invalid RLP: encoded list too short");
        }
        const totalLength = lLength + length;
        if (totalLength > input.length) {
          throw (0, errors_ts_1.QRLJSErrorWithoutCode)("invalid RLP: total length is larger than the data");
        }
        innerRemainder = safeSlice(input, lLength, totalLength);
        while (innerRemainder.length) {
          d = _decode(innerRemainder);
          decoded.push(d.data);
          innerRemainder = d.remainder;
        }
        return {
          data: decoded,
          remainder: input.subarray(totalLength)
        };
      }
    }
    __name(_decode, "_decode");
    var cachedHexes = Array.from({ length: 256 }, (_v, i) => i.toString(16).padStart(2, "0"));
    function bytesToHex2(uint8a) {
      let hex = "";
      for (let i = 0; i < uint8a.length; i++) {
        hex += cachedHexes[uint8a[i]];
      }
      return hex;
    }
    __name(bytesToHex2, "bytesToHex");
    function parseHexByte(hexByte) {
      const byte = Number.parseInt(hexByte, 16);
      if (Number.isNaN(byte))
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)("Invalid byte sequence");
      return byte;
    }
    __name(parseHexByte, "parseHexByte");
    var asciis2 = { _0: 48, _9: 57, _A: 65, _F: 70, _a: 97, _f: 102 };
    function asciiToBase162(char) {
      if (char >= asciis2._0 && char <= asciis2._9)
        return char - asciis2._0;
      if (char >= asciis2._A && char <= asciis2._F)
        return char - (asciis2._A - 10);
      if (char >= asciis2._a && char <= asciis2._f)
        return char - (asciis2._a - 10);
      return;
    }
    __name(asciiToBase162, "asciiToBase16");
    function hexToBytes2(hex) {
      if (typeof hex !== "string")
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)("hex string expected, got " + typeof hex);
      if (hex.slice(0, 2) === "0x")
        hex = hex.slice(2);
      const hl = hex.length;
      const al = hl / 2;
      if (hl % 2)
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)("padded hex string expected, got unpadded hex of length " + hl);
      const array = new Uint8Array(al);
      for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
        const n1 = asciiToBase162(hex.charCodeAt(hi));
        const n2 = asciiToBase162(hex.charCodeAt(hi + 1));
        if (n1 === void 0 || n2 === void 0) {
          const char = hex[hi] + hex[hi + 1];
          throw (0, errors_ts_1.QRLJSErrorWithoutCode)('hex string expected, got non-hex character "' + char + '" at index ' + hi);
        }
        array[ai] = n1 * 16 + n2;
      }
      return array;
    }
    __name(hexToBytes2, "hexToBytes");
    function concatBytes2(...arrays) {
      if (arrays.length === 1)
        return arrays[0];
      const length = arrays.reduce((a, arr) => a + arr.length, 0);
      const result = new Uint8Array(length);
      for (let i = 0, pad = 0; i < arrays.length; i++) {
        const arr = arrays[i];
        result.set(arr, pad);
        pad += arr.length;
      }
      return result;
    }
    __name(concatBytes2, "concatBytes");
    function utf8ToBytes2(utf) {
      return new TextEncoder().encode(utf);
    }
    __name(utf8ToBytes2, "utf8ToBytes");
    function numberToHex(integer) {
      if (integer < 0) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)("Invalid integer as argument, must be unsigned!");
      }
      const hex = integer.toString(16);
      return hex.length % 2 ? `0${hex}` : hex;
    }
    __name(numberToHex, "numberToHex");
    function padToEven(a) {
      return a.length % 2 ? `0${a}` : a;
    }
    __name(padToEven, "padToEven");
    function isHexString(str) {
      return str.length >= 2 && str[0] === "0" && str[1] === "x";
    }
    __name(isHexString, "isHexString");
    function stripHexPrefix(str) {
      if (typeof str !== "string") {
        return str;
      }
      return isHexString(str) ? str.slice(2) : str;
    }
    __name(stripHexPrefix, "stripHexPrefix");
    function toBytes(v) {
      if (v instanceof Uint8Array) {
        return v;
      }
      if (typeof v === "string") {
        if (isHexString(v)) {
          return hexToBytes2(padToEven(stripHexPrefix(v)));
        }
        return utf8ToBytes2(v);
      }
      if (typeof v === "number" || typeof v === "bigint") {
        if (!v) {
          return Uint8Array.from([]);
        }
        return hexToBytes2(numberToHex(v));
      }
      if (v === null || v === void 0) {
        return Uint8Array.from([]);
      }
      throw (0, errors_ts_1.QRLJSErrorWithoutCode)("toBytes: received unsupported type " + typeof v);
    }
    __name(toBytes, "toBytes");
    function encode(input) {
      if (Array.isArray(input)) {
        const output = [];
        let outputLength = 0;
        for (let i = 0; i < input.length; i++) {
          const encoded = encode(input[i]);
          output.push(encoded);
          outputLength += encoded.length;
        }
        return concatBytes2(encodeLength(outputLength, 192), ...output);
      }
      const inputBuf = toBytes(input);
      if (inputBuf.length === 1 && inputBuf[0] < 128) {
        return inputBuf;
      }
      return concatBytes2(encodeLength(inputBuf.length, 128), inputBuf);
    }
    __name(encode, "encode");
    function decode(input, stream = false) {
      if (typeof input === "undefined" || input === null || input.length === 0) {
        return Uint8Array.from([]);
      }
      const inputBytes = toBytes(input);
      const decoded = _decode(inputBytes);
      if (stream) {
        return {
          data: decoded.data,
          remainder: decoded.remainder.slice()
        };
      }
      if (decoded.remainder.length !== 0) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)("invalid RLP: remainder must be zero");
      }
      return decoded.data;
    }
    __name(decode, "decode");
    exports2.utils = {
      bytesToHex: bytesToHex2,
      concatBytes: concatBytes2,
      hexToBytes: hexToBytes2,
      utf8ToBytes: utf8ToBytes2
    };
    exports2.RLP = { encode, decode };
  }
});

// packages/util/dist/cjs/errors.js
var require_errors2 = __commonJS({
  "packages/util/dist/cjs/errors.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLJSErrorWithoutCode = exports2.QRLJSError = exports2.DEFAULT_ERROR_CODE = void 0;
    var rlp_1 = require_cjs();
    Object.defineProperty(exports2, "DEFAULT_ERROR_CODE", { enumerable: true, get: /* @__PURE__ */ __name(function() {
      return rlp_1.DEFAULT_ERROR_CODE;
    }, "get") });
    Object.defineProperty(exports2, "QRLJSError", { enumerable: true, get: /* @__PURE__ */ __name(function() {
      return rlp_1.QRLJSError;
    }, "get") });
    Object.defineProperty(exports2, "QRLJSErrorWithoutCode", { enumerable: true, get: /* @__PURE__ */ __name(function() {
      return rlp_1.QRLJSErrorWithoutCode;
    }, "get") });
  }
});

// packages/util/node_modules/@noble/hashes/utils.js
var utils_exports = {};
__export(utils_exports, {
  abytes: () => abytes2,
  aexists: () => aexists2,
  ahash: () => ahash,
  anumber: () => anumber2,
  aoutput: () => aoutput2,
  asyncLoop: () => asyncLoop,
  byteSwap: () => byteSwap2,
  byteSwap32: () => byteSwap322,
  bytesToHex: () => bytesToHex,
  checkOpts: () => checkOpts,
  clean: () => clean2,
  concatBytes: () => concatBytes,
  createHasher: () => createHasher2,
  createView: () => createView,
  hexToBytes: () => hexToBytes,
  isBytes: () => isBytes2,
  isLE: () => isLE2,
  kdfInputToBytes: () => kdfInputToBytes,
  nextTick: () => nextTick,
  oidNist: () => oidNist2,
  randomBytes: () => randomBytes,
  rotl: () => rotl,
  rotr: () => rotr,
  swap32IfBE: () => swap32IfBE2,
  swap8IfBE: () => swap8IfBE,
  u32: () => u322,
  u8: () => u8,
  utf8ToBytes: () => utf8ToBytes
});
function isBytes2(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function anumber2(n, title = "") {
  if (!Number.isSafeInteger(n) || n < 0) {
    const prefix = title && `"${title}" `;
    throw new Error(`${prefix}expected integer >= 0, got ${n}`);
  }
}
function abytes2(value, length, title = "") {
  const bytes = isBytes2(value);
  const len = value?.length;
  const needsLen = length !== void 0;
  if (!bytes || needsLen && len !== length) {
    const prefix = title && `"${title}" `;
    const ofLen = needsLen ? ` of length ${length}` : "";
    const got = bytes ? `length=${len}` : `type=${typeof value}`;
    throw new Error(prefix + "expected Uint8Array" + ofLen + ", got " + got);
  }
  return value;
}
function ahash(h) {
  if (typeof h !== "function" || typeof h.create !== "function")
    throw new Error("Hash must wrapped by utils.createHasher");
  anumber2(h.outputLen);
  anumber2(h.blockLen);
}
function aexists2(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput2(out, instance) {
  abytes2(out, void 0, "digestInto() output");
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error('"digestInto() output" expected to be of length >=' + min);
  }
}
function u8(arr) {
  return new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
}
function u322(arr) {
  return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
function clean2(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word, shift) {
  return word << 32 - shift | word >>> shift;
}
function rotl(word, shift) {
  return word << shift | word >>> 32 - shift >>> 0;
}
function byteSwap2(word) {
  return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
}
function byteSwap322(arr) {
  for (let i = 0; i < arr.length; i++) {
    arr[i] = byteSwap2(arr[i]);
  }
  return arr;
}
function bytesToHex(bytes) {
  abytes2(bytes);
  if (hasHexBuiltin)
    return bytes.toHex();
  let hex = "";
  for (let i = 0; i < bytes.length; i++) {
    hex += hexes[bytes[i]];
  }
  return hex;
}
function asciiToBase16(ch) {
  if (ch >= asciis._0 && ch <= asciis._9)
    return ch - asciis._0;
  if (ch >= asciis.A && ch <= asciis.F)
    return ch - (asciis.A - 10);
  if (ch >= asciis.a && ch <= asciis.f)
    return ch - (asciis.a - 10);
  return;
}
function hexToBytes(hex) {
  if (typeof hex !== "string")
    throw new Error("hex string expected, got " + typeof hex);
  if (hasHexBuiltin)
    return Uint8Array.fromHex(hex);
  const hl = hex.length;
  const al = hl / 2;
  if (hl % 2)
    throw new Error("hex string expected, got unpadded hex of length " + hl);
  const array = new Uint8Array(al);
  for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
    const n1 = asciiToBase16(hex.charCodeAt(hi));
    const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
    if (n1 === void 0 || n2 === void 0) {
      const char = hex[hi] + hex[hi + 1];
      throw new Error('hex string expected, got non-hex character "' + char + '" at index ' + hi);
    }
    array[ai] = n1 * 16 + n2;
  }
  return array;
}
async function asyncLoop(iters, tick, cb) {
  let ts = Date.now();
  for (let i = 0; i < iters; i++) {
    cb(i);
    const diff = Date.now() - ts;
    if (diff >= 0 && diff < tick)
      continue;
    await nextTick();
    ts += diff;
  }
}
function utf8ToBytes(str) {
  if (typeof str !== "string")
    throw new Error("string expected");
  return new Uint8Array(new TextEncoder().encode(str));
}
function kdfInputToBytes(data, errorTitle = "") {
  if (typeof data === "string")
    return utf8ToBytes(data);
  return abytes2(data, void 0, errorTitle);
}
function concatBytes(...arrays) {
  let sum = 0;
  for (let i = 0; i < arrays.length; i++) {
    const a = arrays[i];
    abytes2(a);
    sum += a.length;
  }
  const res = new Uint8Array(sum);
  for (let i = 0, pad = 0; i < arrays.length; i++) {
    const a = arrays[i];
    res.set(a, pad);
    pad += a.length;
  }
  return res;
}
function checkOpts(defaults, opts) {
  if (opts !== void 0 && {}.toString.call(opts) !== "[object Object]")
    throw new Error("options must be object or undefined");
  const merged = Object.assign(defaults, opts);
  return merged;
}
function createHasher2(hashCons, info = {}) {
  const hashC = /* @__PURE__ */ __name((msg, opts) => hashCons(opts).update(msg).digest(), "hashC");
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
function randomBytes(bytesLength = 32) {
  const cr = typeof globalThis === "object" ? globalThis.crypto : null;
  if (typeof cr?.getRandomValues !== "function")
    throw new Error("crypto.getRandomValues must be defined");
  return cr.getRandomValues(new Uint8Array(bytesLength));
}
var isLE2, swap8IfBE, swap32IfBE2, hasHexBuiltin, hexes, asciis, nextTick, oidNist2;
var init_utils2 = __esm({
  "packages/util/node_modules/@noble/hashes/utils.js"() {
    __name(isBytes2, "isBytes");
    __name(anumber2, "anumber");
    __name(abytes2, "abytes");
    __name(ahash, "ahash");
    __name(aexists2, "aexists");
    __name(aoutput2, "aoutput");
    __name(u8, "u8");
    __name(u322, "u32");
    __name(clean2, "clean");
    __name(createView, "createView");
    __name(rotr, "rotr");
    __name(rotl, "rotl");
    isLE2 = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
    __name(byteSwap2, "byteSwap");
    swap8IfBE = isLE2 ? (n) => n : (n) => byteSwap2(n);
    __name(byteSwap322, "byteSwap32");
    swap32IfBE2 = isLE2 ? (u) => u : byteSwap322;
    hasHexBuiltin = /* @__PURE__ */ (() => (
      // @ts-ignore
      typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function"
    ))();
    hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
    __name(bytesToHex, "bytesToHex");
    asciis = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 };
    __name(asciiToBase16, "asciiToBase16");
    __name(hexToBytes, "hexToBytes");
    nextTick = /* @__PURE__ */ __name(async () => {
    }, "nextTick");
    __name(asyncLoop, "asyncLoop");
    __name(utf8ToBytes, "utf8ToBytes");
    __name(kdfInputToBytes, "kdfInputToBytes");
    __name(concatBytes, "concatBytes");
    __name(checkOpts, "checkOpts");
    __name(createHasher2, "createHasher");
    __name(randomBytes, "randomBytes");
    oidNist2 = /* @__PURE__ */ __name((suffix) => ({
      oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
    }), "oidNist");
  }
});

// packages/util/dist/cjs/bytes.js
var require_bytes = __commonJS({
  "packages/util/dist/cjs/bytes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.concatBytes = exports2.bytesToBigInt = exports2.bigIntToUnpaddedBytes = exports2.bigIntToBytes = exports2.bytesToHex = exports2.hexToBytes = void 0;
    exports2.equalsBytes = equalsBytes;
    var utils_js_1 = (init_utils2(), __toCommonJS(utils_exports));
    var errors_ts_1 = require_errors2();
    function padToEven(value) {
      return value.length % 2 === 0 ? value : `0${value}`;
    }
    __name(padToEven, "padToEven");
    function stripHexPrefix(value) {
      return value.startsWith("0x") ? value.slice(2) : value;
    }
    __name(stripHexPrefix, "stripHexPrefix");
    var hexToBytes2 = /* @__PURE__ */ __name((hex) => {
      if (!hex.startsWith("0x")) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)("input string must be 0x prefixed");
      }
      return (0, utils_js_1.hexToBytes)(padToEven(stripHexPrefix(hex)));
    }, "hexToBytes");
    exports2.hexToBytes = hexToBytes2;
    var bytesToHex2 = /* @__PURE__ */ __name((bytes) => {
      return `0x${(0, utils_js_1.bytesToHex)(bytes)}`;
    }, "bytesToHex");
    exports2.bytesToHex = bytesToHex2;
    var bigIntToBytes = /* @__PURE__ */ __name((num) => {
      return (0, exports2.hexToBytes)(`0x${padToEven(num.toString(16))}`);
    }, "bigIntToBytes");
    exports2.bigIntToBytes = bigIntToBytes;
    var bigIntToUnpaddedBytes = /* @__PURE__ */ __name((value) => {
      const bytes = (0, exports2.bigIntToBytes)(value);
      let first = 0;
      while (first < bytes.length && bytes[first] === 0)
        first++;
      return bytes.slice(first);
    }, "bigIntToUnpaddedBytes");
    exports2.bigIntToUnpaddedBytes = bigIntToUnpaddedBytes;
    var bytesToBigInt = /* @__PURE__ */ __name((bytes) => {
      const hex = (0, exports2.bytesToHex)(bytes);
      return hex === "0x" ? 0n : BigInt(hex);
    }, "bytesToBigInt");
    exports2.bytesToBigInt = bytesToBigInt;
    var concatBytes2 = /* @__PURE__ */ __name((...arrays) => {
      const length = arrays.reduce((sum, array) => sum + array.length, 0);
      const result = new Uint8Array(length);
      let offset = 0;
      for (const array of arrays) {
        result.set(array, offset);
        offset += array.length;
      }
      return result;
    }, "concatBytes");
    exports2.concatBytes = concatBytes2;
    function equalsBytes(a, b) {
      if (a.length !== b.length)
        return false;
      for (let i = 0; i < a.length; i++) {
        if (a[i] !== b[i])
          return false;
      }
      return true;
    }
    __name(equalsBytes, "equalsBytes");
  }
});

// packages/util/dist/cjs/types.js
var require_types = __commonJS({
  "packages/util/dist/cjs/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// packages/util/node_modules/@noble/hashes/_u64.js
function fromBig2(n, le = false) {
  if (le)
    return { h: Number(n & U32_MASK642), l: Number(n >> _32n2 & U32_MASK642) };
  return { h: Number(n >> _32n2 & U32_MASK642) | 0, l: Number(n & U32_MASK642) | 0 };
}
function split2(lst, le = false) {
  const len = lst.length;
  let Ah = new Uint32Array(len);
  let Al = new Uint32Array(len);
  for (let i = 0; i < len; i++) {
    const { h, l } = fromBig2(lst[i], le);
    [Ah[i], Al[i]] = [h, l];
  }
  return [Ah, Al];
}
var U32_MASK642, _32n2, rotlSH2, rotlSL2, rotlBH2, rotlBL2;
var init_u642 = __esm({
  "packages/util/node_modules/@noble/hashes/_u64.js"() {
    U32_MASK642 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
    _32n2 = /* @__PURE__ */ BigInt(32);
    __name(fromBig2, "fromBig");
    __name(split2, "split");
    rotlSH2 = /* @__PURE__ */ __name((h, l, s) => h << s | l >>> 32 - s, "rotlSH");
    rotlSL2 = /* @__PURE__ */ __name((h, l, s) => l << s | h >>> 32 - s, "rotlSL");
    rotlBH2 = /* @__PURE__ */ __name((h, l, s) => l << s - 32 | h >>> 64 - s, "rotlBH");
    rotlBL2 = /* @__PURE__ */ __name((h, l, s) => h << s - 32 | l >>> 64 - s, "rotlBL");
  }
});

// packages/util/node_modules/@noble/hashes/sha3.js
var sha3_exports2 = {};
__export(sha3_exports2, {
  Keccak: () => Keccak2,
  keccakP: () => keccakP2,
  keccak_224: () => keccak_2242,
  keccak_256: () => keccak_2562,
  keccak_384: () => keccak_3842,
  keccak_512: () => keccak_5122,
  sha3_224: () => sha3_2242,
  sha3_256: () => sha3_2562,
  sha3_384: () => sha3_3842,
  sha3_512: () => sha3_5122,
  shake128: () => shake1282,
  shake128_32: () => shake128_322,
  shake256: () => shake2562,
  shake256_64: () => shake256_642
});
function keccakP2(s, rounds = 24) {
  const B = new Uint32Array(5 * 2);
  for (let round = 24 - rounds; round < 24; round++) {
    for (let x = 0; x < 10; x++)
      B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
    for (let x = 0; x < 10; x += 2) {
      const idx1 = (x + 8) % 10;
      const idx0 = (x + 2) % 10;
      const B0 = B[idx0];
      const B1 = B[idx0 + 1];
      const Th = rotlH2(B0, B1, 1) ^ B[idx1];
      const Tl = rotlL2(B0, B1, 1) ^ B[idx1 + 1];
      for (let y = 0; y < 50; y += 10) {
        s[x + y] ^= Th;
        s[x + y + 1] ^= Tl;
      }
    }
    let curH = s[2];
    let curL = s[3];
    for (let t = 0; t < 24; t++) {
      const shift = SHA3_ROTL2[t];
      const Th = rotlH2(curH, curL, shift);
      const Tl = rotlL2(curH, curL, shift);
      const PI = SHA3_PI2[t];
      curH = s[PI];
      curL = s[PI + 1];
      s[PI] = Th;
      s[PI + 1] = Tl;
    }
    for (let y = 0; y < 50; y += 10) {
      for (let x = 0; x < 10; x++)
        B[x] = s[y + x];
      for (let x = 0; x < 10; x++)
        s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
    }
    s[0] ^= SHA3_IOTA_H2[round];
    s[1] ^= SHA3_IOTA_L2[round];
  }
  clean2(B);
}
var _0n2, _1n2, _2n2, _7n2, _256n2, _0x71n2, SHA3_PI2, SHA3_ROTL2, _SHA3_IOTA2, IOTAS2, SHA3_IOTA_H2, SHA3_IOTA_L2, rotlH2, rotlL2, Keccak2, genKeccak2, sha3_2242, sha3_2562, sha3_3842, sha3_5122, keccak_2242, keccak_2562, keccak_3842, keccak_5122, genShake2, shake1282, shake2562, shake128_322, shake256_642;
var init_sha32 = __esm({
  "packages/util/node_modules/@noble/hashes/sha3.js"() {
    init_u642();
    init_utils2();
    _0n2 = BigInt(0);
    _1n2 = BigInt(1);
    _2n2 = BigInt(2);
    _7n2 = BigInt(7);
    _256n2 = BigInt(256);
    _0x71n2 = BigInt(113);
    SHA3_PI2 = [];
    SHA3_ROTL2 = [];
    _SHA3_IOTA2 = [];
    for (let round = 0, R = _1n2, x = 1, y = 0; round < 24; round++) {
      [x, y] = [y, (2 * x + 3 * y) % 5];
      SHA3_PI2.push(2 * (5 * y + x));
      SHA3_ROTL2.push((round + 1) * (round + 2) / 2 % 64);
      let t = _0n2;
      for (let j = 0; j < 7; j++) {
        R = (R << _1n2 ^ (R >> _7n2) * _0x71n2) % _256n2;
        if (R & _2n2)
          t ^= _1n2 << (_1n2 << BigInt(j)) - _1n2;
      }
      _SHA3_IOTA2.push(t);
    }
    IOTAS2 = split2(_SHA3_IOTA2, true);
    SHA3_IOTA_H2 = IOTAS2[0];
    SHA3_IOTA_L2 = IOTAS2[1];
    rotlH2 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBH2(h, l, s) : rotlSH2(h, l, s), "rotlH");
    rotlL2 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBL2(h, l, s) : rotlSL2(h, l, s), "rotlL");
    __name(keccakP2, "keccakP");
    Keccak2 = class _Keccak {
      static {
        __name(this, "Keccak");
      }
      state;
      pos = 0;
      posOut = 0;
      finished = false;
      state32;
      destroyed = false;
      blockLen;
      suffix;
      outputLen;
      enableXOF = false;
      rounds;
      // NOTE: we accept arguments in bytes instead of bits here.
      constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
        this.blockLen = blockLen;
        this.suffix = suffix;
        this.outputLen = outputLen;
        this.enableXOF = enableXOF;
        this.rounds = rounds;
        anumber2(outputLen, "outputLen");
        if (!(0 < blockLen && blockLen < 200))
          throw new Error("only keccak-f1600 function is supported");
        this.state = new Uint8Array(200);
        this.state32 = u322(this.state);
      }
      clone() {
        return this._cloneInto();
      }
      keccak() {
        swap32IfBE2(this.state32);
        keccakP2(this.state32, this.rounds);
        swap32IfBE2(this.state32);
        this.posOut = 0;
        this.pos = 0;
      }
      update(data) {
        aexists2(this);
        abytes2(data);
        const { blockLen, state } = this;
        const len = data.length;
        for (let pos = 0; pos < len; ) {
          const take = Math.min(blockLen - this.pos, len - pos);
          for (let i = 0; i < take; i++)
            state[this.pos++] ^= data[pos++];
          if (this.pos === blockLen)
            this.keccak();
        }
        return this;
      }
      finish() {
        if (this.finished)
          return;
        this.finished = true;
        const { state, suffix, pos, blockLen } = this;
        state[pos] ^= suffix;
        if ((suffix & 128) !== 0 && pos === blockLen - 1)
          this.keccak();
        state[blockLen - 1] ^= 128;
        this.keccak();
      }
      writeInto(out) {
        aexists2(this, false);
        abytes2(out);
        this.finish();
        const bufferOut = this.state;
        const { blockLen } = this;
        for (let pos = 0, len = out.length; pos < len; ) {
          if (this.posOut >= blockLen)
            this.keccak();
          const take = Math.min(blockLen - this.posOut, len - pos);
          out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
          this.posOut += take;
          pos += take;
        }
        return out;
      }
      xofInto(out) {
        if (!this.enableXOF)
          throw new Error("XOF is not possible for this instance");
        return this.writeInto(out);
      }
      xof(bytes) {
        anumber2(bytes);
        return this.xofInto(new Uint8Array(bytes));
      }
      digestInto(out) {
        aoutput2(out, this);
        if (this.finished)
          throw new Error("digest() was already called");
        this.writeInto(out);
        this.destroy();
        return out;
      }
      digest() {
        return this.digestInto(new Uint8Array(this.outputLen));
      }
      destroy() {
        this.destroyed = true;
        clean2(this.state);
      }
      _cloneInto(to) {
        const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
        to ||= new _Keccak(blockLen, suffix, outputLen, enableXOF, rounds);
        to.state32.set(this.state32);
        to.pos = this.pos;
        to.posOut = this.posOut;
        to.finished = this.finished;
        to.rounds = rounds;
        to.suffix = suffix;
        to.outputLen = outputLen;
        to.enableXOF = enableXOF;
        to.destroyed = this.destroyed;
        return to;
      }
    };
    genKeccak2 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher2(() => new Keccak2(blockLen, suffix, outputLen), info), "genKeccak");
    sha3_2242 = /* @__PURE__ */ genKeccak2(
      6,
      144,
      28,
      /* @__PURE__ */ oidNist2(7)
    );
    sha3_2562 = /* @__PURE__ */ genKeccak2(
      6,
      136,
      32,
      /* @__PURE__ */ oidNist2(8)
    );
    sha3_3842 = /* @__PURE__ */ genKeccak2(
      6,
      104,
      48,
      /* @__PURE__ */ oidNist2(9)
    );
    sha3_5122 = /* @__PURE__ */ genKeccak2(
      6,
      72,
      64,
      /* @__PURE__ */ oidNist2(10)
    );
    keccak_2242 = /* @__PURE__ */ genKeccak2(1, 144, 28);
    keccak_2562 = /* @__PURE__ */ genKeccak2(1, 136, 32);
    keccak_3842 = /* @__PURE__ */ genKeccak2(1, 104, 48);
    keccak_5122 = /* @__PURE__ */ genKeccak2(1, 72, 64);
    genShake2 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher2((opts = {}) => new Keccak2(blockLen, suffix, opts.dkLen === void 0 ? outputLen : opts.dkLen, true), info), "genShake");
    shake1282 = /* @__PURE__ */ genShake2(31, 168, 16, /* @__PURE__ */ oidNist2(11));
    shake2562 = /* @__PURE__ */ genShake2(31, 136, 32, /* @__PURE__ */ oidNist2(12));
    shake128_322 = /* @__PURE__ */ genShake2(31, 168, 32, /* @__PURE__ */ oidNist2(11));
    shake256_642 = /* @__PURE__ */ genShake2(31, 136, 64, /* @__PURE__ */ oidNist2(12));
  }
});

// packages/util/dist/cjs/qrl/constants.js
var require_constants2 = __commonJS({
  "packages/util/dist/cjs/qrl/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRL_ADDRESS_PREFIX = exports2.QRL_ADDRESS_HEX_LENGTH = exports2.QRL_ADDRESS_BYTES = void 0;
    exports2.QRL_ADDRESS_BYTES = 64;
    exports2.QRL_ADDRESS_HEX_LENGTH = exports2.QRL_ADDRESS_BYTES * 2;
    exports2.QRL_ADDRESS_PREFIX = "Q";
  }
});

// packages/util/dist/cjs/qrl/address.js
var require_address = __commonJS({
  "packages/util/dist/cjs/qrl/address.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLAddress = void 0;
    exports2.assertQRLAddressBytes = assertQRLAddressBytes;
    exports2.isValidQRLAddress = isValidQRLAddress;
    exports2.qrlAddressFromBytes = qrlAddressFromBytes;
    exports2.qrlAddressFromHex = qrlAddressFromHex;
    exports2.createQRLContractAddress = createQRLContractAddress;
    exports2.createQRLContractAddress2 = createQRLContractAddress2;
    var sha3_js_1 = (init_sha32(), __toCommonJS(sha3_exports2));
    var rlp_1 = require_cjs();
    var bytes_ts_1 = require_bytes();
    var errors_ts_1 = require_errors2();
    var constants_ts_1 = require_constants2();
    var QRL_ADDRESS_RE = new RegExp(`^${constants_ts_1.QRL_ADDRESS_PREFIX}[0-9a-fA-F]{${constants_ts_1.QRL_ADDRESS_HEX_LENGTH}}$`);
    var QRL_HEX_RE = new RegExp(`^0x[0-9a-fA-F]{${constants_ts_1.QRL_ADDRESS_HEX_LENGTH}}$`);
    var QRL_CONTRACT_ADDRESS_DOMAIN = new TextEncoder().encode("QRL-ADDR-v1");
    var UINT64_MAX = 2n ** 64n - 1n;
    var QRLAddress = class _QRLAddress {
      static {
        __name(this, "QRLAddress");
      }
      constructor(bytes) {
        assertQRLAddressBytes(bytes);
        this.bytes = new Uint8Array(bytes);
      }
      /**
       * Returns a QRL address from a 64-byte array.
       */
      static fromBytes(bytes) {
        return new _QRLAddress(bytes);
      }
      /**
       * Returns a QRL address from a 0x-prefixed 128-character hex string.
       */
      static fromHex(hex) {
        if (!QRL_HEX_RE.test(hex)) {
          throw (0, errors_ts_1.QRLJSErrorWithoutCode)(`Invalid QRL address hex input=${hex}`);
        }
        return new _QRLAddress((0, bytes_ts_1.hexToBytes)(hex));
      }
      /**
       * Returns a QRL address from a Q-prefixed address string.
       */
      static fromString(value) {
        if (!isValidQRLAddress(value)) {
          throw (0, errors_ts_1.QRLJSErrorWithoutCode)(`Invalid QRL address input=${value}`);
        }
        return new _QRLAddress((0, bytes_ts_1.hexToBytes)(`0x${value.slice(1)}`));
      }
      /**
       * Returns the zero QRL address.
       */
      static zero() {
        return new _QRLAddress(new Uint8Array(constants_ts_1.QRL_ADDRESS_BYTES));
      }
      /**
       * Is address equal to another.
       */
      equals(address) {
        return (0, bytes_ts_1.equalsBytes)(this.bytes, address.bytes);
      }
      /**
       * Is address zero.
       */
      isZero() {
        return this.equals(_QRLAddress.zero());
      }
      /**
       * Returns a new Uint8Array representation of address.
       */
      toBytes() {
        return new Uint8Array(this.bytes);
      }
      /**
       * Returns a 0x-prefixed lowercase hex encoding of address bytes.
       */
      toHex() {
        return (0, bytes_ts_1.bytesToHex)(this.bytes);
      }
      /**
       * Returns the canonical QIP-55 mixed-case QRL address string.
       */
      toString() {
        return toQRLChecksumAddress(this.bytes);
      }
    };
    exports2.QRLAddress = QRLAddress;
    function assertQRLAddressBytes(bytes) {
      if (!(bytes instanceof Uint8Array)) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)("QRL address bytes must be Uint8Array");
      }
      if (bytes.length !== constants_ts_1.QRL_ADDRESS_BYTES) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)(`Invalid QRL address length=${bytes.length}`);
      }
    }
    __name(assertQRLAddressBytes, "assertQRLAddressBytes");
    function isValidQRLAddress(value) {
      if (typeof value !== "string" || !QRL_ADDRESS_RE.test(value)) {
        return false;
      }
      const body = value.slice(1);
      if (body === body.toLowerCase() || body === body.toUpperCase()) {
        return true;
      }
      return value === toQRLChecksumAddress((0, bytes_ts_1.hexToBytes)(`0x${body}`));
    }
    __name(isValidQRLAddress, "isValidQRLAddress");
    function qrlAddressFromBytes(bytes) {
      return QRLAddress.fromBytes(bytes);
    }
    __name(qrlAddressFromBytes, "qrlAddressFromBytes");
    function qrlAddressFromHex(hex) {
      return QRLAddress.fromHex(hex);
    }
    __name(qrlAddressFromHex, "qrlAddressFromHex");
    function createQRLContractAddress(sender, nonce) {
      if (nonce < 0n || nonce > UINT64_MAX) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)(`Invalid QRL contract nonce=${nonce.toString()}`);
      }
      const encoded = rlp_1.RLP.encode([sender.toBytes(), nonce]);
      return QRLAddress.fromBytes(qrlContractAddressHash(encoded));
    }
    __name(createQRLContractAddress, "createQRLContractAddress");
    function createQRLContractAddress2(sender, salt64, initCodeHash) {
      if (salt64.length !== constants_ts_1.QRL_ADDRESS_BYTES) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)(`Invalid QRL CREATE2 salt length=${salt64.length}`);
      }
      if (initCodeHash.length !== 32) {
        throw (0, errors_ts_1.QRLJSErrorWithoutCode)(`Invalid QRL CREATE2 init code hash length=${initCodeHash.length}`);
      }
      return QRLAddress.fromBytes(qrlContractAddressHash(new Uint8Array([255]), sender.toBytes(), salt64, initCodeHash));
    }
    __name(createQRLContractAddress2, "createQRLContractAddress2");
    function qrlContractAddressHash(...parts) {
      const hasher = sha3_js_1.keccak_512.create();
      hasher.update(QRL_CONTRACT_ADDRESS_DOMAIN);
      for (const part of parts) {
        hasher.update(part);
      }
      return hasher.digest();
    }
    __name(qrlContractAddressHash, "qrlContractAddressHash");
    function toQRLChecksumAddress(bytes) {
      assertQRLAddressBytes(bytes);
      const lowerBody = (0, bytes_ts_1.bytesToHex)(bytes).slice(2);
      const checksum = sha3_js_1.shake256.create({ dkLen: constants_ts_1.QRL_ADDRESS_BYTES }).update(new TextEncoder().encode(lowerBody)).digest();
      let out = constants_ts_1.QRL_ADDRESS_PREFIX;
      for (let i = 0; i < lowerBody.length; i++) {
        const char = lowerBody[i];
        if (char >= "a" && char <= "f") {
          let nibble = checksum[Math.floor(i / 2)];
          if (i % 2 === 0) {
            nibble >>= 4;
          } else {
            nibble &= 15;
          }
          out += nibble >= 8 ? char.toUpperCase() : char;
        } else {
          out += char;
        }
      }
      return out;
    }
    __name(toQRLChecksumAddress, "toQRLChecksumAddress");
  }
});

// packages/util/dist/cjs/qrl/index.js
var require_qrl = __commonJS({
  "packages/util/dist/cjs/qrl/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: /* @__PURE__ */ __name(function() {
          return m[k];
        }, "get") };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_address(), exports2);
    __exportStar(require_constants2(), exports2);
  }
});

// packages/util/dist/cjs/index.js
var require_cjs2 = __commonJS({
  "packages/util/dist/cjs/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: /* @__PURE__ */ __name(function() {
          return m[k];
        }, "get") };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.qrl = void 0;
    __exportStar(require_errors2(), exports2);
    __exportStar(require_bytes(), exports2);
    __exportStar(require_types(), exports2);
    exports2.qrl = require_qrl();
  }
});

// packages/block/dist/cjs/qrl/errors.js
var require_errors3 = __commonJS({
  "packages/block/dist/cjs/qrl/errors.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.qrlBlockError = qrlBlockError;
    var util_1 = require_cjs2();
    function qrlBlockError(message) {
      return (0, util_1.QRLJSErrorWithoutCode)(message);
    }
    __name(qrlBlockError, "qrlBlockError");
  }
});

// packages/block/dist/cjs/qrl/utils.js
var require_utils = __commonJS({
  "packages/block/dist/cjs/qrl/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.copyBytes = copyBytes;
    exports2.copyOptionalBytes = copyOptionalBytes;
    exports2.assertBytes = assertBytes;
    exports2.assertByteLength = assertByteLength;
    exports2.assertNonNegativeBigInt = assertNonNegativeBigInt;
    exports2.assertOptionalNumber = assertOptionalNumber;
    exports2.qrlZeroHash = qrlZeroHash;
    exports2.qrlEmptyRootHash = qrlEmptyRootHash;
    exports2.qrlZeroBloom = qrlZeroBloom;
    exports2.validateHash = validateHash;
    exports2.validateLogTopic = validateLogTopic;
    exports2.validateBloom = validateBloom;
    exports2.hex = hex;
    exports2.optionalHex = optionalHex;
    exports2.quantity = quantity;
    exports2.optionalQuantity = optionalQuantity;
    exports2.numberQuantity = numberQuantity;
    exports2.optionalNumberQuantity = optionalNumberQuantity;
    exports2.bigintToRLP = bigintToRLP;
    var util_1 = require_cjs2();
    var constants_ts_1 = require_constants();
    var errors_ts_1 = require_errors3();
    function copyBytes(bytes) {
      return new Uint8Array(bytes);
    }
    __name(copyBytes, "copyBytes");
    function copyOptionalBytes(bytes) {
      return bytes === void 0 ? void 0 : copyBytes(bytes);
    }
    __name(copyOptionalBytes, "copyOptionalBytes");
    function assertBytes(name, value) {
      if (!(value instanceof Uint8Array)) {
        throw (0, errors_ts_1.qrlBlockError)(`${name} must be Uint8Array`);
      }
    }
    __name(assertBytes, "assertBytes");
    function assertByteLength(name, value, length) {
      assertBytes(name, value);
      if (value.length !== length) {
        throw (0, errors_ts_1.qrlBlockError)(`Invalid ${name} length=${value.length}`);
      }
    }
    __name(assertByteLength, "assertByteLength");
    function assertNonNegativeBigInt(name, value) {
      if (typeof value !== "bigint" || value < 0n) {
        throw (0, errors_ts_1.qrlBlockError)(`${name} must be a non-negative bigint`);
      }
    }
    __name(assertNonNegativeBigInt, "assertNonNegativeBigInt");
    function assertOptionalNumber(name, value) {
      if (value !== void 0 && (!Number.isSafeInteger(value) || value < 0)) {
        throw (0, errors_ts_1.qrlBlockError)(`${name} must be a non-negative safe integer`);
      }
    }
    __name(assertOptionalNumber, "assertOptionalNumber");
    function qrlZeroHash() {
      return new Uint8Array(constants_ts_1.QRL_HASH_BYTES);
    }
    __name(qrlZeroHash, "qrlZeroHash");
    function qrlEmptyRootHash() {
      return (0, util_1.hexToBytes)("0x56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421");
    }
    __name(qrlEmptyRootHash, "qrlEmptyRootHash");
    function qrlZeroBloom() {
      return new Uint8Array(constants_ts_1.QRL_LOGS_BLOOM_BYTES);
    }
    __name(qrlZeroBloom, "qrlZeroBloom");
    function validateHash(name, value) {
      assertByteLength(name, value, constants_ts_1.QRL_HASH_BYTES);
      return copyBytes(value);
    }
    __name(validateHash, "validateHash");
    function validateLogTopic(name, value) {
      assertByteLength(name, value, constants_ts_1.QRL_LOG_TOPIC_BYTES);
      return copyBytes(value);
    }
    __name(validateLogTopic, "validateLogTopic");
    function validateBloom(name, value) {
      assertByteLength(name, value, constants_ts_1.QRL_LOGS_BLOOM_BYTES);
      return copyBytes(value);
    }
    __name(validateBloom, "validateBloom");
    function hex(bytes) {
      return (0, util_1.bytesToHex)(bytes);
    }
    __name(hex, "hex");
    function optionalHex(bytes) {
      return bytes === void 0 ? void 0 : hex(bytes);
    }
    __name(optionalHex, "optionalHex");
    function quantity(value) {
      return `0x${value.toString(16)}`;
    }
    __name(quantity, "quantity");
    function optionalQuantity(value) {
      return value === void 0 ? void 0 : quantity(value);
    }
    __name(optionalQuantity, "optionalQuantity");
    function numberQuantity(value) {
      return `0x${value.toString(16)}`;
    }
    __name(numberQuantity, "numberQuantity");
    function optionalNumberQuantity(value) {
      return value === void 0 ? void 0 : numberQuantity(value);
    }
    __name(optionalNumberQuantity, "optionalNumberQuantity");
    function bigintToRLP(value) {
      assertNonNegativeBigInt("RLP bigint", value);
      return (0, util_1.bigIntToUnpaddedBytes)(value);
    }
    __name(bigintToRLP, "bigintToRLP");
  }
});

// packages/block/dist/cjs/qrl/bloom.js
var require_bloom = __commonJS({
  "packages/block/dist/cjs/qrl/bloom.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createQRLLogsBloom = createQRLLogsBloom;
    exports2.createQRLReceiptsBloom = createQRLReceiptsBloom;
    exports2.mergeQRLBlooms = mergeQRLBlooms;
    var sha3_js_1 = (init_sha3(), __toCommonJS(sha3_exports));
    var constants_ts_1 = require_constants();
    var utils_ts_1 = require_utils();
    function createQRLLogsBloom(logs) {
      const bloom = (0, utils_ts_1.qrlZeroBloom)();
      for (const log of logs) {
        addToBloom(bloom, log.address.toBytes());
        for (const topic of log.topics) {
          addToBloom(bloom, topic);
        }
      }
      return bloom;
    }
    __name(createQRLLogsBloom, "createQRLLogsBloom");
    function createQRLReceiptsBloom(receipts) {
      return mergeQRLBlooms(receipts.map((receipt) => receipt.logsBloom));
    }
    __name(createQRLReceiptsBloom, "createQRLReceiptsBloom");
    function mergeQRLBlooms(blooms) {
      const out = (0, utils_ts_1.qrlZeroBloom)();
      for (const [index, bloom] of blooms.entries()) {
        const validated = (0, utils_ts_1.validateBloom)(`QRL bloom ${index}`, bloom);
        for (let i = 0; i < constants_ts_1.QRL_LOGS_BLOOM_BYTES; i++) {
          out[i] |= validated[i];
        }
      }
      return out;
    }
    __name(mergeQRLBlooms, "mergeQRLBlooms");
    function addToBloom(bloom, data) {
      const hash = (0, sha3_js_1.keccak_256)(data);
      setBloomBit(bloom, hash[0], hash[1]);
      setBloomBit(bloom, hash[2], hash[3]);
      setBloomBit(bloom, hash[4], hash[5]);
    }
    __name(addToBloom, "addToBloom");
    function setBloomBit(bloom, high, low) {
      const bit = (high << 8 | low) & 2047;
      const byteIndex = constants_ts_1.QRL_LOGS_BLOOM_BYTES - (bit >> 3) - 1;
      bloom[byteIndex] |= 1 << (low & 7);
    }
    __name(setBloomBit, "setBloomBit");
  }
});

// packages/block/dist/cjs/qrl/header.js
var require_header = __commonJS({
  "packages/block/dist/cjs/qrl/header.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLBlockHeader = void 0;
    var sha3_js_1 = (init_sha3(), __toCommonJS(sha3_exports));
    var rlp_1 = require_cjs();
    var util_1 = require_cjs2();
    var errors_ts_1 = require_errors3();
    var utils_ts_1 = require_utils();
    var QRLBlockHeader = class {
      static {
        __name(this, "QRLBlockHeader");
      }
      constructor(data = {}) {
        this.parentHash = (0, utils_ts_1.validateHash)("QRL header parentHash", data.parentHash ?? (0, utils_ts_1.qrlZeroHash)());
        this.number = data.number ?? 0n;
        this.timestamp = data.timestamp ?? 0n;
        this.gasLimit = data.gasLimit ?? 0n;
        this.gasUsed = data.gasUsed ?? 0n;
        this.baseFee = data.baseFee ?? 0n;
        this.coinbase = data.coinbase ?? util_1.qrl.QRLAddress.zero();
        this.transactionsRoot = (0, utils_ts_1.validateHash)("QRL header transactionsRoot", data.transactionsRoot ?? (0, utils_ts_1.qrlEmptyRootHash)());
        this.receiptsRoot = (0, utils_ts_1.validateHash)("QRL header receiptsRoot", data.receiptsRoot ?? (0, utils_ts_1.qrlEmptyRootHash)());
        this.stateRoot = (0, utils_ts_1.validateHash)("QRL header stateRoot", data.stateRoot ?? (0, utils_ts_1.qrlZeroHash)());
        this.logsBloom = data.logsBloom === void 0 ? (0, utils_ts_1.qrlZeroBloom)() : (0, utils_ts_1.validateBloom)("QRL header logsBloom", data.logsBloom);
        this.random = (0, utils_ts_1.validateHash)("QRL header random", data.random ?? (0, utils_ts_1.qrlZeroHash)());
        this.extraData = (0, utils_ts_1.copyBytes)(data.extraData ?? new Uint8Array(0));
        this.withdrawalsRoot = (0, utils_ts_1.validateHash)("QRL header withdrawalsRoot", data.withdrawalsRoot ?? (0, utils_ts_1.qrlEmptyRootHash)());
        for (const [name, value] of [
          ["number", this.number],
          ["timestamp", this.timestamp],
          ["gasLimit", this.gasLimit],
          ["gasUsed", this.gasUsed],
          ["baseFee", this.baseFee]
        ]) {
          if (value < 0n) {
            throw (0, errors_ts_1.qrlBlockError)(`QRL header ${name} must be non-negative`);
          }
        }
        this.cachedHash = (0, sha3_js_1.keccak_256)(rlp_1.RLP.encode(this.raw()));
        Object.freeze(this);
      }
      raw() {
        const fields = [
          this.parentHash,
          this.coinbase.toBytes(),
          this.stateRoot,
          this.transactionsRoot,
          this.receiptsRoot,
          this.logsBloom,
          (0, utils_ts_1.bigintToRLP)(this.number),
          (0, utils_ts_1.bigintToRLP)(this.gasLimit),
          (0, utils_ts_1.bigintToRLP)(this.gasUsed),
          (0, utils_ts_1.bigintToRLP)(this.timestamp),
          this.extraData,
          this.random,
          (0, utils_ts_1.bigintToRLP)(this.baseFee)
        ];
        fields.push(this.withdrawalsRoot);
        return fields;
      }
      hash() {
        return (0, utils_ts_1.copyBytes)(this.cachedHash);
      }
      toJSON() {
        return {
          parentHash: (0, utils_ts_1.hex)(this.parentHash),
          miner: this.coinbase.toString(),
          stateRoot: (0, utils_ts_1.hex)(this.stateRoot),
          transactionsRoot: (0, utils_ts_1.hex)(this.transactionsRoot),
          receiptsRoot: (0, utils_ts_1.hex)(this.receiptsRoot),
          logsBloom: (0, utils_ts_1.hex)(this.logsBloom),
          number: (0, utils_ts_1.quantity)(this.number),
          gasLimit: (0, utils_ts_1.quantity)(this.gasLimit),
          gasUsed: (0, utils_ts_1.quantity)(this.gasUsed),
          timestamp: (0, utils_ts_1.quantity)(this.timestamp),
          extraData: (0, utils_ts_1.hex)(this.extraData),
          prevRandao: (0, utils_ts_1.hex)(this.random),
          baseFeePerGas: (0, utils_ts_1.optionalQuantity)(this.baseFee),
          withdrawalsRoot: (0, utils_ts_1.hex)(this.withdrawalsRoot),
          hash: (0, utils_ts_1.hex)(this.cachedHash)
        };
      }
    };
    exports2.QRLBlockHeader = QRLBlockHeader;
  }
});

// packages/block/dist/cjs/qrl/block.js
var require_block = __commonJS({
  "packages/block/dist/cjs/qrl/block.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLBlock = void 0;
    var bloom_ts_1 = require_bloom();
    var header_ts_1 = require_header();
    var utils_ts_1 = require_utils();
    var QRLBlock = class {
      static {
        __name(this, "QRLBlock");
      }
      constructor(data = {}) {
        this.transactions = Object.freeze([...data.transactions ?? []]);
        this.receipts = Object.freeze([...data.receipts ?? []]);
        this.header = normalizeHeader(data.header, this.receipts);
        Object.freeze(this);
      }
      hash() {
        return this.header.hash();
      }
      toJSON() {
        return {
          hash: (0, utils_ts_1.hex)(this.hash()),
          header: this.header.toJSON(),
          transactions: this.transactions.map((tx) => tx.toJSON()),
          receipts: this.receipts.map((receipt) => receipt.toJSON())
        };
      }
    };
    exports2.QRLBlock = QRLBlock;
    function normalizeHeader(header, receipts) {
      if (header instanceof header_ts_1.QRLBlockHeader) {
        return header;
      }
      const gasUsed = receipts.at(-1)?.cumulativeGasUsed;
      return new header_ts_1.QRLBlockHeader({
        ...header,
        gasUsed: header?.gasUsed ?? gasUsed ?? 0n,
        logsBloom: header?.logsBloom ?? (0, bloom_ts_1.createQRLReceiptsBloom)(receipts)
      });
    }
    __name(normalizeHeader, "normalizeHeader");
  }
});

// packages/block/dist/cjs/qrl/log.js
var require_log = __commonJS({
  "packages/block/dist/cjs/qrl/log.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLLog = void 0;
    var utils_ts_1 = require_utils();
    var QRLLog = class _QRLLog {
      static {
        __name(this, "QRLLog");
      }
      constructor(data) {
        this.address = data.address;
        this._topics = Object.freeze((data.topics ?? []).map((topic, index) => (0, utils_ts_1.validateLogTopic)(`QRL log topic ${index}`, topic)));
        this._data = (0, utils_ts_1.copyBytes)(data.data ?? new Uint8Array(0));
        this.blockNumber = data.blockNumber;
        this._txHash = data.txHash === void 0 ? void 0 : (0, utils_ts_1.validateHash)("QRL log txHash", data.txHash);
        this.txIndex = data.txIndex;
        this._blockHash = data.blockHash === void 0 ? void 0 : (0, utils_ts_1.validateHash)("QRL log blockHash", data.blockHash);
        this.index = data.index;
        this.removed = data.removed ?? false;
        Object.freeze(this);
      }
      get topics() {
        return Object.freeze(this._topics.map(utils_ts_1.copyBytes));
      }
      get data() {
        return (0, utils_ts_1.copyBytes)(this._data);
      }
      get txHash() {
        return this._txHash === void 0 ? void 0 : (0, utils_ts_1.copyBytes)(this._txHash);
      }
      get blockHash() {
        return this._blockHash === void 0 ? void 0 : (0, utils_ts_1.copyBytes)(this._blockHash);
      }
      withInclusion(data) {
        return new _QRLLog({
          address: this.address,
          topics: this._topics.map(utils_ts_1.copyBytes),
          data: this._data,
          blockNumber: data.blockNumber,
          txHash: data.txHash,
          txIndex: data.txIndex,
          blockHash: data.blockHash,
          index: data.index,
          removed: this.removed
        });
      }
      toJSON() {
        return {
          address: this.address.toString(),
          topics: this._topics.map(utils_ts_1.hex),
          data: (0, utils_ts_1.hex)(this._data),
          blockNumber: (0, utils_ts_1.optionalQuantity)(this.blockNumber),
          transactionHash: (0, utils_ts_1.optionalHex)(this._txHash),
          transactionIndex: (0, utils_ts_1.optionalNumberQuantity)(this.txIndex),
          blockHash: (0, utils_ts_1.optionalHex)(this._blockHash),
          logIndex: (0, utils_ts_1.optionalNumberQuantity)(this.index),
          removed: this.removed
        };
      }
    };
    exports2.QRLLog = QRLLog;
  }
});

// packages/block/dist/cjs/qrl/receipt.js
var require_receipt = __commonJS({
  "packages/block/dist/cjs/qrl/receipt.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLReceipt = void 0;
    var bloom_ts_1 = require_bloom();
    var errors_ts_1 = require_errors3();
    var utils_ts_1 = require_utils();
    var QRLReceipt = class _QRLReceipt {
      static {
        __name(this, "QRLReceipt");
      }
      constructor(data) {
        this._txHash = (0, utils_ts_1.validateHash)("QRL receipt txHash", data.txHash);
        this._blockHash = data.blockHash === void 0 ? void 0 : (0, utils_ts_1.validateHash)("QRL receipt blockHash", data.blockHash);
        this.blockNumber = data.blockNumber;
        this.transactionIndex = data.transactionIndex;
        this.from = data.from;
        this.to = data.to;
        this.createdAddress = data.createdAddress;
        this.status = data.status;
        this.gasUsed = data.gasUsed;
        this.cumulativeGasUsed = data.cumulativeGasUsed;
        this.effectiveGasPrice = data.effectiveGasPrice;
        this._logs = Object.freeze([...data.logs ?? []]);
        this._logsBloom = data.logsBloom === void 0 ? (0, bloom_ts_1.createQRLLogsBloom)(this._logs) : (0, utils_ts_1.validateBloom)("QRL receipt logsBloom", data.logsBloom);
        if (this.status !== 0 && this.status !== 1) {
          throw (0, errors_ts_1.qrlBlockError)(`Invalid QRL receipt status=${this.status}`);
        }
        if (this.gasUsed < 0n || this.cumulativeGasUsed < 0n) {
          throw (0, errors_ts_1.qrlBlockError)("QRL receipt gas values must be non-negative");
        }
        if (this.effectiveGasPrice !== void 0 && this.effectiveGasPrice < 0n) {
          throw (0, errors_ts_1.qrlBlockError)("QRL receipt effective gas price must be non-negative");
        }
        Object.freeze(this);
      }
      get txHash() {
        return (0, utils_ts_1.copyBytes)(this._txHash);
      }
      get blockHash() {
        return this._blockHash === void 0 ? void 0 : (0, utils_ts_1.copyBytes)(this._blockHash);
      }
      get logs() {
        return Object.freeze([...this._logs]);
      }
      get logsBloom() {
        return (0, utils_ts_1.copyBytes)(this._logsBloom);
      }
      withInclusion(data) {
        let logIndex = data.logIndexStart ?? 0;
        const includedLogs = this._logs.map((log) => log.withInclusion({
          blockHash: data.blockHash,
          blockNumber: data.blockNumber,
          txHash: this._txHash,
          txIndex: data.transactionIndex,
          index: logIndex++
        }));
        return new _QRLReceipt({
          txHash: this._txHash,
          blockHash: data.blockHash,
          blockNumber: data.blockNumber,
          transactionIndex: data.transactionIndex,
          from: this.from,
          to: this.to,
          createdAddress: this.createdAddress,
          status: this.status,
          gasUsed: this.gasUsed,
          cumulativeGasUsed: data.cumulativeGasUsed ?? this.cumulativeGasUsed,
          effectiveGasPrice: this.effectiveGasPrice,
          logs: includedLogs,
          logsBloom: this._logsBloom
        });
      }
      toJSON() {
        return {
          transactionHash: (0, utils_ts_1.hex)(this._txHash),
          blockHash: (0, utils_ts_1.optionalHex)(this._blockHash),
          blockNumber: (0, utils_ts_1.optionalQuantity)(this.blockNumber),
          transactionIndex: (0, utils_ts_1.optionalNumberQuantity)(this.transactionIndex),
          from: this.from.toString(),
          to: this.to?.toString(),
          contractAddress: this.createdAddress?.toString(),
          status: (0, utils_ts_1.quantity)(BigInt(this.status)),
          gasUsed: (0, utils_ts_1.quantity)(this.gasUsed),
          cumulativeGasUsed: (0, utils_ts_1.quantity)(this.cumulativeGasUsed),
          effectiveGasPrice: (0, utils_ts_1.optionalQuantity)(this.effectiveGasPrice),
          logsBloom: (0, utils_ts_1.hex)(this._logsBloom),
          logs: this._logs.map((log) => log.toJSON())
        };
      }
    };
    exports2.QRLReceipt = QRLReceipt;
  }
});

// packages/mpt/node_modules/@noble/hashes/_u64.js
function fromBig3(n, le = false) {
  if (le)
    return { h: Number(n & U32_MASK643), l: Number(n >> _32n3 & U32_MASK643) };
  return { h: Number(n >> _32n3 & U32_MASK643) | 0, l: Number(n & U32_MASK643) | 0 };
}
function split3(lst, le = false) {
  const len = lst.length;
  let Ah = new Uint32Array(len);
  let Al = new Uint32Array(len);
  for (let i = 0; i < len; i++) {
    const { h, l } = fromBig3(lst[i], le);
    [Ah[i], Al[i]] = [h, l];
  }
  return [Ah, Al];
}
var U32_MASK643, _32n3, rotlSH3, rotlSL3, rotlBH3, rotlBL3;
var init_u643 = __esm({
  "packages/mpt/node_modules/@noble/hashes/_u64.js"() {
    U32_MASK643 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
    _32n3 = /* @__PURE__ */ BigInt(32);
    __name(fromBig3, "fromBig");
    __name(split3, "split");
    rotlSH3 = /* @__PURE__ */ __name((h, l, s) => h << s | l >>> 32 - s, "rotlSH");
    rotlSL3 = /* @__PURE__ */ __name((h, l, s) => l << s | h >>> 32 - s, "rotlSL");
    rotlBH3 = /* @__PURE__ */ __name((h, l, s) => l << s - 32 | h >>> 64 - s, "rotlBH");
    rotlBL3 = /* @__PURE__ */ __name((h, l, s) => h << s - 32 | l >>> 64 - s, "rotlBL");
  }
});

// packages/mpt/node_modules/@noble/hashes/utils.js
function isBytes3(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function anumber3(n, title = "") {
  if (!Number.isSafeInteger(n) || n < 0) {
    const prefix = title && `"${title}" `;
    throw new Error(`${prefix}expected integer >= 0, got ${n}`);
  }
}
function abytes3(value, length, title = "") {
  const bytes = isBytes3(value);
  const len = value?.length;
  const needsLen = length !== void 0;
  if (!bytes || needsLen && len !== length) {
    const prefix = title && `"${title}" `;
    const ofLen = needsLen ? ` of length ${length}` : "";
    const got = bytes ? `length=${len}` : `type=${typeof value}`;
    throw new Error(prefix + "expected Uint8Array" + ofLen + ", got " + got);
  }
  return value;
}
function aexists3(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput3(out, instance) {
  abytes3(out, void 0, "digestInto() output");
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error('"digestInto() output" expected to be of length >=' + min);
  }
}
function u323(arr) {
  return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
function clean3(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function byteSwap3(word) {
  return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
}
function byteSwap323(arr) {
  for (let i = 0; i < arr.length; i++) {
    arr[i] = byteSwap3(arr[i]);
  }
  return arr;
}
function createHasher3(hashCons, info = {}) {
  const hashC = /* @__PURE__ */ __name((msg, opts) => hashCons(opts).update(msg).digest(), "hashC");
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var isLE3, swap32IfBE3, oidNist3;
var init_utils3 = __esm({
  "packages/mpt/node_modules/@noble/hashes/utils.js"() {
    __name(isBytes3, "isBytes");
    __name(anumber3, "anumber");
    __name(abytes3, "abytes");
    __name(aexists3, "aexists");
    __name(aoutput3, "aoutput");
    __name(u323, "u32");
    __name(clean3, "clean");
    isLE3 = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
    __name(byteSwap3, "byteSwap");
    __name(byteSwap323, "byteSwap32");
    swap32IfBE3 = isLE3 ? (u) => u : byteSwap323;
    __name(createHasher3, "createHasher");
    oidNist3 = /* @__PURE__ */ __name((suffix) => ({
      oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
    }), "oidNist");
  }
});

// packages/mpt/node_modules/@noble/hashes/sha3.js
var sha3_exports3 = {};
__export(sha3_exports3, {
  Keccak: () => Keccak3,
  keccakP: () => keccakP3,
  keccak_224: () => keccak_2243,
  keccak_256: () => keccak_2563,
  keccak_384: () => keccak_3843,
  keccak_512: () => keccak_5123,
  sha3_224: () => sha3_2243,
  sha3_256: () => sha3_2563,
  sha3_384: () => sha3_3843,
  sha3_512: () => sha3_5123,
  shake128: () => shake1283,
  shake128_32: () => shake128_323,
  shake256: () => shake2563,
  shake256_64: () => shake256_643
});
function keccakP3(s, rounds = 24) {
  const B = new Uint32Array(5 * 2);
  for (let round = 24 - rounds; round < 24; round++) {
    for (let x = 0; x < 10; x++)
      B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
    for (let x = 0; x < 10; x += 2) {
      const idx1 = (x + 8) % 10;
      const idx0 = (x + 2) % 10;
      const B0 = B[idx0];
      const B1 = B[idx0 + 1];
      const Th = rotlH3(B0, B1, 1) ^ B[idx1];
      const Tl = rotlL3(B0, B1, 1) ^ B[idx1 + 1];
      for (let y = 0; y < 50; y += 10) {
        s[x + y] ^= Th;
        s[x + y + 1] ^= Tl;
      }
    }
    let curH = s[2];
    let curL = s[3];
    for (let t = 0; t < 24; t++) {
      const shift = SHA3_ROTL3[t];
      const Th = rotlH3(curH, curL, shift);
      const Tl = rotlL3(curH, curL, shift);
      const PI = SHA3_PI3[t];
      curH = s[PI];
      curL = s[PI + 1];
      s[PI] = Th;
      s[PI + 1] = Tl;
    }
    for (let y = 0; y < 50; y += 10) {
      for (let x = 0; x < 10; x++)
        B[x] = s[y + x];
      for (let x = 0; x < 10; x++)
        s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
    }
    s[0] ^= SHA3_IOTA_H3[round];
    s[1] ^= SHA3_IOTA_L3[round];
  }
  clean3(B);
}
var _0n3, _1n3, _2n3, _7n3, _256n3, _0x71n3, SHA3_PI3, SHA3_ROTL3, _SHA3_IOTA3, IOTAS3, SHA3_IOTA_H3, SHA3_IOTA_L3, rotlH3, rotlL3, Keccak3, genKeccak3, sha3_2243, sha3_2563, sha3_3843, sha3_5123, keccak_2243, keccak_2563, keccak_3843, keccak_5123, genShake3, shake1283, shake2563, shake128_323, shake256_643;
var init_sha33 = __esm({
  "packages/mpt/node_modules/@noble/hashes/sha3.js"() {
    init_u643();
    init_utils3();
    _0n3 = BigInt(0);
    _1n3 = BigInt(1);
    _2n3 = BigInt(2);
    _7n3 = BigInt(7);
    _256n3 = BigInt(256);
    _0x71n3 = BigInt(113);
    SHA3_PI3 = [];
    SHA3_ROTL3 = [];
    _SHA3_IOTA3 = [];
    for (let round = 0, R = _1n3, x = 1, y = 0; round < 24; round++) {
      [x, y] = [y, (2 * x + 3 * y) % 5];
      SHA3_PI3.push(2 * (5 * y + x));
      SHA3_ROTL3.push((round + 1) * (round + 2) / 2 % 64);
      let t = _0n3;
      for (let j = 0; j < 7; j++) {
        R = (R << _1n3 ^ (R >> _7n3) * _0x71n3) % _256n3;
        if (R & _2n3)
          t ^= _1n3 << (_1n3 << BigInt(j)) - _1n3;
      }
      _SHA3_IOTA3.push(t);
    }
    IOTAS3 = split3(_SHA3_IOTA3, true);
    SHA3_IOTA_H3 = IOTAS3[0];
    SHA3_IOTA_L3 = IOTAS3[1];
    rotlH3 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBH3(h, l, s) : rotlSH3(h, l, s), "rotlH");
    rotlL3 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBL3(h, l, s) : rotlSL3(h, l, s), "rotlL");
    __name(keccakP3, "keccakP");
    Keccak3 = class _Keccak {
      static {
        __name(this, "Keccak");
      }
      state;
      pos = 0;
      posOut = 0;
      finished = false;
      state32;
      destroyed = false;
      blockLen;
      suffix;
      outputLen;
      enableXOF = false;
      rounds;
      // NOTE: we accept arguments in bytes instead of bits here.
      constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
        this.blockLen = blockLen;
        this.suffix = suffix;
        this.outputLen = outputLen;
        this.enableXOF = enableXOF;
        this.rounds = rounds;
        anumber3(outputLen, "outputLen");
        if (!(0 < blockLen && blockLen < 200))
          throw new Error("only keccak-f1600 function is supported");
        this.state = new Uint8Array(200);
        this.state32 = u323(this.state);
      }
      clone() {
        return this._cloneInto();
      }
      keccak() {
        swap32IfBE3(this.state32);
        keccakP3(this.state32, this.rounds);
        swap32IfBE3(this.state32);
        this.posOut = 0;
        this.pos = 0;
      }
      update(data) {
        aexists3(this);
        abytes3(data);
        const { blockLen, state } = this;
        const len = data.length;
        for (let pos = 0; pos < len; ) {
          const take = Math.min(blockLen - this.pos, len - pos);
          for (let i = 0; i < take; i++)
            state[this.pos++] ^= data[pos++];
          if (this.pos === blockLen)
            this.keccak();
        }
        return this;
      }
      finish() {
        if (this.finished)
          return;
        this.finished = true;
        const { state, suffix, pos, blockLen } = this;
        state[pos] ^= suffix;
        if ((suffix & 128) !== 0 && pos === blockLen - 1)
          this.keccak();
        state[blockLen - 1] ^= 128;
        this.keccak();
      }
      writeInto(out) {
        aexists3(this, false);
        abytes3(out);
        this.finish();
        const bufferOut = this.state;
        const { blockLen } = this;
        for (let pos = 0, len = out.length; pos < len; ) {
          if (this.posOut >= blockLen)
            this.keccak();
          const take = Math.min(blockLen - this.posOut, len - pos);
          out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
          this.posOut += take;
          pos += take;
        }
        return out;
      }
      xofInto(out) {
        if (!this.enableXOF)
          throw new Error("XOF is not possible for this instance");
        return this.writeInto(out);
      }
      xof(bytes) {
        anumber3(bytes);
        return this.xofInto(new Uint8Array(bytes));
      }
      digestInto(out) {
        aoutput3(out, this);
        if (this.finished)
          throw new Error("digest() was already called");
        this.writeInto(out);
        this.destroy();
        return out;
      }
      digest() {
        return this.digestInto(new Uint8Array(this.outputLen));
      }
      destroy() {
        this.destroyed = true;
        clean3(this.state);
      }
      _cloneInto(to) {
        const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
        to ||= new _Keccak(blockLen, suffix, outputLen, enableXOF, rounds);
        to.state32.set(this.state32);
        to.pos = this.pos;
        to.posOut = this.posOut;
        to.finished = this.finished;
        to.rounds = rounds;
        to.suffix = suffix;
        to.outputLen = outputLen;
        to.enableXOF = enableXOF;
        to.destroyed = this.destroyed;
        return to;
      }
    };
    genKeccak3 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher3(() => new Keccak3(blockLen, suffix, outputLen), info), "genKeccak");
    sha3_2243 = /* @__PURE__ */ genKeccak3(
      6,
      144,
      28,
      /* @__PURE__ */ oidNist3(7)
    );
    sha3_2563 = /* @__PURE__ */ genKeccak3(
      6,
      136,
      32,
      /* @__PURE__ */ oidNist3(8)
    );
    sha3_3843 = /* @__PURE__ */ genKeccak3(
      6,
      104,
      48,
      /* @__PURE__ */ oidNist3(9)
    );
    sha3_5123 = /* @__PURE__ */ genKeccak3(
      6,
      72,
      64,
      /* @__PURE__ */ oidNist3(10)
    );
    keccak_2243 = /* @__PURE__ */ genKeccak3(1, 144, 28);
    keccak_2563 = /* @__PURE__ */ genKeccak3(1, 136, 32);
    keccak_3843 = /* @__PURE__ */ genKeccak3(1, 104, 48);
    keccak_5123 = /* @__PURE__ */ genKeccak3(1, 72, 64);
    genShake3 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher3((opts = {}) => new Keccak3(blockLen, suffix, opts.dkLen === void 0 ? outputLen : opts.dkLen, true), info), "genShake");
    shake1283 = /* @__PURE__ */ genShake3(31, 168, 16, /* @__PURE__ */ oidNist3(11));
    shake2563 = /* @__PURE__ */ genShake3(31, 136, 32, /* @__PURE__ */ oidNist3(12));
    shake128_323 = /* @__PURE__ */ genShake3(31, 168, 32, /* @__PURE__ */ oidNist3(11));
    shake256_643 = /* @__PURE__ */ genShake3(31, 136, 64, /* @__PURE__ */ oidNist3(12));
  }
});

// packages/mpt/dist/cjs/index.js
var require_cjs3 = __commonJS({
  "packages/mpt/dist/cjs/index.js"(exports2) {
    "use strict";
    var __classPrivateFieldGet = exports2 && exports2.__classPrivateFieldGet || function(receiver, state, kind, f) {
      if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
      if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
      return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    };
    var _MerklePatriciaTrie_entries;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MerklePatriciaTrie = void 0;
    var sha3_js_1 = (init_sha33(), __toCommonJS(sha3_exports3));
    var rlp_1 = require_cjs();
    var util_1 = require_cjs2();
    var EMPTY_TRIE_ROOT = (0, util_1.hexToBytes)("0x56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421");
    var BRANCH_NODE_LENGTH = 17;
    var HASH_LENGTH = 32;
    var TERMINATOR_NIBBLE = 16;
    var MerklePatriciaTrie = class {
      static {
        __name(this, "MerklePatriciaTrie");
      }
      constructor() {
        _MerklePatriciaTrie_entries.set(this, /* @__PURE__ */ new Map());
      }
      async put(key, value) {
        __classPrivateFieldGet(this, _MerklePatriciaTrie_entries, "f").set((0, util_1.bytesToHex)(key), {
          key: new Uint8Array(key),
          value: new Uint8Array(value)
        });
      }
      root() {
        if (__classPrivateFieldGet(this, _MerklePatriciaTrie_entries, "f").size === 0) {
          return new Uint8Array(EMPTY_TRIE_ROOT);
        }
        const entries = [...__classPrivateFieldGet(this, _MerklePatriciaTrie_entries, "f").values()].sort((left, right) => (0, util_1.bytesToHex)(left.key).localeCompare((0, util_1.bytesToHex)(right.key))).map((entry) => ({
          nibbles: keybytesToHex(entry.key),
          value: entry.value
        }));
        return (0, sha3_js_1.keccak_256)(encodeNode(buildNode(entries, 0)));
      }
    };
    exports2.MerklePatriciaTrie = MerklePatriciaTrie;
    _MerklePatriciaTrie_entries = /* @__PURE__ */ new WeakMap();
    function buildNode(entries, depth) {
      if (entries.length === 1) {
        return {
          type: "leaf",
          path: entries[0].nibbles.slice(depth),
          value: entries[0].value
        };
      }
      const sharedPrefixLength = commonPrefixLength(entries, depth);
      if (sharedPrefixLength > 0) {
        return {
          type: "extension",
          path: entries[0].nibbles.slice(depth, depth + sharedPrefixLength),
          child: buildNode(entries, depth + sharedPrefixLength)
        };
      }
      const children = new Array(BRANCH_NODE_LENGTH - 1).fill(void 0);
      let value;
      const groups = /* @__PURE__ */ new Map();
      for (const entry of entries) {
        if (entry.nibbles.length === depth) {
          value = entry.value;
          continue;
        }
        const nibble = entry.nibbles[depth];
        if (nibble === TERMINATOR_NIBBLE) {
          value = entry.value;
          continue;
        }
        const group = groups.get(nibble);
        if (group === void 0) {
          groups.set(nibble, [entry]);
        } else {
          group.push(entry);
        }
      }
      for (const [nibble, group] of groups) {
        children[nibble] = buildNode(group, depth + 1);
      }
      return { type: "branch", children, value };
    }
    __name(buildNode, "buildNode");
    function encodeNode(node) {
      return rlp_1.RLP.encode(nodeToInput(node));
    }
    __name(encodeNode, "encodeNode");
    function nodeToInput(node) {
      switch (node.type) {
        case "branch":
          return [
            ...node.children.map((child) => child === void 0 ? new Uint8Array(0) : nodeReference(child)),
            node.value ?? new Uint8Array(0)
          ];
        case "extension":
          return [compactEncode(node.path), nodeReference(node.child)];
        case "leaf":
          return [compactEncode(node.path), node.value];
      }
    }
    __name(nodeToInput, "nodeToInput");
    function nodeReference(node) {
      const encoded = encodeNode(node);
      return encoded.length < HASH_LENGTH ? nodeToInput(node) : (0, sha3_js_1.keccak_256)(encoded);
    }
    __name(nodeReference, "nodeReference");
    function keybytesToHex(bytes) {
      const nibbles = [];
      for (const byte of bytes) {
        nibbles.push(byte >> 4, byte & 15);
      }
      nibbles.push(TERMINATOR_NIBBLE);
      return nibbles;
    }
    __name(keybytesToHex, "keybytesToHex");
    function compactEncode(path) {
      const nibbles = [...path];
      const hasTerminator = nibbles[nibbles.length - 1] === TERMINATOR_NIBBLE;
      if (hasTerminator) {
        nibbles.pop();
      }
      const oddLength = nibbles.length % 2 === 1;
      const bytes = [];
      let index = 0;
      let firstByte = hasTerminator ? 1 << 5 : 0;
      if (oddLength) {
        firstByte |= 1 << 4;
        firstByte |= nibbles[0];
        index = 1;
      }
      bytes.push(firstByte);
      for (; index < nibbles.length; index += 2) {
        bytes.push(nibbles[index] << 4 | nibbles[index + 1]);
      }
      return new Uint8Array(bytes);
    }
    __name(compactEncode, "compactEncode");
    function commonPrefixLength(entries, depth) {
      const first = entries[0].nibbles;
      let length = 0;
      while (depth + length < first.length) {
        const nibble = first[depth + length];
        for (let i = 1; i < entries.length; i++) {
          if (entries[i].nibbles[depth + length] !== nibble) {
            return length;
          }
        }
        length++;
      }
      return length;
    }
    __name(commonPrefixLength, "commonPrefixLength");
  }
});

// packages/tx/dist/cjs/qrl/access.js
var require_access = __commonJS({
  "packages/tx/dist/cjs/qrl/access.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.copyQRLAccessList = copyQRLAccessList;
    exports2.accessListToBytes = accessListToBytes;
    exports2.accessListFromBytes = accessListFromBytes;
    var util_1 = require_cjs2();
    function copyQRLAccessList(accessList) {
      return accessList.map((tuple) => ({
        address: util_1.qrl.QRLAddress.fromBytes(tuple.address.toBytes()),
        storageKeys: tuple.storageKeys.map((key) => new Uint8Array(key))
      }));
    }
    __name(copyQRLAccessList, "copyQRLAccessList");
    function accessListToBytes(accessList) {
      return accessList.map((tuple) => [
        tuple.address.toBytes(),
        tuple.storageKeys.map((key) => new Uint8Array(key))
      ]);
    }
    __name(accessListToBytes, "accessListToBytes");
    function accessListFromBytes(values) {
      return values.map((tuple) => {
        if (!Array.isArray(tuple) || tuple.length !== 2 || !(tuple[0] instanceof Uint8Array)) {
          throw (0, util_1.QRLJSErrorWithoutCode)("Invalid QRL access tuple");
        }
        const storageKeys = tuple[1];
        if (!Array.isArray(storageKeys)) {
          throw (0, util_1.QRLJSErrorWithoutCode)("Invalid QRL access tuple storage keys");
        }
        return {
          address: util_1.qrl.QRLAddress.fromBytes(tuple[0]),
          storageKeys: storageKeys.map((key) => {
            if (!(key instanceof Uint8Array)) {
              throw (0, util_1.QRLJSErrorWithoutCode)("Invalid QRL access tuple storage key");
            }
            return new Uint8Array(key);
          })
        };
      });
    }
    __name(accessListFromBytes, "accessListFromBytes");
  }
});

// packages/tx/dist/cjs/qrl/constants.js
var require_constants3 = __commonJS({
  "packages/tx/dist/cjs/qrl/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRL_DESCRIPTOR_BYTES = exports2.QRL_DYNAMIC_FEE_TX_TYPE = void 0;
    exports2.QRL_DYNAMIC_FEE_TX_TYPE = 2;
    exports2.QRL_DESCRIPTOR_BYTES = 3;
  }
});

// packages/tx/node_modules/@noble/hashes/_u64.js
function fromBig4(n, le = false) {
  if (le)
    return { h: Number(n & U32_MASK644), l: Number(n >> _32n4 & U32_MASK644) };
  return { h: Number(n >> _32n4 & U32_MASK644) | 0, l: Number(n & U32_MASK644) | 0 };
}
function split4(lst, le = false) {
  const len = lst.length;
  let Ah = new Uint32Array(len);
  let Al = new Uint32Array(len);
  for (let i = 0; i < len; i++) {
    const { h, l } = fromBig4(lst[i], le);
    [Ah[i], Al[i]] = [h, l];
  }
  return [Ah, Al];
}
var U32_MASK644, _32n4, rotlSH4, rotlSL4, rotlBH4, rotlBL4;
var init_u644 = __esm({
  "packages/tx/node_modules/@noble/hashes/_u64.js"() {
    U32_MASK644 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
    _32n4 = /* @__PURE__ */ BigInt(32);
    __name(fromBig4, "fromBig");
    __name(split4, "split");
    rotlSH4 = /* @__PURE__ */ __name((h, l, s) => h << s | l >>> 32 - s, "rotlSH");
    rotlSL4 = /* @__PURE__ */ __name((h, l, s) => l << s | h >>> 32 - s, "rotlSL");
    rotlBH4 = /* @__PURE__ */ __name((h, l, s) => l << s - 32 | h >>> 64 - s, "rotlBH");
    rotlBL4 = /* @__PURE__ */ __name((h, l, s) => h << s - 32 | l >>> 64 - s, "rotlBL");
  }
});

// packages/tx/node_modules/@noble/hashes/utils.js
function isBytes4(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function anumber4(n, title = "") {
  if (!Number.isSafeInteger(n) || n < 0) {
    const prefix = title && `"${title}" `;
    throw new Error(`${prefix}expected integer >= 0, got ${n}`);
  }
}
function abytes4(value, length, title = "") {
  const bytes = isBytes4(value);
  const len = value?.length;
  const needsLen = length !== void 0;
  if (!bytes || needsLen && len !== length) {
    const prefix = title && `"${title}" `;
    const ofLen = needsLen ? ` of length ${length}` : "";
    const got = bytes ? `length=${len}` : `type=${typeof value}`;
    throw new Error(prefix + "expected Uint8Array" + ofLen + ", got " + got);
  }
  return value;
}
function aexists4(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput4(out, instance) {
  abytes4(out, void 0, "digestInto() output");
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error('"digestInto() output" expected to be of length >=' + min);
  }
}
function u324(arr) {
  return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
function clean4(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function byteSwap4(word) {
  return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
}
function byteSwap324(arr) {
  for (let i = 0; i < arr.length; i++) {
    arr[i] = byteSwap4(arr[i]);
  }
  return arr;
}
function createHasher4(hashCons, info = {}) {
  const hashC = /* @__PURE__ */ __name((msg, opts) => hashCons(opts).update(msg).digest(), "hashC");
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var isLE4, swap32IfBE4, oidNist4;
var init_utils4 = __esm({
  "packages/tx/node_modules/@noble/hashes/utils.js"() {
    __name(isBytes4, "isBytes");
    __name(anumber4, "anumber");
    __name(abytes4, "abytes");
    __name(aexists4, "aexists");
    __name(aoutput4, "aoutput");
    __name(u324, "u32");
    __name(clean4, "clean");
    isLE4 = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
    __name(byteSwap4, "byteSwap");
    __name(byteSwap324, "byteSwap32");
    swap32IfBE4 = isLE4 ? (u) => u : byteSwap324;
    __name(createHasher4, "createHasher");
    oidNist4 = /* @__PURE__ */ __name((suffix) => ({
      oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
    }), "oidNist");
  }
});

// packages/tx/node_modules/@noble/hashes/sha3.js
var sha3_exports4 = {};
__export(sha3_exports4, {
  Keccak: () => Keccak4,
  keccakP: () => keccakP4,
  keccak_224: () => keccak_2244,
  keccak_256: () => keccak_2564,
  keccak_384: () => keccak_3844,
  keccak_512: () => keccak_5124,
  sha3_224: () => sha3_2244,
  sha3_256: () => sha3_2564,
  sha3_384: () => sha3_3844,
  sha3_512: () => sha3_5124,
  shake128: () => shake1284,
  shake128_32: () => shake128_324,
  shake256: () => shake2564,
  shake256_64: () => shake256_644
});
function keccakP4(s, rounds = 24) {
  const B = new Uint32Array(5 * 2);
  for (let round = 24 - rounds; round < 24; round++) {
    for (let x = 0; x < 10; x++)
      B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
    for (let x = 0; x < 10; x += 2) {
      const idx1 = (x + 8) % 10;
      const idx0 = (x + 2) % 10;
      const B0 = B[idx0];
      const B1 = B[idx0 + 1];
      const Th = rotlH4(B0, B1, 1) ^ B[idx1];
      const Tl = rotlL4(B0, B1, 1) ^ B[idx1 + 1];
      for (let y = 0; y < 50; y += 10) {
        s[x + y] ^= Th;
        s[x + y + 1] ^= Tl;
      }
    }
    let curH = s[2];
    let curL = s[3];
    for (let t = 0; t < 24; t++) {
      const shift = SHA3_ROTL4[t];
      const Th = rotlH4(curH, curL, shift);
      const Tl = rotlL4(curH, curL, shift);
      const PI = SHA3_PI4[t];
      curH = s[PI];
      curL = s[PI + 1];
      s[PI] = Th;
      s[PI + 1] = Tl;
    }
    for (let y = 0; y < 50; y += 10) {
      for (let x = 0; x < 10; x++)
        B[x] = s[y + x];
      for (let x = 0; x < 10; x++)
        s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
    }
    s[0] ^= SHA3_IOTA_H4[round];
    s[1] ^= SHA3_IOTA_L4[round];
  }
  clean4(B);
}
var _0n4, _1n4, _2n4, _7n4, _256n4, _0x71n4, SHA3_PI4, SHA3_ROTL4, _SHA3_IOTA4, IOTAS4, SHA3_IOTA_H4, SHA3_IOTA_L4, rotlH4, rotlL4, Keccak4, genKeccak4, sha3_2244, sha3_2564, sha3_3844, sha3_5124, keccak_2244, keccak_2564, keccak_3844, keccak_5124, genShake4, shake1284, shake2564, shake128_324, shake256_644;
var init_sha34 = __esm({
  "packages/tx/node_modules/@noble/hashes/sha3.js"() {
    init_u644();
    init_utils4();
    _0n4 = BigInt(0);
    _1n4 = BigInt(1);
    _2n4 = BigInt(2);
    _7n4 = BigInt(7);
    _256n4 = BigInt(256);
    _0x71n4 = BigInt(113);
    SHA3_PI4 = [];
    SHA3_ROTL4 = [];
    _SHA3_IOTA4 = [];
    for (let round = 0, R = _1n4, x = 1, y = 0; round < 24; round++) {
      [x, y] = [y, (2 * x + 3 * y) % 5];
      SHA3_PI4.push(2 * (5 * y + x));
      SHA3_ROTL4.push((round + 1) * (round + 2) / 2 % 64);
      let t = _0n4;
      for (let j = 0; j < 7; j++) {
        R = (R << _1n4 ^ (R >> _7n4) * _0x71n4) % _256n4;
        if (R & _2n4)
          t ^= _1n4 << (_1n4 << BigInt(j)) - _1n4;
      }
      _SHA3_IOTA4.push(t);
    }
    IOTAS4 = split4(_SHA3_IOTA4, true);
    SHA3_IOTA_H4 = IOTAS4[0];
    SHA3_IOTA_L4 = IOTAS4[1];
    rotlH4 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBH4(h, l, s) : rotlSH4(h, l, s), "rotlH");
    rotlL4 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBL4(h, l, s) : rotlSL4(h, l, s), "rotlL");
    __name(keccakP4, "keccakP");
    Keccak4 = class _Keccak {
      static {
        __name(this, "Keccak");
      }
      state;
      pos = 0;
      posOut = 0;
      finished = false;
      state32;
      destroyed = false;
      blockLen;
      suffix;
      outputLen;
      enableXOF = false;
      rounds;
      // NOTE: we accept arguments in bytes instead of bits here.
      constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
        this.blockLen = blockLen;
        this.suffix = suffix;
        this.outputLen = outputLen;
        this.enableXOF = enableXOF;
        this.rounds = rounds;
        anumber4(outputLen, "outputLen");
        if (!(0 < blockLen && blockLen < 200))
          throw new Error("only keccak-f1600 function is supported");
        this.state = new Uint8Array(200);
        this.state32 = u324(this.state);
      }
      clone() {
        return this._cloneInto();
      }
      keccak() {
        swap32IfBE4(this.state32);
        keccakP4(this.state32, this.rounds);
        swap32IfBE4(this.state32);
        this.posOut = 0;
        this.pos = 0;
      }
      update(data) {
        aexists4(this);
        abytes4(data);
        const { blockLen, state } = this;
        const len = data.length;
        for (let pos = 0; pos < len; ) {
          const take = Math.min(blockLen - this.pos, len - pos);
          for (let i = 0; i < take; i++)
            state[this.pos++] ^= data[pos++];
          if (this.pos === blockLen)
            this.keccak();
        }
        return this;
      }
      finish() {
        if (this.finished)
          return;
        this.finished = true;
        const { state, suffix, pos, blockLen } = this;
        state[pos] ^= suffix;
        if ((suffix & 128) !== 0 && pos === blockLen - 1)
          this.keccak();
        state[blockLen - 1] ^= 128;
        this.keccak();
      }
      writeInto(out) {
        aexists4(this, false);
        abytes4(out);
        this.finish();
        const bufferOut = this.state;
        const { blockLen } = this;
        for (let pos = 0, len = out.length; pos < len; ) {
          if (this.posOut >= blockLen)
            this.keccak();
          const take = Math.min(blockLen - this.posOut, len - pos);
          out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
          this.posOut += take;
          pos += take;
        }
        return out;
      }
      xofInto(out) {
        if (!this.enableXOF)
          throw new Error("XOF is not possible for this instance");
        return this.writeInto(out);
      }
      xof(bytes) {
        anumber4(bytes);
        return this.xofInto(new Uint8Array(bytes));
      }
      digestInto(out) {
        aoutput4(out, this);
        if (this.finished)
          throw new Error("digest() was already called");
        this.writeInto(out);
        this.destroy();
        return out;
      }
      digest() {
        return this.digestInto(new Uint8Array(this.outputLen));
      }
      destroy() {
        this.destroyed = true;
        clean4(this.state);
      }
      _cloneInto(to) {
        const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
        to ||= new _Keccak(blockLen, suffix, outputLen, enableXOF, rounds);
        to.state32.set(this.state32);
        to.pos = this.pos;
        to.posOut = this.posOut;
        to.finished = this.finished;
        to.rounds = rounds;
        to.suffix = suffix;
        to.outputLen = outputLen;
        to.enableXOF = enableXOF;
        to.destroyed = this.destroyed;
        return to;
      }
    };
    genKeccak4 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher4(() => new Keccak4(blockLen, suffix, outputLen), info), "genKeccak");
    sha3_2244 = /* @__PURE__ */ genKeccak4(
      6,
      144,
      28,
      /* @__PURE__ */ oidNist4(7)
    );
    sha3_2564 = /* @__PURE__ */ genKeccak4(
      6,
      136,
      32,
      /* @__PURE__ */ oidNist4(8)
    );
    sha3_3844 = /* @__PURE__ */ genKeccak4(
      6,
      104,
      48,
      /* @__PURE__ */ oidNist4(9)
    );
    sha3_5124 = /* @__PURE__ */ genKeccak4(
      6,
      72,
      64,
      /* @__PURE__ */ oidNist4(10)
    );
    keccak_2244 = /* @__PURE__ */ genKeccak4(1, 144, 28);
    keccak_2564 = /* @__PURE__ */ genKeccak4(1, 136, 32);
    keccak_3844 = /* @__PURE__ */ genKeccak4(1, 104, 48);
    keccak_5124 = /* @__PURE__ */ genKeccak4(1, 72, 64);
    genShake4 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher4((opts = {}) => new Keccak4(blockLen, suffix, opts.dkLen === void 0 ? outputLen : opts.dkLen, true), info), "genShake");
    shake1284 = /* @__PURE__ */ genShake4(31, 168, 16, /* @__PURE__ */ oidNist4(11));
    shake2564 = /* @__PURE__ */ genShake4(31, 136, 32, /* @__PURE__ */ oidNist4(12));
    shake128_324 = /* @__PURE__ */ genShake4(31, 168, 32, /* @__PURE__ */ oidNist4(11));
    shake256_644 = /* @__PURE__ */ genShake4(31, 136, 64, /* @__PURE__ */ oidNist4(12));
  }
});

// packages/tx/dist/cjs/qrl/dynamicFee.js
var require_dynamicFee = __commonJS({
  "packages/tx/dist/cjs/qrl/dynamicFee.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLDynamicFeeTransaction = void 0;
    var sha3_js_1 = (init_sha34(), __toCommonJS(sha3_exports4));
    var rlp_1 = require_cjs();
    var util_1 = require_cjs2();
    var access_ts_1 = require_access();
    var constants_ts_1 = require_constants3();
    var QRLDynamicFeeTransaction = class _QRLDynamicFeeTransaction {
      static {
        __name(this, "QRLDynamicFeeTransaction");
      }
      constructor(data) {
        this.type = constants_ts_1.QRL_DYNAMIC_FEE_TX_TYPE;
        const normalized = normalizeTxData(data);
        this.chainId = normalized.chainId;
        this.nonce = normalized.nonce;
        this.gasTipCap = normalized.gasTipCap;
        this.gasFeeCap = normalized.gasFeeCap;
        this.gasLimit = normalized.gasLimit;
        this.to = normalized.to;
        this.value = normalized.value;
        this.data = normalized.data;
        this.accessList = normalized.accessList;
        this.descriptor = normalized.descriptor;
        this.extraParams = normalized.extraParams;
        this.signature = normalized.signature;
        this.publicKey = normalized.publicKey;
        Object.freeze(this);
      }
      isContractCreation() {
        return this.to === void 0;
      }
      gasPrice() {
        return this.gasFeeCap;
      }
      cost() {
        return this.gasPrice() * this.gasLimit + this.value;
      }
      raw() {
        return [
          (0, util_1.bigIntToUnpaddedBytes)(this.chainId),
          (0, util_1.bigIntToUnpaddedBytes)(this.nonce),
          (0, util_1.bigIntToUnpaddedBytes)(this.gasTipCap),
          (0, util_1.bigIntToUnpaddedBytes)(this.gasFeeCap),
          (0, util_1.bigIntToUnpaddedBytes)(this.gasLimit),
          this.to?.toBytes() ?? new Uint8Array(0),
          (0, util_1.bigIntToUnpaddedBytes)(this.value),
          new Uint8Array(this.data),
          (0, access_ts_1.accessListToBytes)(this.accessList),
          new Uint8Array(this.descriptor),
          new Uint8Array(this.extraParams),
          new Uint8Array(this.signature),
          new Uint8Array(this.publicKey)
        ];
      }
      signingRaw() {
        return [
          (0, util_1.bigIntToUnpaddedBytes)(this.chainId),
          (0, util_1.bigIntToUnpaddedBytes)(this.nonce),
          (0, util_1.bigIntToUnpaddedBytes)(this.gasTipCap),
          (0, util_1.bigIntToUnpaddedBytes)(this.gasFeeCap),
          (0, util_1.bigIntToUnpaddedBytes)(this.gasLimit),
          this.to?.toBytes() ?? new Uint8Array(0),
          (0, util_1.bigIntToUnpaddedBytes)(this.value),
          new Uint8Array(this.data),
          (0, access_ts_1.accessListToBytes)(this.accessList),
          new Uint8Array(this.descriptor),
          new Uint8Array(this.extraParams)
        ];
      }
      getMessageToSign() {
        return prefixedRlpHash(this.type, this.signingRaw());
      }
      hash() {
        return prefixedRlpHash(this.type, this.raw());
      }
      serialize() {
        return (0, util_1.concatBytes)(new Uint8Array([this.type]), rlp_1.RLP.encode(this.raw()));
      }
      toJSON() {
        return {
          type: `0x${this.type.toString(16).padStart(2, "0")}`,
          chainId: `0x${this.chainId.toString(16)}`,
          nonce: `0x${this.nonce.toString(16)}`,
          gasTipCap: `0x${this.gasTipCap.toString(16)}`,
          gasFeeCap: `0x${this.gasFeeCap.toString(16)}`,
          gasLimit: `0x${this.gasLimit.toString(16)}`,
          to: this.to?.toString(),
          value: `0x${this.value.toString(16)}`,
          data: (0, util_1.bytesToHex)(this.data),
          accessList: this.accessList.map((tuple) => ({
            address: tuple.address.toString(),
            storageKeys: tuple.storageKeys.map((key) => (0, util_1.bytesToHex)(key))
          })),
          descriptor: (0, util_1.bytesToHex)(this.descriptor),
          extraParams: (0, util_1.bytesToHex)(this.extraParams),
          signature: (0, util_1.bytesToHex)(this.signature),
          publicKey: (0, util_1.bytesToHex)(this.publicKey)
        };
      }
      static fromSerialized(serialized) {
        if (serialized[0] !== constants_ts_1.QRL_DYNAMIC_FEE_TX_TYPE) {
          throw (0, util_1.QRLJSErrorWithoutCode)(`Invalid QRL transaction type=${serialized[0] ?? "undefined"}`);
        }
        const decoded = rlp_1.RLP.decode(serialized.subarray(1));
        if (!Array.isArray(decoded) || decoded.length !== 13) {
          throw (0, util_1.QRLJSErrorWithoutCode)("Invalid QRL dynamic fee transaction payload");
        }
        const [chainId, nonce, gasTipCap, gasFeeCap, gasLimit, to, value, data, accessList, descriptor, extraParams, signature, publicKey] = decoded;
        for (const field of [
          chainId,
          nonce,
          gasTipCap,
          gasFeeCap,
          gasLimit,
          to,
          value,
          data,
          descriptor,
          extraParams,
          signature,
          publicKey
        ]) {
          if (!(field instanceof Uint8Array)) {
            throw (0, util_1.QRLJSErrorWithoutCode)("Invalid QRL dynamic fee transaction scalar field");
          }
        }
        if (!Array.isArray(accessList)) {
          throw (0, util_1.QRLJSErrorWithoutCode)("Invalid QRL dynamic fee transaction access list");
        }
        const toBytes = asBytes(to);
        return new _QRLDynamicFeeTransaction({
          chainId: (0, util_1.bytesToBigInt)(asBytes(chainId)),
          nonce: (0, util_1.bytesToBigInt)(asBytes(nonce)),
          gasTipCap: (0, util_1.bytesToBigInt)(asBytes(gasTipCap)),
          gasFeeCap: (0, util_1.bytesToBigInt)(asBytes(gasFeeCap)),
          gasLimit: (0, util_1.bytesToBigInt)(asBytes(gasLimit)),
          to: toBytes.length === 0 ? void 0 : util_1.qrl.QRLAddress.fromBytes(toBytes),
          value: (0, util_1.bytesToBigInt)(asBytes(value)),
          data: asBytes(data),
          accessList: (0, access_ts_1.accessListFromBytes)(accessList),
          descriptor: asBytes(descriptor),
          extraParams: asBytes(extraParams),
          signature: asBytes(signature),
          publicKey: asBytes(publicKey)
        });
      }
    };
    exports2.QRLDynamicFeeTransaction = QRLDynamicFeeTransaction;
    function normalizeTxData(data) {
      const chainId = validateNonNegativeBigint("chainId", data.chainId);
      const nonce = validateBigintLike("nonce", data.nonce);
      const gasTipCap = validateNonNegativeBigint("gasTipCap", data.gasTipCap);
      const gasFeeCap = validateNonNegativeBigint("gasFeeCap", data.gasFeeCap);
      const gasLimit = validateBigintLike("gasLimit", data.gasLimit);
      const value = validateNonNegativeBigint("value", data.value ?? 0n);
      if (gasFeeCap < gasTipCap) {
        throw (0, util_1.QRLJSErrorWithoutCode)("QRL gasFeeCap cannot be less than gasTipCap");
      }
      const descriptor = copyBytes(data.descriptor ?? new Uint8Array(constants_ts_1.QRL_DESCRIPTOR_BYTES));
      if (descriptor.length !== constants_ts_1.QRL_DESCRIPTOR_BYTES) {
        throw (0, util_1.QRLJSErrorWithoutCode)(`Invalid QRL descriptor length=${descriptor.length}`);
      }
      return {
        chainId,
        nonce,
        gasTipCap,
        gasFeeCap,
        gasLimit,
        to: normalizeTo(data.to),
        value,
        data: copyBytes(data.data ?? new Uint8Array(0)),
        accessList: (0, access_ts_1.copyQRLAccessList)(data.accessList ?? []),
        descriptor,
        extraParams: copyBytes(data.extraParams ?? new Uint8Array(0)),
        signature: copyBytes(data.signature ?? new Uint8Array(0)),
        publicKey: copyBytes(data.publicKey ?? new Uint8Array(0))
      };
    }
    __name(normalizeTxData, "normalizeTxData");
    function normalizeTo(to) {
      if (to === void 0) {
        return void 0;
      }
      if (to instanceof util_1.qrl.QRLAddress) {
        return util_1.qrl.QRLAddress.fromBytes(to.toBytes());
      }
      if (to instanceof Uint8Array) {
        if (to.length === 0) {
          return void 0;
        }
        return util_1.qrl.QRLAddress.fromBytes(to);
      }
      if (typeof to === "string") {
        return util_1.qrl.QRLAddress.fromString(to);
      }
      throw (0, util_1.QRLJSErrorWithoutCode)("Invalid QRL transaction to field");
    }
    __name(normalizeTo, "normalizeTo");
    function validateBigintLike(name, value) {
      if (typeof value === "number") {
        if (!Number.isSafeInteger(value)) {
          throw (0, util_1.QRLJSErrorWithoutCode)(`QRL ${name} must be a safe integer`);
        }
        return validateNonNegativeBigint(name, BigInt(value));
      }
      return validateNonNegativeBigint(name, value);
    }
    __name(validateBigintLike, "validateBigintLike");
    function validateNonNegativeBigint(name, value) {
      if (typeof value !== "bigint") {
        throw (0, util_1.QRLJSErrorWithoutCode)(`QRL ${name} must be a bigint`);
      }
      if (value < 0n) {
        throw (0, util_1.QRLJSErrorWithoutCode)(`QRL ${name} cannot be negative`);
      }
      return value;
    }
    __name(validateNonNegativeBigint, "validateNonNegativeBigint");
    function copyBytes(bytes) {
      if (!(bytes instanceof Uint8Array)) {
        throw (0, util_1.QRLJSErrorWithoutCode)("QRL transaction byte fields must be Uint8Array");
      }
      return new Uint8Array(bytes);
    }
    __name(copyBytes, "copyBytes");
    function asBytes(value) {
      if (!(value instanceof Uint8Array)) {
        throw (0, util_1.QRLJSErrorWithoutCode)("Invalid QRL dynamic fee transaction scalar field");
      }
      return value;
    }
    __name(asBytes, "asBytes");
    function prefixedRlpHash(prefix, value) {
      return (0, sha3_js_1.keccak_256)((0, util_1.concatBytes)(new Uint8Array([prefix]), rlp_1.RLP.encode(value)));
    }
    __name(prefixedRlpHash, "prefixedRlpHash");
  }
});

// packages/tx/dist/cjs/qrl/constructors.js
var require_constructors = __commonJS({
  "packages/tx/dist/cjs/qrl/constructors.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createQRLDynamicFeeTransaction = createQRLDynamicFeeTransaction;
    exports2.createQRLContractCreationTransaction = createQRLContractCreationTransaction;
    exports2.createQRLContractCallTransaction = createQRLContractCallTransaction;
    var dynamicFee_ts_1 = require_dynamicFee();
    function createQRLDynamicFeeTransaction(data) {
      return new dynamicFee_ts_1.QRLDynamicFeeTransaction(data);
    }
    __name(createQRLDynamicFeeTransaction, "createQRLDynamicFeeTransaction");
    function createQRLContractCreationTransaction(data) {
      return new dynamicFee_ts_1.QRLDynamicFeeTransaction(data);
    }
    __name(createQRLContractCreationTransaction, "createQRLContractCreationTransaction");
    function createQRLContractCallTransaction(data) {
      return new dynamicFee_ts_1.QRLDynamicFeeTransaction(data);
    }
    __name(createQRLContractCallTransaction, "createQRLContractCallTransaction");
  }
});

// packages/tx/dist/cjs/qrl/signing.js
var require_signing = __commonJS({
  "packages/tx/dist/cjs/qrl/signing.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// packages/tx/dist/cjs/qrl/transaction.js
var require_transaction = __commonJS({
  "packages/tx/dist/cjs/qrl/transaction.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLTransaction = void 0;
    var util_1 = require_cjs2();
    var constants_ts_1 = require_constants3();
    var dynamicFee_ts_1 = require_dynamicFee();
    var QRLTransaction = class _QRLTransaction {
      static {
        __name(this, "QRLTransaction");
      }
      constructor(inner) {
        this.inner = inner;
        Object.freeze(this);
      }
      static fromDynamicFee(data) {
        return new _QRLTransaction(new dynamicFee_ts_1.QRLDynamicFeeTransaction(data));
      }
      static fromSerialized(bytes) {
        if (bytes[0] !== constants_ts_1.QRL_DYNAMIC_FEE_TX_TYPE) {
          throw (0, util_1.QRLJSErrorWithoutCode)(`Unsupported QRL transaction type=${bytes[0]}`);
        }
        return new _QRLTransaction(dynamicFee_ts_1.QRLDynamicFeeTransaction.fromSerialized(bytes));
      }
      type() {
        return this.inner.type;
      }
      chainId() {
        return this.inner.chainId;
      }
      nonce() {
        return this.inner.nonce;
      }
      to() {
        return this.inner.to;
      }
      data() {
        return new Uint8Array(this.inner.data);
      }
      gasLimit() {
        return this.inner.gasLimit;
      }
      gasPrice() {
        return this.inner.gasPrice();
      }
      gasTipCap() {
        return this.inner.gasTipCap;
      }
      gasFeeCap() {
        return this.inner.gasFeeCap;
      }
      value() {
        return this.inner.value;
      }
      cost() {
        return this.inner.cost();
      }
      hash() {
        return this.inner.hash();
      }
      serialize() {
        return this.inner.serialize();
      }
      isContractCreation() {
        return this.inner.isContractCreation();
      }
    };
    exports2.QRLTransaction = QRLTransaction;
  }
});

// packages/tx/dist/cjs/qrl/types.js
var require_types2 = __commonJS({
  "packages/tx/dist/cjs/qrl/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// packages/tx/dist/cjs/qrl/index.js
var require_qrl2 = __commonJS({
  "packages/tx/dist/cjs/qrl/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: /* @__PURE__ */ __name(function() {
          return m[k];
        }, "get") };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_access(), exports2);
    __exportStar(require_constants3(), exports2);
    __exportStar(require_constructors(), exports2);
    __exportStar(require_dynamicFee(), exports2);
    __exportStar(require_signing(), exports2);
    __exportStar(require_transaction(), exports2);
    __exportStar(require_types2(), exports2);
  }
});

// packages/tx/dist/cjs/index.js
var require_cjs4 = __commonJS({
  "packages/tx/dist/cjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.qrl = void 0;
    exports2.qrl = require_qrl2();
  }
});

// packages/block/dist/cjs/qrl/roots.js
var require_roots = __commonJS({
  "packages/block/dist/cjs/qrl/roots.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.genQRLTransactionsRoot = genQRLTransactionsRoot;
    exports2.genQRLReceiptsRoot = genQRLReceiptsRoot;
    var mpt_1 = require_cjs3();
    var rlp_1 = require_cjs();
    var tx_1 = require_cjs4();
    var util_1 = require_cjs2();
    var utils_ts_1 = require_utils();
    async function genQRLTransactionsRoot(transactions) {
      return genQRLTrieRoot(transactions.map((tx) => tx.serialize()));
    }
    __name(genQRLTransactionsRoot, "genQRLTransactionsRoot");
    async function genQRLReceiptsRoot(receipts) {
      return genQRLTrieRoot(receipts.map(encodeQRLReceiptForRoot));
    }
    __name(genQRLReceiptsRoot, "genQRLReceiptsRoot");
    async function genQRLTrieRoot(values) {
      if (values.length === 0) {
        return (0, utils_ts_1.qrlEmptyRootHash)();
      }
      const trie = new mpt_1.MerklePatriciaTrie();
      for (const [index, value] of values.entries()) {
        await trie.put(rlp_1.RLP.encode(index), value);
      }
      return trie.root();
    }
    __name(genQRLTrieRoot, "genQRLTrieRoot");
    function encodeQRLReceiptForRoot(receipt) {
      return (0, util_1.concatBytes)(new Uint8Array([tx_1.qrl.QRL_DYNAMIC_FEE_TX_TYPE]), rlp_1.RLP.encode([
        receipt.status === 1 ? new Uint8Array([1]) : new Uint8Array(0),
        (0, utils_ts_1.bigintToRLP)(receipt.cumulativeGasUsed),
        receipt.logsBloom,
        receipt.logs.map(encodeQRLLogForRoot)
      ]));
    }
    __name(encodeQRLReceiptForRoot, "encodeQRLReceiptForRoot");
    function encodeQRLLogForRoot(log) {
      return [log.address.toBytes(), log.topics.map((topic) => new Uint8Array(topic)), log.data];
    }
    __name(encodeQRLLogForRoot, "encodeQRLLogForRoot");
  }
});

// packages/block/dist/cjs/qrl/index.js
var require_qrl3 = __commonJS({
  "packages/block/dist/cjs/qrl/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: /* @__PURE__ */ __name(function() {
          return m[k];
        }, "get") };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_block(), exports2);
    __exportStar(require_bloom(), exports2);
    __exportStar(require_constants(), exports2);
    __exportStar(require_errors3(), exports2);
    __exportStar(require_header(), exports2);
    __exportStar(require_log(), exports2);
    __exportStar(require_receipt(), exports2);
    __exportStar(require_roots(), exports2);
  }
});

// packages/block/dist/cjs/index.js
var require_cjs5 = __commonJS({
  "packages/block/dist/cjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.qrl = void 0;
    exports2.qrl = require_qrl3();
  }
});

// packages/evm/dist/cjs/qrl/errors.js
var require_errors4 = __commonJS({
  "packages/evm/dist/cjs/qrl/errors.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLVMRevert = exports2.QRLVMError = void 0;
    var QRLVMError = class extends Error {
      static {
        __name(this, "QRLVMError");
      }
      constructor(message) {
        super(message);
        this.name = "QRLVMError";
      }
    };
    exports2.QRLVMError = QRLVMError;
    var QRLVMRevert = class extends QRLVMError {
      static {
        __name(this, "QRLVMRevert");
      }
      constructor(returnValue) {
        super("QRL execution reverted");
        this.returnValue = new Uint8Array(returnValue);
      }
    };
    exports2.QRLVMRevert = QRLVMRevert;
  }
});

// packages/statemanager/dist/cjs/qrl/constants.js
var require_constants4 = __commonJS({
  "packages/statemanager/dist/cjs/qrl/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRL_EMPTY_CODE_HASH = exports2.QRL_EMPTY_ROOT_HASH = exports2.QRL_STATE_HASH_BYTES = exports2.QRL_STORAGE_VALUE_BYTES = exports2.QRL_STORAGE_KEY_BYTES = exports2.QRL_STATE_NONCE_MAX = void 0;
    var util_1 = require_cjs2();
    exports2.QRL_STATE_NONCE_MAX = 2n ** 64n - 1n;
    exports2.QRL_STORAGE_KEY_BYTES = 32;
    exports2.QRL_STORAGE_VALUE_BYTES = 64;
    exports2.QRL_STATE_HASH_BYTES = 32;
    exports2.QRL_EMPTY_ROOT_HASH = (0, util_1.hexToBytes)("0x56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421");
    exports2.QRL_EMPTY_CODE_HASH = (0, util_1.hexToBytes)("0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470");
  }
});

// packages/statemanager/dist/cjs/qrl/account.js
var require_account = __commonJS({
  "packages/statemanager/dist/cjs/qrl/account.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLAccount = void 0;
    exports2.normalizeNonce = normalizeNonce;
    exports2.normalizeBalance = normalizeBalance;
    var util_1 = require_cjs2();
    var constants_ts_1 = require_constants4();
    var QRLAccount = class _QRLAccount {
      static {
        __name(this, "QRLAccount");
      }
      constructor(data = {}) {
        const nonce = normalizeNonce(data.nonce ?? 0n);
        const balance = normalizeBalance(data.balance ?? 0n);
        const storageRoot = data.storageRoot ?? constants_ts_1.QRL_EMPTY_ROOT_HASH;
        const codeHash = data.codeHash ?? constants_ts_1.QRL_EMPTY_CODE_HASH;
        assertStateHash("storageRoot", storageRoot);
        assertStateHash("codeHash", codeHash);
        this.nonce = nonce;
        this.balance = balance;
        this._storageRoot = new Uint8Array(storageRoot);
        this._codeHash = new Uint8Array(codeHash);
        Object.freeze(this);
      }
      static empty() {
        return new _QRLAccount();
      }
      get storageRoot() {
        return new Uint8Array(this._storageRoot);
      }
      get codeHash() {
        return new Uint8Array(this._codeHash);
      }
      isEmpty() {
        return this.nonce === 0n && this.balance === 0n && (0, util_1.equalsBytes)(this._codeHash, constants_ts_1.QRL_EMPTY_CODE_HASH);
      }
      clone() {
        return new _QRLAccount({
          nonce: this.nonce,
          balance: this.balance,
          storageRoot: this._storageRoot,
          codeHash: this._codeHash
        });
      }
      with(data) {
        return new _QRLAccount({
          nonce: data.nonce ?? this.nonce,
          balance: data.balance ?? this.balance,
          storageRoot: data.storageRoot ?? this._storageRoot,
          codeHash: data.codeHash ?? this._codeHash
        });
      }
    };
    exports2.QRLAccount = QRLAccount;
    function normalizeNonce(nonce) {
      const value = typeof nonce === "number" ? BigInt(nonce) : nonce;
      if (typeof value !== "bigint" || value < 0n || value > constants_ts_1.QRL_STATE_NONCE_MAX) {
        throw (0, util_1.QRLJSErrorWithoutCode)(`Invalid QRL account nonce=${nonce.toString()}`);
      }
      return value;
    }
    __name(normalizeNonce, "normalizeNonce");
    function normalizeBalance(balance) {
      if (typeof balance !== "bigint" || balance < 0n) {
        throw (0, util_1.QRLJSErrorWithoutCode)(`Invalid QRL account balance=${balance.toString()}`);
      }
      return balance;
    }
    __name(normalizeBalance, "normalizeBalance");
    function assertStateHash(name, value) {
      if (!(value instanceof Uint8Array)) {
        throw (0, util_1.QRLJSErrorWithoutCode)(`QRL account ${name} must be Uint8Array`);
      }
      if (value.length !== constants_ts_1.QRL_STATE_HASH_BYTES) {
        throw (0, util_1.QRLJSErrorWithoutCode)(`Invalid QRL account ${name} length=${value.length}`);
      }
    }
    __name(assertStateHash, "assertStateHash");
  }
});

// packages/statemanager/dist/cjs/qrl/genesis.js
var require_genesis = __commonJS({
  "packages/statemanager/dist/cjs/qrl/genesis.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.applyQRLGenesisState = applyQRLGenesisState;
    async function applyQRLGenesisState(stateManager, genesis) {
      await stateManager.applyGenesisState(genesis);
    }
    __name(applyQRLGenesisState, "applyQRLGenesisState");
  }
});

// packages/statemanager/node_modules/@noble/hashes/_u64.js
function fromBig5(n, le = false) {
  if (le)
    return { h: Number(n & U32_MASK645), l: Number(n >> _32n5 & U32_MASK645) };
  return { h: Number(n >> _32n5 & U32_MASK645) | 0, l: Number(n & U32_MASK645) | 0 };
}
function split5(lst, le = false) {
  const len = lst.length;
  let Ah = new Uint32Array(len);
  let Al = new Uint32Array(len);
  for (let i = 0; i < len; i++) {
    const { h, l } = fromBig5(lst[i], le);
    [Ah[i], Al[i]] = [h, l];
  }
  return [Ah, Al];
}
var U32_MASK645, _32n5, rotlSH5, rotlSL5, rotlBH5, rotlBL5;
var init_u645 = __esm({
  "packages/statemanager/node_modules/@noble/hashes/_u64.js"() {
    U32_MASK645 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
    _32n5 = /* @__PURE__ */ BigInt(32);
    __name(fromBig5, "fromBig");
    __name(split5, "split");
    rotlSH5 = /* @__PURE__ */ __name((h, l, s) => h << s | l >>> 32 - s, "rotlSH");
    rotlSL5 = /* @__PURE__ */ __name((h, l, s) => l << s | h >>> 32 - s, "rotlSL");
    rotlBH5 = /* @__PURE__ */ __name((h, l, s) => l << s - 32 | h >>> 64 - s, "rotlBH");
    rotlBL5 = /* @__PURE__ */ __name((h, l, s) => h << s - 32 | l >>> 64 - s, "rotlBL");
  }
});

// packages/statemanager/node_modules/@noble/hashes/utils.js
function isBytes5(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function anumber5(n, title = "") {
  if (!Number.isSafeInteger(n) || n < 0) {
    const prefix = title && `"${title}" `;
    throw new Error(`${prefix}expected integer >= 0, got ${n}`);
  }
}
function abytes5(value, length, title = "") {
  const bytes = isBytes5(value);
  const len = value?.length;
  const needsLen = length !== void 0;
  if (!bytes || needsLen && len !== length) {
    const prefix = title && `"${title}" `;
    const ofLen = needsLen ? ` of length ${length}` : "";
    const got = bytes ? `length=${len}` : `type=${typeof value}`;
    throw new Error(prefix + "expected Uint8Array" + ofLen + ", got " + got);
  }
  return value;
}
function aexists5(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput5(out, instance) {
  abytes5(out, void 0, "digestInto() output");
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error('"digestInto() output" expected to be of length >=' + min);
  }
}
function u325(arr) {
  return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
function clean5(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function byteSwap5(word) {
  return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
}
function byteSwap325(arr) {
  for (let i = 0; i < arr.length; i++) {
    arr[i] = byteSwap5(arr[i]);
  }
  return arr;
}
function createHasher5(hashCons, info = {}) {
  const hashC = /* @__PURE__ */ __name((msg, opts) => hashCons(opts).update(msg).digest(), "hashC");
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var isLE5, swap32IfBE5, oidNist5;
var init_utils5 = __esm({
  "packages/statemanager/node_modules/@noble/hashes/utils.js"() {
    __name(isBytes5, "isBytes");
    __name(anumber5, "anumber");
    __name(abytes5, "abytes");
    __name(aexists5, "aexists");
    __name(aoutput5, "aoutput");
    __name(u325, "u32");
    __name(clean5, "clean");
    isLE5 = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
    __name(byteSwap5, "byteSwap");
    __name(byteSwap325, "byteSwap32");
    swap32IfBE5 = isLE5 ? (u) => u : byteSwap325;
    __name(createHasher5, "createHasher");
    oidNist5 = /* @__PURE__ */ __name((suffix) => ({
      oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
    }), "oidNist");
  }
});

// packages/statemanager/node_modules/@noble/hashes/sha3.js
var sha3_exports5 = {};
__export(sha3_exports5, {
  Keccak: () => Keccak5,
  keccakP: () => keccakP5,
  keccak_224: () => keccak_2245,
  keccak_256: () => keccak_2565,
  keccak_384: () => keccak_3845,
  keccak_512: () => keccak_5125,
  sha3_224: () => sha3_2245,
  sha3_256: () => sha3_2565,
  sha3_384: () => sha3_3845,
  sha3_512: () => sha3_5125,
  shake128: () => shake1285,
  shake128_32: () => shake128_325,
  shake256: () => shake2565,
  shake256_64: () => shake256_645
});
function keccakP5(s, rounds = 24) {
  const B = new Uint32Array(5 * 2);
  for (let round = 24 - rounds; round < 24; round++) {
    for (let x = 0; x < 10; x++)
      B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
    for (let x = 0; x < 10; x += 2) {
      const idx1 = (x + 8) % 10;
      const idx0 = (x + 2) % 10;
      const B0 = B[idx0];
      const B1 = B[idx0 + 1];
      const Th = rotlH5(B0, B1, 1) ^ B[idx1];
      const Tl = rotlL5(B0, B1, 1) ^ B[idx1 + 1];
      for (let y = 0; y < 50; y += 10) {
        s[x + y] ^= Th;
        s[x + y + 1] ^= Tl;
      }
    }
    let curH = s[2];
    let curL = s[3];
    for (let t = 0; t < 24; t++) {
      const shift = SHA3_ROTL5[t];
      const Th = rotlH5(curH, curL, shift);
      const Tl = rotlL5(curH, curL, shift);
      const PI = SHA3_PI5[t];
      curH = s[PI];
      curL = s[PI + 1];
      s[PI] = Th;
      s[PI + 1] = Tl;
    }
    for (let y = 0; y < 50; y += 10) {
      for (let x = 0; x < 10; x++)
        B[x] = s[y + x];
      for (let x = 0; x < 10; x++)
        s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
    }
    s[0] ^= SHA3_IOTA_H5[round];
    s[1] ^= SHA3_IOTA_L5[round];
  }
  clean5(B);
}
var _0n5, _1n5, _2n5, _7n5, _256n5, _0x71n5, SHA3_PI5, SHA3_ROTL5, _SHA3_IOTA5, IOTAS5, SHA3_IOTA_H5, SHA3_IOTA_L5, rotlH5, rotlL5, Keccak5, genKeccak5, sha3_2245, sha3_2565, sha3_3845, sha3_5125, keccak_2245, keccak_2565, keccak_3845, keccak_5125, genShake5, shake1285, shake2565, shake128_325, shake256_645;
var init_sha35 = __esm({
  "packages/statemanager/node_modules/@noble/hashes/sha3.js"() {
    init_u645();
    init_utils5();
    _0n5 = BigInt(0);
    _1n5 = BigInt(1);
    _2n5 = BigInt(2);
    _7n5 = BigInt(7);
    _256n5 = BigInt(256);
    _0x71n5 = BigInt(113);
    SHA3_PI5 = [];
    SHA3_ROTL5 = [];
    _SHA3_IOTA5 = [];
    for (let round = 0, R = _1n5, x = 1, y = 0; round < 24; round++) {
      [x, y] = [y, (2 * x + 3 * y) % 5];
      SHA3_PI5.push(2 * (5 * y + x));
      SHA3_ROTL5.push((round + 1) * (round + 2) / 2 % 64);
      let t = _0n5;
      for (let j = 0; j < 7; j++) {
        R = (R << _1n5 ^ (R >> _7n5) * _0x71n5) % _256n5;
        if (R & _2n5)
          t ^= _1n5 << (_1n5 << BigInt(j)) - _1n5;
      }
      _SHA3_IOTA5.push(t);
    }
    IOTAS5 = split5(_SHA3_IOTA5, true);
    SHA3_IOTA_H5 = IOTAS5[0];
    SHA3_IOTA_L5 = IOTAS5[1];
    rotlH5 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBH5(h, l, s) : rotlSH5(h, l, s), "rotlH");
    rotlL5 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBL5(h, l, s) : rotlSL5(h, l, s), "rotlL");
    __name(keccakP5, "keccakP");
    Keccak5 = class _Keccak {
      static {
        __name(this, "Keccak");
      }
      state;
      pos = 0;
      posOut = 0;
      finished = false;
      state32;
      destroyed = false;
      blockLen;
      suffix;
      outputLen;
      enableXOF = false;
      rounds;
      // NOTE: we accept arguments in bytes instead of bits here.
      constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
        this.blockLen = blockLen;
        this.suffix = suffix;
        this.outputLen = outputLen;
        this.enableXOF = enableXOF;
        this.rounds = rounds;
        anumber5(outputLen, "outputLen");
        if (!(0 < blockLen && blockLen < 200))
          throw new Error("only keccak-f1600 function is supported");
        this.state = new Uint8Array(200);
        this.state32 = u325(this.state);
      }
      clone() {
        return this._cloneInto();
      }
      keccak() {
        swap32IfBE5(this.state32);
        keccakP5(this.state32, this.rounds);
        swap32IfBE5(this.state32);
        this.posOut = 0;
        this.pos = 0;
      }
      update(data) {
        aexists5(this);
        abytes5(data);
        const { blockLen, state } = this;
        const len = data.length;
        for (let pos = 0; pos < len; ) {
          const take = Math.min(blockLen - this.pos, len - pos);
          for (let i = 0; i < take; i++)
            state[this.pos++] ^= data[pos++];
          if (this.pos === blockLen)
            this.keccak();
        }
        return this;
      }
      finish() {
        if (this.finished)
          return;
        this.finished = true;
        const { state, suffix, pos, blockLen } = this;
        state[pos] ^= suffix;
        if ((suffix & 128) !== 0 && pos === blockLen - 1)
          this.keccak();
        state[blockLen - 1] ^= 128;
        this.keccak();
      }
      writeInto(out) {
        aexists5(this, false);
        abytes5(out);
        this.finish();
        const bufferOut = this.state;
        const { blockLen } = this;
        for (let pos = 0, len = out.length; pos < len; ) {
          if (this.posOut >= blockLen)
            this.keccak();
          const take = Math.min(blockLen - this.posOut, len - pos);
          out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
          this.posOut += take;
          pos += take;
        }
        return out;
      }
      xofInto(out) {
        if (!this.enableXOF)
          throw new Error("XOF is not possible for this instance");
        return this.writeInto(out);
      }
      xof(bytes) {
        anumber5(bytes);
        return this.xofInto(new Uint8Array(bytes));
      }
      digestInto(out) {
        aoutput5(out, this);
        if (this.finished)
          throw new Error("digest() was already called");
        this.writeInto(out);
        this.destroy();
        return out;
      }
      digest() {
        return this.digestInto(new Uint8Array(this.outputLen));
      }
      destroy() {
        this.destroyed = true;
        clean5(this.state);
      }
      _cloneInto(to) {
        const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
        to ||= new _Keccak(blockLen, suffix, outputLen, enableXOF, rounds);
        to.state32.set(this.state32);
        to.pos = this.pos;
        to.posOut = this.posOut;
        to.finished = this.finished;
        to.rounds = rounds;
        to.suffix = suffix;
        to.outputLen = outputLen;
        to.enableXOF = enableXOF;
        to.destroyed = this.destroyed;
        return to;
      }
    };
    genKeccak5 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher5(() => new Keccak5(blockLen, suffix, outputLen), info), "genKeccak");
    sha3_2245 = /* @__PURE__ */ genKeccak5(
      6,
      144,
      28,
      /* @__PURE__ */ oidNist5(7)
    );
    sha3_2565 = /* @__PURE__ */ genKeccak5(
      6,
      136,
      32,
      /* @__PURE__ */ oidNist5(8)
    );
    sha3_3845 = /* @__PURE__ */ genKeccak5(
      6,
      104,
      48,
      /* @__PURE__ */ oidNist5(9)
    );
    sha3_5125 = /* @__PURE__ */ genKeccak5(
      6,
      72,
      64,
      /* @__PURE__ */ oidNist5(10)
    );
    keccak_2245 = /* @__PURE__ */ genKeccak5(1, 144, 28);
    keccak_2565 = /* @__PURE__ */ genKeccak5(1, 136, 32);
    keccak_3845 = /* @__PURE__ */ genKeccak5(1, 104, 48);
    keccak_5125 = /* @__PURE__ */ genKeccak5(1, 72, 64);
    genShake5 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher5((opts = {}) => new Keccak5(blockLen, suffix, opts.dkLen === void 0 ? outputLen : opts.dkLen, true), info), "genShake");
    shake1285 = /* @__PURE__ */ genShake5(31, 168, 16, /* @__PURE__ */ oidNist5(11));
    shake2565 = /* @__PURE__ */ genShake5(31, 136, 32, /* @__PURE__ */ oidNist5(12));
    shake128_325 = /* @__PURE__ */ genShake5(31, 168, 32, /* @__PURE__ */ oidNist5(11));
    shake256_645 = /* @__PURE__ */ genShake5(31, 136, 64, /* @__PURE__ */ oidNist5(12));
  }
});

// packages/statemanager/dist/cjs/qrl/storage.js
var require_storage = __commonJS({
  "packages/statemanager/dist/cjs/qrl/storage.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.assertQRLStorageKey = assertQRLStorageKey;
    exports2.assertQRLStorageValue = assertQRLStorageValue;
    exports2.cloneQRLStorageValue = cloneQRLStorageValue;
    exports2.emptyQRLStorageValue = emptyQRLStorageValue;
    exports2.isEmptyQRLStorageValue = isEmptyQRLStorageValue;
    var util_1 = require_cjs2();
    var constants_ts_1 = require_constants4();
    function assertQRLStorageKey(key) {
      if (!(key instanceof Uint8Array)) {
        throw (0, util_1.QRLJSErrorWithoutCode)("QRL storage key must be Uint8Array");
      }
      if (key.length !== constants_ts_1.QRL_STORAGE_KEY_BYTES) {
        throw (0, util_1.QRLJSErrorWithoutCode)(`Invalid QRL storage key length=${key.length}`);
      }
    }
    __name(assertQRLStorageKey, "assertQRLStorageKey");
    function assertQRLStorageValue(value) {
      if (!(value instanceof Uint8Array)) {
        throw (0, util_1.QRLJSErrorWithoutCode)("QRL storage value must be Uint8Array");
      }
      if (value.length !== constants_ts_1.QRL_STORAGE_VALUE_BYTES) {
        throw (0, util_1.QRLJSErrorWithoutCode)(`Invalid QRL storage value length=${value.length}`);
      }
    }
    __name(assertQRLStorageValue, "assertQRLStorageValue");
    function cloneQRLStorageValue(value) {
      assertQRLStorageValue(value);
      return new Uint8Array(value);
    }
    __name(cloneQRLStorageValue, "cloneQRLStorageValue");
    function emptyQRLStorageValue() {
      return new Uint8Array(constants_ts_1.QRL_STORAGE_VALUE_BYTES);
    }
    __name(emptyQRLStorageValue, "emptyQRLStorageValue");
    function isEmptyQRLStorageValue(value) {
      assertQRLStorageValue(value);
      return (0, util_1.equalsBytes)(value, emptyQRLStorageValue());
    }
    __name(isEmptyQRLStorageValue, "isEmptyQRLStorageValue");
  }
});

// packages/statemanager/dist/cjs/qrl/stateManager.js
var require_stateManager = __commonJS({
  "packages/statemanager/dist/cjs/qrl/stateManager.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLStateManager = void 0;
    var sha3_js_1 = (init_sha35(), __toCommonJS(sha3_exports5));
    var mpt_1 = require_cjs3();
    var rlp_1 = require_cjs();
    var util_1 = require_cjs2();
    var account_ts_1 = require_account();
    var storage_ts_1 = require_storage();
    var QRLStateManager = class _QRLStateManager {
      static {
        __name(this, "QRLStateManager");
      }
      constructor(options = {}) {
        this.stack = [emptyLayer()];
        if (options.genesis !== void 0) {
          this.applyGenesisStateSync(options.genesis);
        }
      }
      async applyGenesisState(genesis) {
        this.applyGenesisStateSync(genesis);
      }
      async getAccount(address) {
        return this.getAccountSync(address)?.clone();
      }
      async putAccount(address, account) {
        this.putAccountSync(address, account);
      }
      async deleteAccount(address) {
        const key = addressKey(address);
        this.topLayer().accounts.set(key, void 0);
        this.topLayer().code.delete(key);
        this.topLayer().storage.delete(key);
      }
      async accountExists(address) {
        return this.getAccountSync(address) !== void 0;
      }
      async getNonce(address) {
        return this.getAccountSync(address)?.nonce ?? 0n;
      }
      async setNonce(address, nonce) {
        const account = this.getOrCreateAccount(address);
        this.putAccountSync(address, account.with({ nonce: (0, account_ts_1.normalizeNonce)(nonce) }));
      }
      async incrementNonce(address) {
        const nonce = await this.getNonce(address);
        await this.setNonce(address, nonce + 1n);
      }
      async getBalance(address) {
        return this.getAccountSync(address)?.balance ?? 0n;
      }
      async setBalance(address, balance) {
        const account = this.getOrCreateAccount(address);
        this.putAccountSync(address, account.with({ balance: (0, account_ts_1.normalizeBalance)(balance) }));
      }
      async addBalance(address, amount) {
        const balance = (0, account_ts_1.normalizeBalance)(amount);
        await this.setBalance(address, await this.getBalance(address) + balance);
      }
      async subBalance(address, amount) {
        const balance = (0, account_ts_1.normalizeBalance)(amount);
        const current = await this.getBalance(address);
        if (balance > current) {
          throw (0, util_1.QRLJSErrorWithoutCode)("QRL account balance underflow");
        }
        await this.setBalance(address, current - balance);
      }
      async getCode(address) {
        return new Uint8Array(this.topLayer().code.get(addressKey(address)) ?? new Uint8Array(0));
      }
      async putCode(address, code) {
        const key = addressKey(address);
        const codeCopy = new Uint8Array(code);
        this.topLayer().code.set(key, codeCopy);
        this.putAccountSync(address, this.getOrCreateAccount(address).with({ codeHash: (0, sha3_js_1.keccak_256)(codeCopy) }));
      }
      async getCodeSize(address) {
        return (await this.getCode(address)).length;
      }
      async getStorage(address, key) {
        (0, storage_ts_1.assertQRLStorageKey)(key);
        const accountStorage = this.topLayer().storage.get(addressKey(address));
        return new Uint8Array(accountStorage?.get(storageKey(key)) ?? (0, storage_ts_1.emptyQRLStorageValue)());
      }
      async putStorage(address, key, value) {
        (0, storage_ts_1.assertQRLStorageKey)(key);
        (0, storage_ts_1.assertQRLStorageValue)(value);
        const accountKey = addressKey(address);
        const top = this.topLayer();
        const accountStorage = top.storage.get(accountKey) ?? /* @__PURE__ */ new Map();
        accountStorage.set(storageKey(key), new Uint8Array(value));
        top.storage.set(accountKey, accountStorage);
        if (this.getAccountSync(address) === void 0) {
          this.putAccountSync(address, account_ts_1.QRLAccount.empty());
        }
      }
      async clearStorage(address) {
        this.topLayer().storage.delete(addressKey(address));
      }
      async getStateRoot() {
        const trie = new mpt_1.MerklePatriciaTrie();
        const layer = this.topLayer();
        for (const [addressHex, account] of [...layer.accounts.entries()].sort(([left], [right]) => left.localeCompare(right))) {
          if (account === void 0) {
            continue;
          }
          const address = util_1.qrl.QRLAddress.fromHex(addressHex);
          const storageRoot = await this.getAccountStorageRoot(address);
          const stateAccount = account.with({ storageRoot });
          await trie.put((0, util_1.hexToBytes)(addressHex), encodeStateAccount(stateAccount));
        }
        return trie.root();
      }
      async getAccountStorageRoot(address) {
        const trie = new mpt_1.MerklePatriciaTrie();
        const accountStorage = this.topLayer().storage.get(addressKey(address));
        if (accountStorage === void 0) {
          return trie.root();
        }
        for (const [key, value] of [...accountStorage.entries()].sort(([left], [right]) => left.localeCompare(right))) {
          if (!(0, storage_ts_1.isEmptyQRLStorageValue)(value)) {
            await trie.put((0, util_1.hexToBytes)(key), value);
          }
        }
        return trie.root();
      }
      async checkpoint() {
        this.stack.push(copyLayer(this.topLayer()));
      }
      async commit() {
        if (this.stack.length <= 1) {
          throw (0, util_1.QRLJSErrorWithoutCode)("Cannot commit without an active QRL state checkpoint");
        }
        this.stack.splice(-2, 1);
      }
      async revert() {
        if (this.stack.length <= 1) {
          throw (0, util_1.QRLJSErrorWithoutCode)("Cannot revert without an active QRL state checkpoint");
        }
        this.stack.pop();
      }
      shallowCopy() {
        const copy = new _QRLStateManager();
        copy.stack.length = 0;
        for (const layer of this.stack) {
          copy.stack.push(copyLayer(layer));
        }
        return copy;
      }
      getAccountSync(address) {
        return this.topLayer().accounts.get(addressKey(address));
      }
      putAccountSync(address, account) {
        this.topLayer().accounts.set(addressKey(address), account.clone());
      }
      getOrCreateAccount(address) {
        return this.getAccountSync(address) ?? account_ts_1.QRLAccount.empty();
      }
      topLayer() {
        return this.stack[this.stack.length - 1];
      }
      applyGenesisStateSync(genesis) {
        for (const [addressInput, account] of Object.entries(genesis)) {
          const address = util_1.qrl.QRLAddress.fromString(addressInput);
          const balance = account.balance === void 0 ? 0n : parseGenesisBigInt(account.balance);
          const nonce = account.nonce ?? 0n;
          this.putAccountSync(address, new account_ts_1.QRLAccount({ balance, nonce }));
          if (account.code !== void 0) {
            const code = parseGenesisBytes(account.code);
            this.topLayer().code.set(addressKey(address), code);
            this.putAccountSync(address, this.getOrCreateAccount(address).with({ codeHash: (0, sha3_js_1.keccak_256)(code) }));
          }
          for (const [key, value] of Object.entries(account.storage ?? {})) {
            const storageKeyBytes = parseGenesisBytes(key);
            const storageValueBytes = parseGenesisBytes(value);
            (0, storage_ts_1.assertQRLStorageKey)(storageKeyBytes);
            (0, storage_ts_1.assertQRLStorageValue)(storageValueBytes);
            const accountStorage = this.topLayer().storage.get(addressKey(address)) ?? /* @__PURE__ */ new Map();
            accountStorage.set(storageKey(storageKeyBytes), storageValueBytes);
            this.topLayer().storage.set(addressKey(address), accountStorage);
          }
        }
      }
    };
    exports2.QRLStateManager = QRLStateManager;
    function emptyLayer() {
      return {
        accounts: /* @__PURE__ */ new Map(),
        code: /* @__PURE__ */ new Map(),
        storage: /* @__PURE__ */ new Map()
      };
    }
    __name(emptyLayer, "emptyLayer");
    function copyLayer(layer) {
      const storage = /* @__PURE__ */ new Map();
      for (const [address, accountStorage] of layer.storage) {
        const storageCopy = /* @__PURE__ */ new Map();
        for (const [key, value] of accountStorage) {
          storageCopy.set(key, new Uint8Array(value));
        }
        storage.set(address, storageCopy);
      }
      const code = /* @__PURE__ */ new Map();
      for (const [address, value] of layer.code) {
        code.set(address, new Uint8Array(value));
      }
      const accounts = /* @__PURE__ */ new Map();
      for (const [address, account] of layer.accounts) {
        accounts.set(address, account?.clone());
      }
      return { accounts, code, storage };
    }
    __name(copyLayer, "copyLayer");
    function addressKey(address) {
      return address.toHex();
    }
    __name(addressKey, "addressKey");
    function storageKey(key) {
      return (0, util_1.bytesToHex)(key);
    }
    __name(storageKey, "storageKey");
    function parseGenesisBigInt(value) {
      if (typeof value === "bigint") {
        return (0, account_ts_1.normalizeBalance)(value);
      }
      if (/^0x[0-9a-fA-F]+$/.test(value)) {
        return (0, account_ts_1.normalizeBalance)(BigInt(value));
      }
      if (/^[0-9]+$/.test(value)) {
        return (0, account_ts_1.normalizeBalance)(BigInt(value));
      }
      throw (0, util_1.QRLJSErrorWithoutCode)(`Invalid QRL genesis bigint=${value}`);
    }
    __name(parseGenesisBigInt, "parseGenesisBigInt");
    function parseGenesisBytes(value) {
      if (value instanceof Uint8Array) {
        return new Uint8Array(value);
      }
      if (!/^0x[0-9a-fA-F]*$/.test(value)) {
        throw (0, util_1.QRLJSErrorWithoutCode)(`Invalid QRL genesis hex bytes=${value}`);
      }
      return (0, util_1.hexToBytes)(value);
    }
    __name(parseGenesisBytes, "parseGenesisBytes");
    function encodeStateAccount(account) {
      return rlp_1.RLP.encode([
        (0, util_1.bigIntToUnpaddedBytes)(account.nonce),
        (0, util_1.bigIntToUnpaddedBytes)(account.balance),
        account.storageRoot,
        account.codeHash
      ]);
    }
    __name(encodeStateAccount, "encodeStateAccount");
  }
});

// packages/statemanager/dist/cjs/qrl/index.js
var require_qrl4 = __commonJS({
  "packages/statemanager/dist/cjs/qrl/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: /* @__PURE__ */ __name(function() {
          return m[k];
        }, "get") };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_account(), exports2);
    __exportStar(require_constants4(), exports2);
    __exportStar(require_genesis(), exports2);
    __exportStar(require_stateManager(), exports2);
    __exportStar(require_storage(), exports2);
  }
});

// packages/statemanager/dist/cjs/index.js
var require_cjs6 = __commonJS({
  "packages/statemanager/dist/cjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.qrl = void 0;
    exports2.qrl = require_qrl4();
  }
});

// node_modules/@noble/hashes/_u64.js
function fromBig6(n, le = false) {
  if (le)
    return { h: Number(n & U32_MASK646), l: Number(n >> _32n6 & U32_MASK646) };
  return { h: Number(n >> _32n6 & U32_MASK646) | 0, l: Number(n & U32_MASK646) | 0 };
}
function split6(lst, le = false) {
  const len = lst.length;
  let Ah = new Uint32Array(len);
  let Al = new Uint32Array(len);
  for (let i = 0; i < len; i++) {
    const { h, l } = fromBig6(lst[i], le);
    [Ah[i], Al[i]] = [h, l];
  }
  return [Ah, Al];
}
function add(Ah, Al, Bh, Bl) {
  const l = (Al >>> 0) + (Bl >>> 0);
  return { h: Ah + Bh + (l / 2 ** 32 | 0) | 0, l: l | 0 };
}
var U32_MASK646, _32n6, shrSH, shrSL, rotrSH, rotrSL, rotrBH, rotrBL, rotlSH6, rotlSL6, rotlBH6, rotlBL6, add3L, add3H, add4L, add4H, add5L, add5H;
var init_u646 = __esm({
  "node_modules/@noble/hashes/_u64.js"() {
    U32_MASK646 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
    _32n6 = /* @__PURE__ */ BigInt(32);
    __name(fromBig6, "fromBig");
    __name(split6, "split");
    shrSH = /* @__PURE__ */ __name((h, _l, s) => h >>> s, "shrSH");
    shrSL = /* @__PURE__ */ __name((h, l, s) => h << 32 - s | l >>> s, "shrSL");
    rotrSH = /* @__PURE__ */ __name((h, l, s) => h >>> s | l << 32 - s, "rotrSH");
    rotrSL = /* @__PURE__ */ __name((h, l, s) => h << 32 - s | l >>> s, "rotrSL");
    rotrBH = /* @__PURE__ */ __name((h, l, s) => h << 64 - s | l >>> s - 32, "rotrBH");
    rotrBL = /* @__PURE__ */ __name((h, l, s) => h >>> s - 32 | l << 64 - s, "rotrBL");
    rotlSH6 = /* @__PURE__ */ __name((h, l, s) => h << s | l >>> 32 - s, "rotlSH");
    rotlSL6 = /* @__PURE__ */ __name((h, l, s) => l << s | h >>> 32 - s, "rotlSL");
    rotlBH6 = /* @__PURE__ */ __name((h, l, s) => l << s - 32 | h >>> 64 - s, "rotlBH");
    rotlBL6 = /* @__PURE__ */ __name((h, l, s) => h << s - 32 | l >>> 64 - s, "rotlBL");
    __name(add, "add");
    add3L = /* @__PURE__ */ __name((Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0), "add3L");
    add3H = /* @__PURE__ */ __name((low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0, "add3H");
    add4L = /* @__PURE__ */ __name((Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0), "add4L");
    add4H = /* @__PURE__ */ __name((low, Ah, Bh, Ch, Dh) => Ah + Bh + Ch + Dh + (low / 2 ** 32 | 0) | 0, "add4H");
    add5L = /* @__PURE__ */ __name((Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0), "add5L");
    add5H = /* @__PURE__ */ __name((low, Ah, Bh, Ch, Dh, Eh) => Ah + Bh + Ch + Dh + Eh + (low / 2 ** 32 | 0) | 0, "add5H");
  }
});

// node_modules/@noble/hashes/utils.js
function isBytes6(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
function anumber6(n, title = "") {
  if (typeof n !== "number") {
    const prefix = title && `"${title}" `;
    throw new TypeError(`${prefix}expected number, got ${typeof n}`);
  }
  if (!Number.isSafeInteger(n) || n < 0) {
    const prefix = title && `"${title}" `;
    throw new RangeError(`${prefix}expected integer >= 0, got ${n}`);
  }
}
function abytes6(value, length, title = "") {
  const bytes = isBytes6(value);
  const len = value?.length;
  const needsLen = length !== void 0;
  if (!bytes || needsLen && len !== length) {
    const prefix = title && `"${title}" `;
    const ofLen = needsLen ? ` of length ${length}` : "";
    const got = bytes ? `length=${len}` : `type=${typeof value}`;
    const message = prefix + "expected Uint8Array" + ofLen + ", got " + got;
    if (!bytes)
      throw new TypeError(message);
    throw new RangeError(message);
  }
  return value;
}
function aexists6(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput6(out, instance) {
  abytes6(out, void 0, "digestInto() output");
  const min = instance.outputLen;
  if (out.length < min) {
    throw new RangeError('"digestInto() output" expected to be of length >=' + min);
  }
}
function u326(arr) {
  return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
function clean6(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView2(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr2(word, shift) {
  return word << 32 - shift | word >>> shift;
}
function byteSwap6(word) {
  return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
}
function byteSwap326(arr) {
  for (let i = 0; i < arr.length; i++) {
    arr[i] = byteSwap6(arr[i]);
  }
  return arr;
}
function createHasher6(hashCons, info = {}) {
  const hashC = /* @__PURE__ */ __name((msg, opts) => hashCons(opts).update(msg).digest(), "hashC");
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.canXOF = tmp.canXOF;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var isLE6, swap32IfBE6, oidNist6;
var init_utils6 = __esm({
  "node_modules/@noble/hashes/utils.js"() {
    __name(isBytes6, "isBytes");
    __name(anumber6, "anumber");
    __name(abytes6, "abytes");
    __name(aexists6, "aexists");
    __name(aoutput6, "aoutput");
    __name(u326, "u32");
    __name(clean6, "clean");
    __name(createView2, "createView");
    __name(rotr2, "rotr");
    isLE6 = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
    __name(byteSwap6, "byteSwap");
    __name(byteSwap326, "byteSwap32");
    swap32IfBE6 = isLE6 ? (u) => u : byteSwap326;
    __name(createHasher6, "createHasher");
    oidNist6 = /* @__PURE__ */ __name((suffix) => ({
      // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
      // Larger suffix values would need base-128 OID encoding and a different length byte.
      oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
    }), "oidNist");
  }
});

// node_modules/@noble/hashes/sha3.js
var sha3_exports6 = {};
__export(sha3_exports6, {
  Keccak: () => Keccak6,
  keccakP: () => keccakP6,
  keccak_224: () => keccak_2246,
  keccak_256: () => keccak_2566,
  keccak_384: () => keccak_3846,
  keccak_512: () => keccak_5126,
  sha3_224: () => sha3_2246,
  sha3_256: () => sha3_2566,
  sha3_384: () => sha3_3846,
  sha3_512: () => sha3_5126,
  shake128: () => shake1286,
  shake128_32: () => shake128_326,
  shake256: () => shake2566,
  shake256_64: () => shake256_646
});
function keccakP6(s, rounds = 24) {
  anumber6(rounds, "rounds");
  if (rounds < 1 || rounds > 24)
    throw new Error('"rounds" expected integer 1..24');
  const B = new Uint32Array(5 * 2);
  for (let round = 24 - rounds; round < 24; round++) {
    for (let x = 0; x < 10; x++)
      B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
    for (let x = 0; x < 10; x += 2) {
      const idx1 = (x + 8) % 10;
      const idx0 = (x + 2) % 10;
      const B0 = B[idx0];
      const B1 = B[idx0 + 1];
      const Th = rotlH6(B0, B1, 1) ^ B[idx1];
      const Tl = rotlL6(B0, B1, 1) ^ B[idx1 + 1];
      for (let y = 0; y < 50; y += 10) {
        s[x + y] ^= Th;
        s[x + y + 1] ^= Tl;
      }
    }
    let curH = s[2];
    let curL = s[3];
    for (let t = 0; t < 24; t++) {
      const shift = SHA3_ROTL6[t];
      const Th = rotlH6(curH, curL, shift);
      const Tl = rotlL6(curH, curL, shift);
      const PI = SHA3_PI6[t];
      curH = s[PI];
      curL = s[PI + 1];
      s[PI] = Th;
      s[PI + 1] = Tl;
    }
    for (let y = 0; y < 50; y += 10) {
      const b0 = s[y], b1 = s[y + 1], b2 = s[y + 2], b3 = s[y + 3];
      s[y] ^= ~s[y + 2] & s[y + 4];
      s[y + 1] ^= ~s[y + 3] & s[y + 5];
      s[y + 2] ^= ~s[y + 4] & s[y + 6];
      s[y + 3] ^= ~s[y + 5] & s[y + 7];
      s[y + 4] ^= ~s[y + 6] & s[y + 8];
      s[y + 5] ^= ~s[y + 7] & s[y + 9];
      s[y + 6] ^= ~s[y + 8] & b0;
      s[y + 7] ^= ~s[y + 9] & b1;
      s[y + 8] ^= ~b0 & b2;
      s[y + 9] ^= ~b1 & b3;
    }
    s[0] ^= SHA3_IOTA_H6[round];
    s[1] ^= SHA3_IOTA_L6[round];
  }
  clean6(B);
}
var _0n6, _1n6, _2n6, _7n6, _256n6, _0x71n6, SHA3_PI6, SHA3_ROTL6, _SHA3_IOTA6, IOTAS6, SHA3_IOTA_H6, SHA3_IOTA_L6, rotlH6, rotlL6, Keccak6, genKeccak6, sha3_2246, sha3_2566, sha3_3846, sha3_5126, keccak_2246, keccak_2566, keccak_3846, keccak_5126, genShake6, shake1286, shake2566, shake128_326, shake256_646;
var init_sha36 = __esm({
  "node_modules/@noble/hashes/sha3.js"() {
    init_u646();
    init_utils6();
    _0n6 = BigInt(0);
    _1n6 = BigInt(1);
    _2n6 = BigInt(2);
    _7n6 = BigInt(7);
    _256n6 = BigInt(256);
    _0x71n6 = BigInt(113);
    SHA3_PI6 = [];
    SHA3_ROTL6 = [];
    _SHA3_IOTA6 = [];
    for (let round = 0, R = _1n6, x = 1, y = 0; round < 24; round++) {
      [x, y] = [y, (2 * x + 3 * y) % 5];
      SHA3_PI6.push(2 * (5 * y + x));
      SHA3_ROTL6.push((round + 1) * (round + 2) / 2 % 64);
      let t = _0n6;
      for (let j = 0; j < 7; j++) {
        R = (R << _1n6 ^ (R >> _7n6) * _0x71n6) % _256n6;
        if (R & _2n6)
          t ^= _1n6 << (_1n6 << BigInt(j)) - _1n6;
      }
      _SHA3_IOTA6.push(t);
    }
    IOTAS6 = split6(_SHA3_IOTA6, true);
    SHA3_IOTA_H6 = IOTAS6[0];
    SHA3_IOTA_L6 = IOTAS6[1];
    rotlH6 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBH6(h, l, s) : rotlSH6(h, l, s), "rotlH");
    rotlL6 = /* @__PURE__ */ __name((h, l, s) => s > 32 ? rotlBL6(h, l, s) : rotlSL6(h, l, s), "rotlL");
    __name(keccakP6, "keccakP");
    Keccak6 = class _Keccak {
      static {
        __name(this, "Keccak");
      }
      state;
      pos = 0;
      posOut = 0;
      finished = false;
      state32;
      destroyed = false;
      blockLen;
      suffix;
      outputLen;
      canXOF;
      enableXOF = false;
      rounds;
      // NOTE: we accept arguments in bytes instead of bits here.
      constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
        this.blockLen = blockLen;
        this.suffix = suffix;
        this.outputLen = outputLen;
        this.enableXOF = enableXOF;
        this.canXOF = enableXOF;
        this.rounds = rounds;
        anumber6(outputLen, "outputLen");
        if (!(0 < blockLen && blockLen < 200))
          throw new Error("only keccak-f1600 function is supported");
        this.state = new Uint8Array(200);
        this.state32 = u326(this.state);
      }
      clone() {
        return this._cloneInto();
      }
      keccak() {
        swap32IfBE6(this.state32);
        keccakP6(this.state32, this.rounds);
        swap32IfBE6(this.state32);
        this.posOut = 0;
        this.pos = 0;
      }
      update(data) {
        aexists6(this);
        abytes6(data);
        const { blockLen, state } = this;
        const len = data.length;
        for (let pos = 0; pos < len; ) {
          const take = Math.min(blockLen - this.pos, len - pos);
          for (let i = 0; i < take; i++)
            state[this.pos++] ^= data[pos++];
          if (this.pos === blockLen)
            this.keccak();
        }
        return this;
      }
      finish() {
        if (this.finished)
          return;
        this.finished = true;
        const { state, suffix, pos, blockLen } = this;
        state[pos] ^= suffix;
        if ((suffix & 128) !== 0 && pos === blockLen - 1)
          this.keccak();
        state[blockLen - 1] ^= 128;
        this.keccak();
      }
      writeInto(out) {
        aexists6(this, false);
        abytes6(out);
        this.finish();
        const bufferOut = this.state;
        const { blockLen } = this;
        for (let pos = 0, len = out.length; pos < len; ) {
          if (this.posOut >= blockLen)
            this.keccak();
          const take = Math.min(blockLen - this.posOut, len - pos);
          out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
          this.posOut += take;
          pos += take;
        }
        return out;
      }
      xofInto(out) {
        if (!this.enableXOF)
          throw new Error("XOF is not possible for this instance");
        return this.writeInto(out);
      }
      xof(bytes) {
        anumber6(bytes);
        return this.xofInto(new Uint8Array(bytes));
      }
      digestInto(out) {
        aoutput6(out, this);
        if (this.finished)
          throw new Error("digest() was already called");
        this.writeInto(out.subarray(0, this.outputLen));
        this.destroy();
      }
      digest() {
        const out = new Uint8Array(this.outputLen);
        this.digestInto(out);
        return out;
      }
      destroy() {
        this.destroyed = true;
        clean6(this.state);
      }
      _cloneInto(to) {
        const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
        to ||= new _Keccak(blockLen, suffix, outputLen, enableXOF, rounds);
        to.blockLen = blockLen;
        to.state32.set(this.state32);
        to.pos = this.pos;
        to.posOut = this.posOut;
        to.finished = this.finished;
        to.rounds = rounds;
        to.suffix = suffix;
        to.outputLen = outputLen;
        to.enableXOF = enableXOF;
        to.canXOF = this.canXOF;
        to.destroyed = this.destroyed;
        return to;
      }
    };
    genKeccak6 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher6(() => new Keccak6(blockLen, suffix, outputLen), info), "genKeccak");
    sha3_2246 = /* @__PURE__ */ genKeccak6(
      6,
      144,
      28,
      /* @__PURE__ */ oidNist6(7)
    );
    sha3_2566 = /* @__PURE__ */ genKeccak6(
      6,
      136,
      32,
      /* @__PURE__ */ oidNist6(8)
    );
    sha3_3846 = /* @__PURE__ */ genKeccak6(
      6,
      104,
      48,
      /* @__PURE__ */ oidNist6(9)
    );
    sha3_5126 = /* @__PURE__ */ genKeccak6(
      6,
      72,
      64,
      /* @__PURE__ */ oidNist6(10)
    );
    keccak_2246 = /* @__PURE__ */ genKeccak6(1, 144, 28);
    keccak_2566 = /* @__PURE__ */ genKeccak6(1, 136, 32);
    keccak_3846 = /* @__PURE__ */ genKeccak6(1, 104, 48);
    keccak_5126 = /* @__PURE__ */ genKeccak6(1, 72, 64);
    genShake6 = /* @__PURE__ */ __name((suffix, blockLen, outputLen, info = {}) => createHasher6((opts = {}) => new Keccak6(blockLen, suffix, opts.dkLen === void 0 ? outputLen : opts.dkLen, true), info), "genShake");
    shake1286 = /* @__PURE__ */ genShake6(31, 168, 16, /* @__PURE__ */ oidNist6(11));
    shake2566 = /* @__PURE__ */ genShake6(31, 136, 32, /* @__PURE__ */ oidNist6(12));
    shake128_326 = /* @__PURE__ */ genShake6(31, 168, 32, /* @__PURE__ */ oidNist6(11));
    shake256_646 = /* @__PURE__ */ genShake6(31, 136, 64, /* @__PURE__ */ oidNist6(12));
  }
});

// packages/evm/dist/cjs/qrl/uint512.js
var require_uint512 = __commonJS({
  "packages/evm/dist/cjs/qrl/uint512.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLUint512 = exports2.QRL_WORD_MAX = exports2.QRL_WORD_MOD = exports2.QRL_WORD_BYTES = exports2.QRL_WORD_BITS = void 0;
    var errors_ts_1 = require_errors4();
    exports2.QRL_WORD_BITS = 512n;
    exports2.QRL_WORD_BYTES = 64;
    exports2.QRL_WORD_MOD = 1n << exports2.QRL_WORD_BITS;
    exports2.QRL_WORD_MAX = exports2.QRL_WORD_MOD - 1n;
    var QRL_SIGN_BIT = 1n << exports2.QRL_WORD_BITS - 1n;
    var QRLUint512 = class _QRLUint512 {
      static {
        __name(this, "QRLUint512");
      }
      constructor(value) {
        this.value = moduloWord(value);
      }
      static zero() {
        return new _QRLUint512(0n);
      }
      static one() {
        return new _QRLUint512(1n);
      }
      static fromBigInt(value) {
        return new _QRLUint512(value);
      }
      static fromBytes(bytes) {
        if (bytes.length > exports2.QRL_WORD_BYTES) {
          throw new errors_ts_1.QRLVMError(`QRL uint512 byte length exceeds 64 bytes: ${bytes.length}`);
        }
        let value = 0n;
        for (const byte of bytes) {
          value = (value << 8n) + BigInt(byte);
        }
        return new _QRLUint512(value);
      }
      toBigInt() {
        return this.value;
      }
      toBytes32() {
        return bigintToBytes(this.value & (1n << 256n) - 1n, 32);
      }
      toBytes64() {
        return bigintToBytes(this.value, exports2.QRL_WORD_BYTES);
      }
      isZero() {
        return this.value === 0n;
      }
      add(other) {
        return new _QRLUint512(this.value + other.value);
      }
      sub(other) {
        return new _QRLUint512(this.value - other.value);
      }
      mul(other) {
        return new _QRLUint512(this.value * other.value);
      }
      div(other) {
        return other.isZero() ? _QRLUint512.zero() : new _QRLUint512(this.value / other.value);
      }
      mod(other) {
        return other.isZero() ? _QRLUint512.zero() : new _QRLUint512(this.value % other.value);
      }
      sdiv(other) {
        const dividend = this.toSignedBigInt();
        const divisor = other.toSignedBigInt();
        if (divisor === 0n) {
          return _QRLUint512.zero();
        }
        const quotient = abs(dividend) / abs(divisor);
        return _QRLUint512.fromBigInt(dividend < 0n !== divisor < 0n ? -quotient : quotient);
      }
      smod(other) {
        const dividend = this.toSignedBigInt();
        const divisor = other.toSignedBigInt();
        if (divisor === 0n) {
          return _QRLUint512.zero();
        }
        const remainder = abs(dividend) % abs(divisor);
        return _QRLUint512.fromBigInt(dividend < 0n ? -remainder : remainder);
      }
      addmod(addend, modulo) {
        return modulo.isZero() ? _QRLUint512.zero() : _QRLUint512.fromBigInt((this.value + addend.value) % modulo.value);
      }
      mulmod(multiplier, modulo) {
        return modulo.isZero() ? _QRLUint512.zero() : _QRLUint512.fromBigInt(this.value * multiplier.value % modulo.value);
      }
      exp(exponent) {
        return new _QRLUint512(modularPow(this.value, exponent.value, exports2.QRL_WORD_MOD));
      }
      lt(other) {
        return this.value < other.value ? _QRLUint512.one() : _QRLUint512.zero();
      }
      gt(other) {
        return this.value > other.value ? _QRLUint512.one() : _QRLUint512.zero();
      }
      slt(other) {
        return this.toSignedBigInt() < other.toSignedBigInt() ? _QRLUint512.one() : _QRLUint512.zero();
      }
      sgt(other) {
        return this.toSignedBigInt() > other.toSignedBigInt() ? _QRLUint512.one() : _QRLUint512.zero();
      }
      eq(other) {
        return this.value === other.value ? _QRLUint512.one() : _QRLUint512.zero();
      }
      byte(index) {
        if (index.value >= BigInt(exports2.QRL_WORD_BYTES)) {
          return _QRLUint512.zero();
        }
        return _QRLUint512.fromBigInt(BigInt(this.toBytes64()[Number(index.value)]));
      }
      signExtend(byteIndex) {
        if (byteIndex.value >= BigInt(exports2.QRL_WORD_BYTES)) {
          return this;
        }
        const bitIndex = (byteIndex.value + 1n) * 8n - 1n;
        const signBit = 1n << bitIndex;
        const mask = signBit - 1n;
        return (this.value & signBit) !== 0n ? new _QRLUint512(this.value | exports2.QRL_WORD_MAX ^ mask) : new _QRLUint512(this.value & mask);
      }
      and(other) {
        return new _QRLUint512(this.value & other.value);
      }
      or(other) {
        return new _QRLUint512(this.value | other.value);
      }
      xor(other) {
        return new _QRLUint512(this.value ^ other.value);
      }
      not() {
        return new _QRLUint512(exports2.QRL_WORD_MAX ^ this.value);
      }
      shl(bits) {
        if (bits.value >= exports2.QRL_WORD_BITS) {
          return _QRLUint512.zero();
        }
        return new _QRLUint512(this.value << bits.value);
      }
      shr(bits) {
        if (bits.value >= exports2.QRL_WORD_BITS) {
          return _QRLUint512.zero();
        }
        return new _QRLUint512(this.value >> bits.value);
      }
      sar(bits) {
        const signed = this.toSignedBigInt();
        if (bits.value >= exports2.QRL_WORD_BITS) {
          return signed < 0n ? new _QRLUint512(exports2.QRL_WORD_MAX) : _QRLUint512.zero();
        }
        return new _QRLUint512(signed >> bits.value);
      }
      toSignedBigInt() {
        return this.value >= QRL_SIGN_BIT ? this.value - exports2.QRL_WORD_MOD : this.value;
      }
    };
    exports2.QRLUint512 = QRLUint512;
    function abs(value) {
      return value < 0n ? -value : value;
    }
    __name(abs, "abs");
    function modularPow(base, exponent, modulo) {
      if (modulo === 1n) {
        return 0n;
      }
      let result = 1n;
      let currentBase = base % modulo;
      let currentExponent = exponent;
      while (currentExponent > 0n) {
        if ((currentExponent & 1n) === 1n) {
          result = result * currentBase % modulo;
        }
        currentExponent >>= 1n;
        currentBase = currentBase * currentBase % modulo;
      }
      return result;
    }
    __name(modularPow, "modularPow");
    function moduloWord(value) {
      const modded = value % exports2.QRL_WORD_MOD;
      return modded >= 0n ? modded : modded + exports2.QRL_WORD_MOD;
    }
    __name(moduloWord, "moduloWord");
    function bigintToBytes(value, length) {
      const out = new Uint8Array(length);
      let current = value;
      for (let i = length - 1; i >= 0; i--) {
        out[i] = Number(current & 0xffn);
        current >>= 8n;
      }
      return out;
    }
    __name(bigintToBytes, "bigintToBytes");
  }
});

// packages/evm/dist/cjs/qrl/gas.js
var require_gas = __commonJS({
  "packages/evm/dist/cjs/qrl/gas.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRL_MAX_INIT_CODE_SIZE = exports2.QRL_MAX_CODE_SIZE = exports2.QRL_CALL_CREATE_DEPTH = exports2.QRL_MAX_MEMORY_GAS_SIZE = exports2.QRL_GAS = void 0;
    exports2.qrlBaseGas = qrlBaseGas;
    exports2.qrlWordGas = qrlWordGas;
    exports2.qrlMemoryTotalGas = qrlMemoryTotalGas;
    exports2.qrlMemoryExpansionGas = qrlMemoryExpansionGas;
    exports2.qrlCopyGas = qrlCopyGas;
    exports2.qrlKeccak256DynamicGas = qrlKeccak256DynamicGas;
    exports2.qrlLogDynamicGas = qrlLogDynamicGas;
    exports2.qrlCreateInitCodeGas = qrlCreateInitCodeGas;
    exports2.qrlCreate2InitCodeGas = qrlCreate2InitCodeGas;
    exports2.qrlExpDynamicGas = qrlExpDynamicGas;
    exports2.qrlSLoadDynamicGas = qrlSLoadDynamicGas;
    exports2.qrlSStoreDynamicGas = qrlSStoreDynamicGas;
    exports2.qrlCallDynamicGas = qrlCallDynamicGas;
    exports2.qrlChildCallGas = qrlChildCallGas;
    exports2.qrlDynamicGas = qrlDynamicGas;
    var errors_ts_1 = require_errors4();
    var uint512_ts_1 = require_uint512();
    exports2.QRL_GAS = {
      quickStep: 2n,
      fastestStep: 3n,
      fastStep: 5n,
      midStep: 8n,
      slowStep: 10n,
      extStep: 20n,
      warmStorageRead: 100n,
      coldAccountAccess: 2600n,
      coldSload: 2100n,
      callValueTransfer: 9000n,
      callStipend: 2300n,
      callNewAccount: 25000n,
      create: 32000n,
      create2: 32000n,
      createData: 200n,
      copy: 3n,
      exp: 10n,
      expByte: 50n,
      initCodeWord: 2n,
      jumpdest: 1n,
      keccak256: 30n,
      keccak256Word: 6n,
      log: 375n,
      logData: 8n,
      logTopic: 375n,
      memory: 3n,
      quadCoeffDiv: 512n,
      sloadEip2200: 800n,
      sstoreSentryEip2200: 2300n,
      sstoreSetEip2200: 20000n,
      sstoreResetEip2200: 5000n,
      sstoreClearsScheduleRefundEip2200: 15000n,
      sstoreClearsScheduleRefundEip3529: 4800n
    };
    exports2.QRL_MAX_MEMORY_GAS_SIZE = 0x1fffffffe0n;
    exports2.QRL_CALL_CREATE_DEPTH = 1024;
    exports2.QRL_MAX_CODE_SIZE = 24576;
    exports2.QRL_MAX_INIT_CODE_SIZE = 49152;
    function qrlBaseGas(opcode) {
      if (!Number.isInteger(opcode) || opcode < 0 || opcode > 255) {
        throw new errors_ts_1.QRLVMError("Unsupported QRL opcode=" + opcode);
      }
      if (opcode >= 96 && opcode <= 159) {
        return exports2.QRL_GAS.fastestStep;
      }
      if (opcode >= 160 && opcode <= 175) {
        return exports2.QRL_GAS.fastestStep;
      }
      if (opcode >= 176 && opcode <= 191) {
        return exports2.QRL_GAS.fastestStep;
      }
      if (opcode >= 192 && opcode <= 196) {
        return 0n;
      }
      switch (opcode) {
        case 0:
        case 243:
        case 253:
          return 0n;
        case 1:
        case 3:
        case 16:
        case 17:
        case 18:
        case 19:
        case 20:
        case 21:
        case 22:
        case 23:
        case 24:
        case 25:
        case 26:
        case 27:
        case 28:
        case 29:
        case 53:
        case 55:
        case 57:
        case 62:
        case 81:
        case 82:
        case 83:
          return exports2.QRL_GAS.fastestStep;
        case 2:
        case 4:
        case 5:
        case 6:
        case 7:
        case 11:
        case 71:
          return exports2.QRL_GAS.fastStep;
        case 8:
        case 9:
        case 86:
          return exports2.QRL_GAS.midStep;
        case 87:
          return exports2.QRL_GAS.slowStep;
        case 32:
          return exports2.QRL_GAS.keccak256;
        case 49:
        case 59:
        case 60:
        case 63:
        case 241:
        case 244:
        case 250:
          return exports2.QRL_GAS.warmStorageRead;
        case 64:
          return exports2.QRL_GAS.extStep;
        case 48:
        case 50:
        case 51:
        case 52:
        case 54:
        case 56:
        case 58:
        case 61:
        case 65:
        case 66:
        case 67:
        case 68:
        case 69:
        case 70:
        case 72:
        case 80:
        case 88:
        case 89:
        case 90:
        case 95:
          return exports2.QRL_GAS.quickStep;
        case 91:
          return exports2.QRL_GAS.jumpdest;
        case 10:
        case 84:
        case 85:
          return 0n;
        case 240:
          return exports2.QRL_GAS.create;
        case 245:
          return exports2.QRL_GAS.create2;
        default:
          throw new errors_ts_1.QRLVMError("Unsupported QRL opcode=0x" + opcode.toString(16));
      }
    }
    __name(qrlBaseGas, "qrlBaseGas");
    function qrlWordGas(sizeBytes) {
      const size = toNonNegativeBigInt(sizeBytes, "sizeBytes");
      if (size === 0n) {
        return 0n;
      }
      return (size + BigInt(uint512_ts_1.QRL_WORD_BYTES) - 1n) / BigInt(uint512_ts_1.QRL_WORD_BYTES);
    }
    __name(qrlWordGas, "qrlWordGas");
    function qrlMemoryTotalGas(sizeBytes) {
      const size = toNonNegativeBigInt(sizeBytes, "sizeBytes");
      if (size === 0n) {
        return 0n;
      }
      if (size > exports2.QRL_MAX_MEMORY_GAS_SIZE) {
        throw new errors_ts_1.QRLVMError("QRL memory gas size overflow: " + size.toString());
      }
      const words = qrlWordGas(size);
      return words * exports2.QRL_GAS.memory + words * words / exports2.QRL_GAS.quadCoeffDiv;
    }
    __name(qrlMemoryTotalGas, "qrlMemoryTotalGas");
    function qrlMemoryExpansionGas(currentBytes, targetBytes) {
      const current = toNonNegativeBigInt(currentBytes, "currentBytes");
      const target = toNonNegativeBigInt(targetBytes, "targetBytes");
      if (target <= current) {
        return 0n;
      }
      return qrlMemoryTotalGas(target) - qrlMemoryTotalGas(current);
    }
    __name(qrlMemoryExpansionGas, "qrlMemoryExpansionGas");
    function qrlCopyGas(sizeBytes) {
      return qrlWordGas(sizeBytes) * exports2.QRL_GAS.copy;
    }
    __name(qrlCopyGas, "qrlCopyGas");
    function qrlKeccak256DynamicGas(sizeBytes) {
      return qrlWordGas(sizeBytes) * exports2.QRL_GAS.keccak256Word;
    }
    __name(qrlKeccak256DynamicGas, "qrlKeccak256DynamicGas");
    function qrlLogDynamicGas(topicCount, dataSizeBytes) {
      const topics = toNonNegativeBigInt(topicCount, "topicCount");
      const dataSize = toNonNegativeBigInt(dataSizeBytes, "dataSizeBytes");
      return exports2.QRL_GAS.log + topics * exports2.QRL_GAS.logTopic + dataSize * exports2.QRL_GAS.logData;
    }
    __name(qrlLogDynamicGas, "qrlLogDynamicGas");
    function qrlCreateInitCodeGas(sizeBytes) {
      return qrlWordGas(sizeBytes) * exports2.QRL_GAS.initCodeWord;
    }
    __name(qrlCreateInitCodeGas, "qrlCreateInitCodeGas");
    function qrlCreate2InitCodeGas(sizeBytes) {
      return qrlCreateInitCodeGas(sizeBytes) + qrlKeccak256DynamicGas(sizeBytes);
    }
    __name(qrlCreate2InitCodeGas, "qrlCreate2InitCodeGas");
    function qrlExpDynamicGas(exponentByteLength) {
      return exports2.QRL_GAS.exp + toNonNegativeBigInt(exponentByteLength, "exponentByteLength") * exports2.QRL_GAS.expByte;
    }
    __name(qrlExpDynamicGas, "qrlExpDynamicGas");
    function qrlSLoadDynamicGas(warmAccess) {
      return warmAccess ? exports2.QRL_GAS.warmStorageRead : exports2.QRL_GAS.coldSload;
    }
    __name(qrlSLoadDynamicGas, "qrlSLoadDynamicGas");
    function qrlSStoreDynamicGas(options) {
      if (options.gasRemaining <= exports2.QRL_GAS.sstoreSentryEip2200) {
        throw new errors_ts_1.QRLVMError("QRL SSTORE sentry gas not met");
      }
      const accessCost = options.warmAccess ? 0n : exports2.QRL_GAS.coldSload;
      if (options.currentEqualsValue) {
        return { gasCost: accessCost + exports2.QRL_GAS.warmStorageRead, refundDelta: 0n };
      }
      if (options.originalEqualsCurrent) {
        if (options.originalIsEmpty) {
          return { gasCost: accessCost + exports2.QRL_GAS.sstoreSetEip2200, refundDelta: 0n };
        }
        return {
          gasCost: accessCost + (exports2.QRL_GAS.sstoreResetEip2200 - exports2.QRL_GAS.coldSload),
          refundDelta: options.valueIsEmpty ? exports2.QRL_GAS.sstoreClearsScheduleRefundEip3529 : 0n
        };
      }
      let refundDelta = 0n;
      if (!options.originalIsEmpty) {
        if (options.currentIsEmpty) {
          refundDelta -= exports2.QRL_GAS.sstoreClearsScheduleRefundEip3529;
        } else if (options.valueIsEmpty) {
          refundDelta += exports2.QRL_GAS.sstoreClearsScheduleRefundEip3529;
        }
      }
      if (options.originalEqualsValue) {
        if (options.originalIsEmpty) {
          refundDelta += exports2.QRL_GAS.sstoreSetEip2200 - exports2.QRL_GAS.warmStorageRead;
        } else {
          refundDelta += exports2.QRL_GAS.sstoreResetEip2200 - exports2.QRL_GAS.coldSload - exports2.QRL_GAS.warmStorageRead;
        }
      }
      return { gasCost: accessCost + exports2.QRL_GAS.warmStorageRead, refundDelta };
    }
    __name(qrlSStoreDynamicGas, "qrlSStoreDynamicGas");
    function qrlCallDynamicGas(options) {
      let gas = qrlMemoryExpansionGas(options.memoryCurrentBytes, maxMemoryTarget(options.inputOffset, options.inputSizeBytes, options.outputOffset, options.outputSizeBytes));
      if (options.warmAccess === false) {
        gas += exports2.QRL_GAS.coldAccountAccess - exports2.QRL_GAS.warmStorageRead;
      }
      if (options.transfersValue === true) {
        gas += exports2.QRL_GAS.callValueTransfer;
        if (options.createsAccount === true) {
          gas += exports2.QRL_GAS.callNewAccount;
        }
      }
      return gas;
    }
    __name(qrlCallDynamicGas, "qrlCallDynamicGas");
    function qrlChildCallGas(availableGas, baseGas, requestedGas) {
      if (baseGas > availableGas) {
        throw new errors_ts_1.QRLVMError("QRL out of gas");
      }
      const allocatableGas = availableGas - baseGas;
      const eip150Gas = allocatableGas - allocatableGas / 64n;
      return requestedGas < eip150Gas ? requestedGas : eip150Gas;
    }
    __name(qrlChildCallGas, "qrlChildCallGas");
    function maxMemoryTarget(firstOffset, firstSize, secondOffset, secondSize) {
      const first = memoryTarget(firstOffset, firstSize, "first");
      const second = memoryTarget(secondOffset, secondSize, "second");
      return first > second ? first : second;
    }
    __name(maxMemoryTarget, "maxMemoryTarget");
    function memoryTarget(offsetInput, sizeInput, name) {
      const offset = toNonNegativeBigInt(offsetInput, name + "Offset");
      const size = toNonNegativeBigInt(sizeInput, name + "Size");
      return size === 0n ? 0n : offset + size;
    }
    __name(memoryTarget, "memoryTarget");
    function qrlDynamicGas(opcode, options = {}) {
      const memoryGas = qrlMemoryExpansionGas(options.memoryCurrentBytes ?? 0n, options.memoryTargetBytes ?? 0n);
      switch (opcode) {
        case 32:
          return memoryGas + qrlKeccak256DynamicGas(options.hashSizeBytes ?? 0n);
        case 55:
        case 57:
        case 60:
        case 62:
          return memoryGas + qrlCopyGas(options.copySizeBytes ?? 0n);
        case 10:
          return qrlExpDynamicGas(options.exponentByteLength ?? 0n);
        case 192:
        case 193:
        case 194:
        case 195:
        case 196:
          return memoryGas + qrlLogDynamicGas(options.logTopicCount ?? BigInt(opcode - 192), options.logDataSizeBytes ?? 0n);
        case 240:
          return memoryGas + qrlCreateInitCodeGas(options.initCodeSizeBytes ?? 0n);
        case 245:
          return memoryGas + qrlCreate2InitCodeGas(options.initCodeSizeBytes ?? 0n);
        case 241:
          return qrlCallDynamicGas({
            memoryCurrentBytes: options.memoryCurrentBytes ?? 0n,
            inputOffset: options.callInputOffset ?? 0n,
            inputSizeBytes: options.callInputSizeBytes ?? 0n,
            outputOffset: options.callOutputOffset ?? 0n,
            outputSizeBytes: options.callOutputSizeBytes ?? 0n,
            transfersValue: options.transfersValue,
            createsAccount: options.createsAccount,
            warmAccess: options.warmAccess
          });
        case 244:
        case 250:
          return qrlCallDynamicGas({
            memoryCurrentBytes: options.memoryCurrentBytes ?? 0n,
            inputOffset: options.callInputOffset ?? 0n,
            inputSizeBytes: options.callInputSizeBytes ?? 0n,
            outputOffset: options.callOutputOffset ?? 0n,
            outputSizeBytes: options.callOutputSizeBytes ?? 0n,
            warmAccess: options.warmAccess
          });
        default:
          return memoryGas;
      }
    }
    __name(qrlDynamicGas, "qrlDynamicGas");
    function toNonNegativeBigInt(value, name) {
      if (typeof value === "number") {
        if (!Number.isSafeInteger(value) || value < 0) {
          throw new errors_ts_1.QRLVMError("Invalid QRL gas " + name + "=" + value);
        }
        return BigInt(value);
      }
      if (value < 0n) {
        throw new errors_ts_1.QRLVMError("Invalid QRL gas " + name + "=" + value.toString());
      }
      return value;
    }
    __name(toNonNegativeBigInt, "toNonNegativeBigInt");
  }
});

// packages/evm/dist/cjs/qrl/memory.js
var require_memory = __commonJS({
  "packages/evm/dist/cjs/qrl/memory.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLMemory = void 0;
    var errors_ts_1 = require_errors4();
    var uint512_ts_1 = require_uint512();
    var QRLMemory = class {
      static {
        __name(this, "QRLMemory");
      }
      constructor() {
        this.store = new Uint8Array(0);
      }
      length() {
        return this.store.length;
      }
      resize(size) {
        if (!Number.isSafeInteger(size) || size < 0) {
          throw new errors_ts_1.QRLVMError(`Invalid QRL memory size=${size}`);
        }
        const alignedSize = alignMemorySize(size);
        if (alignedSize <= this.store.length) {
          return;
        }
        const next = new Uint8Array(alignedSize);
        next.set(this.store);
        this.store = next;
      }
      getCopy(offset, size) {
        this.assertRange(offset, size);
        if (size === 0) {
          return new Uint8Array(0);
        }
        this.resize(offset + size);
        return new Uint8Array(this.store.subarray(offset, offset + size));
      }
      getWord(offset) {
        return uint512_ts_1.QRLUint512.fromBytes(this.getCopy(offset, uint512_ts_1.QRL_WORD_BYTES));
      }
      set(offset, size, value) {
        this.assertRange(offset, size);
        if (value.length < size) {
          throw new errors_ts_1.QRLVMError("QRL memory write value is shorter than size");
        }
        this.resize(offset + size);
        this.store.set(value.subarray(0, size), offset);
      }
      setWord(offset, value) {
        this.set(offset, uint512_ts_1.QRL_WORD_BYTES, value.toBytes64());
      }
      setByte(offset, value) {
        this.set(offset, 1, new Uint8Array([Number(value.toBigInt() & 0xffn)]));
      }
      assertRange(offset, size) {
        if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(size) || offset < 0 || size < 0) {
          throw new errors_ts_1.QRLVMError(`Invalid QRL memory range offset=${offset} size=${size}`);
        }
      }
    };
    exports2.QRLMemory = QRLMemory;
    function alignMemorySize(size) {
      if (size === 0) {
        return 0;
      }
      return Math.ceil(size / uint512_ts_1.QRL_WORD_BYTES) * uint512_ts_1.QRL_WORD_BYTES;
    }
    __name(alignMemorySize, "alignMemorySize");
  }
});

// packages/evm/dist/cjs/qrl/message.js
var require_message = __commonJS({
  "packages/evm/dist/cjs/qrl/message.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLMessage = void 0;
    exports2.defaultQRLExecutionContext = defaultQRLExecutionContext;
    var util_1 = require_cjs2();
    var QRLMessage = class {
      static {
        __name(this, "QRLMessage");
      }
      constructor(data) {
        this.caller = data.caller;
        this.to = data.to;
        this.value = data.value ?? 0n;
        this.data = new Uint8Array(data.data ?? new Uint8Array(0));
        this.code = new Uint8Array(data.code ?? new Uint8Array(0));
        this.returnData = new Uint8Array(data.returnData ?? new Uint8Array(0));
        this.gasLimit = data.gasLimit ?? 0xffffffffffn;
        this.depth = data.depth ?? 0;
        this.isStatic = data.isStatic ?? false;
      }
    };
    exports2.QRLMessage = QRLMessage;
    function defaultQRLExecutionContext() {
      const zero = util_1.qrl.QRLAddress.zero();
      return {
        origin: zero,
        caller: zero,
        address: zero,
        coinbase: zero,
        gasPrice: 0n,
        blockNumber: 0n,
        timestamp: 0n,
        gasLimit: 0n,
        chainId: 1n,
        baseFee: 0n,
        prevRandao: 0n,
        blockHashes: /* @__PURE__ */ new Map()
      };
    }
    __name(defaultQRLExecutionContext, "defaultQRLExecutionContext");
  }
});

// node_modules/@noble/hashes/_md.js
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD, SHA256_IV, SHA224_IV, SHA384_IV, SHA512_IV;
var init_md = __esm({
  "node_modules/@noble/hashes/_md.js"() {
    init_utils6();
    __name(Chi, "Chi");
    __name(Maj, "Maj");
    HashMD = class {
      static {
        __name(this, "HashMD");
      }
      blockLen;
      outputLen;
      canXOF = false;
      padOffset;
      isLE;
      // For partial updates less than block size
      buffer;
      view;
      finished = false;
      length = 0;
      pos = 0;
      destroyed = false;
      constructor(blockLen, outputLen, padOffset, isLE7) {
        this.blockLen = blockLen;
        this.outputLen = outputLen;
        this.padOffset = padOffset;
        this.isLE = isLE7;
        this.buffer = new Uint8Array(blockLen);
        this.view = createView2(this.buffer);
      }
      update(data) {
        aexists6(this);
        abytes6(data);
        const { view, buffer, blockLen } = this;
        const len = data.length;
        for (let pos = 0; pos < len; ) {
          const take = Math.min(blockLen - this.pos, len - pos);
          if (take === blockLen) {
            const dataView = createView2(data);
            for (; blockLen <= len - pos; pos += blockLen)
              this.process(dataView, pos);
            continue;
          }
          buffer.set(data.subarray(pos, pos + take), this.pos);
          this.pos += take;
          pos += take;
          if (this.pos === blockLen) {
            this.process(view, 0);
            this.pos = 0;
          }
        }
        this.length += data.length;
        this.roundClean();
        return this;
      }
      digestInto(out) {
        aexists6(this);
        aoutput6(out, this);
        this.finished = true;
        const { buffer, view, blockLen, isLE: isLE7 } = this;
        let { pos } = this;
        buffer[pos++] = 128;
        clean6(this.buffer.subarray(pos));
        if (this.padOffset > blockLen - pos) {
          this.process(view, 0);
          pos = 0;
        }
        for (let i = pos; i < blockLen; i++)
          buffer[i] = 0;
        view.setBigUint64(blockLen - 8, BigInt(this.length * 8), isLE7);
        this.process(view, 0);
        const oview = createView2(out);
        const len = this.outputLen;
        if (len % 4)
          throw new Error("_sha2: outputLen must be aligned to 32bit");
        const outLen = len / 4;
        const state = this.get();
        if (outLen > state.length)
          throw new Error("_sha2: outputLen bigger than state");
        for (let i = 0; i < outLen; i++)
          oview.setUint32(4 * i, state[i], isLE7);
      }
      digest() {
        const { buffer, outputLen } = this;
        this.digestInto(buffer);
        const res = buffer.slice(0, outputLen);
        this.destroy();
        return res;
      }
      _cloneInto(to) {
        to ||= new this.constructor();
        to.set(...this.get());
        const { blockLen, buffer, length, finished, destroyed, pos } = this;
        to.destroyed = destroyed;
        to.finished = finished;
        to.length = length;
        to.pos = pos;
        if (length % blockLen)
          to.buffer.set(buffer);
        return to;
      }
      clone() {
        return this._cloneInto();
      }
    };
    SHA256_IV = /* @__PURE__ */ Uint32Array.from([
      1779033703,
      3144134277,
      1013904242,
      2773480762,
      1359893119,
      2600822924,
      528734635,
      1541459225
    ]);
    SHA224_IV = /* @__PURE__ */ Uint32Array.from([
      3238371032,
      914150663,
      812702999,
      4144912697,
      4290775857,
      1750603025,
      1694076839,
      3204075428
    ]);
    SHA384_IV = /* @__PURE__ */ Uint32Array.from([
      3418070365,
      3238371032,
      1654270250,
      914150663,
      2438529370,
      812702999,
      355462360,
      4144912697,
      1731405415,
      4290775857,
      2394180231,
      1750603025,
      3675008525,
      1694076839,
      1203062813,
      3204075428
    ]);
    SHA512_IV = /* @__PURE__ */ Uint32Array.from([
      1779033703,
      4089235720,
      3144134277,
      2227873595,
      1013904242,
      4271175723,
      2773480762,
      1595750129,
      1359893119,
      2917565137,
      2600822924,
      725511199,
      528734635,
      4215389547,
      1541459225,
      327033209
    ]);
  }
});

// node_modules/@noble/hashes/sha2.js
var sha2_exports = {};
__export(sha2_exports, {
  _SHA224: () => _SHA224,
  _SHA256: () => _SHA256,
  _SHA384: () => _SHA384,
  _SHA512: () => _SHA512,
  _SHA512_224: () => _SHA512_224,
  _SHA512_256: () => _SHA512_256,
  sha224: () => sha224,
  sha256: () => sha256,
  sha384: () => sha384,
  sha512: () => sha512,
  sha512_224: () => sha512_224,
  sha512_256: () => sha512_256
});
var SHA256_K, SHA256_W, SHA2_32B, _SHA256, _SHA224, K512, SHA512_Kh, SHA512_Kl, SHA512_W_H, SHA512_W_L, SHA2_64B, _SHA512, _SHA384, T224_IV, T256_IV, _SHA512_224, _SHA512_256, sha256, sha224, sha512, sha384, sha512_256, sha512_224;
var init_sha2 = __esm({
  "node_modules/@noble/hashes/sha2.js"() {
    init_md();
    init_u646();
    init_utils6();
    SHA256_K = /* @__PURE__ */ Uint32Array.from([
      1116352408,
      1899447441,
      3049323471,
      3921009573,
      961987163,
      1508970993,
      2453635748,
      2870763221,
      3624381080,
      310598401,
      607225278,
      1426881987,
      1925078388,
      2162078206,
      2614888103,
      3248222580,
      3835390401,
      4022224774,
      264347078,
      604807628,
      770255983,
      1249150122,
      1555081692,
      1996064986,
      2554220882,
      2821834349,
      2952996808,
      3210313671,
      3336571891,
      3584528711,
      113926993,
      338241895,
      666307205,
      773529912,
      1294757372,
      1396182291,
      1695183700,
      1986661051,
      2177026350,
      2456956037,
      2730485921,
      2820302411,
      3259730800,
      3345764771,
      3516065817,
      3600352804,
      4094571909,
      275423344,
      430227734,
      506948616,
      659060556,
      883997877,
      958139571,
      1322822218,
      1537002063,
      1747873779,
      1955562222,
      2024104815,
      2227730452,
      2361852424,
      2428436474,
      2756734187,
      3204031479,
      3329325298
    ]);
    SHA256_W = /* @__PURE__ */ new Uint32Array(64);
    SHA2_32B = class extends HashMD {
      static {
        __name(this, "SHA2_32B");
      }
      constructor(outputLen) {
        super(64, outputLen, 8, false);
      }
      get() {
        const { A, B, C, D, E, F, G, H } = this;
        return [A, B, C, D, E, F, G, H];
      }
      // prettier-ignore
      set(A, B, C, D, E, F, G, H) {
        this.A = A | 0;
        this.B = B | 0;
        this.C = C | 0;
        this.D = D | 0;
        this.E = E | 0;
        this.F = F | 0;
        this.G = G | 0;
        this.H = H | 0;
      }
      process(view, offset) {
        for (let i = 0; i < 16; i++, offset += 4)
          SHA256_W[i] = view.getUint32(offset, false);
        for (let i = 16; i < 64; i++) {
          const W15 = SHA256_W[i - 15];
          const W2 = SHA256_W[i - 2];
          const s0 = rotr2(W15, 7) ^ rotr2(W15, 18) ^ W15 >>> 3;
          const s1 = rotr2(W2, 17) ^ rotr2(W2, 19) ^ W2 >>> 10;
          SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
        }
        let { A, B, C, D, E, F, G, H } = this;
        for (let i = 0; i < 64; i++) {
          const sigma1 = rotr2(E, 6) ^ rotr2(E, 11) ^ rotr2(E, 25);
          const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
          const sigma0 = rotr2(A, 2) ^ rotr2(A, 13) ^ rotr2(A, 22);
          const T2 = sigma0 + Maj(A, B, C) | 0;
          H = G;
          G = F;
          F = E;
          E = D + T1 | 0;
          D = C;
          C = B;
          B = A;
          A = T1 + T2 | 0;
        }
        A = A + this.A | 0;
        B = B + this.B | 0;
        C = C + this.C | 0;
        D = D + this.D | 0;
        E = E + this.E | 0;
        F = F + this.F | 0;
        G = G + this.G | 0;
        H = H + this.H | 0;
        this.set(A, B, C, D, E, F, G, H);
      }
      roundClean() {
        clean6(SHA256_W);
      }
      destroy() {
        this.destroyed = true;
        this.set(0, 0, 0, 0, 0, 0, 0, 0);
        clean6(this.buffer);
      }
    };
    _SHA256 = class extends SHA2_32B {
      static {
        __name(this, "_SHA256");
      }
      // We cannot use array here since array allows indexing by variable
      // which means optimizer/compiler cannot use registers.
      A = SHA256_IV[0] | 0;
      B = SHA256_IV[1] | 0;
      C = SHA256_IV[2] | 0;
      D = SHA256_IV[3] | 0;
      E = SHA256_IV[4] | 0;
      F = SHA256_IV[5] | 0;
      G = SHA256_IV[6] | 0;
      H = SHA256_IV[7] | 0;
      constructor() {
        super(32);
      }
    };
    _SHA224 = class extends SHA2_32B {
      static {
        __name(this, "_SHA224");
      }
      A = SHA224_IV[0] | 0;
      B = SHA224_IV[1] | 0;
      C = SHA224_IV[2] | 0;
      D = SHA224_IV[3] | 0;
      E = SHA224_IV[4] | 0;
      F = SHA224_IV[5] | 0;
      G = SHA224_IV[6] | 0;
      H = SHA224_IV[7] | 0;
      constructor() {
        super(28);
      }
    };
    K512 = /* @__PURE__ */ (() => split6([
      "0x428a2f98d728ae22",
      "0x7137449123ef65cd",
      "0xb5c0fbcfec4d3b2f",
      "0xe9b5dba58189dbbc",
      "0x3956c25bf348b538",
      "0x59f111f1b605d019",
      "0x923f82a4af194f9b",
      "0xab1c5ed5da6d8118",
      "0xd807aa98a3030242",
      "0x12835b0145706fbe",
      "0x243185be4ee4b28c",
      "0x550c7dc3d5ffb4e2",
      "0x72be5d74f27b896f",
      "0x80deb1fe3b1696b1",
      "0x9bdc06a725c71235",
      "0xc19bf174cf692694",
      "0xe49b69c19ef14ad2",
      "0xefbe4786384f25e3",
      "0x0fc19dc68b8cd5b5",
      "0x240ca1cc77ac9c65",
      "0x2de92c6f592b0275",
      "0x4a7484aa6ea6e483",
      "0x5cb0a9dcbd41fbd4",
      "0x76f988da831153b5",
      "0x983e5152ee66dfab",
      "0xa831c66d2db43210",
      "0xb00327c898fb213f",
      "0xbf597fc7beef0ee4",
      "0xc6e00bf33da88fc2",
      "0xd5a79147930aa725",
      "0x06ca6351e003826f",
      "0x142929670a0e6e70",
      "0x27b70a8546d22ffc",
      "0x2e1b21385c26c926",
      "0x4d2c6dfc5ac42aed",
      "0x53380d139d95b3df",
      "0x650a73548baf63de",
      "0x766a0abb3c77b2a8",
      "0x81c2c92e47edaee6",
      "0x92722c851482353b",
      "0xa2bfe8a14cf10364",
      "0xa81a664bbc423001",
      "0xc24b8b70d0f89791",
      "0xc76c51a30654be30",
      "0xd192e819d6ef5218",
      "0xd69906245565a910",
      "0xf40e35855771202a",
      "0x106aa07032bbd1b8",
      "0x19a4c116b8d2d0c8",
      "0x1e376c085141ab53",
      "0x2748774cdf8eeb99",
      "0x34b0bcb5e19b48a8",
      "0x391c0cb3c5c95a63",
      "0x4ed8aa4ae3418acb",
      "0x5b9cca4f7763e373",
      "0x682e6ff3d6b2b8a3",
      "0x748f82ee5defb2fc",
      "0x78a5636f43172f60",
      "0x84c87814a1f0ab72",
      "0x8cc702081a6439ec",
      "0x90befffa23631e28",
      "0xa4506cebde82bde9",
      "0xbef9a3f7b2c67915",
      "0xc67178f2e372532b",
      "0xca273eceea26619c",
      "0xd186b8c721c0c207",
      "0xeada7dd6cde0eb1e",
      "0xf57d4f7fee6ed178",
      "0x06f067aa72176fba",
      "0x0a637dc5a2c898a6",
      "0x113f9804bef90dae",
      "0x1b710b35131c471b",
      "0x28db77f523047d84",
      "0x32caab7b40c72493",
      "0x3c9ebe0a15c9bebc",
      "0x431d67c49c100d4c",
      "0x4cc5d4becb3e42b6",
      "0x597f299cfc657e2a",
      "0x5fcb6fab3ad6faec",
      "0x6c44198c4a475817"
    ].map((n) => BigInt(n))))();
    SHA512_Kh = /* @__PURE__ */ (() => K512[0])();
    SHA512_Kl = /* @__PURE__ */ (() => K512[1])();
    SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
    SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);
    SHA2_64B = class extends HashMD {
      static {
        __name(this, "SHA2_64B");
      }
      constructor(outputLen) {
        super(128, outputLen, 16, false);
      }
      // prettier-ignore
      get() {
        const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
        return [Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl];
      }
      // prettier-ignore
      set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
        this.Ah = Ah | 0;
        this.Al = Al | 0;
        this.Bh = Bh | 0;
        this.Bl = Bl | 0;
        this.Ch = Ch | 0;
        this.Cl = Cl | 0;
        this.Dh = Dh | 0;
        this.Dl = Dl | 0;
        this.Eh = Eh | 0;
        this.El = El | 0;
        this.Fh = Fh | 0;
        this.Fl = Fl | 0;
        this.Gh = Gh | 0;
        this.Gl = Gl | 0;
        this.Hh = Hh | 0;
        this.Hl = Hl | 0;
      }
      process(view, offset) {
        for (let i = 0; i < 16; i++, offset += 4) {
          SHA512_W_H[i] = view.getUint32(offset);
          SHA512_W_L[i] = view.getUint32(offset += 4);
        }
        for (let i = 16; i < 80; i++) {
          const W15h = SHA512_W_H[i - 15] | 0;
          const W15l = SHA512_W_L[i - 15] | 0;
          const s0h = rotrSH(W15h, W15l, 1) ^ rotrSH(W15h, W15l, 8) ^ shrSH(W15h, W15l, 7);
          const s0l = rotrSL(W15h, W15l, 1) ^ rotrSL(W15h, W15l, 8) ^ shrSL(W15h, W15l, 7);
          const W2h = SHA512_W_H[i - 2] | 0;
          const W2l = SHA512_W_L[i - 2] | 0;
          const s1h = rotrSH(W2h, W2l, 19) ^ rotrBH(W2h, W2l, 61) ^ shrSH(W2h, W2l, 6);
          const s1l = rotrSL(W2h, W2l, 19) ^ rotrBL(W2h, W2l, 61) ^ shrSL(W2h, W2l, 6);
          const SUMl = add4L(s0l, s1l, SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
          const SUMh = add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]);
          SHA512_W_H[i] = SUMh | 0;
          SHA512_W_L[i] = SUMl | 0;
        }
        let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
        for (let i = 0; i < 80; i++) {
          const sigma1h = rotrSH(Eh, El, 14) ^ rotrSH(Eh, El, 18) ^ rotrBH(Eh, El, 41);
          const sigma1l = rotrSL(Eh, El, 14) ^ rotrSL(Eh, El, 18) ^ rotrBL(Eh, El, 41);
          const CHIh = Eh & Fh ^ ~Eh & Gh;
          const CHIl = El & Fl ^ ~El & Gl;
          const T1ll = add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
          const T1h = add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
          const T1l = T1ll | 0;
          const sigma0h = rotrSH(Ah, Al, 28) ^ rotrBH(Ah, Al, 34) ^ rotrBH(Ah, Al, 39);
          const sigma0l = rotrSL(Ah, Al, 28) ^ rotrBL(Ah, Al, 34) ^ rotrBL(Ah, Al, 39);
          const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
          const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
          Hh = Gh | 0;
          Hl = Gl | 0;
          Gh = Fh | 0;
          Gl = Fl | 0;
          Fh = Eh | 0;
          Fl = El | 0;
          ({ h: Eh, l: El } = add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
          Dh = Ch | 0;
          Dl = Cl | 0;
          Ch = Bh | 0;
          Cl = Bl | 0;
          Bh = Ah | 0;
          Bl = Al | 0;
          const All = add3L(T1l, sigma0l, MAJl);
          Ah = add3H(All, T1h, sigma0h, MAJh);
          Al = All | 0;
        }
        ({ h: Ah, l: Al } = add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
        ({ h: Bh, l: Bl } = add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
        ({ h: Ch, l: Cl } = add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
        ({ h: Dh, l: Dl } = add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
        ({ h: Eh, l: El } = add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
        ({ h: Fh, l: Fl } = add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
        ({ h: Gh, l: Gl } = add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
        ({ h: Hh, l: Hl } = add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
        this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
      }
      roundClean() {
        clean6(SHA512_W_H, SHA512_W_L);
      }
      destroy() {
        this.destroyed = true;
        clean6(this.buffer);
        this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
      }
    };
    _SHA512 = class extends SHA2_64B {
      static {
        __name(this, "_SHA512");
      }
      Ah = SHA512_IV[0] | 0;
      Al = SHA512_IV[1] | 0;
      Bh = SHA512_IV[2] | 0;
      Bl = SHA512_IV[3] | 0;
      Ch = SHA512_IV[4] | 0;
      Cl = SHA512_IV[5] | 0;
      Dh = SHA512_IV[6] | 0;
      Dl = SHA512_IV[7] | 0;
      Eh = SHA512_IV[8] | 0;
      El = SHA512_IV[9] | 0;
      Fh = SHA512_IV[10] | 0;
      Fl = SHA512_IV[11] | 0;
      Gh = SHA512_IV[12] | 0;
      Gl = SHA512_IV[13] | 0;
      Hh = SHA512_IV[14] | 0;
      Hl = SHA512_IV[15] | 0;
      constructor() {
        super(64);
      }
    };
    _SHA384 = class extends SHA2_64B {
      static {
        __name(this, "_SHA384");
      }
      Ah = SHA384_IV[0] | 0;
      Al = SHA384_IV[1] | 0;
      Bh = SHA384_IV[2] | 0;
      Bl = SHA384_IV[3] | 0;
      Ch = SHA384_IV[4] | 0;
      Cl = SHA384_IV[5] | 0;
      Dh = SHA384_IV[6] | 0;
      Dl = SHA384_IV[7] | 0;
      Eh = SHA384_IV[8] | 0;
      El = SHA384_IV[9] | 0;
      Fh = SHA384_IV[10] | 0;
      Fl = SHA384_IV[11] | 0;
      Gh = SHA384_IV[12] | 0;
      Gl = SHA384_IV[13] | 0;
      Hh = SHA384_IV[14] | 0;
      Hl = SHA384_IV[15] | 0;
      constructor() {
        super(48);
      }
    };
    T224_IV = /* @__PURE__ */ Uint32Array.from([
      2352822216,
      424955298,
      1944164710,
      2312950998,
      502970286,
      855612546,
      1738396948,
      1479516111,
      258812777,
      2077511080,
      2011393907,
      79989058,
      1067287976,
      1780299464,
      286451373,
      2446758561
    ]);
    T256_IV = /* @__PURE__ */ Uint32Array.from([
      573645204,
      4230739756,
      2673172387,
      3360449730,
      596883563,
      1867755857,
      2520282905,
      1497426621,
      2519219938,
      2827943907,
      3193839141,
      1401305490,
      721525244,
      746961066,
      246885852,
      2177182882
    ]);
    _SHA512_224 = class extends SHA2_64B {
      static {
        __name(this, "_SHA512_224");
      }
      Ah = T224_IV[0] | 0;
      Al = T224_IV[1] | 0;
      Bh = T224_IV[2] | 0;
      Bl = T224_IV[3] | 0;
      Ch = T224_IV[4] | 0;
      Cl = T224_IV[5] | 0;
      Dh = T224_IV[6] | 0;
      Dl = T224_IV[7] | 0;
      Eh = T224_IV[8] | 0;
      El = T224_IV[9] | 0;
      Fh = T224_IV[10] | 0;
      Fl = T224_IV[11] | 0;
      Gh = T224_IV[12] | 0;
      Gl = T224_IV[13] | 0;
      Hh = T224_IV[14] | 0;
      Hl = T224_IV[15] | 0;
      constructor() {
        super(28);
      }
    };
    _SHA512_256 = class extends SHA2_64B {
      static {
        __name(this, "_SHA512_256");
      }
      Ah = T256_IV[0] | 0;
      Al = T256_IV[1] | 0;
      Bh = T256_IV[2] | 0;
      Bl = T256_IV[3] | 0;
      Ch = T256_IV[4] | 0;
      Cl = T256_IV[5] | 0;
      Dh = T256_IV[6] | 0;
      Dl = T256_IV[7] | 0;
      Eh = T256_IV[8] | 0;
      El = T256_IV[9] | 0;
      Fh = T256_IV[10] | 0;
      Fl = T256_IV[11] | 0;
      Gh = T256_IV[12] | 0;
      Gl = T256_IV[13] | 0;
      Hh = T256_IV[14] | 0;
      Hl = T256_IV[15] | 0;
      constructor() {
        super(32);
      }
    };
    sha256 = /* @__PURE__ */ createHasher6(
      () => new _SHA256(),
      /* @__PURE__ */ oidNist6(1)
    );
    sha224 = /* @__PURE__ */ createHasher6(
      () => new _SHA224(),
      /* @__PURE__ */ oidNist6(4)
    );
    sha512 = /* @__PURE__ */ createHasher6(
      () => new _SHA512(),
      /* @__PURE__ */ oidNist6(3)
    );
    sha384 = /* @__PURE__ */ createHasher6(
      () => new _SHA384(),
      /* @__PURE__ */ oidNist6(2)
    );
    sha512_256 = /* @__PURE__ */ createHasher6(
      () => new _SHA512_256(),
      /* @__PURE__ */ oidNist6(6)
    );
    sha512_224 = /* @__PURE__ */ createHasher6(
      () => new _SHA512_224(),
      /* @__PURE__ */ oidNist6(5)
    );
  }
});

// packages/evm/dist/cjs/qrl/precompiles.js
var require_precompiles = __commonJS({
  "packages/evm/dist/cjs/qrl/precompiles.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isQRLPrecompile = isQRLPrecompile;
    exports2.runQRLPrecompile = runQRLPrecompile;
    exports2.qrlPrecompileGas = qrlPrecompileGas;
    var sha2_js_1 = (init_sha2(), __toCommonJS(sha2_exports));
    var util_1 = require_cjs2();
    var errors_ts_1 = require_errors4();
    var uint512_ts_1 = require_uint512();
    var PRECOMPILE_DEPOSIT_ROOT = 1;
    var PRECOMPILE_SHA256 = 2;
    var PRECOMPILE_IDENTITY = 4;
    var PRECOMPILE_BIG_MODEXP = 5;
    var SHA256_BASE_GAS = 60n;
    var SHA256_PER_WORD_GAS = 12n;
    var IDENTITY_BASE_GAS = 15n;
    var IDENTITY_PER_WORD_GAS = 3n;
    var DEPOSIT_ROOT_SHA256_OPS = 238n;
    var BIG_MODEXP_MIN_GAS = 200n;
    var ZERO_CHUNK = new Uint8Array(32);
    function isQRLPrecompile(address) {
      const id = precompileId(address);
      return id === PRECOMPILE_DEPOSIT_ROOT || id === PRECOMPILE_SHA256 || id === PRECOMPILE_IDENTITY || id === PRECOMPILE_BIG_MODEXP;
    }
    __name(isQRLPrecompile, "isQRLPrecompile");
    function runQRLPrecompile(address, input, gasLimit, gasRefund) {
      const gasUsed = qrlPrecompileGas(address, input);
      if (gasUsed > gasLimit) {
        return {
          returnValue: new Uint8Array(0),
          gasUsed: gasLimit,
          gasRemaining: 0n,
          gasRefund: 0n,
          exceptionError: new errors_ts_1.QRLVMError("QRL out of gas")
        };
      }
      return {
        returnValue: qrlPrecompileOutput(address, input),
        gasUsed,
        gasRemaining: gasLimit - gasUsed,
        gasRefund
      };
    }
    __name(runQRLPrecompile, "runQRLPrecompile");
    function qrlPrecompileGas(address, input) {
      switch (precompileId(address)) {
        case PRECOMPILE_DEPOSIT_ROOT:
          return (wordGas(64) * SHA256_PER_WORD_GAS + SHA256_BASE_GAS) * DEPOSIT_ROOT_SHA256_OPS;
        case PRECOMPILE_SHA256:
          return wordGas(input.length) * SHA256_PER_WORD_GAS + SHA256_BASE_GAS;
        case PRECOMPILE_IDENTITY:
          return wordGas(input.length) * IDENTITY_PER_WORD_GAS + IDENTITY_BASE_GAS;
        case PRECOMPILE_BIG_MODEXP:
          return bigModExpGas(input);
        default:
          throw new errors_ts_1.QRLVMError("Unsupported QRL precompile");
      }
    }
    __name(qrlPrecompileGas, "qrlPrecompileGas");
    function qrlPrecompileOutput(address, input) {
      switch (precompileId(address)) {
        case PRECOMPILE_DEPOSIT_ROOT:
          return depositRoot(input);
        case PRECOMPILE_SHA256:
          return Uint8Array.from((0, sha2_js_1.sha256)(input));
        case PRECOMPILE_IDENTITY:
          return new Uint8Array(input);
        case PRECOMPILE_BIG_MODEXP:
          return bigModExp(input);
        default:
          throw new errors_ts_1.QRLVMError("Unsupported QRL precompile");
      }
    }
    __name(qrlPrecompileOutput, "qrlPrecompileOutput");
    function precompileId(address) {
      const bytes = address.toBytes();
      for (let i = 0; i < bytes.length - 1; i++) {
        if (bytes[i] !== 0) {
          return -1;
        }
      }
      return bytes[bytes.length - 1];
    }
    __name(precompileId, "precompileId");
    function wordGas(sizeBytes) {
      return sizeBytes === 0 ? 0n : (BigInt(sizeBytes) + BigInt(uint512_ts_1.QRL_WORD_BYTES) - 1n) / BigInt(uint512_ts_1.QRL_WORD_BYTES);
    }
    __name(wordGas, "wordGas");
    function bigModExpGas(input) {
      const baseLen = (0, util_1.bytesToBigInt)(getData(input, 0, 32));
      const expLen = (0, util_1.bytesToBigInt)(getData(input, 32, 32));
      const modLen = (0, util_1.bytesToBigInt)(getData(input, 64, 32));
      const payload = input.length > 96 ? input.slice(96) : new Uint8Array(0);
      let expHead;
      if (BigInt(payload.length) <= baseLen) {
        expHead = 0n;
      } else if (expLen > 32n) {
        expHead = (0, util_1.bytesToBigInt)(getData(payload, baseLen, 32n));
      } else {
        expHead = (0, util_1.bytesToBigInt)(getData(payload, baseLen, expLen));
      }
      const msb = expHead === 0n ? 0n : BigInt(expHead.toString(2).length - 1);
      const adjustedExpLen = (expLen > 32n ? (expLen - 32n) * 8n : 0n) + msb;
      const maxLen = baseLen > modLen ? baseLen : modLen;
      let gas = ((maxLen + 7n) / 8n) ** 2n;
      gas = gas * (adjustedExpLen > 1n ? adjustedExpLen : 1n) / 3n;
      return gas < BIG_MODEXP_MIN_GAS ? BIG_MODEXP_MIN_GAS : gas;
    }
    __name(bigModExpGas, "bigModExpGas");
    function bigModExp(input) {
      const baseLen = (0, util_1.bytesToBigInt)(getData(input, 0, 32));
      const expLen = (0, util_1.bytesToBigInt)(getData(input, 32, 32));
      const modLen = (0, util_1.bytesToBigInt)(getData(input, 64, 32));
      const payload = input.length > 96 ? input.slice(96) : new Uint8Array(0);
      if (baseLen === 0n && modLen === 0n) {
        return new Uint8Array(0);
      }
      const base = (0, util_1.bytesToBigInt)(getData(payload, 0, baseLen));
      const exp = (0, util_1.bytesToBigInt)(getData(payload, baseLen, expLen));
      const mod = (0, util_1.bytesToBigInt)(getData(payload, baseLen + expLen, modLen));
      if (mod === 0n) {
        return leftPad(new Uint8Array(0), Number(modLen));
      }
      const value = modPow(base, exp, mod);
      return leftPad(bigIntToBytes(value), Number(modLen));
    }
    __name(bigModExp, "bigModExp");
    function modPow(baseInput, exponentInput, modulus) {
      let result = 1n;
      let base = baseInput % modulus;
      let exponent = exponentInput;
      while (exponent > 0n) {
        if ((exponent & 1n) === 1n) {
          result = result * base % modulus;
        }
        exponent >>= 1n;
        base = base * base % modulus;
      }
      return result;
    }
    __name(modPow, "modPow");
    function depositRoot(input) {
      const publicKey = getData(input, 0, 2592);
      const withdrawalCredentials = getData(input, 2592, 64);
      const amount = getData(input, 2656, 8);
      const signature = getData(input, 2664, 4627);
      return merkleize([
        merkleize(chunks(publicKey)),
        merkleize(chunks(withdrawalCredentials)),
        amountChunk(amount),
        merkleize(chunks(signature))
      ]);
    }
    __name(depositRoot, "depositRoot");
    function chunks(bytes) {
      const out = [];
      for (let offset = 0; offset < bytes.length; offset += 32) {
        const chunk = new Uint8Array(32);
        chunk.set(bytes.slice(offset, offset + 32));
        out.push(chunk);
      }
      return out.length === 0 ? [new Uint8Array(32)] : out;
    }
    __name(chunks, "chunks");
    function merkleize(leavesInput) {
      let leaves = leavesInput.map((leaf) => {
        if (leaf.length !== 32) {
          throw new errors_ts_1.QRLVMError("QRL depositroot SSZ leaf must be 32 bytes");
        }
        return new Uint8Array(leaf);
      });
      const targetLength = nextPowerOfTwo(leaves.length);
      while (leaves.length < targetLength) {
        leaves.push(ZERO_CHUNK);
      }
      while (leaves.length > 1) {
        const next = [];
        for (let i = 0; i < leaves.length; i += 2) {
          next.push(Uint8Array.from((0, sha2_js_1.sha256)(concat32(leaves[i], leaves[i + 1]))));
        }
        leaves = next;
      }
      return leaves[0];
    }
    __name(merkleize, "merkleize");
    function amountChunk(amountBytes) {
      const chunk = new Uint8Array(32);
      chunk.set(amountBytes.slice(0, 8));
      return chunk;
    }
    __name(amountChunk, "amountChunk");
    function nextPowerOfTwo(value) {
      let power = 1;
      while (power < value) {
        power *= 2;
      }
      return power;
    }
    __name(nextPowerOfTwo, "nextPowerOfTwo");
    function concat32(left, right) {
      const out = new Uint8Array(64);
      out.set(left);
      out.set(right, 32);
      return out;
    }
    __name(concat32, "concat32");
    function getData(input, offsetInput, sizeInput) {
      const offset = Number(offsetInput);
      const size = Number(sizeInput);
      const output = new Uint8Array(size);
      if (offset < input.length) {
        output.set(input.slice(offset, offset + size));
      }
      return output;
    }
    __name(getData, "getData");
    function bigIntToBytes(value) {
      if (value === 0n) {
        return new Uint8Array(0);
      }
      let hex = value.toString(16);
      if (hex.length % 2 !== 0) {
        hex = `0${hex}`;
      }
      const bytes = new Uint8Array(hex.length / 2);
      for (let i = 0; i < bytes.length; i++) {
        bytes[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
      }
      return bytes;
    }
    __name(bigIntToBytes, "bigIntToBytes");
    function leftPad(bytes, length) {
      if (bytes.length >= length) {
        return bytes.slice(bytes.length - length);
      }
      const out = new Uint8Array(length);
      out.set(bytes, length - bytes.length);
      return out;
    }
    __name(leftPad, "leftPad");
  }
});

// packages/evm/dist/cjs/qrl/stack.js
var require_stack = __commonJS({
  "packages/evm/dist/cjs/qrl/stack.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLStack = void 0;
    var errors_ts_1 = require_errors4();
    var uint512_ts_1 = require_uint512();
    var QRLStack = class {
      static {
        __name(this, "QRLStack");
      }
      constructor(limit = 1024) {
        this.data = [];
        this.limit = limit;
      }
      push(value) {
        if (this.data.length >= this.limit) {
          throw new errors_ts_1.QRLVMError("QRL stack overflow");
        }
        this.data.push(uint512_ts_1.QRLUint512.fromBigInt(value.toBigInt()));
      }
      pop() {
        const value = this.data.pop();
        if (value === void 0) {
          throw new errors_ts_1.QRLVMError("QRL stack underflow");
        }
        return value;
      }
      peek() {
        const value = this.data[this.data.length - 1];
        if (value === void 0) {
          throw new errors_ts_1.QRLVMError("QRL stack underflow");
        }
        return value;
      }
      replaceTop(value) {
        if (this.data.length === 0) {
          throw new errors_ts_1.QRLVMError("QRL stack underflow");
        }
        this.data[this.data.length - 1] = uint512_ts_1.QRLUint512.fromBigInt(value.toBigInt());
      }
      dup(position) {
        if (position < 1 || position > this.data.length) {
          throw new errors_ts_1.QRLVMError("QRL stack underflow");
        }
        this.push(this.data[this.data.length - position]);
      }
      swap(position) {
        if (position < 1 || position >= this.data.length) {
          throw new errors_ts_1.QRLVMError("QRL stack underflow");
        }
        const top = this.data.length - 1;
        const other = top - position;
        const tmp = this.data[top];
        this.data[top] = this.data[other];
        this.data[other] = tmp;
      }
      length() {
        return this.data.length;
      }
      values() {
        return this.data.map((value) => uint512_ts_1.QRLUint512.fromBigInt(value.toBigInt()));
      }
    };
    exports2.QRLStack = QRLStack;
  }
});

// packages/evm/dist/cjs/qrl/interpreter.js
var require_interpreter = __commonJS({
  "packages/evm/dist/cjs/qrl/interpreter.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLInterpreter = void 0;
    var sha3_js_1 = (init_sha36(), __toCommonJS(sha3_exports6));
    var util_1 = require_cjs2();
    var errors_ts_1 = require_errors4();
    var gas_ts_1 = require_gas();
    var memory_ts_1 = require_memory();
    var message_ts_1 = require_message();
    var precompiles_ts_1 = require_precompiles();
    var stack_ts_1 = require_stack();
    var uint512_ts_1 = require_uint512();
    var QRLInterpreter = class _QRLInterpreter {
      static {
        __name(this, "QRLInterpreter");
      }
      constructor(options) {
        this.stateManager = options.stateManager;
        this.context = options.context;
        this.gasState = options.gasState ?? createGasState(options);
        this.allowUnlimitedContractSize = options.allowUnlimitedContractSize;
        this.traceListener = options.traceListener;
      }
      async run(message) {
        const stack = new stack_ts_1.QRLStack();
        const memory = new memory_ts_1.QRLMemory();
        const logs = [];
        let returnData = new Uint8Array(message.returnData);
        const code = message.code;
        const jumpdests = collectJumpdests(code);
        let pc = 0;
        let gasUsed = 0n;
        const gasRefundSnapshot = this.gasState.gasRefund;
        await this.stateManager.checkpoint();
        try {
          while (pc < code.length) {
            const opcodePc = pc;
            const opcode = code[pc++];
            if (this.traceListener?.step !== void 0) {
              try {
                this.traceListener.step({
                  pc: opcodePc,
                  opcode,
                  depth: message.depth,
                  code,
                  gasLeft: message.gasLimit - gasUsed,
                  stack: /* @__PURE__ */ __name(() => stack.values(), "stack"),
                  memory: /* @__PURE__ */ __name(() => memory.getCopy(0, memory.length()), "memory")
                });
              } catch {
              }
            }
            gasUsed = consumeGas(gasUsed, message.gasLimit, (0, gas_ts_1.qrlBaseGas)(opcode));
            if (opcode >= 96 && opcode <= 159) {
              const size = opcode - 95;
              stack.push(uint512_ts_1.QRLUint512.fromBytes(readPadded(code, pc, size)));
              pc += size;
              continue;
            }
            if (opcode >= 160 && opcode <= 175) {
              stack.dup(opcode - 159);
              continue;
            }
            if (opcode >= 176 && opcode <= 191) {
              stack.swap(opcode - 175);
              continue;
            }
            switch (opcode) {
              case 0:
                await this.stateManager.commit();
                return success(stack, message.gasLimit, gasUsed, this.gasState.gasRefund, new Uint8Array(0), logs);
              case 1:
                binary(stack, (a, b) => a.add(b));
                break;
              case 2:
                binary(stack, (a, b) => a.mul(b));
                break;
              case 3:
                binary(stack, (a, b) => a.sub(b));
                break;
              case 4:
                binary(stack, (a, b) => a.div(b));
                break;
              case 5:
                binary(stack, (a, b) => a.sdiv(b));
                break;
              case 6:
                binary(stack, (a, b) => a.mod(b));
                break;
              case 7:
                binary(stack, (a, b) => a.smod(b));
                break;
              case 8:
                ternary(stack, (a, b, c) => a.addmod(b, c));
                break;
              case 9:
                ternary(stack, (a, b, c) => a.mulmod(b, c));
                break;
              case 10: {
                const base = stack.pop();
                const exponent = stack.pop();
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  exponentByteLength: exponentByteLength(exponent)
                });
                stack.push(base.exp(exponent));
                break;
              }
              case 11: {
                const byteIndex = stack.pop();
                const value = stack.pop();
                stack.push(value.signExtend(byteIndex));
                break;
              }
              case 16:
                binary(stack, (a, b) => a.lt(b));
                break;
              case 17:
                binary(stack, (a, b) => a.gt(b));
                break;
              case 18:
                binary(stack, (a, b) => a.slt(b));
                break;
              case 19:
                binary(stack, (a, b) => a.sgt(b));
                break;
              case 20:
                binary(stack, (a, b) => a.eq(b));
                break;
              case 21:
                stack.push(stack.pop().isZero() ? uint512_ts_1.QRLUint512.one() : uint512_ts_1.QRLUint512.zero());
                break;
              case 22:
                binary(stack, (a, b) => a.and(b));
                break;
              case 23:
                binary(stack, (a, b) => a.or(b));
                break;
              case 24:
                binary(stack, (a, b) => a.xor(b));
                break;
              case 25:
                stack.push(stack.pop().not());
                break;
              case 26: {
                const index = stack.pop();
                const value = stack.pop();
                stack.push(value.byte(index));
                break;
              }
              case 27:
                binary(stack, (shift, value) => value.shl(shift));
                break;
              case 28:
                binary(stack, (shift, value) => value.shr(shift));
                break;
              case 29:
                binary(stack, (shift, value) => value.sar(shift));
                break;
              case 32: {
                const offset = toSafeNumber(stack.pop());
                const size = toSafeNumber(stack.pop());
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  hashSizeBytes: size,
                  memoryTargetBytes: memoryTarget(offset, size)
                });
                stack.push(uint512_ts_1.QRLUint512.fromBytes((0, sha3_js_1.keccak_256)(memory.getCopy(offset, size))));
                break;
              }
              case 48:
                pushAddress(stack, this.context.address);
                break;
              case 49: {
                const address = util_1.qrl.QRLAddress.fromBytes(stack.pop().toBytes64());
                gasUsed = this.chargeAccountAccess(gasUsed, message.gasLimit, address);
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(await this.stateManager.getBalance(address)));
                break;
              }
              case 50:
                pushAddress(stack, this.context.origin);
                break;
              case 51:
                pushAddress(stack, message.caller);
                break;
              case 52:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(message.value));
                break;
              case 53: {
                const offset = toSafeNumber(stack.pop());
                stack.push(uint512_ts_1.QRLUint512.fromBytes(readPadded(message.data, offset, 64)));
                break;
              }
              case 54:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(BigInt(message.data.length)));
                break;
              case 55: {
                const memOffset = toSafeNumber(stack.pop());
                const dataOffset = toSafeNumber(stack.pop());
                const size = toSafeNumber(stack.pop());
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  copySizeBytes: size,
                  memoryTargetBytes: memoryTarget(memOffset, size)
                });
                memory.set(memOffset, size, readPadded(message.data, dataOffset, size));
                break;
              }
              case 56:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(BigInt(code.length)));
                break;
              case 57: {
                const memOffset = toSafeNumber(stack.pop());
                const codeOffset = toSafeNumber(stack.pop());
                const size = toSafeNumber(stack.pop());
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  copySizeBytes: size,
                  memoryTargetBytes: memoryTarget(memOffset, size)
                });
                memory.set(memOffset, size, readPadded(code, codeOffset, size));
                break;
              }
              case 58:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(this.context.gasPrice));
                break;
              case 59: {
                const address = util_1.qrl.QRLAddress.fromBytes(stack.pop().toBytes64());
                gasUsed = this.chargeAccountAccess(gasUsed, message.gasLimit, address);
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(BigInt(await this.stateManager.getCodeSize(address))));
                break;
              }
              case 60: {
                const address = util_1.qrl.QRLAddress.fromBytes(stack.pop().toBytes64());
                const memOffset = toSafeNumber(stack.pop());
                const codeOffset = toSafeNumber(stack.pop());
                const size = toSafeNumber(stack.pop());
                gasUsed = this.chargeAccountAccess(gasUsed, message.gasLimit, address);
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  copySizeBytes: size,
                  memoryTargetBytes: memoryTarget(memOffset, size)
                });
                memory.set(memOffset, size, readPadded(await this.stateManager.getCode(address), codeOffset, size));
                break;
              }
              case 61:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(BigInt(returnData.length)));
                break;
              case 62: {
                const memOffset = toSafeNumber(stack.pop());
                const dataOffset = toSafeNumber(stack.pop());
                const size = toSafeNumber(stack.pop());
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  copySizeBytes: size,
                  memoryTargetBytes: memoryTarget(memOffset, size)
                });
                memory.set(memOffset, size, readReturnData(returnData, dataOffset, size));
                break;
              }
              case 63: {
                const address = util_1.qrl.QRLAddress.fromBytes(stack.pop().toBytes64());
                gasUsed = this.chargeAccountAccess(gasUsed, message.gasLimit, address);
                const account = await this.stateManager.getAccount(address);
                stack.push(uint512_ts_1.QRLUint512.fromBytes(account?.codeHash ?? new Uint8Array(32)));
                break;
              }
              case 64: {
                const blockNumber = stack.pop().toBigInt();
                const hash = this.context.blockHashes.get(blockNumber) ?? new Uint8Array(32);
                stack.push(uint512_ts_1.QRLUint512.fromBytes(hash));
                break;
              }
              case 65:
                pushAddress(stack, this.context.coinbase);
                break;
              case 66:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(this.context.timestamp));
                break;
              case 67:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(this.context.blockNumber));
                break;
              case 68:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(this.context.prevRandao));
                break;
              case 69:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(this.context.gasLimit));
                break;
              case 70:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(this.context.chainId));
                break;
              case 71:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(await this.stateManager.getBalance(message.to)));
                break;
              case 72:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(this.context.baseFee));
                break;
              case 80:
                stack.pop();
                break;
              case 81: {
                const offset = toSafeNumber(stack.peek());
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  memoryTargetBytes: memoryTarget(offset, 64)
                });
                stack.replaceTop(memory.getWord(offset));
                break;
              }
              case 82: {
                const offset = toSafeNumber(stack.pop());
                const value = stack.pop();
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  memoryTargetBytes: memoryTarget(offset, 64)
                });
                memory.setWord(offset, value);
                break;
              }
              case 83: {
                const offset = toSafeNumber(stack.pop());
                const value = stack.pop();
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  memoryTargetBytes: memoryTarget(offset, 1)
                });
                memory.setByte(offset, value);
                break;
              }
              case 84: {
                const key = stack.peek().toBytes32();
                const accessKey = storageAccessKey(message.to, key);
                const warmAccess = this.gasState.accessedStorage.has(accessKey);
                gasUsed = consumeGas(gasUsed, message.gasLimit, (0, gas_ts_1.qrlSLoadDynamicGas)(warmAccess));
                this.gasState.accessedStorage.add(accessKey);
                stack.replaceTop(uint512_ts_1.QRLUint512.fromBytes(await this.stateManager.getStorage(message.to, key)));
                break;
              }
              case 85: {
                if (message.isStatic) {
                  throw new errors_ts_1.QRLVMError("QRL static execution cannot write storage");
                }
                const key = stack.pop().toBytes32();
                const value = stack.pop().toBytes64();
                const accessKey = storageAccessKey(message.to, key);
                const warmAccess = this.gasState.accessedStorage.has(accessKey);
                const current = await this.stateManager.getStorage(message.to, key);
                const original = await this.getOriginalStorage(message.to, key, accessKey, current);
                const { gasCost, refundDelta } = (0, gas_ts_1.qrlSStoreDynamicGas)({
                  gasRemaining: gasRemaining(message.gasLimit, gasUsed),
                  currentEqualsValue: equalBytes(current, value),
                  originalEqualsCurrent: equalBytes(original, current),
                  originalIsEmpty: isEmptyStorageValue(original),
                  currentIsEmpty: isEmptyStorageValue(current),
                  valueIsEmpty: isEmptyStorageValue(value),
                  originalEqualsValue: equalBytes(original, value),
                  warmAccess
                });
                gasUsed = consumeGas(gasUsed, message.gasLimit, gasCost);
                this.gasState.accessedStorage.add(accessKey);
                this.gasState.gasRefund += refundDelta;
                await this.stateManager.putStorage(message.to, key, value);
                break;
              }
              case 86: {
                const dest = toSafeNumber(stack.pop());
                assertJumpdest(jumpdests, dest);
                pc = dest;
                break;
              }
              case 87: {
                const dest = toSafeNumber(stack.pop());
                const condition = stack.pop();
                if (!condition.isZero()) {
                  assertJumpdest(jumpdests, dest);
                  pc = dest;
                }
                break;
              }
              case 88:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(BigInt(opcodePc)));
                break;
              case 89:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(BigInt(memory.length())));
                break;
              case 90:
                stack.push(uint512_ts_1.QRLUint512.fromBigInt(message.gasLimit - gasUsed));
                break;
              case 91:
                break;
              case 95:
                stack.push(uint512_ts_1.QRLUint512.zero());
                break;
              case 192:
              case 193:
              case 194:
              case 195:
              case 196: {
                const topicCount = opcode - 192;
                const logRecord = popLog(stack, topicCount, message.to, message.isStatic);
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  logDataSizeBytes: logRecord.dataSize,
                  logTopicCount: topicCount,
                  memoryTargetBytes: memoryTarget(logRecord.offset, logRecord.dataSize)
                });
                logs.push({
                  address: logRecord.address,
                  topics: logRecord.topics,
                  data: memory.getCopy(logRecord.offset, logRecord.dataSize)
                });
                break;
              }
              case 240: {
                const args = popCreateArgs(stack);
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  initCodeSizeBytes: args.size,
                  memoryTargetBytes: memoryTarget(args.offset, args.size)
                });
                const childGasLimit = (0, gas_ts_1.qrlChildCallGas)(gasRemaining(message.gasLimit, gasUsed), 0n, message.gasLimit);
                const create = await this.runNestedCreate({
                  kind: "create",
                  value: args.value,
                  initCode: memory.getCopy(args.offset, args.size),
                  gasLimit: childGasLimit,
                  message
                });
                gasUsed = consumeGas(gasUsed, message.gasLimit, create.result.gasUsed);
                if (create.result.exceptionError === void 0) {
                  returnData = new Uint8Array(0);
                  pushAddress(stack, create.address);
                } else {
                  returnData = create.result.returnValue;
                  stack.push(uint512_ts_1.QRLUint512.zero());
                }
                break;
              }
              case 241: {
                const args = popCallArgs(stack);
                const warmAccess = this.isWarmAccount(args.target);
                const callGasCost = (0, gas_ts_1.qrlDynamicGas)(opcode, {
                  memoryCurrentBytes: memory.length(),
                  callInputOffset: args.inOffset,
                  callInputSizeBytes: args.inSize,
                  callOutputOffset: args.outOffset,
                  callOutputSizeBytes: args.outSize,
                  transfersValue: args.value !== 0n,
                  createsAccount: args.value !== 0n && await this.isEmptyAccount(args.target),
                  warmAccess
                });
                let childGasLimit = (0, gas_ts_1.qrlChildCallGas)(gasRemaining(message.gasLimit, gasUsed), callGasCost, args.gasLimit);
                if (args.value !== 0n) {
                  childGasLimit += gas_ts_1.QRL_GAS.callStipend;
                }
                gasUsed = consumeGas(gasUsed, message.gasLimit, callGasCost);
                this.markWarmAccount(args.target);
                const result = await this.runNestedCall({
                  kind: "call",
                  target: args.target,
                  gasLimit: childGasLimit,
                  value: args.value,
                  input: memory.getCopy(args.inOffset, args.inSize),
                  isStatic: message.isStatic,
                  message
                });
                gasUsed = consumeGas(gasUsed, message.gasLimit, result.gasUsed);
                returnData = copyCallReturnData(memory, args.outOffset, args.outSize, result);
                if (result.exceptionError === void 0) {
                  logs.push(...(result.logs ?? []).map(copyExecutionLog));
                }
                stack.push(result.exceptionError === void 0 ? uint512_ts_1.QRLUint512.one() : uint512_ts_1.QRLUint512.zero());
                break;
              }
              case 244: {
                const args = popStaticCallArgs(stack);
                const warmAccess = this.isWarmAccount(args.target);
                const callGasCost = (0, gas_ts_1.qrlDynamicGas)(opcode, {
                  memoryCurrentBytes: memory.length(),
                  callInputOffset: args.inOffset,
                  callInputSizeBytes: args.inSize,
                  callOutputOffset: args.outOffset,
                  callOutputSizeBytes: args.outSize,
                  warmAccess
                });
                const childGasLimit = (0, gas_ts_1.qrlChildCallGas)(gasRemaining(message.gasLimit, gasUsed), callGasCost, args.gasLimit);
                gasUsed = consumeGas(gasUsed, message.gasLimit, callGasCost);
                this.markWarmAccount(args.target);
                const result = await this.runNestedCall({
                  kind: "delegatecall",
                  target: args.target,
                  gasLimit: childGasLimit,
                  value: message.value,
                  input: memory.getCopy(args.inOffset, args.inSize),
                  isStatic: message.isStatic,
                  message
                });
                gasUsed = consumeGas(gasUsed, message.gasLimit, result.gasUsed);
                returnData = copyCallReturnData(memory, args.outOffset, args.outSize, result);
                if (result.exceptionError === void 0) {
                  logs.push(...(result.logs ?? []).map(copyExecutionLog));
                }
                stack.push(result.exceptionError === void 0 ? uint512_ts_1.QRLUint512.one() : uint512_ts_1.QRLUint512.zero());
                break;
              }
              case 245: {
                const args = popCreate2Args(stack);
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  initCodeSizeBytes: args.size,
                  memoryTargetBytes: memoryTarget(args.offset, args.size)
                });
                const childGasLimit = (0, gas_ts_1.qrlChildCallGas)(gasRemaining(message.gasLimit, gasUsed), 0n, message.gasLimit);
                const create = await this.runNestedCreate({
                  kind: "create2",
                  value: args.value,
                  initCode: memory.getCopy(args.offset, args.size),
                  gasLimit: childGasLimit,
                  salt: args.salt,
                  message
                });
                gasUsed = consumeGas(gasUsed, message.gasLimit, create.result.gasUsed);
                if (create.result.exceptionError === void 0) {
                  returnData = new Uint8Array(0);
                  pushAddress(stack, create.address);
                } else {
                  returnData = create.result.returnValue;
                  stack.push(uint512_ts_1.QRLUint512.zero());
                }
                break;
              }
              case 250: {
                const args = popStaticCallArgs(stack);
                const warmAccess = this.isWarmAccount(args.target);
                const callGasCost = (0, gas_ts_1.qrlDynamicGas)(opcode, {
                  memoryCurrentBytes: memory.length(),
                  callInputOffset: args.inOffset,
                  callInputSizeBytes: args.inSize,
                  callOutputOffset: args.outOffset,
                  callOutputSizeBytes: args.outSize,
                  warmAccess
                });
                const childGasLimit = (0, gas_ts_1.qrlChildCallGas)(gasRemaining(message.gasLimit, gasUsed), callGasCost, args.gasLimit);
                gasUsed = consumeGas(gasUsed, message.gasLimit, callGasCost);
                this.markWarmAccount(args.target);
                const result = await this.runNestedCall({
                  kind: "staticcall",
                  target: args.target,
                  gasLimit: childGasLimit,
                  value: 0n,
                  input: memory.getCopy(args.inOffset, args.inSize),
                  isStatic: true,
                  message
                });
                gasUsed = consumeGas(gasUsed, message.gasLimit, result.gasUsed);
                returnData = copyCallReturnData(memory, args.outOffset, args.outSize, result);
                if (result.exceptionError === void 0) {
                  logs.push(...(result.logs ?? []).map(copyExecutionLog));
                }
                stack.push(result.exceptionError === void 0 ? uint512_ts_1.QRLUint512.one() : uint512_ts_1.QRLUint512.zero());
                break;
              }
              case 243: {
                const offset = toSafeNumber(stack.pop());
                const size = toSafeNumber(stack.pop());
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  memoryTargetBytes: memoryTarget(offset, size)
                });
                const returnValue = memory.getCopy(offset, size);
                await this.stateManager.commit();
                return success(stack, message.gasLimit, gasUsed, this.gasState.gasRefund, new Uint8Array(returnValue), logs);
              }
              case 253: {
                const offset = toSafeNumber(stack.pop());
                const size = toSafeNumber(stack.pop());
                gasUsed = chargeDynamicGas(gasUsed, message.gasLimit, opcode, memory, {
                  memoryTargetBytes: memoryTarget(offset, size)
                });
                throw new errors_ts_1.QRLVMRevert(memory.getCopy(offset, size));
              }
              case 254:
                throw new errors_ts_1.QRLVMError("QRL invalid opcode");
              default:
                throw new errors_ts_1.QRLVMError(`Unsupported QRL opcode=0x${opcode.toString(16).padStart(2, "0")}`);
            }
          }
          await this.stateManager.commit();
          return success(stack, message.gasLimit, gasUsed, this.gasState.gasRefund, new Uint8Array(0), logs);
        } catch (error) {
          await this.stateManager.revert();
          this.gasState.gasRefund = gasRefundSnapshot;
          const exceptionError = error instanceof errors_ts_1.QRLVMError ? error : new errors_ts_1.QRLVMError(error.message);
          const reverted = error instanceof errors_ts_1.QRLVMRevert;
          return {
            returnValue: reverted ? error.returnValue : new Uint8Array(0),
            gasUsed: reverted ? gasUsed : message.gasLimit,
            gasRemaining: reverted ? gasRemaining(message.gasLimit, gasUsed) : 0n,
            gasRefund: reverted ? this.gasState.gasRefund : 0n,
            exceptionError,
            stack
          };
        }
      }
      chargeAccountAccess(gasUsed, gasLimit, address) {
        const warmAccess = this.isWarmAccount(address);
        this.markWarmAccount(address);
        if (warmAccess) {
          return gasUsed;
        }
        return consumeGas(gasUsed, gasLimit, gas_ts_1.QRL_GAS.coldAccountAccess - gas_ts_1.QRL_GAS.warmStorageRead);
      }
      isWarmAccount(address) {
        return this.gasState.accessedAccounts.has(address.toHex());
      }
      markWarmAccount(address) {
        this.gasState.accessedAccounts.add(address.toHex());
      }
      async isEmptyAccount(address) {
        return await this.stateManager.getNonce(address) === 0n && await this.stateManager.getBalance(address) === 0n && await this.stateManager.getCodeSize(address) === 0;
      }
      async getOriginalStorage(address, key, accessKey, current) {
        const cached = this.gasState.originalStorage.get(accessKey);
        if (cached !== void 0) {
          return new Uint8Array(cached);
        }
        const original = new Uint8Array(current ?? await this.stateManager.getStorage(address, key));
        this.gasState.originalStorage.set(accessKey, original);
        return new Uint8Array(original);
      }
      async runNestedCreate(options) {
        const listener = this.traceListener;
        if (listener?.enterFrame !== void 0) {
          try {
            listener.enterFrame({
              kind: options.kind,
              depth: options.message.depth + 1,
              from: this.context.address,
              input: options.initCode,
              value: options.value,
              gasLimit: options.gasLimit
            });
          } catch {
          }
        }
        let nested;
        try {
          nested = await this.runNestedCreateInner(options);
        } catch (error) {
          if (listener?.exitFrame !== void 0) {
            try {
              listener.exitFrame({
                returnValue: new Uint8Array(0),
                gasUsed: options.gasLimit,
                exceptionError: error instanceof errors_ts_1.QRLVMError ? error : new errors_ts_1.QRLVMError(error.message)
              });
            } catch {
            }
          }
          throw error;
        }
        if (listener?.exitFrame !== void 0) {
          try {
            listener.exitFrame({
              returnValue: nested.result.returnValue,
              gasUsed: nested.result.gasUsed,
              exceptionError: nested.result.exceptionError,
              createdAddress: nested.address
            });
          } catch {
          }
        }
        return nested;
      }
      async runNestedCreateInner(options) {
        if (options.initCode.length > gas_ts_1.QRL_MAX_INIT_CODE_SIZE) {
          return nestedCreateError(util_1.qrl.QRLAddress.zero(), options.gasLimit, "QRL init code size exceeds limit");
        }
        if (options.message.depth >= gas_ts_1.QRL_CALL_CREATE_DEPTH) {
          return nestedCreateError(util_1.qrl.QRLAddress.zero(), options.gasLimit, "QRL call/create depth exceeded");
        }
        if (options.message.isStatic) {
          throw new errors_ts_1.QRLVMError("QRL static execution cannot create contracts");
        }
        const creator = options.message.to;
        const address = options.kind === "create" ? util_1.qrl.createQRLContractAddress(creator, await this.stateManager.getNonce(creator)) : util_1.qrl.createQRLContractAddress2(creator, options.salt, (0, sha3_js_1.keccak_256)(options.initCode));
        const context = {
          ...this.context,
          caller: creator,
          address
        };
        if (options.value !== 0n && await this.stateManager.getBalance(creator) < options.value) {
          return nestedCreateError(address, options.gasLimit, "QRL account balance underflow");
        }
        await this.stateManager.incrementNonce(creator);
        if (await this.stateManager.getNonce(address) !== 0n || await this.stateManager.getCodeSize(address) !== 0) {
          return nestedCreateError(address, options.gasLimit, "QRL contract address collision");
        }
        const gasRefundSnapshot = this.gasState.gasRefund;
        await this.stateManager.checkpoint();
        try {
          await this.stateManager.setNonce(address, 1n);
          if (options.value !== 0n) {
            await this.stateManager.subBalance(creator, options.value);
            await this.stateManager.addBalance(address, options.value);
          }
          const result = await new _QRLInterpreter({
            stateManager: this.stateManager,
            context,
            gasState: this.gasState,
            allowUnlimitedContractSize: this.allowUnlimitedContractSize,
            traceListener: this.traceListener
          }).run(new message_ts_1.QRLMessage({
            caller: creator,
            to: address,
            value: options.value,
            data: new Uint8Array(0),
            code: options.initCode,
            gasLimit: options.gasLimit,
            depth: options.message.depth + 1,
            isStatic: false
          }));
          if (result.exceptionError !== void 0) {
            await this.stateManager.revert();
            this.gasState.gasRefund = gasRefundSnapshot;
            return { address, result };
          }
          if (this.allowUnlimitedContractSize !== true && !isValidDeployedCode(result.returnValue)) {
            await this.stateManager.revert();
            this.gasState.gasRefund = gasRefundSnapshot;
            return {
              address,
              result: {
                ...result,
                gasRefund: gasRefundSnapshot,
                exceptionError: new errors_ts_1.QRLVMError("QRL invalid deployed code")
              }
            };
          }
          await this.stateManager.putCode(address, result.returnValue);
          await this.stateManager.commit();
          return { address, result };
        } catch (error) {
          await this.stateManager.revert();
          this.gasState.gasRefund = gasRefundSnapshot;
          return {
            address,
            result: {
              returnValue: new Uint8Array(0),
              gasUsed: options.gasLimit,
              gasRemaining: 0n,
              gasRefund: 0n,
              exceptionError: error instanceof errors_ts_1.QRLVMError ? error : new errors_ts_1.QRLVMError(error.message)
            }
          };
        }
      }
      async runNestedCall(options) {
        const listener = this.traceListener;
        if (listener?.enterFrame !== void 0) {
          try {
            listener.enterFrame({
              kind: options.kind,
              depth: options.message.depth + 1,
              from: this.context.address,
              target: options.target,
              input: options.input,
              value: options.value,
              gasLimit: options.gasLimit
            });
          } catch {
          }
        }
        let result;
        try {
          result = await this.runNestedCallInner(options);
        } catch (error) {
          if (listener?.exitFrame !== void 0) {
            try {
              listener.exitFrame({
                returnValue: new Uint8Array(0),
                gasUsed: options.gasLimit,
                exceptionError: error instanceof errors_ts_1.QRLVMError ? error : new errors_ts_1.QRLVMError(error.message)
              });
            } catch {
            }
          }
          throw error;
        }
        if (listener?.exitFrame !== void 0) {
          try {
            listener.exitFrame({
              returnValue: result.returnValue,
              gasUsed: result.gasUsed,
              exceptionError: result.exceptionError
            });
          } catch {
          }
        }
        return result;
      }
      async runNestedCallInner(options) {
        if (options.message.depth >= gas_ts_1.QRL_CALL_CREATE_DEPTH) {
          return nestedCallError(options.gasLimit, "QRL call/create depth exceeded", this.gasState.gasRefund);
        }
        if (options.kind === "call" && options.isStatic && options.value !== 0n) {
          throw new errors_ts_1.QRLVMError("QRL static execution cannot transfer value");
        }
        const isDelegateCall = options.kind === "delegatecall";
        const address = isDelegateCall ? options.message.to : options.target;
        const caller = isDelegateCall ? options.message.caller : options.message.to;
        const context = {
          ...this.context,
          caller,
          address
        };
        const gasRefundSnapshot = this.gasState.gasRefund;
        await this.stateManager.checkpoint();
        try {
          if (options.kind === "call" && options.value !== 0n) {
            await this.stateManager.subBalance(options.message.to, options.value);
            await this.stateManager.addBalance(options.target, options.value);
          }
          if ((0, precompiles_ts_1.isQRLPrecompile)(options.target)) {
            if (this.traceListener?.precompile !== void 0) {
              try {
                this.traceListener.precompile({
                  depth: options.message.depth + 1,
                  address: options.target
                });
              } catch {
              }
            }
            const result2 = (0, precompiles_ts_1.runQRLPrecompile)(options.target, options.input, options.gasLimit, this.gasState.gasRefund);
            if (result2.exceptionError !== void 0) {
              await this.stateManager.revert();
              this.gasState.gasRefund = gasRefundSnapshot;
              return result2;
            }
            await this.stateManager.commit();
            return result2;
          }
          const code = await this.stateManager.getCode(options.target);
          const result = await new _QRLInterpreter({
            stateManager: this.stateManager,
            context,
            gasState: this.gasState,
            allowUnlimitedContractSize: this.allowUnlimitedContractSize,
            traceListener: this.traceListener
          }).run(new message_ts_1.QRLMessage({
            caller,
            to: address,
            value: options.value,
            data: options.input,
            code,
            gasLimit: options.gasLimit,
            depth: options.message.depth + 1,
            isStatic: options.isStatic
          }));
          if (result.exceptionError !== void 0) {
            await this.stateManager.revert();
            this.gasState.gasRefund = gasRefundSnapshot;
            return result;
          }
          await this.stateManager.commit();
          return result;
        } catch (error) {
          await this.stateManager.revert();
          this.gasState.gasRefund = gasRefundSnapshot;
          return {
            returnValue: new Uint8Array(0),
            gasUsed: options.gasLimit,
            gasRemaining: 0n,
            gasRefund: 0n,
            exceptionError: error instanceof errors_ts_1.QRLVMError ? error : new errors_ts_1.QRLVMError(error.message)
          };
        }
      }
    };
    exports2.QRLInterpreter = QRLInterpreter;
    function createGasState(options) {
      const accessedAccounts = /* @__PURE__ */ new Set();
      for (const address of options.warmedAccounts ?? []) {
        accessedAccounts.add(address.toHex());
      }
      const accessedStorage = /* @__PURE__ */ new Set();
      for (const access of options.warmedStorage ?? []) {
        accessedStorage.add(storageAccessKey(access.address, access.key));
      }
      return {
        accessedAccounts,
        accessedStorage,
        originalStorage: /* @__PURE__ */ new Map(),
        gasRefund: 0n
      };
    }
    __name(createGasState, "createGasState");
    function nestedCallError(gasLimit, message, gasRefund) {
      return {
        returnValue: new Uint8Array(0),
        gasUsed: 0n,
        gasRemaining: gasLimit,
        gasRefund,
        exceptionError: new errors_ts_1.QRLVMError(message)
      };
    }
    __name(nestedCallError, "nestedCallError");
    function nestedCreateError(address, gasLimit, message) {
      return {
        address,
        result: {
          returnValue: new Uint8Array(0),
          gasUsed: 0n,
          gasRemaining: gasLimit,
          gasRefund: 0n,
          exceptionError: new errors_ts_1.QRLVMError(message)
        }
      };
    }
    __name(nestedCreateError, "nestedCreateError");
    function success(stack, gasLimit, gasUsed, gasRefund, returnValue = new Uint8Array(0), logs = []) {
      return {
        returnValue,
        gasUsed,
        gasRemaining: gasRemaining(gasLimit, gasUsed),
        gasRefund,
        stack,
        logs: logs.map(copyExecutionLog)
      };
    }
    __name(success, "success");
    function isValidDeployedCode(code) {
      return code.length <= gas_ts_1.QRL_MAX_CODE_SIZE && code[0] !== 239;
    }
    __name(isValidDeployedCode, "isValidDeployedCode");
    function storageAccessKey(address, key) {
      return address.toHex() + ":" + bytesToHex2(key);
    }
    __name(storageAccessKey, "storageAccessKey");
    function bytesToHex2(bytes) {
      return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
    }
    __name(bytesToHex2, "bytesToHex");
    function equalBytes(left, right) {
      if (left.length !== right.length) {
        return false;
      }
      for (let i = 0; i < left.length; i++) {
        if (left[i] !== right[i]) {
          return false;
        }
      }
      return true;
    }
    __name(equalBytes, "equalBytes");
    function isEmptyStorageValue(value) {
      return value.every((byte) => byte === 0);
    }
    __name(isEmptyStorageValue, "isEmptyStorageValue");
    function chargeDynamicGas(gasUsed, gasLimit, opcode, memory, options) {
      return consumeGas(gasUsed, gasLimit, (0, gas_ts_1.qrlDynamicGas)(opcode, {
        ...options,
        memoryCurrentBytes: memory.length()
      }));
    }
    __name(chargeDynamicGas, "chargeDynamicGas");
    function consumeGas(gasUsed, gasLimit, gasCost) {
      const nextGasUsed = gasUsed + gasCost;
      if (nextGasUsed > gasLimit) {
        throw new errors_ts_1.QRLVMError("QRL out of gas");
      }
      return nextGasUsed;
    }
    __name(consumeGas, "consumeGas");
    function gasRemaining(gasLimit, gasUsed) {
      return gasUsed > gasLimit ? 0n : gasLimit - gasUsed;
    }
    __name(gasRemaining, "gasRemaining");
    function memoryTarget(offset, size) {
      if (size === 0) {
        return 0n;
      }
      return BigInt(offset) + BigInt(size);
    }
    __name(memoryTarget, "memoryTarget");
    function exponentByteLength(exponent) {
      const bytes = exponent.toBytes64();
      const firstNonZero = bytes.findIndex((byte) => byte !== 0);
      return firstNonZero === -1 ? 0 : bytes.length - firstNonZero;
    }
    __name(exponentByteLength, "exponentByteLength");
    function binary(stack, op) {
      const a = stack.pop();
      const b = stack.pop();
      stack.push(op(a, b));
    }
    __name(binary, "binary");
    function ternary(stack, op) {
      const a = stack.pop();
      const b = stack.pop();
      const c = stack.pop();
      stack.push(op(a, b, c));
    }
    __name(ternary, "ternary");
    function popCreateArgs(stack) {
      return {
        value: stack.pop().toBigInt(),
        offset: toSafeNumber(stack.pop()),
        size: toSafeNumber(stack.pop())
      };
    }
    __name(popCreateArgs, "popCreateArgs");
    function popCreate2Args(stack) {
      return {
        value: stack.pop().toBigInt(),
        offset: toSafeNumber(stack.pop()),
        size: toSafeNumber(stack.pop()),
        salt: stack.pop().toBytes64()
      };
    }
    __name(popCreate2Args, "popCreate2Args");
    function popCallArgs(stack) {
      return {
        gasLimit: stack.pop().toBigInt(),
        target: util_1.qrl.QRLAddress.fromBytes(stack.pop().toBytes64()),
        value: stack.pop().toBigInt(),
        inOffset: toSafeNumber(stack.pop()),
        inSize: toSafeNumber(stack.pop()),
        outOffset: toSafeNumber(stack.pop()),
        outSize: toSafeNumber(stack.pop())
      };
    }
    __name(popCallArgs, "popCallArgs");
    function popStaticCallArgs(stack) {
      return {
        gasLimit: stack.pop().toBigInt(),
        target: util_1.qrl.QRLAddress.fromBytes(stack.pop().toBytes64()),
        inOffset: toSafeNumber(stack.pop()),
        inSize: toSafeNumber(stack.pop()),
        outOffset: toSafeNumber(stack.pop()),
        outSize: toSafeNumber(stack.pop())
      };
    }
    __name(popStaticCallArgs, "popStaticCallArgs");
    function copyCallReturnData(memory, outOffset, outSize, result) {
      const returnData = new Uint8Array(result.returnValue);
      const copySize = Math.min(outSize, returnData.length);
      if (copySize > 0) {
        memory.set(outOffset, copySize, returnData.subarray(0, copySize));
      }
      return returnData;
    }
    __name(copyCallReturnData, "copyCallReturnData");
    function popLog(stack, topicCount, address, isStatic) {
      if (isStatic) {
        throw new errors_ts_1.QRLVMError("QRL static execution cannot emit logs");
      }
      const offset = toSafeNumber(stack.pop());
      const dataSize = toSafeNumber(stack.pop());
      const topics = [];
      for (let i = 0; i < topicCount; i++) {
        topics.push(stack.pop().toBytes64());
      }
      return {
        address: util_1.qrl.QRLAddress.fromBytes(address.toBytes()),
        topics,
        data: new Uint8Array(0),
        offset,
        dataSize
      };
    }
    __name(popLog, "popLog");
    function copyExecutionLog(log) {
      return {
        address: util_1.qrl.QRLAddress.fromBytes(log.address.toBytes()),
        topics: log.topics.map((topic) => new Uint8Array(topic)),
        data: new Uint8Array(log.data)
      };
    }
    __name(copyExecutionLog, "copyExecutionLog");
    function pushAddress(stack, address) {
      stack.push(uint512_ts_1.QRLUint512.fromBytes(address.toBytes()));
    }
    __name(pushAddress, "pushAddress");
    function toSafeNumber(value) {
      const bigint = value.toBigInt();
      if (bigint > BigInt(Number.MAX_SAFE_INTEGER)) {
        throw new errors_ts_1.QRLVMError(`QRL value exceeds safe JS integer=${bigint.toString()}`);
      }
      return Number(bigint);
    }
    __name(toSafeNumber, "toSafeNumber");
    function readPadded(source, offset, size) {
      const out = new Uint8Array(size);
      if (offset < source.length) {
        out.set(source.subarray(offset, offset + size));
      }
      return out;
    }
    __name(readPadded, "readPadded");
    function readReturnData(source, offset, size) {
      if (offset + size > source.length) {
        throw new errors_ts_1.QRLVMError(`QRL return data copy out of bounds offset=${offset} size=${size} length=${source.length}`);
      }
      return new Uint8Array(source.subarray(offset, offset + size));
    }
    __name(readReturnData, "readReturnData");
    function collectJumpdests(code) {
      const jumpdests = /* @__PURE__ */ new Set();
      for (let pc = 0; pc < code.length; pc++) {
        const opcode = code[pc];
        if (opcode === 91) {
          jumpdests.add(pc);
        } else if (opcode >= 96 && opcode <= 159) {
          pc += opcode - 95;
        }
      }
      return jumpdests;
    }
    __name(collectJumpdests, "collectJumpdests");
    function assertJumpdest(jumpdests, dest) {
      if (!jumpdests.has(dest)) {
        throw new errors_ts_1.QRLVMError(`Invalid QRL jump destination=${dest}`);
      }
    }
    __name(assertJumpdest, "assertJumpdest");
  }
});

// packages/evm/dist/cjs/qrl/evm.js
var require_evm = __commonJS({
  "packages/evm/dist/cjs/qrl/evm.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLEVM = void 0;
    var statemanager_1 = require_cjs6();
    var interpreter_ts_1 = require_interpreter();
    var message_ts_1 = require_message();
    var QRLEVM = class {
      static {
        __name(this, "QRLEVM");
      }
      constructor(options = {}) {
        this.stateManager = options.stateManager ?? new statemanager_1.qrl.QRLStateManager();
        this.baseContext = {
          ...(0, message_ts_1.defaultQRLExecutionContext)(),
          ...options.context
        };
        this.allowUnlimitedContractSize = options.allowUnlimitedContractSize;
        this.traceListener = options.traceListener;
      }
      async runCode(options) {
        const to = options.to ?? this.baseContext.address;
        const caller = options.caller ?? this.baseContext.caller;
        return this.runMessage({
          to,
          caller,
          origin: options.origin,
          data: options.data,
          code: options.code,
          returnData: options.returnData,
          value: options.value,
          gasLimit: options.gasLimit,
          isStatic: options.isStatic,
          context: options.context,
          warmedAccounts: options.warmedAccounts,
          warmedStorage: options.warmedStorage
        });
      }
      async runCall(options) {
        const code = options.code ?? await this.stateManager.getCode(options.to);
        return this.runMessage({
          ...options,
          caller: options.caller ?? this.baseContext.caller,
          code
        });
      }
      async runMessage(options) {
        const context = {
          ...this.baseContext,
          ...options.context,
          origin: options.origin ?? this.baseContext.origin,
          caller: options.caller,
          address: options.to
        };
        const interpreter = new interpreter_ts_1.QRLInterpreter({
          stateManager: this.stateManager,
          context,
          warmedAccounts: options.warmedAccounts,
          warmedStorage: options.warmedStorage,
          allowUnlimitedContractSize: this.allowUnlimitedContractSize,
          traceListener: this.traceListener
        });
        return interpreter.run(new message_ts_1.QRLMessage({
          caller: options.caller,
          to: options.to,
          value: options.value,
          data: options.data,
          code: options.code,
          returnData: options.returnData,
          gasLimit: options.gasLimit,
          isStatic: options.isStatic
        }));
      }
    };
    exports2.QRLEVM = QRLEVM;
  }
});

// packages/evm/dist/cjs/qrl/result.js
var require_result = __commonJS({
  "packages/evm/dist/cjs/qrl/result.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// packages/evm/dist/cjs/qrl/trace.js
var require_trace = __commonJS({
  "packages/evm/dist/cjs/qrl/trace.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// packages/evm/dist/cjs/qrl/index.js
var require_qrl5 = __commonJS({
  "packages/evm/dist/cjs/qrl/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: /* @__PURE__ */ __name(function() {
          return m[k];
        }, "get") };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_errors4(), exports2);
    __exportStar(require_evm(), exports2);
    __exportStar(require_gas(), exports2);
    __exportStar(require_interpreter(), exports2);
    __exportStar(require_memory(), exports2);
    __exportStar(require_message(), exports2);
    __exportStar(require_precompiles(), exports2);
    __exportStar(require_result(), exports2);
    __exportStar(require_stack(), exports2);
    __exportStar(require_uint512(), exports2);
    __exportStar(require_trace(), exports2);
  }
});

// packages/evm/dist/cjs/index.js
var require_cjs7 = __commonJS({
  "packages/evm/dist/cjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.qrl = void 0;
    exports2.qrl = require_qrl5();
  }
});

// packages/vm/dist/cjs/qrl/address.js
var require_address2 = __commonJS({
  "packages/vm/dist/cjs/qrl/address.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createQRLContractAddress2 = exports2.createQRLContractAddress = void 0;
    var util_1 = require_cjs2();
    exports2.createQRLContractAddress = util_1.qrl.createQRLContractAddress;
    exports2.createQRLContractAddress2 = util_1.qrl.createQRLContractAddress2;
  }
});

// packages/vm/dist/cjs/qrl/context.js
var require_context = __commonJS({
  "packages/vm/dist/cjs/qrl/context.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// packages/vm/dist/cjs/qrl/errors.js
var require_errors5 = __commonJS({
  "packages/vm/dist/cjs/qrl/errors.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLRunTxError = void 0;
    exports2.qrlRunTxError = qrlRunTxError;
    var QRLRunTxError = class extends Error {
      static {
        __name(this, "QRLRunTxError");
      }
      constructor(code, message) {
        super(message);
        this.name = "QRLRunTxError";
        this.code = code;
      }
    };
    exports2.QRLRunTxError = QRLRunTxError;
    function qrlRunTxError(code, message) {
      return new QRLRunTxError(code, message);
    }
    __name(qrlRunTxError, "qrlRunTxError");
  }
});

// packages/vm/dist/cjs/qrl/result.js
var require_result2 = __commonJS({
  "packages/vm/dist/cjs/qrl/result.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// packages/vm/dist/cjs/qrl/receipt.js
var require_receipt2 = __commonJS({
  "packages/vm/dist/cjs/qrl/receipt.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createQRLReceiptFromRunTxResult = createQRLReceiptFromRunTxResult;
    var block_1 = require_cjs5();
    function createQRLReceiptFromRunTxResult(options) {
      const { result } = options;
      return new block_1.qrl.QRLReceipt({
        txHash: result.txHash,
        blockHash: options.blockHash,
        blockNumber: options.blockNumber,
        transactionIndex: options.transactionIndex,
        from: result.sender,
        to: result.to,
        createdAddress: result.status === 1 ? result.createdAddress : void 0,
        status: result.status,
        gasUsed: result.gasUsed,
        cumulativeGasUsed: options.cumulativeGasUsed ?? result.gasUsed,
        effectiveGasPrice: result.effectiveGasPrice,
        logs: options.logs ?? logsFromResult(result)
      });
    }
    __name(createQRLReceiptFromRunTxResult, "createQRLReceiptFromRunTxResult");
    function logsFromResult(result) {
      return (result.logs ?? []).map((log) => new block_1.qrl.QRLLog({
        address: log.address,
        topics: log.topics.map((topic) => new Uint8Array(topic)),
        data: new Uint8Array(log.data)
      }));
    }
    __name(logsFromResult, "logsFromResult");
  }
});

// packages/vm/dist/cjs/qrl/opcodeNames.js
var require_opcodeNames = __commonJS({
  "packages/vm/dist/cjs/qrl/opcodeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.qrlOpcodeName = qrlOpcodeName;
    var NAMED = {
      0: "STOP",
      1: "ADD",
      2: "MUL",
      3: "SUB",
      4: "DIV",
      5: "SDIV",
      6: "MOD",
      7: "SMOD",
      8: "ADDMOD",
      9: "MULMOD",
      10: "EXP",
      11: "SIGNEXTEND",
      16: "LT",
      17: "GT",
      18: "SLT",
      19: "SGT",
      20: "EQ",
      21: "ISZERO",
      22: "AND",
      23: "OR",
      24: "XOR",
      25: "NOT",
      26: "BYTE",
      27: "SHL",
      28: "SHR",
      29: "SAR",
      32: "KECCAK256",
      48: "ADDRESS",
      49: "BALANCE",
      50: "ORIGIN",
      51: "CALLER",
      52: "CALLVALUE",
      53: "CALLDATALOAD",
      54: "CALLDATASIZE",
      55: "CALLDATACOPY",
      56: "CODESIZE",
      57: "CODECOPY",
      58: "GASPRICE",
      59: "EXTCODESIZE",
      60: "EXTCODECOPY",
      61: "RETURNDATASIZE",
      62: "RETURNDATACOPY",
      63: "EXTCODEHASH",
      64: "BLOCKHASH",
      65: "COINBASE",
      66: "TIMESTAMP",
      67: "NUMBER",
      68: "PREVRANDAO",
      69: "GASLIMIT",
      70: "CHAINID",
      71: "SELFBALANCE",
      72: "BASEFEE",
      80: "POP",
      81: "MLOAD",
      82: "MSTORE",
      83: "MSTORE8",
      84: "SLOAD",
      85: "SSTORE",
      86: "JUMP",
      87: "JUMPI",
      88: "PC",
      89: "MSIZE",
      90: "GAS",
      91: "JUMPDEST",
      95: "PUSH0",
      240: "CREATE",
      241: "CALL",
      243: "RETURN",
      244: "DELEGATECALL",
      245: "CREATE2",
      250: "STATICCALL",
      253: "REVERT",
      254: "INVALID"
    };
    function qrlOpcodeName(opcode) {
      const named = NAMED[opcode];
      if (named !== void 0) {
        return named;
      }
      if (opcode >= 96 && opcode <= 159) {
        return `PUSH${opcode - 95}`;
      }
      if (opcode >= 160 && opcode <= 175) {
        return `DUP${opcode - 159}`;
      }
      if (opcode >= 176 && opcode <= 191) {
        return `SWAP${opcode - 175}`;
      }
      if (opcode >= 192 && opcode <= 196) {
        return `LOG${opcode - 192}`;
      }
      return `UNKNOWN(0x${opcode.toString(16).padStart(2, "0")})`;
    }
    __name(qrlOpcodeName, "qrlOpcodeName");
  }
});

// packages/vm/dist/cjs/qrl/runTx.js
var require_runTx = __commonJS({
  "packages/vm/dist/cjs/qrl/runTx.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.runQRLTx = runQRLTx;
    exports2.effectiveQrlGasPrice = effectiveQrlGasPrice;
    exports2.qrlIntrinsicGas = qrlIntrinsicGas;
    var evm_1 = require_cjs7();
    var util_1 = require_cjs2();
    var address_ts_1 = require_address2();
    var errors_ts_1 = require_errors5();
    async function runQRLTx(options) {
      const { tx, stateManager } = options;
      const context = normalizeContext(options.context);
      const sender = await resolveSender(options);
      validateChainId(tx, context);
      const effectiveGasPrice = effectiveQrlGasPrice(tx, context);
      if (options.skipNonce !== true) {
        await validateNonce(stateManager, sender, tx.nonce);
      }
      validateQrlInitCodeSize(tx);
      const intrinsicGas = qrlIntrinsicGas(tx);
      if (tx.gasLimit < intrinsicGas) {
        throw (0, errors_ts_1.qrlRunTxError)("INTRINSIC_GAS_TOO_LOW", "QRL transaction gas limit is below intrinsic gas");
      }
      const executionGasLimit = tx.gasLimit - intrinsicGas;
      const maxGasCost = tx.gasLimit * tx.gasFeeCap;
      const upfrontCost = maxGasCost + tx.value;
      if (options.skipBalance !== true && await stateManager.getBalance(sender) < upfrontCost) {
        throw (0, errors_ts_1.qrlRunTxError)("INSUFFICIENT_FUNDS", "QRL sender has insufficient funds");
      }
      const evm = options.evm ?? new evm_1.qrl.QRLEVM({ stateManager });
      let createdAddress;
      if (tx.isContractCreation()) {
        const createNonce = await stateManager.getNonce(sender);
        createdAddress = (0, address_ts_1.createQRLContractAddress)(sender, createNonce);
        await ensureNoContractCollision(stateManager, createdAddress);
      }
      const warmedAccounts = qrlTxWarmedAccounts(tx, sender, context);
      const warmedStorage = qrlTxWarmedStorage(tx);
      await stateManager.subBalance(sender, tx.gasLimit * effectiveGasPrice);
      await stateManager.incrementNonce(sender);
      await stateManager.checkpoint();
      try {
        let execution;
        if (tx.isContractCreation()) {
          await transferValue(stateManager, sender, createdAddress, tx.value);
          execution = await evm.runCode({
            to: createdAddress,
            caller: sender,
            origin: sender,
            code: tx.data,
            value: tx.value,
            gasLimit: executionGasLimit,
            warmedAccounts,
            warmedStorage,
            context: {
              coinbase: context.coinbase,
              blockNumber: context.blockNumber,
              timestamp: context.timestamp,
              gasLimit: context.gasLimit,
              chainId: context.chainId,
              baseFee: context.baseFee,
              gasPrice: effectiveGasPrice
            }
          });
          if (execution.exceptionError === void 0) {
            if (evm.allowUnlimitedContractSize !== true && !isValidDeployedCode(execution.returnValue)) {
              execution = {
                ...execution,
                exceptionError: new evm_1.qrl.QRLVMError("QRL invalid deployed code")
              };
            } else {
              await stateManager.putCode(createdAddress, execution.returnValue);
            }
          }
        } else {
          await transferValue(stateManager, sender, tx.to, tx.value);
          execution = await evm.runCall({
            to: tx.to,
            caller: sender,
            origin: sender,
            data: tx.data,
            value: tx.value,
            gasLimit: executionGasLimit,
            warmedAccounts,
            warmedStorage,
            context: {
              coinbase: context.coinbase,
              blockNumber: context.blockNumber,
              timestamp: context.timestamp,
              gasLimit: context.gasLimit,
              chainId: context.chainId,
              baseFee: context.baseFee,
              gasPrice: effectiveGasPrice
            }
          });
        }
        if (execution.exceptionError !== void 0) {
          await stateManager.revert();
          await refundRemainingGas(stateManager, sender, execution, intrinsicGas, effectiveGasPrice);
          return buildResult(tx, sender, effectiveGasPrice, execution, intrinsicGas, 0, createdAddress);
        }
        await refundRemainingGas(stateManager, sender, execution, intrinsicGas, effectiveGasPrice);
        await stateManager.commit();
        return buildResult(tx, sender, effectiveGasPrice, execution, intrinsicGas, 1, createdAddress);
      } catch (error) {
        await stateManager.revert();
        throw error;
      }
    }
    __name(runQRLTx, "runQRLTx");
    function effectiveQrlGasPrice(tx, context) {
      if (context.noBaseFee && tx.gasFeeCap === 0n && tx.gasTipCap === 0n) {
        return 0n;
      }
      if (tx.gasFeeCap < tx.gasTipCap) {
        throw (0, errors_ts_1.qrlRunTxError)("FEE_CAP_BELOW_TIP", "QRL gas fee cap is below gas tip cap");
      }
      if (tx.gasFeeCap < context.baseFee) {
        throw (0, errors_ts_1.qrlRunTxError)("FEE_CAP_BELOW_BASE_FEE", "QRL gas fee cap is below base fee");
      }
      const tipPlusBaseFee = tx.gasTipCap + context.baseFee;
      return tipPlusBaseFee < tx.gasFeeCap ? tipPlusBaseFee : tx.gasFeeCap;
    }
    __name(effectiveQrlGasPrice, "effectiveQrlGasPrice");
    async function resolveSender(options) {
      if (options.sender !== void 0) {
        return options.sender;
      }
      if (options.signer !== void 0) {
        return options.signer.sender(options.tx);
      }
      throw (0, errors_ts_1.qrlRunTxError)("MISSING_SENDER", "QRL transaction execution requires sender or signer");
    }
    __name(resolveSender, "resolveSender");
    function normalizeContext(context = { chainId: 1n }) {
      return {
        chainId: context.chainId,
        baseFee: context.baseFee ?? 0n,
        coinbase: context.coinbase ?? util_1.qrl.QRLAddress.zero(),
        blockNumber: context.blockNumber ?? 0n,
        timestamp: context.timestamp ?? 0n,
        gasLimit: context.gasLimit ?? 0n,
        noBaseFee: context.noBaseFee ?? true
      };
    }
    __name(normalizeContext, "normalizeContext");
    function validateChainId(tx, context) {
      if (tx.chainId !== context.chainId) {
        throw (0, errors_ts_1.qrlRunTxError)("WRONG_CHAIN_ID", "QRL transaction chain id does not match context");
      }
    }
    __name(validateChainId, "validateChainId");
    async function validateNonce(stateManager, sender, txNonce) {
      const stateNonce = await stateManager.getNonce(sender);
      if (stateNonce < txNonce) {
        throw (0, errors_ts_1.qrlRunTxError)("NONCE_TOO_HIGH", "QRL transaction nonce is higher than state nonce");
      }
      if (stateNonce > txNonce) {
        throw (0, errors_ts_1.qrlRunTxError)("NONCE_TOO_LOW", "QRL transaction nonce is lower than state nonce");
      }
    }
    __name(validateNonce, "validateNonce");
    async function transferValue(stateManager, from, to, value) {
      if (value === 0n) {
        return;
      }
      await stateManager.subBalance(from, value);
      await stateManager.addBalance(to, value);
    }
    __name(transferValue, "transferValue");
    async function refundRemainingGas(stateManager, sender, execution, intrinsicGas, effectiveGasPrice) {
      const refundableGas = execution.gasRemaining + cappedGasRefund(execution, intrinsicGas);
      const refund = refundableGas * effectiveGasPrice;
      if (refund > 0n) {
        await stateManager.addBalance(sender, refund);
      }
    }
    __name(refundRemainingGas, "refundRemainingGas");
    function qrlTxWarmedAccounts(tx, sender, context) {
      const accounts = [sender, context.coinbase];
      if (tx.to !== void 0) {
        accounts.push(tx.to);
      }
      return accounts;
    }
    __name(qrlTxWarmedAccounts, "qrlTxWarmedAccounts");
    function qrlTxWarmedStorage(tx) {
      return tx.accessList.flatMap((tuple) => tuple.storageKeys.map((key) => ({
        address: tuple.address,
        key
      })));
    }
    __name(qrlTxWarmedStorage, "qrlTxWarmedStorage");
    function validateQrlInitCodeSize(tx) {
      if (tx.isContractCreation() && tx.data.length > evm_1.qrl.QRL_MAX_INIT_CODE_SIZE) {
        throw (0, errors_ts_1.qrlRunTxError)("INIT_CODE_SIZE_EXCEEDED", "QRL init code size exceeds limit");
      }
    }
    __name(validateQrlInitCodeSize, "validateQrlInitCodeSize");
    function qrlIntrinsicGas(tx) {
      let gas = tx.isContractCreation() ? 53000n : 21000n;
      for (const byte of tx.data) {
        gas += byte === 0 ? 4n : 16n;
      }
      if (tx.isContractCreation()) {
        gas += evm_1.qrl.qrlCreateInitCodeGas(tx.data.length);
      }
      for (const tuple of tx.accessList) {
        gas += 2400n + BigInt(tuple.storageKeys.length) * 1900n;
      }
      return gas;
    }
    __name(qrlIntrinsicGas, "qrlIntrinsicGas");
    function isValidDeployedCode(code) {
      return code.length <= evm_1.qrl.QRL_MAX_CODE_SIZE && code[0] !== 239;
    }
    __name(isValidDeployedCode, "isValidDeployedCode");
    function chargedGasUsed(execution, intrinsicGas) {
      return intrinsicGas + execution.gasUsed - cappedGasRefund(execution, intrinsicGas);
    }
    __name(chargedGasUsed, "chargedGasUsed");
    function cappedGasRefund(execution, intrinsicGas) {
      const maxRefund = (intrinsicGas + execution.gasUsed) / 5n;
      return execution.gasRefund < maxRefund ? execution.gasRefund : maxRefund;
    }
    __name(cappedGasRefund, "cappedGasRefund");
    async function ensureNoContractCollision(stateManager, address) {
      if (await stateManager.getNonce(address) !== 0n || await stateManager.getCodeSize(address) !== 0) {
        throw (0, errors_ts_1.qrlRunTxError)("CONTRACT_ADDRESS_COLLISION", "QRL contract address collision");
      }
    }
    __name(ensureNoContractCollision, "ensureNoContractCollision");
    function buildResult(tx, sender, effectiveGasPrice, execution, intrinsicGas, status, createdAddress) {
      return {
        txHash: tx.hash(),
        sender,
        to: tx.to,
        createdAddress,
        returnValue: new Uint8Array(execution.returnValue),
        gasUsed: chargedGasUsed(execution, intrinsicGas),
        gasRemaining: execution.gasRemaining + cappedGasRefund(execution, intrinsicGas),
        gasRefund: execution.gasRefund,
        totalGasSpent: chargedGasUsed(execution, intrinsicGas) * effectiveGasPrice,
        effectiveGasPrice,
        executionError: execution.exceptionError,
        status,
        logs: (execution.logs ?? []).map(copyExecutionLog)
      };
    }
    __name(buildResult, "buildResult");
    function copyExecutionLog(log) {
      return {
        address: util_1.qrl.QRLAddress.fromBytes(log.address.toBytes()),
        topics: log.topics.map((topic) => new Uint8Array(topic)),
        data: new Uint8Array(log.data)
      };
    }
    __name(copyExecutionLog, "copyExecutionLog");
  }
});

// packages/vm/dist/cjs/qrl/tracer.js
var require_tracer = __commonJS({
  "packages/vm/dist/cjs/qrl/tracer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createRawStructLogCollector = createRawStructLogCollector;
    exports2.createFrameCollector = createFrameCollector;
    function createRawStructLogCollector(config = {}) {
      const steps = [];
      const includeStack = config.disableStack !== true;
      const includeMemory = config.enableMemory === true;
      const finalStepCost = /* @__PURE__ */ new Map();
      const frameStack = [{}];
      const stepLimit = config.limit !== void 0 && config.limit > 0 ? config.limit : void 0;
      const postLimitNextGas = /* @__PURE__ */ new Map();
      const listener = {
        step: /* @__PURE__ */ __name((step) => {
          if (stepLimit !== void 0 && steps.length >= stepLimit) {
            const frame2 = frameStack[step.depth];
            if (frame2 !== void 0) {
              frame2.truncated = true;
            }
            if (!postLimitNextGas.has(step.depth)) {
              postLimitNextGas.set(step.depth, step.gasLeft);
            }
            return;
          }
          const frame = frameStack[step.depth];
          if (frame !== void 0) {
            frame.lastStepIndex = steps.length;
          }
          steps.push({
            pc: step.pc,
            opcode: step.opcode,
            depth: step.depth,
            gasLeft: step.gasLeft,
            stack: includeStack ? step.stack().map((value) => value.toBigInt()) : void 0,
            memory: includeMemory ? step.memory() : void 0
          });
        }, "step"),
        enterFrame: /* @__PURE__ */ __name((frame) => {
          frameStack.push({ gasLimit: frame.gasLimit });
        }, "enterFrame"),
        exitFrame: /* @__PURE__ */ __name((frame) => {
          const open = frameStack.pop();
          if (open?.lastStepIndex !== void 0 && open.truncated !== true && open.gasLimit !== void 0 && frame.gasUsed <= open.gasLimit) {
            const leftover = open.gasLimit - frame.gasUsed;
            finalStepCost.set(open.lastStepIndex, steps[open.lastStepIndex].gasLeft - leftover);
          }
        }, "exitFrame")
      };
      function finish(rootExecutionGas) {
        const root = frameStack[0];
        if (root?.lastStepIndex !== void 0 && root.truncated !== true && rootExecutionGas !== void 0 && rootExecutionGas.gasUsed <= rootExecutionGas.gasLimit) {
          const leftover = rootExecutionGas.gasLimit - rootExecutionGas.gasUsed;
          finalStepCost.set(root.lastStepIndex, steps[root.lastStepIndex].gasLeft - leftover);
        }
        return steps.map((step, index) => {
          let gasCost = 0n;
          const exact = finalStepCost.get(index);
          if (exact !== void 0) {
            gasCost = exact;
          } else {
            let resolved = false;
            for (let next = index + 1; next < steps.length; next++) {
              if (steps[next].depth < step.depth) {
                resolved = true;
                break;
              }
              if (steps[next].depth === step.depth) {
                gasCost = step.gasLeft - steps[next].gasLeft;
                resolved = true;
                break;
              }
            }
            if (!resolved) {
              const nextGas = postLimitNextGas.get(step.depth);
              if (nextGas !== void 0) {
                gasCost = step.gasLeft - nextGas;
              }
            }
          }
          return {
            ...step,
            gasCost
          };
        });
      }
      __name(finish, "finish");
      return { listener, finish };
    }
    __name(createRawStructLogCollector, "createRawStructLogCollector");
    function createFrameCollector(root) {
      const stack = [root];
      let lastError;
      const listener = {
        enterFrame: /* @__PURE__ */ __name((frame) => {
          try {
            const child = {
              kind: frame.kind,
              depth: frame.depth,
              from: frame.from,
              target: frame.target,
              input: frame.input,
              value: frame.value,
              gasLimit: frame.gasLimit,
              code: frame.kind === "create" || frame.kind === "create2" ? new Uint8Array(frame.input) : void 0,
              steps: [],
              children: []
            };
            const parent = stack[stack.length - 1];
            parent.children.push(child);
            parent.steps.push(child);
            stack.push(child);
          } catch (error) {
            lastError = asError(error);
          }
        }, "enterFrame"),
        exitFrame: /* @__PURE__ */ __name((frame) => {
          try {
            const current = stack.pop();
            if (current === void 0) {
              return;
            }
            current.returnValue = frame.returnValue;
            current.gasUsed = frame.gasUsed;
            current.errorMessage = frame.exceptionError?.message;
            current.createdAddress = frame.createdAddress;
          } catch (error) {
            lastError = asError(error);
          }
        }, "exitFrame"),
        step: /* @__PURE__ */ __name((step) => {
          try {
            const current = stack[stack.length - 1];
            if (current !== void 0) {
              current.code ?? (current.code = new Uint8Array(step.code));
              current.lastPc = step.pc;
              current.steps.push({ pc: step.pc });
            }
          } catch (error) {
            lastError = asError(error);
          }
        }, "step"),
        precompile: /* @__PURE__ */ __name((frame) => {
          try {
            const current = stack[stack.length - 1];
            if (current !== void 0 && current.depth === frame.depth) {
              current.precompile = frame.address;
            }
          } catch (error) {
            lastError = asError(error);
          }
        }, "precompile")
      };
      return {
        listener,
        root,
        get lastError() {
          return lastError;
        }
      };
    }
    __name(createFrameCollector, "createFrameCollector");
    function asError(error) {
      return error instanceof Error ? error : new Error(String(error));
    }
    __name(asError, "asError");
  }
});

// packages/vm/dist/cjs/qrl/vm.js
var require_vm = __commonJS({
  "packages/vm/dist/cjs/qrl/vm.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.QRLVM = void 0;
    var evm_1 = require_cjs7();
    var statemanager_1 = require_cjs6();
    var runTx_ts_1 = require_runTx();
    var QRLVM = class {
      static {
        __name(this, "QRLVM");
      }
      constructor(options = {}) {
        this.stateManager = options.stateManager ?? new statemanager_1.qrl.QRLStateManager();
        this.evm = options.evm ?? new evm_1.qrl.QRLEVM({ stateManager: this.stateManager });
        this.context = options.context;
      }
      runTx(options) {
        return (0, runTx_ts_1.runQRLTx)({
          ...options,
          stateManager: this.stateManager,
          evm: this.evm,
          context: options.context ?? this.context
        });
      }
    };
    exports2.QRLVM = QRLVM;
  }
});

// packages/vm/dist/cjs/qrl/index.js
var require_qrl6 = __commonJS({
  "packages/vm/dist/cjs/qrl/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: /* @__PURE__ */ __name(function() {
          return m[k];
        }, "get") };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_address2(), exports2);
    __exportStar(require_context(), exports2);
    __exportStar(require_errors5(), exports2);
    __exportStar(require_result2(), exports2);
    __exportStar(require_receipt2(), exports2);
    __exportStar(require_opcodeNames(), exports2);
    __exportStar(require_runTx(), exports2);
    __exportStar(require_tracer(), exports2);
    __exportStar(require_vm(), exports2);
  }
});

// packages/vm/dist/cjs/index.js
var require_cjs8 = __commonJS({
  "packages/vm/dist/cjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.qrl = void 0;
    exports2.qrl = require_qrl6();
  }
});

// qrljs-runtime-entry.js
module.exports = {
  block: require_cjs5(),
  evm: require_cjs7(),
  statemanager: require_cjs6(),
  tx: require_cjs4(),
  util: require_cjs2(),
  vm: require_cjs8()
};
/*! Bundled license information:

@noble/hashes/utils.js:
@noble/hashes/utils.js:
@noble/hashes/utils.js:
@noble/hashes/utils.js:
@noble/hashes/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)
*/
