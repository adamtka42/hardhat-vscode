import { Artifact } from "../../types";
export interface QrlLinkReference {
    sourceName: string;
    libraryName: string;
    start: number;
}
export declare function collectLinkReferences(artifact: Artifact): QrlLinkReference[];
export declare function getNeededLibraryNames(artifact: Artifact): string[];
/**
 * Returns the artifact bytecode with every library placeholder replaced by
 * the corresponding deployed library address. Library names are accepted in
 * bare (`MathLib`) and fully qualified (`contracts/MathLib.hyp:MathLib`)
 * form. Throws when a provided library is unknown or ambiguous, when an
 * address is invalid, or when the bytecode does not contain the expected
 * placeholder at a reported offset.
 */
export declare function linkQrlBytecode(artifact: Artifact, libraries: {
    [libraryName: string]: string;
}): string;
/**
 * Names of the libraries whose placeholders are still present in the
 * bytecode, in fully qualified form. Non-empty means the bytecode cannot be
 * deployed yet.
 */
export declare function getUnresolvedLibraries(artifact: Artifact, bytecode: string): string[];
export declare function assertDeployableBytecode(artifact: Artifact, bytecode: string): void;
//# sourceMappingURL=linking.d.ts.map