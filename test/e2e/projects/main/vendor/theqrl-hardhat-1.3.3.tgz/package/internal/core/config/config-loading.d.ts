import { HardhatArguments, ResolvedHardhatConfig } from "../../../types";
export declare function loadConfigAndTasks(hardhatArguments?: Partial<HardhatArguments>): ResolvedHardhatConfig;
//# sourceMappingURL=config-loading.d.ts.map