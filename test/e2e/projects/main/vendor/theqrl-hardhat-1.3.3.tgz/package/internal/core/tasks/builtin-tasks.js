"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = __importDefault(require("path"));
const plugins_1 = require("../plugins");
function default_1() {
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "..", "..", "builtin-tasks", "clean"));
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "..", "..", "builtin-tasks", "compile"));
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "..", "..", "builtin-tasks", "console"));
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "..", "..", "builtin-tasks", "flatten"));
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "..", "..", "builtin-tasks", "help"));
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "..", "..", "builtin-tasks", "run"));
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "..", "..", "builtin-tasks", "node"));
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "..", "..", "builtin-tasks", "qrl"));
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "..", "..", "builtin-tasks", "test"));
}
exports.default = default_1;
//# sourceMappingURL=builtin-tasks.js.map