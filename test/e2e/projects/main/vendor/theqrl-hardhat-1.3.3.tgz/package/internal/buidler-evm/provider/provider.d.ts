/// <reference types="node" />
import { EventEmitter } from "events";
import { HardhatQrlvmNetworkConfig, IQrlProvider, ProjectPaths } from "../../../types";
export declare class HardhatQrlvmProvider extends EventEmitter implements IQrlProvider {
    private _node?;
    private _qrlModule?;
    private _netModule?;
    private _web3Module?;
    private _evmModule?;
    private _buidlerModule?;
    private _debugModule?;
    private _accounts;
    private readonly _chainId;
    private readonly _blockGasLimit;
    private _stackTracesEnabled;
    private readonly _config;
    private readonly _accountConfigs;
    private readonly _cachePath?;
    private readonly _projectRoot?;
    private _stackTraceDecoder?;
    private _stackTraceCacheMtime?;
    private readonly _mutex;
    private readonly _logger;
    private readonly _loggingEnabled;
    private _methodBeingCollapsed?;
    private _methodCollapsedCount;
    private _consoleLogMessages;
    constructor(config: HardhatQrlvmNetworkConfig, paths?: ProjectPaths);
    send(method: string, params?: any[]): Promise<any>;
    private _sendWithLogging;
    private _logCollapsedMethod;
    private _startCollapsingMethod;
    private _stopCollapsingMethod;
    private _shouldCollapseMethod;
    private _send;
    private _routeRequest;
    private _init;
    private _appendStackTrace;
    private _signWithLocalSeed;
    private _getStackTraceDecoder;
    private _logModuleMessages;
    private _logConsoleLog;
    private _logError;
    private _log;
}
//# sourceMappingURL=provider.d.ts.map