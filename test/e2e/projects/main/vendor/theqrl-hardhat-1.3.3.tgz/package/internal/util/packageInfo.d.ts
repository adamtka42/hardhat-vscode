export declare function getPackageRoot(): Promise<string>;
export interface PackageJson {
    name: string;
    version: string;
    engines: {
        node: string;
    };
}
export declare function getPackageJson(): Promise<PackageJson>;
//# sourceMappingURL=packageInfo.d.ts.map