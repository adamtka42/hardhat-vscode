/**
 * Decoder for the compiler's instruction source maps (the solc-inherited
 * `s:l:f:j` format) and the pc → instruction-index mapping.
 */
export interface QrlSourceLocation {
    offset: number;
    length: number;
    sourceIndex: number;
    jumpType: string;
}
/**
 * Decodes a source map string into one location per instruction. Entries are
 * `;`-separated; empty fields inherit the previous entry's value.
 */
export declare function decodeQrlSourceMap(sourceMap: string): QrlSourceLocation[];
/**
 * Maps every byte offset (pc) of the bytecode to its instruction index.
 *
 * QRL note: PUSH spans `0x60`-`0x9f` (PUSH1-64 for 512-bit words and 64-byte
 * addresses) — an Ethereum-style decoder that stops at 0x7f would
 * desynchronize on every address push.
 */
export declare function buildQrlPcToInstruction(bytecode: Uint8Array): number[];
/** Converts a character offset in the source text to a 1-based line number. */
export declare function offsetToLine(source: string, offset: number): number;
//# sourceMappingURL=source-maps.d.ts.map