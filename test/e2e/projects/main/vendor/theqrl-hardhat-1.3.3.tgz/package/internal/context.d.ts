/// <reference types="node" />
/// <reference types="mocha" />
import { ConfigExtender, HardhatRuntimeEnvironment } from "../types";
import { ExtenderManager } from "./core/config/extenders";
import { TasksDSL } from "./core/tasks/dsl";
export declare type GlobalWithHardhatContext = NodeJS.Global & {
    __hardhatContext: HardhatContext;
};
export declare class HardhatContext {
    static isCreated(): boolean;
    static createHardhatContext(): HardhatContext;
    static getHardhatContext(): HardhatContext;
    static deleteHardhatContext(): void;
    readonly tasksDSL: TasksDSL;
    readonly extendersManager: ExtenderManager;
    environment?: HardhatRuntimeEnvironment;
    readonly loadedPlugins: string[];
    readonly configExtenders: ConfigExtender[];
    setHardhatRuntimeEnvironment(env: HardhatRuntimeEnvironment): void;
    getHardhatRuntimeEnvironment(): HardhatRuntimeEnvironment;
    setPluginAsLoaded(pluginName: string): void;
}
//# sourceMappingURL=context.d.ts.map