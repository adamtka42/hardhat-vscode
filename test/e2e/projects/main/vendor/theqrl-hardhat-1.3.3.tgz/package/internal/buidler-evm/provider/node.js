"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = __importDefault(require("events"));
const util_1 = require("util");
const consoleLogger_1 = require("../stack-traces/consoleLogger");
const blockchain_1 = require("./blockchain");
const errors_1 = require("./errors");
const filter_1 = require("./filter");
const output_1 = require("./output");
// tslint:disable only-hardhat-error
class HardhatNode extends events_1.default {
    constructor(_runtime, vm, _blockchain, localAccounts, _rawTransactionSigner, _context = {}, _automine = true, _consoleLogListener, _allowUnlimitedContractSize, _filterNow = () => Date.now()) {
        super();
        this._runtime = _runtime;
        this._blockchain = _blockchain;
        this._rawTransactionSigner = _rawTransactionSigner;
        this._context = _context;
        this._automine = _automine;
        this._consoleLogListener = _consoleLogListener;
        this._allowUnlimitedContractSize = _allowUnlimitedContractSize;
        this._filterNow = _filterNow;
        this._localAccounts = new Map();
        this._transactionsByHash = new Map();
        this._receiptsByTransactionHash = new Map();
        this._transactionHashToBlockHash = new Map();
        this._stateBeforeByBlock = new Map();
        this._pendingTimeIncrease = global.BigInt(0);
        this._totalTimeIncrement = global.BigInt(0);
        this._pendingTransactions = [];
        this._nextSnapshotId = global.BigInt(1);
        this._snapshots = [];
        this._nextFilterId = global.BigInt(1);
        this._filters = new Map();
        this._nextSubscriptionId = global.BigInt(1);
        this._failedStackTraces = 0;
        this._subscriptions = new Map();
        this._initLocalAccounts(localAccounts);
        this._vm = vm;
        this._stateManager = this._vm.stateManager;
        this._getLatestBlock = util_1.promisify(this._blockchain.getLatestBlock.bind(this._blockchain));
        this._getBlock = util_1.promisify(this._blockchain.getBlock.bind(this._blockchain));
    }
    static async create(runtime, options = {}) {
        var _a, _b;
        const localAccounts = (_a = options.accounts) !== null && _a !== void 0 ? _a : [];
        const genesis = Object.assign({}, options.genesis);
        for (const account of localAccounts) {
            genesis[account.address.toString()] = {
                balance: account.balance,
                nonce: account.nonce,
            };
        }
        const stateManager = new runtime.stateQrl.QRLStateManager({
            genesis,
        });
        const evm = new runtime.evmQrl.QRLEVM({
            stateManager,
            allowUnlimitedContractSize: options.allowUnlimitedContractSize,
            traceListener: consoleLogger_1.createQrlConsoleLogTraceListener(options.consoleLogListener),
        });
        const vm = new runtime.vmQrl.QRLVM({
            stateManager,
            evm,
            context: options.context,
        });
        const blockchain = new blockchain_1.Blockchain();
        const genesisBlock = new runtime.blockQrl.QRLBlock({
            header: Object.assign(Object.assign({}, options.genesisHeader), { number: global.BigInt(0), stateRoot: await stateManager.getStateRoot() }),
        });
        await new Promise((resolve, reject) => {
            blockchain.putBlock(genesisBlock, (error) => {
                if (error !== null) {
                    reject(error);
                }
                else {
                    resolve();
                }
            });
        });
        return new HardhatNode(runtime, vm, blockchain, localAccounts, options.rawTransactionSigner, options.context, (_b = options.automine) !== null && _b !== void 0 ? _b : true, options.consoleLogListener, options.allowUnlimitedContractSize, options.filterNow);
    }
    async getLatestBlock() {
        return this._getLatestBlock();
    }
    async getLatestBlockNumber() {
        return (await this._getLatestBlock()).header.number;
    }
    async getBlockByNumber(blockNumber) {
        return this._getBlock(blockNumber);
    }
    async getBlockByHash(hash) {
        return this._getBlock(hash);
    }
    async getBlockByTransactionHash(hash) {
        const blockHash = this._transactionHashToBlockHash.get(hashKey(hash));
        if (blockHash === undefined) {
            return undefined;
        }
        return this.getBlockByHash(blockHash);
    }
    async getTransactionByHash(hash) {
        var _a;
        return (_a = this._transactionsByHash.get(hashKey(hash))) === null || _a === void 0 ? void 0 : _a.transaction;
    }
    async getIndexedTransactionByHash(hash) {
        return this._transactionsByHash.get(hashKey(hash));
    }
    async getTransactionReceipt(hash) {
        return this._receiptsByTransactionHash.get(hashKey(hash));
    }
    async replayTransaction(hash, traceListener) {
        var _a, _b;
        const receipt = await this.getTransactionReceipt(hash);
        if ((receipt === null || receipt === void 0 ? void 0 : receipt.blockHash) === undefined) {
            throw new errors_1.InvalidInputError("QRL transaction not found or not mined");
        }
        const block = await this.getBlockByHash(receipt.blockHash);
        if (block === undefined) {
            throw new errors_1.InvalidInputError("QRL block not found for transaction");
        }
        const stateBefore = this._stateBeforeByBlock.get(hashKey(block.hash()));
        if (stateBefore === undefined) {
            throw new errors_1.InvalidInputError("QRL historical state for the block is not retained; cannot replay the transaction");
        }
        const stateManager = stateBefore.shallowCopy();
        for (const transaction of block.transactions) {
            const indexed = await this.getIndexedTransactionByHash(transaction.hash());
            if (indexed === undefined) {
                throw new errors_1.InvalidInputError("QRL block transaction is not indexed");
            }
            const isTarget = hashKey(transaction.hash()) === hashKey(hash);
            const vm = this._createVm(stateManager, false, isTarget ? traceListener : undefined);
            const result = await vm.runTx({
                tx: transaction,
                sender: indexed.sender,
                context: {
                    chainId: transaction.chainId,
                    baseFee: block.header.baseFee,
                    coinbase: block.header.coinbase,
                    blockNumber: block.header.number,
                    timestamp: block.header.timestamp,
                    gasLimit: block.header.gasLimit,
                    noBaseFee: (_a = this._context.noBaseFee) !== null && _a !== void 0 ? _a : true,
                },
            });
            if (isTarget) {
                return {
                    gasUsed: result.gasUsed,
                    gasLimit: transaction.gasLimit,
                    returnValue: result.returnValue,
                    failed: result.status === 0,
                    errorMessage: (_b = result.executionError) === null || _b === void 0 ? void 0 : _b.message,
                };
            }
        }
        throw new errors_1.InvalidInputError("QRL transaction not found in its block");
    }
    async traceTransactionFrames(hash) {
        var _a, _b, _c;
        const indexed = await this.getIndexedTransactionByHash(hash);
        if (indexed === undefined) {
            throw new errors_1.InvalidInputError("QRL transaction not found");
        }
        const createFrameCollector = this._runtime.vmQrl.createFrameCollector;
        if (createFrameCollector === undefined) {
            throw new errors_1.InvalidInputError("QRL frame trace collector is unavailable");
        }
        const transaction = indexed.transaction;
        const input = (_a = transaction.data) !== null && _a !== void 0 ? _a : new Uint8Array();
        const value = (_b = transaction.value) !== null && _b !== void 0 ? _b : global.BigInt(0);
        const root = {
            kind: transaction.to === undefined ? "create" : "call",
            depth: 0,
            target: transaction.to,
            from: indexed.sender,
            input,
            value,
            gasLimit: transaction.gasLimit,
            code: transaction.to === undefined ? new Uint8Array(input) : undefined,
            steps: [],
            children: [],
        };
        const collector = createFrameCollector(root);
        const outcome = await this.replayTransaction(hash, collector.listener);
        root.returnValue = outcome.returnValue;
        root.gasUsed = outcome.gasUsed;
        root.errorMessage = outcome.failed
            ? (_c = outcome.errorMessage) !== null && _c !== void 0 ? _c : "execution failed" : undefined;
        if (collector.lastError !== undefined) {
            this._failedStackTraces += 1;
            root.traceError = collector.lastError.message;
        }
        return root;
    }
    async traceCallFrames(call, options = {}) {
        var _a;
        const createFrameCollector = this._runtime.vmQrl.createFrameCollector;
        if (createFrameCollector === undefined) {
            throw new errors_1.InvalidInputError("QRL frame trace collector is unavailable");
        }
        const root = {
            kind: "call",
            depth: 0,
            target: call.to,
            from: call.from,
            input: call.data,
            value: call.value,
            gasLimit: call.gasLimit,
            steps: [],
            children: [],
        };
        const collector = createFrameCollector(root);
        const result = await this.runCall(call, {
            usePendingState: options.usePendingState,
            traceListener: collector.listener,
            emitConsoleLogs: false,
        });
        root.returnValue = result.returnValue;
        root.gasUsed = result.gasUsed;
        root.errorMessage = (_a = result.exceptionError) === null || _a === void 0 ? void 0 : _a.message;
        if (collector.lastError !== undefined) {
            this._failedStackTraces += 1;
            root.traceError = collector.lastError.message;
        }
        return root;
    }
    async traceEstimateGasFrames(transaction, sender, options = {}) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
        const createFrameCollector = this._runtime.vmQrl.createFrameCollector;
        if (createFrameCollector === undefined) {
            throw new errors_1.InvalidInputError("QRL frame trace collector is unavailable");
        }
        const root = {
            kind: transaction.to === undefined ? "create" : "call",
            depth: 0,
            target: transaction.to,
            from: sender,
            input: transaction.data,
            value: transaction.value,
            gasLimit: transaction.gasLimit,
            code: transaction.to === undefined
                ? new Uint8Array(transaction.data)
                : undefined,
            steps: [],
            children: [],
        };
        const collector = createFrameCollector(root);
        const latestBlock = await this._getLatestBlock();
        const one = global.BigInt(1);
        const stateManager = options.usePendingState === true
            ? (_a = this._pendingStateManager) !== null && _a !== void 0 ? _a : this._stateManager : this._stateManager;
        const execution = await this._runTxAndRevertMutations(transaction, {
            sender,
            stateManager,
            vm: this._createVm(stateManager, false, collector.listener),
            context: {
                chainId: (_b = this._context.chainId) !== null && _b !== void 0 ? _b : one,
                baseFee: (_c = this._context.baseFee) !== null && _c !== void 0 ? _c : latestBlock.header.baseFee,
                coinbase: (_d = this._context.coinbase) !== null && _d !== void 0 ? _d : latestBlock.header.coinbase,
                blockNumber: latestBlock.header.number + one,
                timestamp: (_f = (_e = this._context.timestamp) !== null && _e !== void 0 ? _e : this._pendingBlockTimestamp) !== null && _f !== void 0 ? _f : this._calculateNextBlockTimestamp(latestBlock),
                gasLimit: (_g = this._context.gasLimit) !== null && _g !== void 0 ? _g : latestBlock.header.gasLimit,
                noBaseFee: (_h = this._context.noBaseFee) !== null && _h !== void 0 ? _h : true,
            },
        });
        if (execution.runTxResult !== undefined) {
            root.returnValue = execution.runTxResult.returnValue;
            root.gasUsed = execution.runTxResult.gasUsed;
            root.createdAddress = execution.runTxResult.createdAddress;
            root.errorMessage = execution.success
                ? undefined
                : (_k = (_j = execution.runTxResult.executionError) === null || _j === void 0 ? void 0 : _j.message) !== null && _k !== void 0 ? _k : "execution failed";
        }
        else {
            root.errorMessage = (_m = (_l = execution.error) === null || _l === void 0 ? void 0 : _l.message) !== null && _m !== void 0 ? _m : "execution failed";
        }
        if (collector.lastError !== undefined) {
            this._failedStackTraces += 1;
            root.traceError = collector.lastError.message;
        }
        return root;
    }
    async debugTraceCall(call, config = {}, options = {}) {
        var _a;
        const createRawStructLogCollector = this._runtime.vmQrl
            .createRawStructLogCollector;
        const opcodeName = this._runtime.vmQrl.qrlOpcodeName;
        if (createRawStructLogCollector === undefined || opcodeName === undefined) {
            throw new errors_1.InvalidInputError("QRL struct log collector is unavailable");
        }
        const collector = createRawStructLogCollector(config);
        const result = await this.runCall(call, {
            usePendingState: options.usePendingState,
            traceListener: collector.listener,
            emitConsoleLogs: false,
        });
        const outcome = {
            gasUsed: result.gasUsed,
            gasLimit: call.gasLimit,
            returnValue: result.returnValue,
            failed: result.exceptionError !== undefined,
            errorMessage: (_a = result.exceptionError) === null || _a === void 0 ? void 0 : _a.message,
        };
        const steps = collector.finish({
            gasLimit: outcome.gasLimit,
            gasUsed: outcome.gasUsed,
        });
        return output_1.getRpcDebugTrace(outcome, steps, opcodeName);
    }
    async debugTraceTransaction(hash, config = {}) {
        const createRawStructLogCollector = this._runtime.vmQrl
            .createRawStructLogCollector;
        const opcodeName = this._runtime.vmQrl.qrlOpcodeName;
        if (createRawStructLogCollector === undefined || opcodeName === undefined) {
            throw new errors_1.InvalidInputError("QRL struct log collector is unavailable");
        }
        const collector = createRawStructLogCollector(config);
        const outcome = await this.replayTransaction(hash, collector.listener);
        const steps = collector.finish({
            gasLimit: outcome.gasLimit,
            gasUsed: outcome.gasUsed,
        });
        return output_1.getRpcDebugTrace(outcome, steps, opcodeName);
    }
    recordStackTraceFailure() {
        this._failedStackTraces += 1;
    }
    async getStackTraceFailuresCount() {
        return this._failedStackTraces;
    }
    async getAccountBalance(address) {
        return this._stateManager.getBalance(address);
    }
    async getAccountNonce(address) {
        return this._stateManager.getNonce(address);
    }
    async getCode(address) {
        return this._stateManager.getCode(address);
    }
    async getStorageAt(address, key) {
        return this._stateManager.getStorage(address, key);
    }
    async getPendingCode(address) {
        var _a;
        return ((_a = this._pendingStateManager) !== null && _a !== void 0 ? _a : this._stateManager).getCode(address);
    }
    async getPendingStorageAt(address, key) {
        var _a;
        return ((_a = this._pendingStateManager) !== null && _a !== void 0 ? _a : this._stateManager).getStorage(address, key);
    }
    async getBlockGasLimit() {
        var _a;
        const latestBlock = await this._getLatestBlock();
        return (_a = this._context.gasLimit) !== null && _a !== void 0 ? _a : latestBlock.header.gasLimit;
    }
    async getCoinbaseAddress() {
        var _a;
        const latestBlock = await this._getLatestBlock();
        return (_a = this._context.coinbase) !== null && _a !== void 0 ? _a : latestBlock.header.coinbase;
    }
    async getGasPrice() {
        return global.BigInt(0);
    }
    async newFilter(criteria) {
        if (criteria.blockHash !== undefined) {
            throw new errors_1.InvalidArgumentsError("QRL installed log filters do not support blockHash criteria");
        }
        const latest = await this.getLatestBlockNumber();
        return this._registerFilter({
            type: "log",
            criteria,
            minimumBlock: filter_1.resolveInstalledFilterMinimum(criteria.fromBlock),
            nextBlock: filter_1.resolveInstalledFilterStart(criteria.fromBlock, latest),
            deadline: this._filterDeadline(),
        });
    }
    async newBlockFilter() {
        return this._registerFilter({
            type: "block",
            lastBlock: await this.getLatestBlockNumber(),
            deadline: this._filterDeadline(),
        });
    }
    async newPendingTransactionFilter() {
        return this._registerFilter({
            type: "pendingTx",
            reported: new Set(),
            deadline: this._filterDeadline(),
        });
    }
    uninstallFilter(filterId) {
        this._sweepExpiredFilters();
        const deleted = this._filters.delete(filterKey(filterId));
        this._scheduleFilterSweep();
        return deleted;
    }
    async getFilterChanges(filterId) {
        const filter = this._lookupFilter(filterId);
        if (filter === undefined) {
            return undefined;
        }
        const latest = await this.getLatestBlockNumber();
        const one = global.BigInt(1);
        if (filter.type === "block") {
            // tslint:disable-next-line:strict-comparisons
            if (filter.lastBlock > latest) {
                filter.lastBlock = latest;
            }
            const hashes = [];
            for (let number = filter.lastBlock + one; 
            // tslint:disable-next-line:strict-comparisons
            number <= latest; number += one) {
                const block = await this.getBlockByNumber(number);
                if (block !== undefined) {
                    hashes.push(output_1.bufferToRpcData(block.hash()));
                }
            }
            filter.lastBlock = latest;
            return hashes;
        }
        if (filter.type === "pendingTx") {
            const current = new Set();
            const fresh = [];
            for (const transaction of await this.getPendingTransactions()) {
                const hash = output_1.bufferToRpcData(transaction.hash());
                current.add(hash);
                if (!filter.reported.has(hash)) {
                    fresh.push(hash);
                }
            }
            filter.reported = current;
            return fresh;
        }
        const toBlock = filter_1.resolveLogFilterBlock(filter.criteria.toBlock, latest, latest);
        const minedTo = minBigInt(toBlock.number, latest);
        const logs = [];
        for (let number = filter.nextBlock; 
        // tslint:disable-next-line:strict-comparisons
        number <= minedTo; number += one) {
            const block = await this.getBlockByNumber(number);
            if (block !== undefined) {
                logs.push(...formatMatchingLogs(block, filter.criteria));
            }
        }
        // tslint:disable-next-line:strict-comparisons
        if (filter.nextBlock <= minedTo) {
            filter.nextBlock = minedTo + one;
        }
        // tslint:disable-next-line:strict-comparisons
        if (toBlock.includesPending && filter.nextBlock <= latest + one) {
            logs.push(...formatMatchingLogs(await this.getPendingBlock(), filter.criteria));
        }
        return logs;
    }
    async getFilterLogs(filterId) {
        const filter = this._lookupFilter(filterId);
        if (filter === undefined) {
            return undefined;
        }
        if (filter.type !== "log") {
            throw new errors_1.InvalidArgumentsError("QRL getFilterLogs is only supported for log filters");
        }
        return this.getLogs(filter.criteria);
    }
    async getLogs(filter) {
        if (filter.blockHash !== undefined) {
            const block = await this.getBlockByHash(filter.blockHash);
            return block === undefined ? [] : formatMatchingLogs(block, filter);
        }
        const latest = await this.getLatestBlockNumber();
        const zero = global.BigInt(0);
        const one = global.BigInt(1);
        const fromBlock = filter_1.resolveLogFilterBlock(filter.fromBlock, zero, latest);
        const toBlock = filter.toBlock === undefined && filter.fromBlock === "pending"
            ? { number: latest + one, includesPending: true }
            : filter_1.resolveLogFilterBlock(filter.toBlock, latest, latest);
        // tslint:disable-next-line:strict-comparisons
        if (fromBlock.number > toBlock.number) {
            return [];
        }
        const logs = [];
        for (let number = fromBlock.number; 
        // tslint:disable-next-line:strict-comparisons
        number <= toBlock.number && number <= latest; number += one) {
            const block = await this.getBlockByNumber(number);
            if (block !== undefined) {
                logs.push(...formatMatchingLogs(block, filter));
            }
        }
        // tslint:disable-next-line:strict-comparisons
        if (toBlock.includesPending && fromBlock.number <= latest + one) {
            logs.push(...formatMatchingLogs(await this.getPendingBlock(), filter));
        }
        return logs;
    }
    newHeadsSubscription() {
        return this._registerSubscription({ type: "newHeads" });
    }
    newPendingTransactionsSubscription(fullObjects = false) {
        return this._registerSubscription({
            type: "newPendingTransactions",
            fullObjects,
        });
    }
    newLogsSubscription(criteria) {
        if (criteria.blockHash !== undefined) {
            throw new errors_1.InvalidArgumentsError("QRL log subscriptions do not support blockHash criteria");
        }
        const from = filter_1.parseSubscriptionBound(criteria.fromBlock, "fromBlock");
        const to = filter_1.parseSubscriptionBound(criteria.toBlock, "toBlock");
        if (from.kind === "latest" && to.kind === "number") {
            throw new errors_1.InvalidArgumentsError("QRL log subscription has an invalid block range");
        }
        if (from.kind === "number" && to.kind === "number") {
            // tslint:disable-next-line:strict-comparisons
            if (from.value > to.value) {
                throw new errors_1.InvalidArgumentsError("QRL log subscription fromBlock cannot be greater than toBlock");
            }
        }
        return this._registerSubscription({
            type: "logs",
            criteria,
            fromBound: from.kind === "number" ? from.value : undefined,
            toBound: to.kind === "number" ? to.value : undefined,
        });
    }
    unsubscribe(subscriptionId) {
        return this._subscriptions.delete(filterKey(subscriptionId));
    }
    installedSubscriptionCount() {
        return this._subscriptions.size;
    }
    installedFilterCount() {
        return this._filters.size;
    }
    async estimateGas(transaction, sender, options = {}) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const upperBound = transaction.gasLimit;
        const zero = global.BigInt(0);
        // tslint:disable-next-line:strict-comparisons
        if (upperBound <= zero) {
            throw new errors_1.InvalidInputError("gas estimation upper bound must be positive");
        }
        const latestBlock = await this._getLatestBlock();
        const one = global.BigInt(1);
        const latestBlockNumber = latestBlock.header.number;
        const stateManager = options.usePendingState === true
            ? (_a = this._pendingStateManager) !== null && _a !== void 0 ? _a : this._stateManager : this._stateManager;
        const executionContext = {
            sender,
            stateManager,
            vm: this._createVm(stateManager, false),
            context: {
                chainId: (_b = this._context.chainId) !== null && _b !== void 0 ? _b : one,
                baseFee: (_c = this._context.baseFee) !== null && _c !== void 0 ? _c : latestBlock.header.baseFee,
                coinbase: (_d = this._context.coinbase) !== null && _d !== void 0 ? _d : latestBlock.header.coinbase,
                blockNumber: latestBlockNumber + one,
                timestamp: (_f = (_e = this._context.timestamp) !== null && _e !== void 0 ? _e : this._pendingBlockTimestamp) !== null && _f !== void 0 ? _f : this._calculateNextBlockTimestamp(latestBlock),
                gasLimit: (_g = this._context.gasLimit) !== null && _g !== void 0 ? _g : latestBlock.header.gasLimit,
                noBaseFee: (_h = this._context.noBaseFee) !== null && _h !== void 0 ? _h : true,
            },
        };
        const upperTransaction = this._copyTransactionWithGasLimit(transaction, upperBound);
        const upperExecution = await this._runTxAndRevertMutations(upperTransaction, executionContext);
        if (!upperExecution.success) {
            return {
                estimation: upperBound,
                runTxResult: upperExecution.runTxResult,
                error: upperExecution.error,
            };
        }
        const initialEstimation = upperExecution.runTxResult.gasUsed;
        return {
            estimation: await this._correctInitialEstimation(transaction, initialEstimation, upperBound, executionContext),
            runTxResult: upperExecution.runTxResult,
        };
    }
    async getLocalAccountAddresses() {
        return [...this._localAccounts.values()].map((address) => address.toString());
    }
    async runTransaction(transaction, sender) {
        const localSender = this._getLocalAccount(sender);
        return this._automine
            ? this._runTransactionInNewBlock(transaction, localSender)
            : this._runTransactionInPendingBlock(transaction, localSender);
    }
    async runRawTransaction(transaction) {
        const sender = await this._getRawTransactionSender(transaction);
        return this._automine
            ? this._runTransactionInNewBlock(transaction, sender)
            : this._runTransactionInPendingBlock(transaction, sender);
    }
    async runTransactionInNewBlock(transaction, sender) {
        return this._runTransactionInNewBlock(transaction, this._getLocalAccount(sender));
    }
    async runRawTransactionInNewBlock(transaction) {
        const sender = await this._getRawTransactionSender(transaction);
        return this._runTransactionInNewBlock(transaction, sender);
    }
    async getPendingTransactions() {
        return this._pendingTransactions.map((entry) => entry.transaction);
    }
    async getPendingAccountBalance(address) {
        var _a;
        return ((_a = this._pendingStateManager) !== null && _a !== void 0 ? _a : this._stateManager).getBalance(address);
    }
    async getPendingAccountNonce(address) {
        var _a;
        return ((_a = this._pendingStateManager) !== null && _a !== void 0 ? _a : this._stateManager).getNonce(address);
    }
    async getPendingBlock() {
        var _a, _b;
        const latestBlock = await this._getLatestBlock();
        const timestamp = (_a = this._pendingBlockTimestamp) !== null && _a !== void 0 ? _a : this._calculateNextBlockTimestamp(latestBlock);
        return this._buildBlockFromPending(latestBlock, timestamp, (_b = this._pendingStateManager) !== null && _b !== void 0 ? _b : this._stateManager);
    }
    async mineBlock(options = {}) {
        if (this._pendingTransactions.length === 0) {
            return this.mineEmptyBlock(options);
        }
        if (hasBlockOverrides(options)) {
            throw new errors_1.InvalidInputError("cannot override block options while pending transactions exist");
        }
        return this._minePendingBlock();
    }
    async setNextBlockTimestamp(timestamp) {
        var _a;
        const latestBlock = await this._getLatestBlock();
        const latestBlockTimestamp = latestBlock.header.timestamp;
        const lowerBound = (_a = this._pendingBlockTimestamp) !== null && _a !== void 0 ? _a : latestBlockTimestamp;
        // tslint:disable-next-line:strict-comparisons
        if (timestamp <= lowerBound) {
            throw new errors_1.InvalidInputError(`timestamp ${timestamp} is not greater than the next block timestamp lower bound ${lowerBound}`);
        }
        this._nextBlockTimestamp = timestamp;
    }
    async increaseTime(increment) {
        const zero = global.BigInt(0);
        // tslint:disable-next-line:strict-comparisons
        if (increment < zero) {
            throw new errors_1.InvalidInputError("time increase must not be negative");
        }
        this._pendingTimeIncrease += increment;
        this._totalTimeIncrement += increment;
        return this._totalTimeIncrement;
    }
    async getTimeIncrement() {
        return this._totalTimeIncrement;
    }
    async getNextBlockTimestamp() {
        return this._nextBlockTimestamp;
    }
    async takeSnapshot() {
        var _a;
        const id = this._nextSnapshotId;
        this._nextSnapshotId += global.BigInt(1);
        this._snapshots.push({
            id,
            latestBlock: await this._getLatestBlock(),
            stateManager: this._stateManager.shallowCopy(),
            pendingStateManager: (_a = this._pendingStateManager) === null || _a === void 0 ? void 0 : _a.shallowCopy(),
            pendingTransactions: this._pendingTransactions.map((entry) => (Object.assign(Object.assign({}, entry), { transactionHash: new Uint8Array(entry.transactionHash) }))),
            pendingBlockTimestamp: this._pendingBlockTimestamp,
            pendingTimeIncrease: this._pendingTimeIncrease,
            totalTimeIncrement: this._totalTimeIncrement,
            nextBlockTimestamp: this._nextBlockTimestamp,
            transactionsByHash: new Map(this._transactionsByHash),
            receiptsByTransactionHash: new Map(this._receiptsByTransactionHash),
            transactionHashToBlockHash: cloneHashMap(this._transactionHashToBlockHash),
            stateBeforeByBlock: new Map(this._stateBeforeByBlock),
        });
        return id;
    }
    async revertToSnapshot(id) {
        var _a;
        const snapshotIndex = this._snapshots.findIndex((candidate) => candidate.id === id);
        if (snapshotIndex === -1) {
            return false;
        }
        const snapshot = this._snapshots[snapshotIndex];
        const removedBlocks = await this._getBlocksAfter(snapshot.latestBlock.header.number);
        this._blockchain.deleteAllFollowingBlocks(snapshot.latestBlock);
        this._replaceStateManager(snapshot.stateManager.shallowCopy());
        this._pendingTransactions.splice(0, this._pendingTransactions.length, ...snapshot.pendingTransactions);
        this._pendingStateManager = (_a = snapshot.pendingStateManager) === null || _a === void 0 ? void 0 : _a.shallowCopy();
        this._pendingVm =
            this._pendingStateManager === undefined
                ? undefined
                : this._createVm(this._pendingStateManager);
        this._pendingBlockTimestamp = snapshot.pendingBlockTimestamp;
        this._pendingTimeIncrease = snapshot.pendingTimeIncrease;
        this._totalTimeIncrement = snapshot.totalTimeIncrement;
        this._nextBlockTimestamp = snapshot.nextBlockTimestamp;
        replaceMap(this._transactionsByHash, snapshot.transactionsByHash);
        replaceMap(this._receiptsByTransactionHash, snapshot.receiptsByTransactionHash);
        replaceMap(this._transactionHashToBlockHash, cloneHashMap(snapshot.transactionHashToBlockHash));
        replaceMap(this._stateBeforeByBlock, snapshot.stateBeforeByBlock);
        this._resetFilterCursors(snapshot.latestBlock.header.number);
        for (const block of removedBlocks) {
            this._notifyRemovedLogSubscriptions(block);
        }
        this._snapshots.splice(snapshotIndex);
        return true;
    }
    async mineEmptyBlock(options = {}) {
        var _a, _b, _c, _d, _e, _f;
        const latestBlock = await this._getLatestBlock();
        const one = global.BigInt(1);
        const latestBlockNumber = latestBlock.header.number;
        const timestamp = this._calculateNextBlockTimestamp(latestBlock, options.timestamp);
        const transactions = [];
        const receipts = [];
        const transactionsRoot = await this._runtime.blockQrl.genQRLTransactionsRoot(transactions);
        const receiptsRoot = await this._runtime.blockQrl.genQRLReceiptsRoot(receipts);
        const stateRoot = await this._stateManager.getStateRoot();
        const block = new this._runtime.blockQrl.QRLBlock({
            header: {
                parentHash: latestBlock.hash(),
                number: latestBlockNumber + one,
                timestamp,
                gasLimit: (_b = (_a = options.gasLimit) !== null && _a !== void 0 ? _a : this._context.gasLimit) !== null && _b !== void 0 ? _b : latestBlock.header.gasLimit,
                baseFee: (_d = (_c = options.baseFee) !== null && _c !== void 0 ? _c : this._context.baseFee) !== null && _d !== void 0 ? _d : latestBlock.header.baseFee,
                coinbase: (_f = (_e = options.coinbase) !== null && _e !== void 0 ? _e : this._context.coinbase) !== null && _f !== void 0 ? _f : latestBlock.header.coinbase,
                transactionsRoot,
                receiptsRoot,
                stateRoot,
            },
            transactions,
            receipts,
        });
        await this._putBlock(block);
        this._consumeTimeControls(options.timestamp);
        this._notifyBlockSubscriptions(block);
        return block;
    }
    async runCall(call, options = {}) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        const latestBlock = await this._getLatestBlock();
        const usePendingState = options.usePendingState === true;
        const one = global.BigInt(1);
        const stateManager = usePendingState
            ? (_a = this._pendingStateManager) !== null && _a !== void 0 ? _a : this._stateManager : this._stateManager;
        const vm = options.traceListener !== undefined
            ? this._createVm(stateManager, (_b = options.emitConsoleLogs) !== null && _b !== void 0 ? _b : false, options.traceListener)
            : stateManager === this._stateManager
                ? this._vm
                : (_c = this._pendingVm) !== null && _c !== void 0 ? _c : this._createVm(stateManager);
        await stateManager.checkpoint();
        try {
            if (call.value !== global.BigInt(0)) {
                await stateManager.subBalance(call.from, call.value);
                await stateManager.addBalance(call.to, call.value);
            }
            return await vm.evm.runCall({
                to: call.to,
                caller: call.from,
                origin: call.from,
                data: call.data,
                value: call.value,
                gasLimit: call.gasLimit,
                context: {
                    coinbase: (_d = this._context.coinbase) !== null && _d !== void 0 ? _d : latestBlock.header.coinbase,
                    blockNumber: usePendingState
                        ? latestBlock.header.number + one
                        : latestBlock.header.number,
                    timestamp: (_e = this._context.timestamp) !== null && _e !== void 0 ? _e : (usePendingState
                        ? (_f = this._pendingBlockTimestamp) !== null && _f !== void 0 ? _f : this._calculateNextBlockTimestamp(latestBlock) : latestBlock.header.timestamp),
                    gasLimit: (_g = this._context.gasLimit) !== null && _g !== void 0 ? _g : latestBlock.header.gasLimit,
                    chainId: (_h = this._context.chainId) !== null && _h !== void 0 ? _h : global.BigInt(1),
                    baseFee: (_j = this._context.baseFee) !== null && _j !== void 0 ? _j : latestBlock.header.baseFee,
                    gasPrice: call.gasPrice,
                },
            });
        }
        finally {
            await stateManager.revert();
        }
    }
    async _correctInitialEstimation(transaction, initialEstimation, upperBound, executionContext) {
        const initialTransaction = this._copyTransactionWithGasLimit(transaction, initialEstimation);
        const initialExecution = await this._runTxAndRevertMutations(initialTransaction, executionContext);
        if (initialExecution.success) {
            return initialEstimation;
        }
        return this._binarySearchEstimation(transaction, initialEstimation, upperBound, executionContext);
    }
    async _binarySearchEstimation(transaction, highestFailingEstimation, lowestSuccessfulEstimation, executionContext, roundNumber = 0) {
        // tslint:disable-next-line:strict-comparisons
        if (lowestSuccessfulEstimation <= highestFailingEstimation) {
            return lowestSuccessfulEstimation;
        }
        const maxRounds = 20;
        const diff = lowestSuccessfulEstimation - highestFailingEstimation;
        const minDiff = minimumGasEstimationDifference(highestFailingEstimation);
        // tslint:disable-next-line:strict-comparisons
        if (diff <= minDiff || roundNumber > maxRounds) {
            return lowestSuccessfulEstimation;
        }
        const two = global.BigInt(2);
        const three = global.BigInt(3);
        const midpoint = highestFailingEstimation + diff / two;
        const optimizedEstimation = roundNumber === 0 ? highestFailingEstimation * three : midpoint;
        const newEstimation = 
        // tslint:disable-next-line:strict-comparisons
        optimizedEstimation > midpoint ? midpoint : optimizedEstimation;
        await new Promise((resolve) => setImmediate(resolve));
        const candidate = this._copyTransactionWithGasLimit(transaction, newEstimation);
        const execution = await this._runTxAndRevertMutations(candidate, executionContext);
        if (execution.success) {
            return this._binarySearchEstimation(transaction, highestFailingEstimation, newEstimation, executionContext, roundNumber + 1);
        }
        return this._binarySearchEstimation(transaction, newEstimation, lowestSuccessfulEstimation, executionContext, roundNumber + 1);
    }
    async _runTxAndRevertMutations(transaction, executionContext) {
        await executionContext.stateManager.checkpoint();
        try {
            const runTxResult = await executionContext.vm.runTx({
                tx: transaction,
                sender: executionContext.sender,
                context: executionContext.context,
                skipBalance: true,
                skipNonce: true,
            });
            const error = runTxResult.executionError;
            return {
                success: error === undefined && runTxResult.status !== 0,
                runTxResult,
                error,
            };
        }
        catch (error) {
            return { success: false, error: error };
        }
        finally {
            await executionContext.stateManager.revert();
        }
    }
    _copyTransactionWithGasLimit(transaction, gasLimit) {
        var _a;
        const Transaction = (_a = this._runtime.txQrl) === null || _a === void 0 ? void 0 : _a.QRLDynamicFeeTransaction;
        if (Transaction === undefined) {
            throw new errors_1.InvalidInputError("QRL transaction constructor is unavailable for gas estimation");
        }
        return new Transaction({
            chainId: transaction.chainId,
            nonce: transaction.nonce,
            gasTipCap: transaction.gasTipCap,
            gasFeeCap: transaction.gasFeeCap,
            gasLimit,
            to: transaction.to,
            value: transaction.value,
            data: transaction.data,
            accessList: transaction.accessList,
            descriptor: transaction.descriptor,
            extraParams: transaction.extraParams,
            signature: transaction.signature,
            publicKey: transaction.publicKey,
        });
    }
    async _buildBlockFromPending(latestBlock, timestamp, stateManager) {
        var _a, _b, _c;
        const one = global.BigInt(1);
        const latestBlockNumber = latestBlock.header.number;
        const blockNumber = latestBlockNumber + one;
        let cumulativeGasUsed = global.BigInt(0);
        const transactions = this._pendingTransactions.map((entry) => entry.transaction);
        const receipts = this._pendingTransactions.map((entry, index) => {
            cumulativeGasUsed += entry.runTxResult.gasUsed;
            return this._runtime.vmQrl.createQRLReceiptFromRunTxResult({
                result: entry.runTxResult,
                blockNumber,
                transactionIndex: index,
                cumulativeGasUsed,
            });
        });
        const transactionsRoot = await this._runtime.blockQrl.genQRLTransactionsRoot(transactions);
        const receiptsRoot = await this._runtime.blockQrl.genQRLReceiptsRoot(receipts);
        const stateRoot = await stateManager.getStateRoot();
        const draftBlock = new this._runtime.blockQrl.QRLBlock({
            header: {
                parentHash: latestBlock.hash(),
                number: blockNumber,
                timestamp,
                gasLimit: (_a = this._context.gasLimit) !== null && _a !== void 0 ? _a : latestBlock.header.gasLimit,
                baseFee: (_b = this._context.baseFee) !== null && _b !== void 0 ? _b : latestBlock.header.baseFee,
                coinbase: (_c = this._context.coinbase) !== null && _c !== void 0 ? _c : latestBlock.header.coinbase,
                transactionsRoot,
                receiptsRoot,
                stateRoot,
            },
            transactions,
            receipts,
        });
        const blockHash = draftBlock.hash();
        let logIndexStart = 0;
        const includedReceipts = receipts.map((receipt, index) => {
            const includedReceipt = receipt.withInclusion({
                blockHash,
                blockNumber,
                transactionIndex: index,
                cumulativeGasUsed: receipt.cumulativeGasUsed,
                logIndexStart,
            });
            logIndexStart += receipt.logs.length;
            return includedReceipt;
        });
        return new this._runtime.blockQrl.QRLBlock({
            header: draftBlock.header,
            transactions,
            receipts: includedReceipts,
        });
    }
    async _minePendingBlock() {
        const stateManager = this._pendingStateManager;
        const timestamp = this._pendingBlockTimestamp;
        if (stateManager === undefined || timestamp === undefined) {
            throw new errors_1.InvalidInputError("Pending block state is unavailable");
        }
        const latestBlock = await this._getLatestBlock();
        const stateBefore = this._stateManager.shallowCopy();
        const block = await this._buildBlockFromPending(latestBlock, timestamp, stateManager);
        let blockWasStored = false;
        try {
            await this._putBlock(block);
            blockWasStored = true;
            this._replaceStateManager(stateManager);
            this._rememberStateBeforeBlock(block, stateBefore);
            this._pendingTransactions.forEach((entry, index) => {
                this._indexMinedTransaction(entry.transactionHash, entry.transaction, entry.sender, block.receipts[index], block);
            });
            this._pendingTransactions.splice(0);
            this._pendingStateManager = undefined;
            this._pendingVm = undefined;
            this._pendingBlockTimestamp = undefined;
            this._notifyBlockSubscriptions(block);
            return block;
        }
        catch (error) {
            if (blockWasStored) {
                await this._deleteBlock(block.hash());
            }
            throw error;
        }
    }
    async _getRawTransactionSender(transaction) {
        var _a;
        const signer = this._rawTransactionSigner;
        if (signer === undefined) {
            throw new errors_1.InvalidInputError("Raw transaction signer is not configured");
        }
        const chainId = (_a = this._context.chainId) !== null && _a !== void 0 ? _a : global.BigInt(1);
        if (transaction.chainId !== chainId) {
            throw new errors_1.InvalidInputError(`Invalid transaction chain id ${transaction.chainId}; expected ${chainId}`);
        }
        let signatureIsValid = false;
        try {
            signatureIsValid = await signer.verify(transaction);
        }
        catch (_error) {
            signatureIsValid = false;
        }
        if (!signatureIsValid) {
            throw new errors_1.InvalidInputError("Invalid transaction signature");
        }
        try {
            return await signer.sender(transaction);
        }
        catch (_error) {
            throw new errors_1.InvalidInputError("Invalid transaction sender");
        }
    }
    async _runTransactionInPendingBlock(transaction, sender) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        const latestBlock = await this._getLatestBlock();
        const isFirstPendingTransaction = this._pendingTransactions.length === 0;
        const timestamp = (_a = this._pendingBlockTimestamp) !== null && _a !== void 0 ? _a : this._calculateNextBlockTimestamp(latestBlock);
        const stateManager = (_b = this._pendingStateManager) !== null && _b !== void 0 ? _b : this._stateManager.shallowCopy();
        const vm = (_c = this._pendingVm) !== null && _c !== void 0 ? _c : this._createVm(stateManager);
        const stateBefore = stateManager.shallowCopy();
        const transactionHash = transaction.hash();
        const one = global.BigInt(1);
        const latestBlockNumber = latestBlock.header.number;
        let runTxResult;
        try {
            runTxResult = await vm.runTx({
                tx: transaction,
                sender,
                context: {
                    chainId: (_d = this._context.chainId) !== null && _d !== void 0 ? _d : global.BigInt(1),
                    baseFee: (_e = this._context.baseFee) !== null && _e !== void 0 ? _e : latestBlock.header.baseFee,
                    coinbase: (_f = this._context.coinbase) !== null && _f !== void 0 ? _f : latestBlock.header.coinbase,
                    blockNumber: latestBlockNumber + one,
                    timestamp,
                    gasLimit: (_g = this._context.gasLimit) !== null && _g !== void 0 ? _g : latestBlock.header.gasLimit,
                    noBaseFee: (_h = this._context.noBaseFee) !== null && _h !== void 0 ? _h : true,
                },
            });
        }
        catch (error) {
            if (!isFirstPendingTransaction) {
                this._pendingStateManager = stateBefore;
                this._pendingVm = this._createVm(stateBefore);
            }
            throw error;
        }
        if (isFirstPendingTransaction) {
            this._pendingStateManager = stateManager;
            this._pendingVm = vm;
            this._pendingBlockTimestamp = timestamp;
            this._consumeTimeControls();
        }
        const actualSender = (_j = runTxResult.sender) !== null && _j !== void 0 ? _j : sender;
        this._pendingTransactions.push({
            transaction,
            transactionHash: new Uint8Array(transactionHash),
            sender: actualSender,
            runTxResult,
        });
        this._transactionsByHash.set(hashKey(transactionHash), {
            transaction,
            sender: actualSender,
        });
        this._notifyPendingTransactionSubscriptions(transaction, actualSender);
        return { transaction, runTxResult };
    }
    async _runTransactionInNewBlock(transaction, sender) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const latestBlock = await this._getLatestBlock();
        const one = global.BigInt(1);
        const latestBlockNumber = latestBlock.header.number;
        const blockNumber = latestBlockNumber + one;
        const timestamp = this._calculateNextBlockTimestamp(latestBlock);
        const transactionHash = transaction.hash();
        const stateBefore = this._stateManager.shallowCopy();
        let storedBlock;
        await this._stateManager.checkpoint();
        try {
            const runTxResult = await this._vm.runTx({
                tx: transaction,
                sender,
                context: {
                    chainId: (_a = this._context.chainId) !== null && _a !== void 0 ? _a : one,
                    baseFee: (_b = this._context.baseFee) !== null && _b !== void 0 ? _b : latestBlock.header.baseFee,
                    coinbase: (_c = this._context.coinbase) !== null && _c !== void 0 ? _c : latestBlock.header.coinbase,
                    blockNumber,
                    timestamp,
                    gasLimit: (_d = this._context.gasLimit) !== null && _d !== void 0 ? _d : latestBlock.header.gasLimit,
                    noBaseFee: (_e = this._context.noBaseFee) !== null && _e !== void 0 ? _e : true,
                },
            });
            const receipt = this._runtime.vmQrl.createQRLReceiptFromRunTxResult({
                result: runTxResult,
                blockNumber,
                transactionIndex: 0,
                cumulativeGasUsed: runTxResult.gasUsed,
            });
            const transactions = [transaction];
            const receipts = [receipt];
            const transactionsRoot = await this._runtime.blockQrl.genQRLTransactionsRoot(transactions);
            const receiptsRoot = await this._runtime.blockQrl.genQRLReceiptsRoot(receipts);
            const stateRoot = await this._stateManager.getStateRoot();
            const draftBlock = new this._runtime.blockQrl.QRLBlock({
                header: {
                    parentHash: latestBlock.hash(),
                    number: blockNumber,
                    timestamp,
                    gasLimit: (_f = this._context.gasLimit) !== null && _f !== void 0 ? _f : latestBlock.header.gasLimit,
                    baseFee: (_g = this._context.baseFee) !== null && _g !== void 0 ? _g : latestBlock.header.baseFee,
                    coinbase: (_h = this._context.coinbase) !== null && _h !== void 0 ? _h : latestBlock.header.coinbase,
                    transactionsRoot,
                    receiptsRoot,
                    stateRoot,
                },
                transactions,
                receipts,
            });
            const includedReceipt = receipt.withInclusion({
                blockHash: draftBlock.hash(),
                blockNumber,
                transactionIndex: 0,
                cumulativeGasUsed: receipt.cumulativeGasUsed,
                logIndexStart: 0,
            });
            const block = new this._runtime.blockQrl.QRLBlock({
                header: draftBlock.header,
                transactions,
                receipts: [includedReceipt],
            });
            await this._putBlock(block);
            storedBlock = block;
            await this._stateManager.commit();
            this._rememberStateBeforeBlock(block, stateBefore);
            this._indexMinedTransaction(transactionHash, transaction, sender, includedReceipt, block);
            this._consumeTimeControls();
            this._notifyPendingTransactionSubscriptions(transaction, sender);
            this._notifyBlockSubscriptions(block);
            return {
                transaction,
                runTxResult,
                receipt: includedReceipt,
                block,
            };
        }
        catch (error) {
            if (storedBlock !== undefined) {
                await this._deleteBlock(storedBlock.hash());
            }
            await this._stateManager.revert();
            throw error;
        }
    }
    _createVm(stateManager, emitConsoleLogs = true, traceListener) {
        const consoleTraceListener = emitConsoleLogs
            ? consoleLogger_1.createQrlConsoleLogTraceListener(this._consoleLogListener)
            : undefined;
        const evm = new this._runtime.evmQrl.QRLEVM({
            stateManager,
            allowUnlimitedContractSize: this._allowUnlimitedContractSize,
            traceListener: combineQrlTraceListeners(consoleTraceListener, traceListener),
        });
        return new this._runtime.vmQrl.QRLVM({
            stateManager,
            evm,
            context: this._context,
        });
    }
    _replaceStateManager(stateManager) {
        this._vm = this._createVm(stateManager);
        this._stateManager = stateManager;
    }
    _rememberStateBeforeBlock(block, stateManager) {
        this._stateBeforeByBlock.set(hashKey(block.hash()), stateManager);
    }
    _indexMinedTransaction(transactionHash, transaction, sender, receipt, block) {
        const key = hashKey(transactionHash);
        this._transactionsByHash.set(key, { transaction, sender });
        this._receiptsByTransactionHash.set(key, receipt);
        this._transactionHashToBlockHash.set(key, new Uint8Array(block.hash()));
    }
    _calculateNextBlockTimestamp(latestBlock, explicitTimestamp) {
        var _a;
        const one = global.BigInt(1);
        const latestBlockTimestamp = latestBlock.header.timestamp;
        const timestamp = (_a = explicitTimestamp !== null && explicitTimestamp !== void 0 ? explicitTimestamp : this._nextBlockTimestamp) !== null && _a !== void 0 ? _a : latestBlockTimestamp + one + this._pendingTimeIncrease;
        // tslint:disable-next-line:strict-comparisons
        if (timestamp <= latestBlockTimestamp) {
            throw new errors_1.InvalidInputError(`timestamp ${timestamp} is not greater than the latest block timestamp ${latestBlockTimestamp}`);
        }
        return timestamp;
    }
    _consumeTimeControls(explicitTimestamp) {
        if (explicitTimestamp !== undefined) {
            return;
        }
        if (this._nextBlockTimestamp !== undefined) {
            this._nextBlockTimestamp = undefined;
            return;
        }
        this._pendingTimeIncrease = global.BigInt(0);
    }
    _resetFilterCursors(latest) {
        const one = global.BigInt(1);
        for (const filter of this._filters.values()) {
            if (filter.type === "block") {
                // tslint:disable-next-line:strict-comparisons
                if (filter.lastBlock > latest) {
                    filter.lastBlock = latest;
                }
                continue;
            }
            if (filter.type === "log") {
                // tslint:disable-next-line:strict-comparisons
                if (filter.nextBlock > latest + one) {
                    filter.nextBlock = filter_1.maxBigInt(filter.minimumBlock, latest + one);
                }
                continue;
            }
            filter.reported.clear();
        }
    }
    _registerSubscription(subscription) {
        const id = this._nextSubscriptionId;
        this._nextSubscriptionId += global.BigInt(1);
        this._subscriptions.set(filterKey(id), subscription);
        return id;
    }
    _notifyPendingTransactionSubscriptions(transaction, sender) {
        for (const [id, subscription] of this._subscriptions) {
            if (subscription.type !== "newPendingTransactions") {
                continue;
            }
            const result = subscription.fullObjects
                ? getPendingRpcTransaction(transaction, sender)
                : output_1.bufferToRpcData(transaction.hash());
            this._emitSubscription(id, result);
        }
    }
    _notifyBlockSubscriptions(block) {
        for (const [id, subscription] of this._subscriptions) {
            if (subscription.type === "newHeads") {
                this._emitSubscription(id, getRpcBlockHeader(block));
                continue;
            }
            if (subscription.type !== "logs" ||
                !subscriptionMatchesBlock(subscription, block.header.number)) {
                continue;
            }
            for (const log of formatMatchingLogs(block, subscription.criteria)) {
                this._emitSubscription(id, log);
            }
        }
    }
    _notifyRemovedLogSubscriptions(block) {
        for (const [id, subscription] of this._subscriptions) {
            if (subscription.type !== "logs" ||
                !subscriptionMatchesBlock(subscription, block.header.number)) {
                continue;
            }
            for (const log of formatMatchingLogs(block, subscription.criteria)) {
                this._emitSubscription(id, Object.assign(Object.assign({}, log), { removed: true }));
            }
        }
    }
    _emitSubscription(id, result) {
        try {
            this.emit("ethEvent", {
                filterId: global.BigInt(id),
                result,
            });
        }
        catch (_error) {
            // Subscription listeners must not interrupt transaction processing.
        }
    }
    async _getBlocksAfter(blockNumber) {
        if (!this._hasLogSubscriptions()) {
            return [];
        }
        const latest = await this.getLatestBlockNumber();
        const one = global.BigInt(1);
        const blocks = [];
        for (let number = blockNumber + one; 
        // tslint:disable-next-line:strict-comparisons
        number <= latest; number += one) {
            const block = await this.getBlockByNumber(number);
            if (block !== undefined) {
                blocks.push(block);
            }
        }
        return blocks;
    }
    _hasLogSubscriptions() {
        for (const subscription of this._subscriptions.values()) {
            if (subscription.type === "logs") {
                return true;
            }
        }
        return false;
    }
    _registerFilter(filter) {
        this._sweepExpiredFilters();
        const id = this._nextFilterId;
        this._nextFilterId += global.BigInt(1);
        this._filters.set(filterKey(id), filter);
        this._scheduleFilterSweep();
        return id;
    }
    _lookupFilter(filterId) {
        this._sweepExpiredFilters();
        const filter = this._filters.get(filterKey(filterId));
        if (filter === undefined) {
            return undefined;
        }
        filter.deadline = this._filterDeadline();
        this._scheduleFilterSweep();
        return filter;
    }
    _filterDeadline() {
        return this._filterNow() + filter_1.QRL_FILTER_DEADLINE_MS;
    }
    _sweepExpiredFilters() {
        const now = this._filterNow();
        for (const [id, filter] of this._filters) {
            if (filter.deadline <= now) {
                this._filters.delete(id);
            }
        }
    }
    _scheduleFilterSweep() {
        var _a, _b;
        if (this._filterExpiryTimer !== undefined) {
            clearTimeout(this._filterExpiryTimer);
            this._filterExpiryTimer = undefined;
        }
        let earliest;
        for (const filter of this._filters.values()) {
            if (earliest === undefined || filter.deadline < earliest) {
                earliest = filter.deadline;
            }
        }
        if (earliest === undefined) {
            return;
        }
        const delay = Math.max(0, earliest - this._filterNow());
        this._filterExpiryTimer = setTimeout(() => {
            this._filterExpiryTimer = undefined;
            this._sweepExpiredFilters();
            this._scheduleFilterSweep();
        }, delay);
        (_b = (_a = this._filterExpiryTimer).unref) === null || _b === void 0 ? void 0 : _b.call(_a);
    }
    async _putBlock(block) {
        return new Promise((resolve, reject) => {
            this._blockchain.putBlock(block, (error) => {
                if (error !== null) {
                    reject(error);
                    return;
                }
                resolve();
            });
        });
    }
    _initLocalAccounts(localAccounts) {
        for (const account of localAccounts) {
            this._localAccounts.set(accountKey(account.address), account.address);
        }
    }
    _getLocalAccount(sender) {
        const key = accountKey(sender);
        const account = this._localAccounts.get(key);
        if (account === undefined) {
            throw new errors_1.InvalidInputError(`unknown account ${key}`);
        }
        return account;
    }
    async _deleteBlock(blockHash) {
        return new Promise((resolve, reject) => {
            this._blockchain.delBlock(blockHash, (error) => {
                if (error !== null) {
                    reject(error);
                    return;
                }
                resolve();
            });
        });
    }
}
exports.HardhatNode = HardhatNode;
function combineQrlTraceListeners(first, second) {
    if (first === undefined) {
        return second;
    }
    if (second === undefined) {
        return first;
    }
    return {
        enterFrame: (frame) => {
            callTraceListener(first.enterFrame, frame);
            callTraceListener(second.enterFrame, frame);
        },
        exitFrame: (frame) => {
            callTraceListener(first.exitFrame, frame);
            callTraceListener(second.exitFrame, frame);
        },
        step: (step) => {
            callTraceListener(first.step, step);
            callTraceListener(second.step, step);
        },
        precompile: (frame) => {
            callTraceListener(first.precompile, frame);
            callTraceListener(second.precompile, frame);
        },
    };
}
function callTraceListener(callback, value) {
    try {
        callback === null || callback === void 0 ? void 0 : callback(value);
    }
    catch (_a) {
        // Observers are diagnostic and must never affect VM execution.
    }
}
function filterKey(id) {
    return id.toString();
}
function minBigInt(left, right) {
    // tslint:disable-next-line:strict-comparisons
    return left < right ? left : right;
}
function formatMatchingLogs(block, filter) {
    return filter_1.collectMatchingLogs(block, filter).map((log) => output_1.getRpcLog(log));
}
function getPendingRpcTransaction(transaction, sender) {
    return Object.assign(Object.assign({}, output_1.getRpcTransaction(transaction, undefined, undefined, false, sender)), { blockHash: null, blockNumber: null, transactionIndex: null });
}
function getRpcBlockHeader(block) {
    if (typeof block.header.toJSON === "function") {
        return block.header.toJSON();
    }
    return {
        hash: output_1.bufferToRpcData(block.hash()),
        parentHash: output_1.bufferToRpcData(block.header.parentHash),
        number: output_1.numberToRpcQuantity(block.header.number),
        timestamp: output_1.numberToRpcQuantity(block.header.timestamp),
    };
}
function subscriptionMatchesBlock(subscription, blockNumber) {
    if (subscription.fromBound !== undefined) {
        // tslint:disable-next-line:strict-comparisons
        if (blockNumber < subscription.fromBound) {
            return false;
        }
    }
    if (subscription.toBound !== undefined) {
        // tslint:disable-next-line:strict-comparisons
        if (blockNumber > subscription.toBound) {
            return false;
        }
    }
    return true;
}
function minimumGasEstimationDifference(estimation) {
    const bigint = (value) => global.BigInt(value);
    // tslint:disable-next-line:strict-comparisons
    if (estimation >= bigint(4000000)) {
        return bigint(50000);
    }
    // tslint:disable-next-line:strict-comparisons
    if (estimation >= bigint(1000000)) {
        return bigint(10000);
    }
    // tslint:disable-next-line:strict-comparisons
    if (estimation >= bigint(100000)) {
        return bigint(1000);
    }
    // tslint:disable-next-line:strict-comparisons
    if (estimation >= bigint(50000)) {
        return bigint(500);
    }
    // tslint:disable-next-line:strict-comparisons
    if (estimation >= bigint(30000)) {
        return bigint(300);
    }
    return bigint(200);
}
function hasBlockOverrides(options) {
    return (options.timestamp !== undefined ||
        options.gasLimit !== undefined ||
        options.baseFee !== undefined ||
        options.coinbase !== undefined);
}
function cloneHashMap(source) {
    return new Map([...source].map(([key, hash]) => [key, new Uint8Array(hash)]));
}
function replaceMap(target, source) {
    target.clear();
    for (const [key, value] of source) {
        target.set(key, value);
    }
}
function hashKey(hash) {
    return Buffer.from(hash).toString("hex").toLowerCase();
}
function accountKey(address) {
    return address.toString().toLowerCase();
}
//# sourceMappingURL=node.js.map