"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const debug_1 = __importDefault(require("debug"));
const find_up_1 = __importDefault(require("find-up"));
const path_1 = __importDefault(require("path"));
const log = debug_1.default("hardhat:core:execution-mode");
/**
 * This module defines different Hardhat execution modes and autodetects them.
 *
 * IMPORTANT: This will have to be revisited once Yarn PnP and npm's tink get
 * widely adopted.
 */
var ExecutionMode;
(function (ExecutionMode) {
    ExecutionMode[ExecutionMode["EXECUTION_MODE_TS_NODE_TESTS"] = 0] = "EXECUTION_MODE_TS_NODE_TESTS";
    ExecutionMode[ExecutionMode["EXECUTION_MODE_LINKED"] = 1] = "EXECUTION_MODE_LINKED";
    ExecutionMode[ExecutionMode["EXECUTION_MODE_GLOBAL_INSTALLATION"] = 2] = "EXECUTION_MODE_GLOBAL_INSTALLATION";
    ExecutionMode[ExecutionMode["EXECUTION_MODE_LOCAL_INSTALLATION"] = 3] = "EXECUTION_MODE_LOCAL_INSTALLATION";
})(ExecutionMode = exports.ExecutionMode || (exports.ExecutionMode = {}));
const workingDirectoryOnLoad = process.cwd();
function getExecutionMode() {
    const isInstalled = __filename.includes("node_modules");
    if (!isInstalled) {
        // When running the tests with ts-node we set the CWD to the root of
        // hardhat-core. We could check if the __filename ends with .ts
        if (__dirname.startsWith(workingDirectoryOnLoad)) {
            return ExecutionMode.EXECUTION_MODE_TS_NODE_TESTS;
        }
        return ExecutionMode.EXECUTION_MODE_LINKED;
    }
    try {
        if (require("is-installed-globally")) {
            return ExecutionMode.EXECUTION_MODE_GLOBAL_INSTALLATION;
        }
    }
    catch (error) {
        log("Failed to load is-installed-globally. Using alternative local installation detection\n", error);
        if (!alternativeIsLocalInstallation()) {
            return ExecutionMode.EXECUTION_MODE_GLOBAL_INSTALLATION;
        }
    }
    return ExecutionMode.EXECUTION_MODE_LOCAL_INSTALLATION;
}
exports.getExecutionMode = getExecutionMode;
/**
 * This is a somewhat more limited detection, but we use it if
 * is-installed-globally fails.
 *
 * If a user installs Hardhat locally, and executes it from outside the
 * directory that contains the `node_module` with the installation, this will
 * fail and return `false`.
 */
function alternativeIsLocalInstallation() {
    let cwd = workingDirectoryOnLoad;
    while (true) {
        const nodeModules = find_up_1.default.sync("node_modules", { cwd });
        if (nodeModules === null) {
            return false;
        }
        if (__dirname.startsWith(nodeModules)) {
            return true;
        }
        cwd = path_1.default.join(nodeModules, "..", "..");
    }
}
//# sourceMappingURL=execution-mode.js.map