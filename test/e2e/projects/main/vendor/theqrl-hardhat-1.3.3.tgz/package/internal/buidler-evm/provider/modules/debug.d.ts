import { HardhatNode } from "../node";
export interface DebugModuleConfig {
    chainId: bigint;
    addressFromBytes: (value: Uint8Array) => any;
    defaultGasLimit: bigint;
    noBaseFee?: boolean;
    createTransaction: (data: Record<string, any>) => any;
    effectiveGasPrice: (transaction: any, context: Record<string, any>) => bigint;
}
export declare class DebugModule {
    private readonly _config;
    private readonly _node;
    constructor(_config: DebugModuleConfig, _node: HardhatNode);
    processRequest(method: string, params?: any[]): Promise<any>;
    private _traceCallParams;
    private _traceCallAction;
    private _traceTransactionParams;
    private _traceTransactionAction;
    private _createCall;
    private _validateStateBlockTag;
}
//# sourceMappingURL=debug.d.ts.map