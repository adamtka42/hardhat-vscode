"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const provider_utils_1 = require("./provider-utils");
const wrapper_1 = require("./wrapper");
exports.DEFAULT_GAS_MULTIPLIER = 1;
function createFixedGasProvider(provider, gasLimit) {
    const rpcGasLimit = provider_utils_1.numberToRpcQuantity(gasLimit);
    return wrapper_1.wrapSend(provider, async (method, params) => {
        if (method === "qrl_sendTransaction") {
            const tx = params[0];
            if (tx !== undefined && tx.gas === undefined) {
                tx.gas = rpcGasLimit;
            }
        }
        return provider.send(method, params);
    });
}
exports.createFixedGasProvider = createFixedGasProvider;
function createFixedGasPriceProvider(provider, gasPrice) {
    const rpcMaxFeePerGas = provider_utils_1.numberToRpcQuantity(gasPrice);
    return wrapper_1.wrapSend(provider, async (method, params) => {
        if (method === "qrl_sendTransaction") {
            const tx = params[0];
            if (tx !== undefined && tx.maxFeePerGas === undefined) {
                tx.maxFeePerGas = rpcMaxFeePerGas;
            }
            if (tx !== undefined && tx.maxPriorityFeePerGas === undefined) {
                tx.maxPriorityFeePerGas = rpcMaxFeePerGas;
            }
            if (tx !== undefined && tx.gasPrice === undefined) {
                tx.gasPrice = rpcMaxFeePerGas;
            }
        }
        return provider.send(method, params);
    });
}
exports.createFixedGasPriceProvider = createFixedGasPriceProvider;
function createAutomaticGasProvider(provider, gasMultiplier = exports.DEFAULT_GAS_MULTIPLIER) {
    const getMultipliedGasEstimation = createMultipliedGasEstimationGetter();
    return wrapper_1.wrapSend(provider, async (method, params) => {
        if (method === "qrl_sendTransaction") {
            const tx = params[0];
            if (tx !== undefined && tx.gas === undefined) {
                tx.gas = await getMultipliedGasEstimation(provider, params, gasMultiplier);
            }
        }
        return provider.send(method, params);
    });
}
exports.createAutomaticGasProvider = createAutomaticGasProvider;
function createAutomaticGasPriceProvider(provider) {
    let maxFeePerGas;
    return wrapper_1.wrapSend(provider, async (method, params) => {
        if (method === "qrl_sendTransaction") {
            const tx = params[0];
            if (tx !== undefined &&
                (tx.maxFeePerGas === undefined || tx.maxPriorityFeePerGas === undefined)) {
                if (maxFeePerGas === undefined) {
                    maxFeePerGas = await provider.send("qrl_gasPrice");
                }
                if (tx.maxFeePerGas === undefined) {
                    tx.maxFeePerGas = maxFeePerGas;
                }
                if (tx.maxPriorityFeePerGas === undefined) {
                    tx.maxPriorityFeePerGas = maxFeePerGas;
                }
                if (tx.gasPrice === undefined) {
                    tx.gasPrice = maxFeePerGas;
                }
            }
        }
        return provider.send(method, params);
    });
}
exports.createAutomaticGasPriceProvider = createAutomaticGasPriceProvider;
function createMultipliedGasEstimationGetter() {
    // We create this getter this way so this cache is recreated when the BRE
    // is reseted
    let cachedGasLimit;
    async function getBlockGasLimit(provider) {
        if (cachedGasLimit === undefined) {
            const latestBlock = await provider.send("qrl_getBlockByNumber", [
                "latest",
                false,
            ]);
            const fetchedGasLimit = provider_utils_1.rpcQuantityToNumber(latestBlock.gasLimit);
            // For future uses, we store a lower value in case the gas limit varies slightly
            cachedGasLimit = Math.floor(fetchedGasLimit * 0.95);
            return fetchedGasLimit;
        }
        return cachedGasLimit;
    }
    return async function getMultipliedGasEstimation(provider, params, gasMultiplier) {
        try {
            const realEstimation = await provider.send("qrl_estimateGas", params);
            if (gasMultiplier === 1) {
                return realEstimation;
            }
            const normalGas = provider_utils_1.rpcQuantityToNumber(realEstimation);
            const gasLimit = await getBlockGasLimit(provider);
            const multiplied = Math.floor(normalGas * gasMultiplier);
            const gas = multiplied > gasLimit ? gasLimit - 1 : multiplied;
            return provider_utils_1.numberToRpcQuantity(gas);
        }
        catch (error) {
            if (error.message.toLowerCase().includes("execution error")) {
                const blockGasLimit = await getBlockGasLimit(provider);
                return provider_utils_1.numberToRpcQuantity(blockGasLimit);
            }
            // tslint:disable-next-line only-hardhat-error
            throw error;
        }
    };
}
//# sourceMappingURL=gas-providers.js.map