import { IQrlProvider } from "../../../types";
export declare const DEFAULT_GAS_MULTIPLIER = 1;
export declare function createFixedGasProvider(provider: IQrlProvider, gasLimit: number): import("../../../types").QrlProvider;
export declare function createFixedGasPriceProvider(provider: IQrlProvider, gasPrice: number): import("../../../types").QrlProvider;
export declare function createAutomaticGasProvider(provider: IQrlProvider, gasMultiplier?: number): import("../../../types").QrlProvider;
export declare function createAutomaticGasPriceProvider(provider: IQrlProvider): import("../../../types").QrlProvider;
//# sourceMappingURL=gas-providers.d.ts.map