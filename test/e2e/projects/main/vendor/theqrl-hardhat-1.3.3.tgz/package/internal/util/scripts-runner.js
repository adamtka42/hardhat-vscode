"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const debug_1 = __importDefault(require("debug"));
const path_1 = __importDefault(require("path"));
const execution_mode_1 = require("../core/execution-mode");
const env_variables_1 = require("../core/params/env-variables");
const log = debug_1.default("hardhat:core:scripts-runner");
async function runScript(scriptPath, scriptArgs = [], extraNodeArgs = [], extraEnvVars = {}) {
    const { fork } = await Promise.resolve().then(() => __importStar(require("child_process")));
    return new Promise((resolve, reject) => {
        const processExecArgv = withFixedInspectArg(process.execArgv);
        const nodeArgs = [
            ...processExecArgv,
            ...getTsNodeArgsIfNeeded(scriptPath),
            ...extraNodeArgs,
        ];
        const childProcess = fork(scriptPath, scriptArgs, {
            stdio: "inherit",
            execArgv: nodeArgs,
            env: Object.assign(Object.assign({}, process.env), extraEnvVars),
        });
        childProcess.once("close", (status) => {
            log(`Script ${scriptPath} exited with status code ${status}`);
            resolve(status);
        });
        childProcess.once("error", reject);
    });
}
exports.runScript = runScript;
async function runScriptWithHardhat(hardhatArguments, scriptPath, scriptArgs = [], extraNodeArgs = [], extraEnvVars = {}) {
    log(`Creating Hardhat subprocess to run ${scriptPath}`);
    const hardhatRegisterPath = resolveHardhatRegisterPath();
    return runScript(scriptPath, scriptArgs, [...extraNodeArgs, "--require", hardhatRegisterPath], Object.assign(Object.assign({}, env_variables_1.getEnvVariablesMap(hardhatArguments)), extraEnvVars));
}
exports.runScriptWithHardhat = runScriptWithHardhat;
/**
 * Fix debugger "inspect" arg from process.argv, if present.
 *
 * When running this process with a debugger, a debugger port
 * is specified via the "--inspect-brk=" arg param in some IDEs/setups.
 *
 * This normally works, but if we do a fork afterwards, we'll get an error stating
 * that the port is already in use (since the fork would also use the same args,
 * therefore the same port number). To prevent this issue, we could replace the port number with
 * a different free one, or simply use the port-agnostic --inspect" flag, and leave the debugger
 * port selection to the Node process itself, which will pick an empty AND valid one.
 *
 * This way, we can properly use the debugger for this process AND for the executed
 * script itself - even if it's compiled using ts-node.
 */
function withFixedInspectArg(argv) {
    const fixIfInspectArg = (arg) => {
        if (arg.toLowerCase().includes("--inspect-brk=")) {
            return "--inspect";
        }
        return arg;
    };
    return argv.map(fixIfInspectArg);
}
/**
 * Ensure hardhat/register source file path is resolved to compiled JS file
 * instead of TS source file, so we don't need to run ts-node unnecessarily.
 */
function resolveHardhatRegisterPath() {
    const executionMode = execution_mode_1.getExecutionMode();
    const isCompiledInstallation = [
        execution_mode_1.ExecutionMode.EXECUTION_MODE_LOCAL_INSTALLATION,
        execution_mode_1.ExecutionMode.EXECUTION_MODE_GLOBAL_INSTALLATION,
        execution_mode_1.ExecutionMode.EXECUTION_MODE_LINKED,
    ].includes(executionMode);
    const hardhatCoreBaseDir = path_1.default.join(__dirname, "..", "..");
    const hardhatCoreCompiledDir = isCompiledInstallation
        ? hardhatCoreBaseDir
        : path_1.default.join(hardhatCoreBaseDir, "..");
    const hardhatCoreRegisterCompiledPath = path_1.default.join(hardhatCoreCompiledDir, "register");
    return hardhatCoreRegisterCompiledPath;
}
exports.resolveHardhatRegisterPath = resolveHardhatRegisterPath;
function getTsNodeArgsIfNeeded(scriptPath) {
    if (execution_mode_1.getExecutionMode() !== execution_mode_1.ExecutionMode.EXECUTION_MODE_TS_NODE_TESTS) {
        return [];
    }
    if (!/\.tsx?$/i.test(scriptPath)) {
        return [];
    }
    const extraNodeArgs = [];
    if (!process.execArgv.includes("ts-node/register")) {
        extraNodeArgs.push("--require");
        extraNodeArgs.push("ts-node/register");
    }
    return extraNodeArgs;
}
//# sourceMappingURL=scripts-runner.js.map