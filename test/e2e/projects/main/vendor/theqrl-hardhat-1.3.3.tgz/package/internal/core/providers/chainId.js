"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const errors_1 = require("../errors");
const errors_list_1 = require("../errors-list");
const provider_utils_1 = require("./provider-utils");
const wrapper_1 = require("./wrapper");
function createChainIdValidationProvider(provider, chainId) {
    const getChainId = provider_utils_1.createChainIdGetter(provider);
    return wrapper_1.wrapSend(provider, async (method, params) => {
        const realChainId = await getChainId();
        if (chainId !== undefined && realChainId !== chainId) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_GLOBAL_CHAIN_ID, {
                configChainId: chainId,
                connectionChainId: realChainId,
            });
        }
        return provider.send(method, params);
    });
}
exports.createChainIdValidationProvider = createChainIdValidationProvider;
//# sourceMappingURL=chainId.js.map