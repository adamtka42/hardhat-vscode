"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Blockchain {
    constructor() {
        this._blocks = [];
        this._blockNumberByHash = new Map();
    }
    getLatestBlock(callback) {
        if (this._blocks.length === 0) {
            callback(new Error("No block available"));
            return;
        }
        callback(null, this._blocks[this._blocks.length - 1]);
    }
    putBlock(block, callback) {
        const blockNumber = blockNumberToIndex(block.header.number);
        if (this._blocks.length !== blockNumber) {
            callback(new Error("Invalid block number"));
            return;
        }
        this._blocks.push(block);
        this._blockNumberByHash.set(blockHashKey(block.hash()), blockNumber);
        callback(null, block);
    }
    delBlock(blockHash, callback) {
        const blockNumber = this._blockNumberByHash.get(blockHashKey(blockHash));
        if (blockNumber === undefined) {
            callback(new Error("Block not found"));
            return;
        }
        this._deleteFrom(blockNumber);
        callback(null);
    }
    getBlock(hashOrBlockNumber, callback) {
        let blockNumber;
        if (typeof hashOrBlockNumber === "bigint") {
            blockNumber = blockNumberToIndex(hashOrBlockNumber);
        }
        else {
            const hash = blockHashKey(hashOrBlockNumber);
            const indexedBlockNumber = this._blockNumberByHash.get(hash);
            if (indexedBlockNumber === undefined) {
                callback(new Error("Block not found"));
                return;
            }
            blockNumber = indexedBlockNumber;
        }
        callback(null, this._blocks[blockNumber]);
    }
    iterator(_name, onBlock, callback) {
        let blockNumber = 0;
        const iterate = (error) => {
            if (error !== null && error !== undefined) {
                callback(error);
                return;
            }
            if (blockNumber >= this._blocks.length) {
                callback(null);
                return;
            }
            onBlock(this._blocks[blockNumber], false, (onBlockError) => {
                blockNumber += 1;
                iterate(onBlockError);
            });
        };
        iterate(null);
    }
    getDetails(_name, callback) {
        callback(null);
    }
    deleteAllFollowingBlocks(block) {
        const blockNumber = blockNumberToIndex(block.header.number);
        const actualBlock = this._blocks[blockNumber];
        if (actualBlock === undefined ||
            !bytesEqual(block.hash(), actualBlock.hash())) {
            // tslint:disable-next-line only-hardhat-error
            throw new Error("Invalid block");
        }
        this._deleteFrom(blockNumber + 1);
    }
    _deleteFrom(blockNumber) {
        for (let index = blockNumber; index < this._blocks.length; index++) {
            this._blockNumberByHash.delete(blockHashKey(this._blocks[index].hash()));
        }
        this._blocks.splice(blockNumber);
    }
}
exports.Blockchain = Blockchain;
function blockNumberToIndex(blockNumber) {
    const index = Number(blockNumber);
    if (!Number.isSafeInteger(index) || index < 0) {
        // tslint:disable-next-line only-hardhat-error
        throw new Error(`Invalid block number ${blockNumber.toString()}`);
    }
    return index;
}
function blockHashKey(hash) {
    return Buffer.from(hash).toString("hex").toLowerCase();
}
function bytesEqual(left, right) {
    if (left.length !== right.length) {
        return false;
    }
    for (let index = 0; index < left.length; index++) {
        if (left[index] !== right[index]) {
            return false;
        }
    }
    return true;
}
//# sourceMappingURL=blockchain.js.map