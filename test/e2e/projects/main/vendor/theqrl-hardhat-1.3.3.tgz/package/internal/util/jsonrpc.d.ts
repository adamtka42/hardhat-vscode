export interface JsonRpcRequest {
    jsonrpc: string;
    method: string;
    params: any[];
    id: number | string;
}
interface SuccessfulJsonRpcResponse {
    jsonrpc: string;
    id: number | string;
    result: any;
}
export interface FailedJsonRpcResponse {
    jsonrpc: string;
    id: number | string | null;
    error: {
        code: number;
        message: string;
        data?: any;
    };
}
export declare type JsonRpcResponse = SuccessfulJsonRpcResponse | FailedJsonRpcResponse;
export declare function parseJsonResponse(text: string): JsonRpcResponse;
export declare function isValidJsonRequest(payload: any): boolean;
export declare function isValidJsonResponse(payload: any): boolean;
export declare function isSuccessfulJsonResponse(payload: JsonRpcResponse): payload is SuccessfulJsonRpcResponse;
export {};
//# sourceMappingURL=jsonrpc.d.ts.map