export interface QrlContractDebugInfo {
    sourceName: string;
    contractName: string;
    abi: any[];
    contractKind?: string;
    bytecode: string;
    bytecodeSourceMap?: string;
    deployedBytecode: string;
    deployedSourceMap?: string;
    linkReferences: any;
    deployedLinkReferences: any;
    immutableReferences: any;
    methodIdentifiers: {
        [signature: string]: string;
    };
    compilerVersion?: string;
}
export interface QrlDebugInfo {
    contracts: QrlContractDebugInfo[];
    /** Source content by sourceName (from the cached compiler input). */
    sourceContent: Map<string, string>;
    /** sourceName by numeric source index (from the cached compiler output). */
    sourceNamesByIndex: Map<number, string>;
    /** Raw per-source ASTs by sourceName. */
    astBySourceName: Map<string, any>;
}
/**
 * Loads the debug information the stack trace decoder needs from the cached
 * compiler input/output JSON files. Returns `undefined` when the cache is
 * missing or unreadable — stack traces then degrade gracefully.
 */
export declare function loadQrlDebugInfo(cachePath: string, projectRoot?: string): QrlDebugInfo | undefined;
//# sourceMappingURL=compiler-to-model.d.ts.map