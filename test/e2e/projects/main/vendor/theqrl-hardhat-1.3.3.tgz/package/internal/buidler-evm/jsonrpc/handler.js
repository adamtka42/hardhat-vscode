"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const debug_1 = __importDefault(require("debug"));
const raw_body_1 = __importDefault(require("raw-body"));
const jsonrpc_1 = require("../../util/jsonrpc");
const errors_1 = require("../provider/errors");
// tslint:disable only-hardhat-error
const log = debug_1.default("buidler:core:qrl:jsonrpc");
class JsonRpcHandler {
    constructor(_provider) {
        this._provider = _provider;
        this.handleHttp = async (req, res) => {
            this._setCorsHeaders(res);
            if (req.method === "OPTIONS") {
                this._sendEmptyResponse(res);
                return;
            }
            let jsonHttpRequest;
            try {
                jsonHttpRequest = await _readJsonHttpRequest(req);
            }
            catch (error) {
                this._sendResponse(res, _handleError(error));
                return;
            }
            if (Array.isArray(jsonHttpRequest)) {
                // Batch semantics: every entry is handled independently; a failing
                // entry never aborts the batch, and ids map 1:1.
                const responses = await Promise.all(jsonHttpRequest.map((singleReq) => this._handleSingleHttpRequest(singleReq)));
                this._sendResponse(res, responses);
                return;
            }
            const rpcResp = await this._handleSingleHttpRequest(jsonHttpRequest);
            this._sendResponse(res, rpcResp);
        };
        this.handleWs = async (ws) => {
            const subscriptions = new Set();
            let isClosed = false;
            const listener = (payload) => {
                // Only forward notifications for subscriptions created through this
                // websocket connection, and never after it closed.
                if (isClosed || !subscriptions.has(payload.subscription)) {
                    return;
                }
                try {
                    ws.send(JSON.stringify({
                        jsonrpc: "2.0",
                        method: "qrl_subscription",
                        params: payload,
                    }));
                }
                catch (error) {
                    _handleError(error);
                }
            };
            // Forward notifications owned by this WebSocket connection.
            this._provider.addListener("notification", listener);
            ws.on("message", async (msg) => {
                let rpcReq;
                let rpcResp;
                try {
                    rpcReq = _readWsRequest(msg);
                    if (!jsonrpc_1.isValidJsonRequest(rpcReq)) {
                        throw new errors_1.InvalidRequestError("Invalid request");
                    }
                    // Subscriptions belong to the connection that created them: an
                    // unsubscribe for a foreign (or unknown) id answers false WITHOUT
                    // reaching the provider, so one client can never remove another
                    // client's subscription — ids are sequential and guessable. The
                    // shortcut applies ONLY to well-formed requests (exactly one string
                    // parameter); malformed ones fall through to standard validation.
                    if (rpcReq.method === "qrl_unsubscribe" &&
                        Array.isArray(rpcReq.params) &&
                        rpcReq.params.length === 1 &&
                        typeof rpcReq.params[0] === "string" &&
                        !subscriptions.has(rpcReq.params[0])) {
                        rpcResp = {
                            jsonrpc: "2.0",
                            id: rpcReq.id,
                            result: false,
                        };
                    }
                    else {
                        rpcResp = await this._handleRequest(rpcReq);
                    }
                    // Track successful qrl_subscribe calls so notifications can be
                    // routed and cleaned up per connection. When the provider finishes
                    // AFTER the socket closed, the close handler has already run — the
                    // subscription must be released immediately instead of leaking.
                    if (rpcReq.method === "qrl_subscribe" &&
                        jsonrpc_1.isValidJsonResponse(rpcResp) &&
                        "result" in rpcResp) {
                        if (isClosed) {
                            try {
                                await this._provider.send("qrl_unsubscribe", [
                                    rpcResp.result,
                                ]);
                            }
                            catch (_a) {
                                // Nothing to clean up if the provider dropped it already.
                            }
                        }
                        else {
                            subscriptions.add(rpcResp.result);
                        }
                    }
                    // A successful own unsubscribe releases the id.
                    if (rpcReq.method === "qrl_unsubscribe" &&
                        Array.isArray(rpcReq.params) &&
                        jsonrpc_1.isValidJsonResponse(rpcResp) &&
                        rpcResp.result === true) {
                        subscriptions.delete(rpcReq.params[0]);
                    }
                }
                catch (error) {
                    rpcResp = _handleError(error);
                }
                if (!jsonrpc_1.isValidJsonResponse(rpcResp)) {
                    rpcResp = _handleError(new errors_1.InternalError("Internal error"));
                }
                if (rpcReq !== undefined) {
                    rpcResp.id = rpcReq.id;
                }
                ws.send(JSON.stringify(rpcResp));
            });
            ws.on("close", () => {
                this._provider.removeListener("notification", listener);
                isClosed = true;
                subscriptions.forEach(async (subscriptionId) => {
                    try {
                        await this._provider.send("qrl_unsubscribe", [subscriptionId]);
                    }
                    catch (_a) {
                        // The provider may not support subscriptions yet.
                    }
                });
            });
        };
        // Subscriptions need a push channel; over plain HTTP they are rejected
        // with a stable error (same behavior as go-qrl). Only WELL-FORMED
        // requests take this shortcut — malformed ones go through the standard
        // validation path and report invalid-request errors.
        this._handleSingleHttpRequest = async (rpcReq) => {
            if (jsonrpc_1.isValidJsonRequest(rpcReq) &&
                (rpcReq.method === "qrl_subscribe" || rpcReq.method === "qrl_unsubscribe")) {
                const rpcResp = _handleError(new errors_1.MethodNotFoundError(`${rpcReq.method} is only supported over WebSocket connections`));
                rpcResp.id = rpcReq.id;
                return rpcResp;
            }
            return this._handleSingleRequest(rpcReq);
        };
        this._handleRequest = async (req) => {
            const result = await this._provider.send(req.method, req.params);
            return {
                jsonrpc: "2.0",
                id: req.id,
                result,
            };
        };
    }
    _sendEmptyResponse(res) {
        res.writeHead(200);
        res.end();
    }
    _setCorsHeaders(res) {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Request-Method", "*");
        res.setHeader("Access-Control-Allow-Methods", "OPTIONS, GET, POST");
        res.setHeader("Access-Control-Allow-Headers", "*");
    }
    _sendResponse(res, rpcResp) {
        res.statusCode = 200;
        res.setHeader("Content-Type", "application/json");
        res.end(JSON.stringify(rpcResp));
    }
    async _handleSingleRequest(req) {
        if (!jsonrpc_1.isValidJsonRequest(req)) {
            return _handleError(new errors_1.InvalidRequestError("Invalid request"));
        }
        const rpcReq = req;
        let rpcResp;
        try {
            rpcResp = await this._handleRequest(rpcReq);
        }
        catch (error) {
            rpcResp = _handleError(error);
        }
        if (!jsonrpc_1.isValidJsonResponse(rpcResp)) {
            // Malformed response coming from the provider; report as internal.
            rpcResp = _handleError(new errors_1.InternalError("Internal error"));
        }
        if (rpcReq !== undefined) {
            rpcResp.id = rpcReq.id !== undefined ? rpcReq.id : null;
        }
        return rpcResp;
    }
}
exports.default = JsonRpcHandler;
const _readJsonHttpRequest = async (req) => {
    let json;
    try {
        const buf = await raw_body_1.default(req);
        const text = buf.toString();
        json = JSON.parse(text);
    }
    catch (error) {
        throw new errors_1.InvalidJsonInputError(`Parse error: ${error.message}`);
    }
    return json;
};
const _readWsRequest = (msg) => {
    let json;
    try {
        json = JSON.parse(msg);
    }
    catch (error) {
        throw new errors_1.InvalidJsonInputError(`Parse error: ${error.message}`);
    }
    return json;
};
const _handleError = (error) => {
    var _a;
    log(`${(_a = error.message) !== null && _a !== void 0 ? _a : error}`);
    // Provider errors carry their own numeric codes; anything else is
    // internal. Unlike the upstream handler, `data` (revert payloads) and
    // `transactionHash` (failed mined transactions) are forwarded so clients
    // behind the HTTP layer keep the full error information.
    if (typeof (error === null || error === void 0 ? void 0 : error.code) !== "number") {
        error = new errors_1.InternalError(typeof (error === null || error === void 0 ? void 0 : error.message) === "string" ? error.message : "Internal error");
    }
    const jsonError = {
        code: error.code,
        message: error.message,
    };
    if (error.data !== undefined) {
        jsonError.data = error.data;
    }
    if (typeof error.transactionHash === "string") {
        jsonError.transactionHash = error.transactionHash;
    }
    return {
        jsonrpc: "2.0",
        id: null,
        error: jsonError,
    };
};
//# sourceMappingURL=handler.js.map