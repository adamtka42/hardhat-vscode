import { OptionalBlockTag } from "./input";
import { RpcLogOutput } from "./output";
export declare const LATEST_BLOCK: bigint;
export declare const QRL_FILTER_DEADLINE_MS: number;
export declare type QRLNormalizedTopics = Array<Set<string> | null>;
export interface QRLLogFilter {
    fromBlock?: OptionalBlockTag;
    toBlock?: OptionalBlockTag;
    blockHash?: Uint8Array;
    addresses?: string[];
    topics?: QRLNormalizedTopics;
}
export declare type QRLInstalledFilter = ({
    type: "log";
    criteria: QRLLogFilter;
    minimumBlock: bigint;
    nextBlock: bigint;
} | {
    type: "block";
    lastBlock: bigint;
} | {
    type: "pendingTx";
    reported: Set<string>;
}) & {
    deadline: number;
};
export declare type QRLSubscription = {
    type: "newHeads";
} | {
    type: "newPendingTransactions";
    fullObjects: boolean;
} | {
    type: "logs";
    criteria: QRLLogFilter;
    fromBound?: bigint;
    toBound?: bigint;
};
export declare type QRLSubscriptionBound = {
    kind: "latest";
} | {
    kind: "number";
    value: bigint;
};
export interface FilterCriteria {
    fromBlock: bigint;
    toBlock: bigint;
    addresses: string[];
    normalizedTopics: QRLNormalizedTopics;
}
interface QrlLogLike {
    address: {
        toString(): string;
    };
    topics: ReadonlyArray<Uint8Array>;
}
interface QrlReceiptLike<LogT extends QrlLogLike> {
    logs: ReadonlyArray<LogT>;
}
interface QrlBlockLike<LogT extends QrlLogLike> {
    receipts: ReadonlyArray<QrlReceiptLike<LogT>>;
}
export declare function parseLogFilter(value: unknown): QRLLogFilter;
export declare function serializeLogCriteria(criteria: QRLLogFilter): Record<string, unknown>;
export declare function parseSubscriptionBound(value: OptionalBlockTag, name: string): QRLSubscriptionBound;
export interface ResolvedLogFilterBlock {
    number: bigint;
    includesPending: boolean;
}
export declare function resolveLogFilterBlock(value: OptionalBlockTag, fallback: bigint, latest: bigint): ResolvedLogFilterBlock;
export declare function resolveInstalledFilterStart(value: OptionalBlockTag, latest: bigint): bigint;
export declare function resolveInstalledFilterMinimum(value: OptionalBlockTag): bigint;
export declare function maxBigInt(left: bigint, right: bigint): bigint;
export declare function collectMatchingLogs<LogT extends QrlLogLike>(block: QrlBlockLike<LogT>, filter: QRLLogFilter): LogT[];
export declare function matchesLogFilter(log: QrlLogLike, filter: QRLLogFilter): boolean;
export declare function filterLogs(logs: RpcLogOutput[], criteria: FilterCriteria): RpcLogOutput[];
export declare function topicMatched(normalizedTopics: QRLNormalizedTopics, logTopics: string[]): boolean;
export declare function bloomFilter(bloom: Uint8Array, addresses: Uint8Array[], normalizedTopics: Array<Array<Uint8Array | null> | null>): boolean;
export {};
//# sourceMappingURL=filter.d.ts.map