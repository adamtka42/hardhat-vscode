"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const deepmerge_1 = __importDefault(require("deepmerge"));
const fs = __importStar(require("fs"));
const path_1 = __importDefault(require("path"));
const lang_1 = require("../../util/lang");
const errors_1 = require("../errors");
const errors_list_1 = require("../errors-list");
function mergeUserAndDefaultConfigs(defaultConfig, userConfig) {
    return deepmerge_1.default(defaultConfig, userConfig, {
        arrayMerge: (destination, source) => source,
    });
}
/**
 * This functions resolves the Hardhat config by merging the user provided config
 * and the default config.
 *
 * @param userConfigPath the user config filepath
 * @param defaultConfig  the default config object
 * @param userConfig     the user config object
 * @param configExtenders An array of ConfigExtenders
 *
 * @returns the resolved config
 */
function resolveConfig(userConfigPath, defaultConfig, userConfig, configExtenders) {
    userConfig = deepFreezeUserConfig(userConfig);
    const config = mergeUserAndDefaultConfigs(defaultConfig, userConfig);
    const paths = resolveProjectPaths(userConfigPath, userConfig.paths);
    const resolved = Object.assign(Object.assign({}, config), { paths, networks: config.networks, hyperion: config.hyperion, defaultNetwork: config.defaultNetwork });
    for (const extender of configExtenders) {
        extender(resolved, userConfig);
    }
    return resolved;
}
exports.resolveConfig = resolveConfig;
function resolvePathFrom(from, defaultPath, relativeOrAbsolutePath = defaultPath) {
    if (path_1.default.isAbsolute(relativeOrAbsolutePath)) {
        return relativeOrAbsolutePath;
    }
    return path_1.default.join(from, relativeOrAbsolutePath);
}
/**
 * This function resolves the ProjectPaths object from the user-provided config
 * and its path. The logic of this is not obvious and should well be document.
 * The good thing is that most users will never use this.
 *
 * Explanation:
 *    - paths.configFile is not overridable
 *    - If a path is absolute it is used "as is".
 *    - If the root path is relative, it's resolved from paths.configFile's dir.
 *    - If any other path is relative, it's resolved from paths.root.
 */
function resolveProjectPaths(userConfigPath, userPaths = {}) {
    const configFile = fs.realpathSync(userConfigPath);
    const configDir = path_1.default.dirname(configFile);
    const root = resolvePathFrom(configDir, "", userPaths.root);
    const otherPathsEntries = Object.entries(userPaths).map(([name, value]) => [name, resolvePathFrom(root, value)]);
    const otherPaths = lang_1.fromEntries(otherPathsEntries);
    return Object.assign(Object.assign({}, otherPaths), { root,
        configFile, sources: resolvePathFrom(root, "contracts", userPaths.sources), cache: resolvePathFrom(root, "cache", userPaths.cache), artifacts: resolvePathFrom(root, "artifacts", userPaths.artifacts), tests: resolvePathFrom(root, "test", userPaths.tests) });
}
exports.resolveProjectPaths = resolveProjectPaths;
function deepFreezeUserConfig(config, propertyPath = []) {
    if (typeof config !== "object" || config === null) {
        return config;
    }
    return new Proxy(config, {
        get(target, property, receiver) {
            return deepFreezeUserConfig(Reflect.get(target, property, receiver), [
                ...propertyPath,
                property,
            ]);
        },
        set(target, property, value, receiver) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.GENERAL.USER_CONFIG_MODIFIED, {
                path: [...propertyPath, property]
                    .map((pathPart) => pathPart.toString())
                    .join("."),
            });
        },
    });
}
//# sourceMappingURL=config-resolution.js.map