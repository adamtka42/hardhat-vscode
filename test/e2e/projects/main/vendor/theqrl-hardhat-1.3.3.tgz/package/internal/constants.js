"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HARDHAT_NAME = "Hardhat";
exports.HARDHAT_EXECUTABLE_NAME = "hardhat";
exports.HARDHAT_QRLVM_NETWORK_NAME = "hardhatqrlvm";
exports.COMPILER_INPUT_FILENAME = "compiler-input.json";
exports.COMPILER_OUTPUT_FILENAME = "compiler-output.json";
//# sourceMappingURL=constants.js.map