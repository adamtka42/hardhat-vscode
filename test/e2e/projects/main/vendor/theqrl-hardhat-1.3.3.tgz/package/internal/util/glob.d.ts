export declare function glob(pattern: string): Promise<string[]>;
export declare function globSync(pattern: string): string[];
//# sourceMappingURL=glob.d.ts.map