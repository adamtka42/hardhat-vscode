/// <reference types="node" />
import { EventEmitter } from "events";
export declare class HttpProvider extends EventEmitter {
    private readonly _url;
    private readonly _networkName;
    private readonly _extraHeaders;
    private readonly _timeout;
    private _nextRequestId;
    constructor(_url: string, _networkName: string, _extraHeaders?: {
        [name: string]: string;
    }, _timeout?: number);
    send(method: string, params?: any[]): Promise<any>;
    private _fetchJsonRpcResponse;
    private _getJsonRpcRequest;
}
//# sourceMappingURL=http.d.ts.map