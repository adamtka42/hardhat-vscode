import { IQrlProvider } from "../../../types";
export declare function wrapSend(provider: IQrlProvider, sendWrapper: (method: string, params: any[]) => Promise<any>): IQrlProvider;
//# sourceMappingURL=wrapper.d.ts.map