"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const defaultConfig = {
    defaultNetwork: "qrl",
    hyperion: {
        version: "local",
        optimizer: {
            enabled: false,
            runs: 200,
        },
    },
    networks: {
        qrl: {
            url: "http://127.0.0.1:33462",
        },
        hardhatqrlvm: {
            chainId: 1,
            accounts: [],
            automine: true,
            blockGasLimit: 30000000,
        },
    },
    mocha: {
        timeout: 20000,
    },
};
exports.default = defaultConfig;
//# sourceMappingURL=default-config.js.map