"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const errors_1 = require("../errors");
const filter_1 = require("../filter");
const input_1 = require("../input");
const output_1 = require("../output");
// tslint:disable only-hardhat-error
class QrlModule {
    constructor(_config, _node, _throwOnTransactionFailures = true, _throwOnCallFailures = true, _logger, _stackTracesEnabled = false) {
        this._config = _config;
        this._node = _node;
        this._throwOnTransactionFailures = _throwOnTransactionFailures;
        this._throwOnCallFailures = _throwOnCallFailures;
        this._logger = _logger;
        this._stackTracesEnabled = _stackTracesEnabled;
    }
    async processRequest(method, params = []) {
        switch (method) {
            case "qrl_accounts":
                return this._accountsAction(...this._accountsParams(params));
            case "qrl_blockNumber":
                return this._blockNumberAction(...this._blockNumberParams(params));
            case "qrl_call":
                return this._callAction(...this._callParams(params));
            case "qrl_chainId":
                return this._chainIdAction(...this._chainIdParams(params));
            case "qrl_coinbase":
                return this._coinbaseAction(...this._coinbaseParams(params));
            case "qrl_estimateGas":
                return this._estimateGasAction(...this._estimateGasParams(params));
            case "qrl_gasPrice":
                return this._gasPriceAction(...this._gasPriceParams(params));
            case "qrl_getBalance":
                return this._getBalanceAction(...this._getBalanceParams(params));
            case "qrl_getBlockByHash":
                return this._getBlockByHashAction(...this._getBlockByHashParams(params));
            case "qrl_getBlockByNumber":
                return this._getBlockByNumberAction(...this._getBlockByNumberParams(params));
            case "qrl_getBlockTransactionCountByHash":
                return this._getBlockTransactionCountByHashAction(...this._getBlockTransactionCountByHashParams(params));
            case "qrl_getBlockTransactionCountByNumber":
                return this._getBlockTransactionCountByNumberAction(...this._getBlockTransactionCountByNumberParams(params));
            case "qrl_getCode":
                return this._getCodeAction(...this._getCodeParams(params));
            case "qrl_getFilterChanges":
                return this._getFilterChangesAction(...this._getFilterChangesParams(params));
            case "qrl_getFilterLogs":
                return this._getFilterLogsAction(...this._getFilterLogsParams(params));
            case "qrl_getLogs":
                return this._getLogsAction(...this._getLogsParams(params));
            case "qrl_getStorageAt":
                return this._getStorageAtAction(...this._getStorageAtParams(params));
            case "qrl_getTransactionByBlockHashAndIndex":
                return this._getTransactionByBlockHashAndIndexAction(...this._getTransactionByBlockHashAndIndexParams(params));
            case "qrl_getTransactionByBlockNumberAndIndex":
                return this._getTransactionByBlockNumberAndIndexAction(...this._getTransactionByBlockNumberAndIndexParams(params));
            case "qrl_getTransactionByHash":
                return this._getTransactionByHashAction(...this._getTransactionByHashParams(params));
            case "qrl_getTransactionCount":
                return this._getTransactionCountAction(...this._getTransactionCountParams(params));
            case "qrl_getTransactionReceipt":
                return this._getTransactionReceiptAction(...this._getTransactionReceiptParams(params));
            case "qrl_mining":
                return this._miningAction(...this._miningParams(params));
            case "qrl_newBlockFilter":
                return this._newBlockFilterAction(...this._newBlockFilterParams(params));
            case "qrl_newFilter":
                return this._newFilterAction(...this._newFilterParams(params));
            case "qrl_newPendingTransactionFilter":
                return this._newPendingTransactionFilterAction(...this._newPendingTransactionFilterParams(params));
            case "qrl_pendingTransactions":
                return this._pendingTransactionsAction(...this._pendingTransactionsParams(params));
            case "qrl_sendRawTransaction":
                return this._sendRawTransactionAction(...this._sendRawTransactionParams(params));
            case "qrl_sendTransaction":
                return this._sendTransactionAction(...this._sendTransactionParams(params));
            case "qrl_subscribe":
                return this._subscribeAction(...this._subscribeParams(params));
            case "qrl_syncing":
                return this._syncingAction(...this._syncingParams(params));
            case "qrl_uninstallFilter":
                return this._uninstallFilterAction(...this._uninstallFilterParams(params));
            case "qrl_unsubscribe":
                return this._unsubscribeAction(...this._unsubscribeParams(params));
        }
        throw new errors_1.MethodNotFoundError(`Method ${method} not found`);
    }
    // qrl_accounts
    _accountsParams(params) {
        return input_1.validateParams(params);
    }
    async _accountsAction() {
        return this._node.getLocalAccountAddresses();
    }
    // qrl_blockNumber
    _blockNumberParams(params) {
        return input_1.validateParams(params);
    }
    async _blockNumberAction() {
        return output_1.numberToRpcQuantity(await this._node.getLatestBlockNumber());
    }
    // qrl_call
    _callParams(params) {
        return input_1.validateParams(params, input_1.rpcCallRequest, input_1.optionalBlockTag);
    }
    async _callAction(request, blockTag) {
        var _a;
        this._validateStateBlockTag(blockTag);
        if (request.from === undefined) {
            throw new errors_1.InvalidArgumentsError("qrl_call requires a QRL from address");
        }
        if (request.to === undefined) {
            throw new errors_1.InvalidArgumentsError("qrl_call requires a QRL to address");
        }
        const { transaction, sender } = await this._createTransaction(request, blockTag === "pending", this._config.defaultGasLimit);
        const latestBlock = await this._node.getLatestBlock();
        const gasPrice = this._config.effectiveGasPrice(transaction, {
            chainId: this._config.chainId,
            baseFee: latestBlock.header.baseFee,
            coinbase: await this._node.getCoinbaseAddress(),
            blockNumber: latestBlock.header.number,
            timestamp: latestBlock.header.timestamp,
            gasLimit: await this._node.getBlockGasLimit(),
            noBaseFee: (_a = this._config.noBaseFee) !== null && _a !== void 0 ? _a : true,
        });
        const call = {
            to: transaction.to,
            from: sender,
            gasLimit: transaction.gasLimit,
            gasPrice,
            value: transaction.value,
            data: transaction.data,
        };
        const result = await this._node.runCall(call, {
            usePendingState: blockTag === "pending",
        });
        this._logCall(call);
        if (result.exceptionError !== undefined && this._throwOnCallFailures) {
            const traceFrame = this._stackTracesEnabled
                ? await this._traceCallFailure(call, blockTag === "pending")
                : undefined;
            throw new errors_1.QrlExecutionError(result.exceptionError.message, output_1.bufferToRpcData(result.returnValue), undefined, traceFrame);
        }
        return output_1.bufferToRpcData(result.returnValue);
    }
    // qrl_chainId
    _chainIdParams(params) {
        return input_1.validateParams(params);
    }
    async _chainIdAction() {
        return output_1.numberToRpcQuantity(this._config.chainId);
    }
    // qrl_coinbase
    _coinbaseParams(params) {
        return input_1.validateParams(params);
    }
    async _coinbaseAction() {
        return (await this._node.getCoinbaseAddress()).toString();
    }
    // qrl_estimateGas
    _estimateGasParams(params) {
        return input_1.validateParams(params, input_1.rpcTransactionRequest, input_1.optionalBlockTag);
    }
    async _estimateGasAction(request, blockTag) {
        var _a, _b, _c, _d, _e;
        this._validateStateBlockTag(blockTag);
        const { transaction, sender } = await this._createTransaction(request, blockTag === "pending", await this._node.getBlockGasLimit());
        const result = await this._node.estimateGas(transaction, sender, {
            usePendingState: blockTag === "pending",
        });
        if (result.error !== undefined ||
            ((_a = result.runTxResult) === null || _a === void 0 ? void 0 : _a.executionError) !== undefined ||
            ((_b = result.runTxResult) === null || _b === void 0 ? void 0 : _b.status) === 0) {
            const traceFrame = this._stackTracesEnabled
                ? await this._traceEstimateGasFailure(transaction, sender, blockTag === "pending")
                : undefined;
            throw new errors_1.QrlExecutionError((_d = (_c = result.error) === null || _c === void 0 ? void 0 : _c.message) !== null && _d !== void 0 ? _d : "QRL gas estimation failed", ((_e = result.runTxResult) === null || _e === void 0 ? void 0 : _e.returnValue) === undefined
                ? undefined
                : output_1.bufferToRpcData(result.runTxResult.returnValue), undefined, traceFrame);
        }
        return output_1.numberToRpcQuantity(result.estimation);
    }
    // qrl_gasPrice
    _gasPriceParams(params) {
        return input_1.validateParams(params);
    }
    async _gasPriceAction() {
        return output_1.numberToRpcQuantity(await this._node.getGasPrice());
    }
    // qrl_getBalance
    _getBalanceParams(params) {
        return input_1.validateParams(params, input_1.rpcAddress, input_1.optionalBlockTag);
    }
    async _getBalanceAction(addressBytes, blockTag) {
        this._validateStateBlockTag(blockTag);
        const address = this._config.addressFromBytes(addressBytes);
        const balance = blockTag === "pending"
            ? await this._node.getPendingAccountBalance(address)
            : await this._node.getAccountBalance(address);
        return output_1.numberToRpcQuantity(balance);
    }
    // qrl_getBlockByHash
    _getBlockByHashParams(params) {
        return input_1.validateParams(params, input_1.rpcHash, input_1.optionalBoolean);
    }
    async _getBlockByHashAction(hash, includeTransactions) {
        const block = await this._node.getBlockByHash(hash);
        return block === undefined
            ? null
            : output_1.getRpcBlock(block, includeTransactions !== null && includeTransactions !== void 0 ? includeTransactions : false);
    }
    // qrl_getBlockByNumber
    _getBlockByNumberParams(params) {
        return input_1.validateParams(params, input_1.blockTag, input_1.optionalBoolean);
    }
    async _getBlockByNumberAction(tag, includeTransactions) {
        const block = await this._resolveBlock(tag);
        return block === undefined
            ? null
            : output_1.getRpcBlock(block, includeTransactions !== null && includeTransactions !== void 0 ? includeTransactions : false);
    }
    // qrl_getBlockTransactionCountByHash
    _getBlockTransactionCountByHashParams(params) {
        return input_1.validateParams(params, input_1.rpcHash);
    }
    async _getBlockTransactionCountByHashAction(hash) {
        const block = await this._node.getBlockByHash(hash);
        return block === undefined
            ? null
            : output_1.numberToRpcQuantity(block.transactions.length);
    }
    // qrl_getBlockTransactionCountByNumber
    _getBlockTransactionCountByNumberParams(params) {
        return input_1.validateParams(params, input_1.blockTag);
    }
    async _getBlockTransactionCountByNumberAction(tag) {
        const block = await this._resolveBlock(tag);
        return block === undefined
            ? null
            : output_1.numberToRpcQuantity(block.transactions.length);
    }
    // qrl_getCode
    _getCodeParams(params) {
        return input_1.validateParams(params, input_1.rpcAddress, input_1.optionalBlockTag);
    }
    async _getCodeAction(addressBytes, blockTagValue) {
        this._validateStateBlockTag(blockTagValue);
        const address = this._config.addressFromBytes(addressBytes);
        const code = blockTagValue === "pending"
            ? await this._node.getPendingCode(address)
            : await this._node.getCode(address);
        return output_1.bufferToRpcData(code);
    }
    // qrl_getFilterChanges
    _getFilterChangesParams(params) {
        return input_1.validateParams(params, input_1.rpcQuantity);
    }
    async _getFilterChangesAction(filterId) {
        const changes = await this._node.getFilterChanges(filterId);
        if (changes === undefined) {
            throw new errors_1.InvalidInputError("QRL filter not found");
        }
        return changes;
    }
    // qrl_getFilterLogs
    _getFilterLogsParams(params) {
        return input_1.validateParams(params, input_1.rpcQuantity);
    }
    async _getFilterLogsAction(filterId) {
        const logs = await this._node.getFilterLogs(filterId);
        if (logs === undefined) {
            throw new errors_1.InvalidInputError("QRL filter not found");
        }
        return logs;
    }
    // qrl_getLogs
    _getLogsParams(params) {
        if (params.length !== 1) {
            throw new errors_1.InvalidArgumentsError("qrl_getLogs expects one filter object");
        }
        return [filter_1.parseLogFilter(params[0])];
    }
    async _getLogsAction(filter) {
        return this._node.getLogs(filter);
    }
    // qrl_getStorageAt
    _getStorageAtParams(params) {
        return input_1.validateParams(params, input_1.rpcAddress, input_1.rpcStorageKey, input_1.optionalBlockTag);
    }
    async _getStorageAtAction(addressBytes, key, blockTagValue) {
        this._validateStateBlockTag(blockTagValue);
        const address = this._config.addressFromBytes(addressBytes);
        const value = blockTagValue === "pending"
            ? await this._node.getPendingStorageAt(address, key)
            : await this._node.getStorageAt(address, key);
        return output_1.bufferToRpcData(value);
    }
    // qrl_getTransactionByBlockHashAndIndex
    _getTransactionByBlockHashAndIndexParams(params) {
        return input_1.validateParams(params, input_1.rpcHash, input_1.rpcQuantity);
    }
    async _getTransactionByBlockHashAndIndexAction(hash, index) {
        return this._transactionAtIndex(await this._node.getBlockByHash(hash), index);
    }
    // qrl_getTransactionByBlockNumberAndIndex
    _getTransactionByBlockNumberAndIndexParams(params) {
        return input_1.validateParams(params, input_1.blockTag, input_1.rpcQuantity);
    }
    async _getTransactionByBlockNumberAndIndexAction(tag, index) {
        return this._transactionAtIndex(await this._resolveBlock(tag), index);
    }
    // qrl_getTransactionByHash
    _getTransactionByHashParams(params) {
        return input_1.validateParams(params, input_1.rpcHash);
    }
    async _getTransactionByHashAction(hash) {
        var _a;
        const indexed = await this._node.getIndexedTransactionByHash(hash);
        if (indexed === undefined) {
            return null;
        }
        const receipt = await this._node.getTransactionReceipt(hash);
        const block = await this._node.getBlockByTransactionHash(hash);
        const foundIndex = block === null || block === void 0 ? void 0 : block.transactions.findIndex((transaction) => bytesEqual(transaction.hash(), hash));
        const index = foundIndex === -1 ? undefined : foundIndex;
        return output_1.getRpcTransaction(indexed.transaction, block, index, false, (_a = receipt === null || receipt === void 0 ? void 0 : receipt.from) !== null && _a !== void 0 ? _a : indexed.sender);
    }
    // qrl_getTransactionCount
    _getTransactionCountParams(params) {
        return input_1.validateParams(params, input_1.rpcAddress, input_1.optionalBlockTag);
    }
    async _getTransactionCountAction(addressBytes, blockTag) {
        this._validateStateBlockTag(blockTag);
        const address = this._config.addressFromBytes(addressBytes);
        const nonce = blockTag === "pending"
            ? await this._node.getPendingAccountNonce(address)
            : await this._node.getAccountNonce(address);
        return output_1.numberToRpcQuantity(nonce);
    }
    // qrl_getTransactionReceipt
    _getTransactionReceiptParams(params) {
        return input_1.validateParams(params, input_1.rpcHash);
    }
    async _getTransactionReceiptAction(hash) {
        const receipt = await this._node.getTransactionReceipt(hash);
        return receipt === undefined ? null : output_1.getRpcTransactionReceipt(receipt);
    }
    // qrl_mining
    _miningParams(params) {
        return input_1.validateParams(params);
    }
    async _miningAction() {
        return false;
    }
    // qrl_newBlockFilter
    _newBlockFilterParams(params) {
        return input_1.validateParams(params);
    }
    async _newBlockFilterAction() {
        return output_1.numberToRpcQuantity(await this._node.newBlockFilter());
    }
    // qrl_newFilter
    _newFilterParams(params) {
        if (params.length !== 1) {
            throw new errors_1.InvalidArgumentsError("qrl_newFilter expects one filter object");
        }
        return [filter_1.parseLogFilter(params[0])];
    }
    async _newFilterAction(filter) {
        return output_1.numberToRpcQuantity(await this._node.newFilter(filter));
    }
    // qrl_newPendingTransactionFilter
    _newPendingTransactionFilterParams(params) {
        return input_1.validateParams(params);
    }
    async _newPendingTransactionFilterAction() {
        return output_1.numberToRpcQuantity(await this._node.newPendingTransactionFilter());
    }
    // qrl_pendingTransactions
    _pendingTransactionsParams(params) {
        return input_1.validateParams(params);
    }
    async _pendingTransactionsAction() {
        const transactions = await this._node.getPendingTransactions();
        return Promise.all(transactions.map(async (transaction) => {
            const indexed = await this._node.getIndexedTransactionByHash(transaction.hash());
            return Object.assign(Object.assign({}, output_1.getRpcTransaction(transaction, undefined, undefined, false, indexed === null || indexed === void 0 ? void 0 : indexed.sender)), { blockHash: null, blockNumber: null, transactionIndex: null });
        }));
    }
    // qrl_sendRawTransaction
    _sendRawTransactionParams(params) {
        return input_1.validateParams(params, input_1.rpcData);
    }
    async _sendRawTransactionAction(serialized) {
        let transaction;
        try {
            transaction = this._config.transactionFromSerialized(serialized);
        }
        catch (error) {
            throw new errors_1.InvalidArgumentsError("Invalid raw QRL transaction: ".concat(error.message));
        }
        return this._submitTransaction(this._node.runRawTransaction(transaction));
    }
    // qrl_sendTransaction
    _sendTransactionParams(params) {
        return input_1.validateParams(params, input_1.rpcTransactionRequest);
    }
    async _sendTransactionAction(request) {
        const { transaction, sender } = await this._createTransaction(request, true, this._config.defaultGasLimit);
        return this._submitTransaction(this._node.runTransaction(transaction, sender));
    }
    // qrl_subscribe
    _subscribeParams(params) {
        if (params.length === 0) {
            throw new errors_1.InvalidInputError("Expected subscription name as first argument");
        }
        if (params.length > 2) {
            throw new errors_1.InvalidArgumentsError("qrl_subscribe expects a type and optional arguments");
        }
        const request = input_1.validateParams([params[0]], input_1.rpcSubscribeRequest)[0];
        return [request, params[1]];
    }
    async _subscribeAction(request, options) {
        switch (request) {
            case "newHeads":
                if (options !== undefined) {
                    throw new errors_1.InvalidArgumentsError("qrl_subscribe newHeads does not accept arguments");
                }
                return output_1.numberToRpcQuantity(this._node.newHeadsSubscription());
            case "newPendingTransactions":
                if (options !== undefined && typeof options !== "boolean") {
                    throw new errors_1.InvalidArgumentsError("qrl_subscribe newPendingTransactions flag must be a boolean");
                }
                return output_1.numberToRpcQuantity(this._node.newPendingTransactionsSubscription(options === true));
            case "logs":
                return output_1.numberToRpcQuantity(this._node.newLogsSubscription(filter_1.parseLogFilter(options !== null && options !== void 0 ? options : {})));
        }
    }
    // qrl_syncing
    _syncingParams(params) {
        return input_1.validateParams(params);
    }
    async _syncingAction() {
        return false;
    }
    // qrl_uninstallFilter
    _uninstallFilterParams(params) {
        return input_1.validateParams(params, input_1.rpcQuantity);
    }
    async _uninstallFilterAction(filterId) {
        return this._node.uninstallFilter(filterId);
    }
    // qrl_unsubscribe
    _unsubscribeParams(params) {
        return input_1.validateParams(params, input_1.rpcQuantity);
    }
    async _unsubscribeAction(subscriptionId) {
        return this._node.unsubscribe(subscriptionId);
    }
    async _createTransaction(request, usePendingState, defaultGasLimit) {
        var _a, _b, _c, _d, _e;
        if (request.from === undefined) {
            throw new errors_1.InvalidArgumentsError("QRL transaction request requires a from address");
        }
        const sender = this._config.addressFromBytes(request.from);
        const nonce = (_a = request.nonce) !== null && _a !== void 0 ? _a : (usePendingState
            ? await this._node.getPendingAccountNonce(sender)
            : await this._node.getAccountNonce(sender));
        const gasLimit = this._resolveGasLimit(request, defaultGasLimit);
        const transaction = this._config.createTransaction({
            chainId: this._config.chainId,
            nonce,
            gasTipCap: (_b = request.maxPriorityFeePerGas) !== null && _b !== void 0 ? _b : global.BigInt(0),
            gasFeeCap: (_c = request.maxFeePerGas) !== null && _c !== void 0 ? _c : global.BigInt(0),
            gasLimit,
            to: request.to === undefined
                ? undefined
                : this._config.addressFromBytes(request.to),
            value: (_d = request.value) !== null && _d !== void 0 ? _d : global.BigInt(0),
            data: (_e = request.data) !== null && _e !== void 0 ? _e : new Uint8Array(0),
        });
        return { transaction, sender };
    }
    _resolveGasLimit(request, defaultGasLimit) {
        var _a, _b;
        if (request.gas !== undefined &&
            request.gasLimit !== undefined &&
            request.gas !== request.gasLimit) {
            throw new errors_1.InvalidArgumentsError("QRL gas and gasLimit cannot differ");
        }
        return (_b = (_a = request.gas) !== null && _a !== void 0 ? _a : request.gasLimit) !== null && _b !== void 0 ? _b : defaultGasLimit;
    }
    async _submitTransaction(resultPromise) {
        var _a, _b;
        const result = await resultPromise;
        const hash = output_1.bufferToRpcData(result.transaction.hash());
        await this._logTransaction(result, hash);
        if (this._throwOnTransactionFailures &&
            result.block !== undefined &&
            result.runTxResult.status === 0) {
            throw new errors_1.QrlExecutionError((_b = (_a = result.runTxResult.executionError) === null || _a === void 0 ? void 0 : _a.message) !== null && _b !== void 0 ? _b : "QRL transaction failed", output_1.bufferToRpcData(result.runTxResult.returnValue), hash);
        }
        return hash;
    }
    async _traceCallFailure(call, usePendingState) {
        try {
            return await this._node.traceCallFrames(call, { usePendingState });
        }
        catch (_error) {
            this._node.recordStackTraceFailure();
            return undefined;
        }
    }
    async _traceEstimateGasFailure(transaction, sender, usePendingState) {
        try {
            return await this._node.traceEstimateGasFrames(transaction, sender, {
                usePendingState,
            });
        }
        catch (_error) {
            this._node.recordStackTraceFailure();
            return undefined;
        }
    }
    _logCall(call) {
        if (this._logger === undefined) {
            return;
        }
        this._logger.logWithTitle("Contract call", call.to.toString());
        this._logger.logWithTitle("From", call.from.toString());
        this._logger.logWithTitle("To", call.to.toString());
        this._logger.logWithTitle("Value", `${call.value.toString()} wei`);
        this._logger.logWithTitle("Gas limit", call.gasLimit.toString());
    }
    async _logTransaction(result, hash) {
        if (this._logger === undefined) {
            return;
        }
        const transaction = result.transaction;
        const indexed = await this._node.getIndexedTransactionByHash(transaction.hash());
        this._logger.logWithTitle("Transaction", hash);
        if ((indexed === null || indexed === void 0 ? void 0 : indexed.sender) !== undefined) {
            this._logger.logWithTitle("From", indexed.sender.toString());
        }
        if (transaction.to === undefined) {
            this._logger.logWithTitle("Contract deployment", "<unknown>");
        }
        else {
            this._logger.logWithTitle("To", transaction.to.toString());
        }
        this._logger.logWithTitle("Value", `${transaction.value.toString(10)} wei`);
        this._logger.logWithTitle("Gas used", `${result.runTxResult.gasUsed.toString(10)} of ${transaction.gasLimit.toString(10)}`);
        if (result.block !== undefined) {
            this._logger.logWithTitle(`Block #${result.block.header.number.toString(10)}`, output_1.bufferToRpcData(result.block.hash()));
        }
    }
    async _resolveBlock(tag) {
        if (tag === "latest") {
            return this._node.getLatestBlock();
        }
        if (tag === "pending") {
            return this._node.getPendingBlock();
        }
        if (tag === "earliest") {
            return this._node.getBlockByNumber(global.BigInt(0));
        }
        return this._node.getBlockByNumber(tag);
    }
    _transactionAtIndex(block, index) {
        var _a;
        if (block === undefined) {
            return null;
        }
        const numericIndex = Number(index);
        const transaction = block.transactions[numericIndex];
        if (transaction === undefined) {
            return null;
        }
        return output_1.getRpcTransaction(transaction, block, numericIndex, false, (_a = block.receipts[numericIndex]) === null || _a === void 0 ? void 0 : _a.from);
    }
    _validateStateBlockTag(blockTag) {
        if (blockTag !== undefined &&
            blockTag !== "latest" &&
            blockTag !== "pending") {
            throw new errors_1.InvalidInputError(`Received unsupported QRL state block param ${blockTag.toString()}. Only latest and pending are supported.`);
        }
    }
}
exports.QrlModule = QrlModule;
function bytesEqual(left, right) {
    return Buffer.from(left).equals(Buffer.from(right));
}
//# sourceMappingURL=qrl.js.map