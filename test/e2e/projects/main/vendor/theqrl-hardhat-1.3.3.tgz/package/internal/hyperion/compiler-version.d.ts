import { LocalCompilerIdentity } from "./compiler-types";
export declare type CompilerFingerprint = LocalCompilerIdentity;
/**
 * Resolves the hypc binary exactly like the compiler invocation does:
 * config `compilerPath`, then HYPERION_HYPC_PATH, then HYPC_PATH, then
 * `hypc` from PATH. Path-like values are made absolute against the project
 * root (the compiler runs with `cwd: projectRoot`), so the version probe
 * and the compilation always target the same binary. Bare names are
 * returned as-is and looked up on PATH at execution time.
 */
export declare function resolveHypcPath(compilerPath: string | undefined, projectRoot: string): string;
/**
 * Extracts the long version (e.g. `0.2.0-ci.2026.5.21+commit.cd63ffc3...`)
 * from `hypc --version` output:
 *
 *   hypc, the hyperion compiler commandline interface
 *   Version: 0.2.0-ci.2026.5.21+commit.cd63ffc3.mod.Linux.g++
 */
export declare function parseHypcVersionOutput(output: string): string | undefined;
/**
 * Returns the warning to print when the configured `hyperion.version`
 * disagrees with the binary, or undefined when nothing should be printed.
 * `"local"` never warns; a concrete version matches when it is the detected
 * long version or its release prefix (local builds carry `-`/`+` suffixes).
 */
export declare function getVersionMismatchWarning(configuredVersion: string, compiler: {
    path: string;
    longVersion?: string;
} | CompilerFingerprint | undefined): string | undefined;
/**
 * Stats and version-probes the resolved hypc binary. Returns undefined when
 * the binary cannot be found — the compile itself will then fail with the
 * real error, and the cache treats "unknown binary" as a miss. The project
 * root anchors relative and empty PATH entries, mirroring how execFile
 * resolves a bare name with `cwd: projectRoot`.
 */
export declare function getCompilerFingerprint(hypcPath: string, projectRoot: string): Promise<CompilerFingerprint | undefined>;
//# sourceMappingURL=compiler-version.d.ts.map