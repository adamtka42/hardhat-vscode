import { HyperionConfig } from "../../types";
import { HyperionInput } from "./compiler-input";
import { ResolvedHyperionCompiler } from "./compiler-types";
export declare const HYPERION_COMPILER_REPOSITORY_ENV = "HYPERION_COMPILER_REPOSITORY_URL";
export declare class Compiler {
    private readonly _config;
    private readonly _projectRoot;
    private readonly _cacheDir;
    private _resolvedCompiler?;
    constructor(_config: HyperionConfig, _projectRoot: string, _cacheDir: string);
    compile(input: HyperionInput): Promise<any>;
    getCompiler(): Promise<ResolvedHyperionCompiler>;
    private _resolveCompiler;
}
export declare function compileHyperion(input: HyperionInput, projectRoot: string, compilerPath?: string): Promise<any>;
//# sourceMappingURL=compiler.d.ts.map