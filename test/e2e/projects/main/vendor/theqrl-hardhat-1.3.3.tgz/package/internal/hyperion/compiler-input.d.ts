import { HyperionOptimizerConfig } from "../../types";
import { DependencyGraph } from "./dependencyGraph";
export interface HyperionInput {
    language: "Hyperion";
    sources: {
        [sourceName: string]: {
            content: string;
        };
    };
    settings: {
        optimizer: {
            enabled: boolean;
            runs?: number;
        };
        metadata: {
            useLiteralContent: true;
        };
        outputSelection: {
            "*": {
                "*": string[];
                "": string[];
            };
        };
    };
}
export declare function getInputFromDependencyGraph(graph: DependencyGraph, optimizer: HyperionOptimizerConfig): HyperionInput;
/**
 * Builds the complete standard JSON input from the dependency graph's
 * sources. Single construction point: the compile task passes the result
 * UNMODIFIED to `compileHyperion` and to the compiler-input cache.
 */
export declare function buildHyperionStandardJsonInput(sources: HyperionInput["sources"], optimizer: HyperionOptimizerConfig): HyperionInput;
//# sourceMappingURL=compiler-input.d.ts.map