import { IQrlProvider } from "../../../types";
export declare function createChainIdValidationProvider(provider: IQrlProvider, chainId?: number): import("../../../types").QrlProvider;
//# sourceMappingURL=chainId.d.ts.map