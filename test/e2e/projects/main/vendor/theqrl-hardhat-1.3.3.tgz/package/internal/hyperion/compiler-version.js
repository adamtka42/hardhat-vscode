"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const child_process_1 = require("child_process");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const util_1 = require("util");
const execFileAsync = util_1.promisify(child_process_1.execFile);
/**
 * Resolves the hypc binary exactly like the compiler invocation does:
 * config `compilerPath`, then HYPERION_HYPC_PATH, then HYPC_PATH, then
 * `hypc` from PATH. Path-like values are made absolute against the project
 * root (the compiler runs with `cwd: projectRoot`), so the version probe
 * and the compilation always target the same binary. Bare names are
 * returned as-is and looked up on PATH at execution time.
 */
function resolveHypcPath(compilerPath, projectRoot) {
    const configured = compilerPath !== undefined
        ? compilerPath
        : process.env.HYPERION_HYPC_PATH !== undefined
            ? process.env.HYPERION_HYPC_PATH
            : process.env.HYPC_PATH !== undefined
                ? process.env.HYPC_PATH
                : "hypc";
    return isPathLike(configured)
        ? path.resolve(projectRoot, configured)
        : configured;
}
exports.resolveHypcPath = resolveHypcPath;
function isPathLike(binary) {
    return binary.includes(path.sep) || binary.includes("/");
}
/**
 * Extracts the long version (e.g. `0.2.0-ci.2026.5.21+commit.cd63ffc3...`)
 * from `hypc --version` output:
 *
 *   hypc, the hyperion compiler commandline interface
 *   Version: 0.2.0-ci.2026.5.21+commit.cd63ffc3.mod.Linux.g++
 */
function parseHypcVersionOutput(output) {
    const match = output.match(/^\s*Version:\s*(\S+)\s*$/m);
    return match !== null ? match[1] : undefined;
}
exports.parseHypcVersionOutput = parseHypcVersionOutput;
/**
 * Returns the warning to print when the configured `hyperion.version`
 * disagrees with the binary, or undefined when nothing should be printed.
 * `"local"` never warns; a concrete version matches when it is the detected
 * long version or its release prefix (local builds carry `-`/`+` suffixes).
 */
function getVersionMismatchWarning(configuredVersion, compiler) {
    if (configuredVersion === "local") {
        return undefined;
    }
    if (compiler === undefined || compiler.longVersion === undefined) {
        return `Hyperion config claims version ${configuredVersion}, but the version of the hypc binary could not be detected.`;
    }
    const detected = compiler.longVersion;
    if (detected === configuredVersion ||
        detected.startsWith(`${configuredVersion}+`) ||
        detected.startsWith(`${configuredVersion}-`)) {
        return undefined;
    }
    const compilerPath = "path" in compiler ? compiler.path : compiler.resolvedPath;
    return `Hyperion config claims version ${configuredVersion}, but ${compilerPath} reports ${detected}. Compiling with the binary's version.`;
}
exports.getVersionMismatchWarning = getVersionMismatchWarning;
// `hypc --version` results memoized per binary identity, so repeated
// fingerprint requests within one run cost a single exec.
const versionCache = new Map();
/**
 * Stats and version-probes the resolved hypc binary. Returns undefined when
 * the binary cannot be found — the compile itself will then fail with the
 * real error, and the cache treats "unknown binary" as a miss. The project
 * root anchors relative and empty PATH entries, mirroring how execFile
 * resolves a bare name with `cwd: projectRoot`.
 */
async function getCompilerFingerprint(hypcPath, projectRoot) {
    const resolvedPath = resolveBinaryOnPath(hypcPath, projectRoot);
    if (resolvedPath === undefined) {
        return undefined;
    }
    let stats;
    try {
        stats = fs.statSync(resolvedPath);
    }
    catch (_a) {
        return undefined;
    }
    const cached = versionCache.get(resolvedPath);
    if (cached !== undefined &&
        cached.mtimeMs === stats.mtimeMs &&
        cached.size === stats.size) {
        return makeFingerprint(resolvedPath, stats, cached.longVersion);
    }
    let longVersion;
    try {
        const { stdout } = await execFileAsync(resolvedPath, ["--version"], {
            shell: process.platform === "win32",
        });
        longVersion = parseHypcVersionOutput(stdout.toString());
    }
    catch (_b) {
        longVersion = undefined;
    }
    versionCache.set(resolvedPath, {
        mtimeMs: stats.mtimeMs,
        size: stats.size,
        longVersion,
    });
    return makeFingerprint(resolvedPath, stats, longVersion);
}
exports.getCompilerFingerprint = getCompilerFingerprint;
// The fingerprint is persisted in the compile cache as JSON, where undefined
// values disappear — omit the key entirely so a stat-identical reload
// compares deep-equal to a freshly computed fingerprint.
function makeFingerprint(resolvedPath, stats, longVersion) {
    const fingerprint = {
        source: "local",
        resolvedPath,
        mtimeMs: stats.mtimeMs,
        size: stats.size,
    };
    if (longVersion !== undefined) {
        fingerprint.longVersion = longVersion;
    }
    return fingerprint;
}
function resolveBinaryOnPath(binary, projectRoot) {
    var _a, _b;
    if (isPathLike(binary)) {
        return fs.existsSync(binary) ? path.resolve(binary) : undefined;
    }
    const pathEntries = ((_a = process.env.PATH) !== null && _a !== void 0 ? _a : "").split(path.delimiter);
    // The bare name is tried first so an explicit `hypc.exe` does not get a
    // second PATHEXT extension appended.
    const extensions = process.platform === "win32"
        ? ["", ...((_b = process.env.PATHEXT) !== null && _b !== void 0 ? _b : ".EXE;.CMD;.BAT").split(";")]
        : [""];
    for (const entry of pathEntries) {
        // Relative and empty PATH entries resolve against the project root —
        // exactly what execFile sees when running with `cwd: projectRoot`.
        const entryDir = path.resolve(projectRoot, entry);
        for (const extension of extensions) {
            const candidate = path.join(entryDir, binary + extension.toLowerCase());
            try {
                if (fs.statSync(candidate).isFile()) {
                    return candidate;
                }
            }
            catch (_c) {
                // Missing or unreadable entries are skipped.
            }
        }
    }
    return undefined;
}
//# sourceMappingURL=compiler-version.js.map