interface QrlAddressLike {
    toString(): string;
}
interface QrlTransactionLike {
    type: number | bigint;
    chainId: bigint;
    nonce: bigint;
    to?: QrlAddressLike;
    gasLimit: bigint;
    gasFeeCap: bigint;
    gasTipCap: bigint;
    value: bigint;
    data: Uint8Array;
    hash(): Uint8Array;
}
interface QrlLogLike {
    address: QrlAddressLike;
    topics: ReadonlyArray<Uint8Array>;
    data: Uint8Array;
    blockNumber?: bigint;
    txHash?: Uint8Array;
    txIndex?: number;
    blockHash?: Uint8Array;
    index?: number;
    removed: boolean;
}
interface QrlReceiptLike {
    txHash: Uint8Array;
    blockHash?: Uint8Array;
    blockNumber?: bigint;
    transactionIndex?: number;
    from: QrlAddressLike;
    to?: QrlAddressLike;
    createdAddress?: QrlAddressLike;
    status: 0 | 1;
    gasUsed: bigint;
    cumulativeGasUsed: bigint;
    effectiveGasPrice?: bigint;
    logs: ReadonlyArray<QrlLogLike>;
    logsBloom: Uint8Array;
}
interface QrlBlockLike {
    header: {
        parentHash: Uint8Array;
        number: bigint;
        timestamp: bigint;
        gasLimit: bigint;
        gasUsed: bigint;
        baseFee: bigint;
        coinbase: QrlAddressLike;
        stateRoot: Uint8Array;
        transactionsRoot: Uint8Array;
        receiptsRoot: Uint8Array;
        logsBloom: Uint8Array;
    };
    transactions: ReadonlyArray<QrlTransactionLike>;
    receipts: ReadonlyArray<QrlReceiptLike>;
    hash(): Uint8Array;
}
export interface RpcBlockOutput {
    hash: string;
    parentHash: string;
    number: string;
    timestamp: string;
    gasLimit: string;
    gasUsed: string;
    baseFeePerGas: string;
    miner: string;
    stateRoot: string;
    transactionsRoot: string;
    receiptsRoot: string;
    logsBloom: string;
    transactions: string[] | RpcTransactionOutput[];
    receipts: RpcTransactionReceiptOutput[];
}
export interface RpcTransactionOutput {
    hash: string;
    type: string;
    chainId: string;
    nonce: string;
    from?: string;
    to?: string;
    gas: string;
    gasLimit: string;
    gasFeeCap: string;
    gasTipCap: string;
    maxFeePerGas: string;
    maxPriorityFeePerGas: string;
    value: string;
    input: string;
    data: string;
    blockHash?: string;
    blockNumber?: string;
    transactionIndex?: string;
}
export interface RpcTransactionReceiptOutput {
    transactionHash: string;
    blockHash?: string;
    blockNumber?: string;
    transactionIndex?: string;
    from: string;
    to?: string;
    contractAddress?: string;
    status: string;
    gasUsed: string;
    cumulativeGasUsed: string;
    effectiveGasPrice?: string;
    logsBloom: string;
    logs: RpcLogOutput[];
}
export interface RpcLogOutput {
    address: string;
    topics: string[];
    data: string;
    blockNumber?: string;
    transactionHash?: string;
    transactionIndex?: string;
    blockHash?: string;
    logIndex?: string;
    removed: boolean;
}
export interface QrlRawStructLogOutputInput {
    pc: number;
    opcode: number;
    depth: number;
    gasLeft: bigint;
    gasCost: bigint;
    stack?: Array<bigint>;
    memory?: Uint8Array;
}
export interface RpcStructLogOutput {
    pc: number;
    op: string;
    gas: number;
    gasCost: number;
    depth: number;
    stack?: string[];
    memory?: string[];
}
export interface RpcDebugTraceOutput {
    gas: number;
    failed: boolean;
    returnValue: string;
    structLogs: RpcStructLogOutput[];
}
export declare function numberToRpcQuantity(n: number | bigint): string;
export declare function bufferToRpcData(buffer: Uint8Array, pad?: number): string;
export declare function getRpcBlock(block: QrlBlockLike, includeTransactions?: boolean): RpcBlockOutput;
export declare function getRpcTransaction(tx: QrlTransactionLike, block?: QrlBlockLike, index?: number, txHashOnly?: false, from?: QrlAddressLike): RpcTransactionOutput;
export declare function getRpcTransaction(tx: QrlTransactionLike, block: QrlBlockLike | undefined, index: number | undefined, txHashOnly: true, from?: QrlAddressLike): string;
export declare function getRpcTransaction(tx: QrlTransactionLike, block?: QrlBlockLike, index?: number, txHashOnly?: boolean, from?: QrlAddressLike): string | RpcTransactionOutput;
export declare function getRpcTransactionReceipt(receipt: QrlReceiptLike): RpcTransactionReceiptOutput;
export declare function getRpcLog(log: QrlLogLike): RpcLogOutput;
export declare function getRpcDebugTrace(result: {
    gasUsed: bigint;
    returnValue: Uint8Array;
    failed: boolean;
}, steps: QrlRawStructLogOutputInput[], opcodeName: (opcode: number) => string): RpcDebugTraceOutput;
export {};
//# sourceMappingURL=output.d.ts.map