export declare const HARDHAT_NAME = "Hardhat";
export declare const HARDHAT_EXECUTABLE_NAME = "hardhat";
export declare const HARDHAT_QRLVM_NETWORK_NAME = "hardhatqrlvm";
export declare const COMPILER_INPUT_FILENAME = "compiler-input.json";
export declare const COMPILER_OUTPUT_FILENAME = "compiler-output.json";
//# sourceMappingURL=constants.d.ts.map