/// <reference types="node" />
import { IncomingMessage, ServerResponse } from "http";
import WebSocket from "ws";
import { IQrlProvider } from "../../../types";
export default class JsonRpcHandler {
    private readonly _provider;
    constructor(_provider: IQrlProvider);
    handleHttp: (req: IncomingMessage, res: ServerResponse) => Promise<void>;
    handleWs: (ws: WebSocket) => Promise<void>;
    private _handleSingleHttpRequest;
    private _sendEmptyResponse;
    private _setCorsHeaders;
    private _sendResponse;
    private _handleSingleRequest;
    private _handleRequest;
}
//# sourceMappingURL=handler.d.ts.map