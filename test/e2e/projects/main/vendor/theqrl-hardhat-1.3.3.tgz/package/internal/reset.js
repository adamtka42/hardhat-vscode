"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * This function resets the Hardhat context.
 *
 * This doesn't unload any loaded Hardhat plugin, so those have to be unloaded
 * manually with `unloadModule`.
 */
const context_1 = require("./context");
const project_structure_1 = require("./core/project-structure");
function resetHardhatContext() {
    if (context_1.HardhatContext.isCreated()) {
        const ctx = context_1.HardhatContext.getHardhatContext();
        const globalAsAny = global;
        if (ctx.environment !== undefined) {
            for (const key of Object.keys(ctx.environment)) {
                globalAsAny[key] = undefined;
            }
            // unload config file too.
            unloadModule(ctx.environment.config.paths.configFile);
        }
        else {
            // We may get here if loading the config has thrown, so be unload it
            let configPath;
            try {
                configPath = project_structure_1.getUserConfigPath();
            }
            catch (error) {
                // We weren't in a Hardhat project
            }
            if (configPath !== undefined) {
                unloadModule(configPath);
            }
        }
        context_1.HardhatContext.deleteHardhatContext();
    }
    // Unload all the Hardhat's entry-points.
    unloadModule("../register");
    unloadModule("./cli/cli");
    unloadModule("./lib/hardhat-lib");
}
exports.resetHardhatContext = resetHardhatContext;
function unloadModule(path) {
    try {
        delete require.cache[require.resolve(path)];
    }
    catch (err) {
        // module wasn't loaded
    }
}
//# sourceMappingURL=reset.js.map