/** Selector (8 hex chars) -> canonical argument types of log(...). */
export declare const CONSOLE_LOG_SIGNATURES: ReadonlyArray<[string, string[]]>;
//# sourceMappingURL=logger.d.ts.map