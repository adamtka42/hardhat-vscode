export interface ResolvedFilesMap {
    [globalName: string]: ResolvedFile;
}
export interface LibraryInfo {
    name: string;
    version: string;
}
export declare class ResolvedFile {
    readonly globalName: string;
    readonly absolutePath: string;
    readonly content: string;
    readonly lastModificationDate: Date;
    readonly library?: LibraryInfo;
    constructor(globalName: string, absolutePath: string, content: string, lastModificationDate: Date, libraryName?: string, libraryVersion?: string);
    getVersionedName(): string;
}
export declare class Resolver {
    private readonly _projectRoot;
    constructor(projectRoot: string);
    resolveProjectSourceFile(pathToResolve: string): Promise<ResolvedFile>;
    resolveLibrarySourceFile(globalName: string): Promise<ResolvedFile>;
    resolveImport(from: ResolvedFile, imported: string): Promise<ResolvedFile>;
    _resolveFile(globalName: string, absolutePath: string, libraryName?: string, libraryVersion?: string): Promise<ResolvedFile>;
    private _isRelativeImport;
    private _resolveFromProjectRoot;
    private _getLibraryName;
}
//# sourceMappingURL=resolver.d.ts.map