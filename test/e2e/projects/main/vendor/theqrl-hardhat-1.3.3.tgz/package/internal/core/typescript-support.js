"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const chalk_1 = __importDefault(require("chalk"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const execution_mode_1 = require("./execution-mode");
const NODE_MODULES_DIR = "node_modules";
function getHardhatNodeModules() {
    return __dirname.substring(0, __dirname.lastIndexOf(NODE_MODULES_DIR) + NODE_MODULES_DIR.length);
}
let cachedIsTypescriptSupported;
function isTypescriptSupported() {
    if (cachedIsTypescriptSupported === undefined) {
        const executionMode = execution_mode_1.getExecutionMode();
        if (executionMode === execution_mode_1.ExecutionMode.EXECUTION_MODE_GLOBAL_INSTALLATION) {
            cachedIsTypescriptSupported = false;
        }
        else if (executionMode === execution_mode_1.ExecutionMode.EXECUTION_MODE_LOCAL_INSTALLATION) {
            const nodeModules = getHardhatNodeModules();
            cachedIsTypescriptSupported =
                fs.existsSync(path.join(nodeModules, "typescript")) &&
                    fs.existsSync(path.join(nodeModules, "ts-node"));
        }
        else {
            // We are inside this project (e.g. running tests), or Hardhat is
            // linked and we can't get the Hardhat project's node_modules, so we
            // return true.
            //
            // This is safe because Hardhat will use this project's installation of
            // TypeScript and ts-node. We need them for compilation and testing, so
            // they'll always be installed.
            cachedIsTypescriptSupported = true;
        }
    }
    return cachedIsTypescriptSupported;
}
exports.isTypescriptSupported = isTypescriptSupported;
function loadTsNodeIfPresent() {
    if (isTypescriptSupported()) {
        // Force ts-node to load files from tsconfig for task/config execution.
        if (process.env.TS_NODE_FILES === undefined) {
            process.env.TS_NODE_FILES = "true";
        }
        try {
            // tslint:disable-next-line no-implicit-dependencies
            require("ts-node/register");
        }
        catch (error) {
            if (error.message.includes("Cannot find module 'typescript'")) {
                console.warn(chalk_1.default.yellow("Failed to load TypeScript support. Please update ts-node."));
                return;
            }
            // tslint:disable-next-line only-hardhat-error
            throw error;
        }
    }
}
exports.loadTsNodeIfPresent = loadTsNodeIfPresent;
//# sourceMappingURL=typescript-support.js.map