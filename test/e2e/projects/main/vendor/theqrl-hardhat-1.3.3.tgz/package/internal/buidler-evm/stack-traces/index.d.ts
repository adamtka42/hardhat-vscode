import { loadQrlDebugInfo, QrlDebugInfo } from "./compiler-to-model";
import { QrlStackTraceDiagnostic, QrlStackTraceEntryType } from "./solidity-stack-trace";
import { inferQrlStackTrace } from "./solidityTracer";
import { QrlStackTraceDecoder, QrlStackTraceEntry } from "./vm-trace-decoder";
export { inferQrlStackTrace, loadQrlDebugInfo, QrlStackTraceDecoder };
export { QrlDebugInfo, QrlStackTraceDiagnostic, QrlStackTraceEntry, QrlStackTraceEntryType, };
/** Builds source-level Hyperion stack-trace lines for a failed frame tree. */
export declare function buildQrlStackTraceLines(rootFrame: any, decoder: QrlStackTraceDecoder): Promise<string[]>;
//# sourceMappingURL=index.d.ts.map