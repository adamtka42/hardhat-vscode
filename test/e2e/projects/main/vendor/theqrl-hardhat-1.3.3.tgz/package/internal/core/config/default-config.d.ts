import { HardhatConfig } from "../../../types";
declare const defaultConfig: HardhatConfig;
export default defaultConfig;
//# sourceMappingURL=default-config.d.ts.map