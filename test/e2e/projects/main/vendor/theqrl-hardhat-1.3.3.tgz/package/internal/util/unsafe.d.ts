/**
 * This function is a typed version of `Object.keys`. Note that it's type
 * unsafe. You have to be sure that `o` has exactly the same keys as `T`.
 */
export declare const unsafeObjectKeys: <T>(o: T) => Extract<keyof T, string>[];
//# sourceMappingURL=unsafe.d.ts.map