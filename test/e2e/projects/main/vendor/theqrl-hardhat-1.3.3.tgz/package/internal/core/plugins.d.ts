import { HardhatContext } from "../context";
interface PackageJson {
    name: string;
    version: string;
    peerDependencies: {
        [name: string]: string;
    };
}
/**
 * Validates a plugin dependencies and loads it.
 * @param pluginName - The plugin name
 * @param hardhatContext - The HardhatContext
 * @param from - Where to resolve plugins and dependencies from. Only for
 * testing purposes.
 */
export declare function usePlugin(hardhatContext: HardhatContext, pluginName: string, from?: string): void;
export declare function loadPluginFile(absolutePluginFilePath: string): void;
export declare function readPackageJson(packageName: string, from?: string): PackageJson | undefined;
export declare function ensurePluginLoadedWithUsePlugin(): void;
export {};
//# sourceMappingURL=plugins.d.ts.map