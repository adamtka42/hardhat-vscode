"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const t = __importStar(require("io-ts"));
const PathReporter_1 = require("io-ts/lib/PathReporter");
const address_1 = require("../../qrl/address");
const errors_1 = require("./errors");
function optional(codec, name = `${codec.name} | undefined`) {
    return new t.Type(name, (u) => u === undefined || codec.is(u), (u, c) => (u === undefined ? t.success(u) : codec.validate(u, c)), (a) => (a === undefined ? undefined : codec.encode(a)));
}
const isRpcQuantityString = (u) => typeof u === "string" &&
    u.match(/^0x(?:0|(?:[1-9a-fA-F][0-9a-fA-F]*))$/) !== null;
const isRpcDataString = (u) => typeof u === "string" && u.match(/^0x(?:[0-9a-fA-F]{2})*$/) !== null;
const isRpcHashString = (u) => typeof u === "string" && u.length === 66 && isRpcDataString(u);
const isRpcTopicString = (u) => typeof u === "string" && u.length === 130 && isRpcDataString(u);
const rpcHexToBytes = (value) => Uint8Array.from(Buffer.from(value.slice(2), "hex"));
exports.rpcQuantity = new t.Type("QUANTITY", (u) => typeof u === "bigint", (u, c) => isRpcQuantityString(u)
    ? t.success(global.BigInt(u))
    : t.failure(u, c), t.identity);
exports.rpcData = new t.Type("DATA", (u) => u instanceof Uint8Array, (u, c) => isRpcDataString(u) ? t.success(rpcHexToBytes(u)) : t.failure(u, c), t.identity);
exports.rpcHash = new t.Type("HASH", (u) => u instanceof Uint8Array, (u, c) => isRpcHashString(u) ? t.success(rpcHexToBytes(u)) : t.failure(u, c), t.identity);
exports.rpcStorageKey = new t.Type("DATA_32", (u) => u instanceof Uint8Array && u.length === 32, (u, c) => typeof u === "string" && u.length === 66 && isRpcDataString(u)
    ? t.success(rpcHexToBytes(u))
    : t.failure(u, c), t.identity);
exports.rpcTopic = new t.Type("TOPIC", (u) => u instanceof Uint8Array, (u, c) => isRpcTopicString(u) ? t.success(rpcHexToBytes(u)) : t.failure(u, c), t.identity);
exports.rpcUnknown = t.unknown;
exports.rpcAddress = new t.Type("ADDRESS", (u) => u instanceof Uint8Array, (u, c) => typeof u === "string" && address_1.isValidQrlAddress(u)
    ? t.success(address_1.qrlAddressToBytes(u))
    : t.failure(u, c), t.identity);
exports.logAddress = t.union([
    exports.rpcAddress,
    t.array(exports.rpcAddress),
    t.undefined,
]);
exports.logTopics = t.union([
    t.array(t.union([t.null, exports.rpcTopic, t.array(t.union([t.null, exports.rpcTopic]))])),
    t.undefined,
]);
exports.blockTag = t.union([
    exports.rpcQuantity,
    t.keyof({
        earliest: null,
        latest: null,
        pending: null,
    }),
]);
exports.optionalBlockTag = t.union([exports.blockTag, t.undefined]);
exports.optionalBoolean = optional(t.boolean);
exports.rpcTransactionRequest = t.type({
    from: exports.rpcAddress,
    to: optional(exports.rpcAddress),
    gas: optional(exports.rpcQuantity),
    gasLimit: optional(exports.rpcQuantity),
    gasPrice: optional(exports.rpcQuantity),
    maxFeePerGas: optional(exports.rpcQuantity),
    maxPriorityFeePerGas: optional(exports.rpcQuantity),
    value: optional(exports.rpcQuantity),
    data: optional(exports.rpcData),
    nonce: optional(exports.rpcQuantity),
    chainId: optional(exports.rpcQuantity),
}, "RpcTransactionRequest");
exports.rpcCallRequest = t.type({
    from: optional(exports.rpcAddress),
    to: optional(exports.rpcAddress),
    gas: optional(exports.rpcQuantity),
    gasLimit: optional(exports.rpcQuantity),
    gasPrice: optional(exports.rpcQuantity),
    maxFeePerGas: optional(exports.rpcQuantity),
    maxPriorityFeePerGas: optional(exports.rpcQuantity),
    value: optional(exports.rpcQuantity),
    data: optional(exports.rpcData),
}, "RpcCallRequest");
exports.rpcFilterRequest = t.type({
    fromBlock: exports.optionalBlockTag,
    toBlock: exports.optionalBlockTag,
    address: exports.logAddress,
    topics: exports.logTopics,
    blockHash: optional(exports.rpcHash),
}, "RpcFilterRequest");
exports.optionalRpcFilterRequest = t.union([
    exports.rpcFilterRequest,
    t.undefined,
]);
exports.rpcSubscribeRequest = t.keyof({
    newHeads: null,
    newPendingTransactions: null,
    logs: null,
}, "RpcSubscribe");
// tslint:disable only-hardhat-error
function validateParams(params, ...types) {
    if (types === undefined && params.length > 0) {
        throw new errors_1.InvalidArgumentsError(`No argument was expected and got ${params.length}`);
    }
    let optionalParams = 0;
    for (let i = types.length - 1; i >= 0; i--) {
        if (types[i].is(undefined)) {
            optionalParams += 1;
        }
        else {
            break;
        }
    }
    if (optionalParams === 0) {
        if (params.length !== types.length) {
            throw new errors_1.InvalidArgumentsError(`Expected exactly ${types.length} arguments and got ${params.length}`);
        }
    }
    else {
        if (params.length > types.length ||
            params.length < types.length - optionalParams) {
            throw new errors_1.InvalidArgumentsError(`Expected between ${types.length - optionalParams} and ${types.length} arguments and got ${params.length}`);
        }
    }
    const decoded = [];
    for (let i = 0; i < types.length; i++) {
        const result = types[i].decode(params[i]);
        if (result.isLeft()) {
            throw new errors_1.InvalidArgumentsError(`Errors encountered in param ${i}: ${PathReporter_1.PathReporter.report(result).join(", ")}`);
        }
        decoded.push(result.value);
    }
    return decoded;
}
exports.validateParams = validateParams;
//# sourceMappingURL=input.js.map