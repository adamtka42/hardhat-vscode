import { ErrorDescriptor } from "./errors-list";
export declare class HardhatError extends Error {
    static isHardhatError(other: any): other is HardhatError;
    readonly errorDescriptor: ErrorDescriptor;
    readonly number: number;
    readonly parent?: Error;
    private readonly _isHardhatError;
    constructor(errorDescriptor: ErrorDescriptor, messageArguments?: {
        [p: string]: any;
    }, parentError?: Error);
}
/**
 * This class is used to throw errors from Hardhat plugins.
 */
export declare class HardhatPluginError extends Error {
    static isHardhatPluginError(other: any): other is HardhatPluginError;
    readonly parent?: Error;
    readonly pluginName: string;
    private readonly _isHardhatPluginError;
    /**
     * Creates a HardhatPluginError.
     *
     * @param pluginName The name of the plugin.
     * @param message An error message that will be shown to the user.
     * @param parent The error that causes this error to be thrown.
     */
    constructor(pluginName: string, message: string, parent?: Error);
    /**
     * A DEPRECATED constructor that automatically obtains the caller package and
     * use it as plugin name.
     *
     * @deprecated Use the above constructor.
     *
     * @param message An error message that will be shown to the user.
     * @param parent The error that causes this error to be thrown.
     */
    constructor(message: string, parent?: Error);
}
/**
 * This function applies error messages templates like this:
 *
 *  - Template is a string which contains a variable tags. A variable tag is a
 *    a variable name surrounded by %. Eg: %plugin1%
 *  - A variable name is a string of alphanumeric ascii characters.
 *  - Every variable tag is replaced by its value.
 *  - %% is replaced by %.
 *  - Values can't contain variable tags.
 *  - If a variable is not present in the template, but present in the values
 *    object, an error is thrown.
 *
 * @param template The template string.
 * @param values A map of variable names to their values.
 */
export declare function applyErrorMessageTemplate(template: string, values: {
    [templateVar: string]: any;
}): string;
//# sourceMappingURL=errors.d.ts.map