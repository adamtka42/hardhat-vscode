import * as t from "io-ts";
export declare const rpcQuantity: t.Type<bigint, bigint, unknown>;
export declare const rpcData: t.Type<Uint8Array, Uint8Array, unknown>;
export declare const rpcHash: t.Type<Uint8Array, Uint8Array, unknown>;
export declare const rpcStorageKey: t.Type<Uint8Array, Uint8Array, unknown>;
export declare const rpcTopic: t.Type<Uint8Array, Uint8Array, unknown>;
export declare const rpcUnknown: t.UnknownC;
export declare const rpcAddress: t.Type<Uint8Array, Uint8Array, unknown>;
export declare const logAddress: t.UnionC<[t.Type<Uint8Array, Uint8Array, unknown>, t.ArrayC<t.Type<Uint8Array, Uint8Array, unknown>>, t.UndefinedC]>;
export declare type LogAddress = t.TypeOf<typeof logAddress>;
export declare const logTopics: t.UnionC<[t.ArrayC<t.UnionC<[t.NullC, t.Type<Uint8Array, Uint8Array, unknown>, t.ArrayC<t.UnionC<[t.NullC, t.Type<Uint8Array, Uint8Array, unknown>]>>]>>, t.UndefinedC]>;
export declare type LogTopics = t.TypeOf<typeof logTopics>;
export declare const blockTag: t.UnionC<[t.Type<bigint, bigint, unknown>, t.KeyofC<{
    earliest: null;
    latest: null;
    pending: null;
}>]>;
export declare type BlockTag = t.TypeOf<typeof blockTag>;
export declare const optionalBlockTag: t.UnionC<[t.UnionC<[t.Type<bigint, bigint, unknown>, t.KeyofC<{
    earliest: null;
    latest: null;
    pending: null;
}>]>, t.UndefinedC]>;
export declare type OptionalBlockTag = t.TypeOf<typeof optionalBlockTag>;
export declare const optionalBoolean: t.Type<boolean | undefined, boolean | undefined, unknown>;
export declare const rpcTransactionRequest: t.TypeC<{
    from: t.Type<Uint8Array, Uint8Array, unknown>;
    to: t.Type<Uint8Array | undefined, Uint8Array | undefined, unknown>;
    gas: t.Type<bigint | undefined, bigint | undefined, unknown>;
    gasLimit: t.Type<bigint | undefined, bigint | undefined, unknown>;
    gasPrice: t.Type<bigint | undefined, bigint | undefined, unknown>;
    maxFeePerGas: t.Type<bigint | undefined, bigint | undefined, unknown>;
    maxPriorityFeePerGas: t.Type<bigint | undefined, bigint | undefined, unknown>;
    value: t.Type<bigint | undefined, bigint | undefined, unknown>;
    data: t.Type<Uint8Array | undefined, Uint8Array | undefined, unknown>;
    nonce: t.Type<bigint | undefined, bigint | undefined, unknown>;
    chainId: t.Type<bigint | undefined, bigint | undefined, unknown>;
}>;
export interface RpcTransactionRequestInput {
    from: string;
    to?: string;
    gas?: string;
    gasLimit?: string;
    gasPrice?: string;
    maxFeePerGas?: string;
    maxPriorityFeePerGas?: string;
    value?: string;
    data?: string;
    nonce?: string;
    chainId?: string;
}
export declare type RpcTransactionRequest = t.TypeOf<typeof rpcTransactionRequest>;
export declare const rpcCallRequest: t.TypeC<{
    from: t.Type<Uint8Array | undefined, Uint8Array | undefined, unknown>;
    to: t.Type<Uint8Array | undefined, Uint8Array | undefined, unknown>;
    gas: t.Type<bigint | undefined, bigint | undefined, unknown>;
    gasLimit: t.Type<bigint | undefined, bigint | undefined, unknown>;
    gasPrice: t.Type<bigint | undefined, bigint | undefined, unknown>;
    maxFeePerGas: t.Type<bigint | undefined, bigint | undefined, unknown>;
    maxPriorityFeePerGas: t.Type<bigint | undefined, bigint | undefined, unknown>;
    value: t.Type<bigint | undefined, bigint | undefined, unknown>;
    data: t.Type<Uint8Array | undefined, Uint8Array | undefined, unknown>;
}>;
export interface RpcCallRequestInput {
    from?: string;
    to: string;
    gas?: string;
    gasLimit?: string;
    gasPrice?: string;
    maxFeePerGas?: string;
    maxPriorityFeePerGas?: string;
    value?: string;
    data?: string;
}
export declare type RpcCallRequest = t.TypeOf<typeof rpcCallRequest>;
export declare const rpcFilterRequest: t.TypeC<{
    fromBlock: t.UnionC<[t.UnionC<[t.Type<bigint, bigint, unknown>, t.KeyofC<{
        earliest: null;
        latest: null;
        pending: null;
    }>]>, t.UndefinedC]>;
    toBlock: t.UnionC<[t.UnionC<[t.Type<bigint, bigint, unknown>, t.KeyofC<{
        earliest: null;
        latest: null;
        pending: null;
    }>]>, t.UndefinedC]>;
    address: t.UnionC<[t.Type<Uint8Array, Uint8Array, unknown>, t.ArrayC<t.Type<Uint8Array, Uint8Array, unknown>>, t.UndefinedC]>;
    topics: t.UnionC<[t.ArrayC<t.UnionC<[t.NullC, t.Type<Uint8Array, Uint8Array, unknown>, t.ArrayC<t.UnionC<[t.NullC, t.Type<Uint8Array, Uint8Array, unknown>]>>]>>, t.UndefinedC]>;
    blockHash: t.Type<Uint8Array | undefined, Uint8Array | undefined, unknown>;
}>;
export interface RpcSubscribe {
    request: RpcFilterRequest;
}
export declare type OptionalRpcFilterRequest = t.TypeOf<typeof optionalRpcFilterRequest>;
export declare const optionalRpcFilterRequest: t.UnionC<[t.TypeC<{
    fromBlock: t.UnionC<[t.UnionC<[t.Type<bigint, bigint, unknown>, t.KeyofC<{
        earliest: null;
        latest: null;
        pending: null;
    }>]>, t.UndefinedC]>;
    toBlock: t.UnionC<[t.UnionC<[t.Type<bigint, bigint, unknown>, t.KeyofC<{
        earliest: null;
        latest: null;
        pending: null;
    }>]>, t.UndefinedC]>;
    address: t.UnionC<[t.Type<Uint8Array, Uint8Array, unknown>, t.ArrayC<t.Type<Uint8Array, Uint8Array, unknown>>, t.UndefinedC]>;
    topics: t.UnionC<[t.ArrayC<t.UnionC<[t.NullC, t.Type<Uint8Array, Uint8Array, unknown>, t.ArrayC<t.UnionC<[t.NullC, t.Type<Uint8Array, Uint8Array, unknown>]>>]>>, t.UndefinedC]>;
    blockHash: t.Type<Uint8Array | undefined, Uint8Array | undefined, unknown>;
}>, t.UndefinedC]>;
export declare type RpcSubscribeRequest = t.TypeOf<typeof rpcSubscribeRequest>;
export declare const rpcSubscribeRequest: t.KeyofC<{
    newHeads: null;
    newPendingTransactions: null;
    logs: null;
}>;
export declare type RpcFilterRequest = t.TypeOf<typeof rpcFilterRequest>;
export declare function validateParams(params: any[]): [];
export declare function validateParams(params: any[], addr: typeof rpcAddress, data: typeof rpcData): [Uint8Array, Uint8Array];
export declare function validateParams(params: any[], addr: typeof rpcAddress, block: typeof optionalBlockTag): [Uint8Array, OptionalBlockTag];
export declare function validateParams(params: any[], addr: typeof rpcAddress, slot: typeof rpcStorageKey, block: typeof optionalBlockTag): [Uint8Array, Uint8Array, OptionalBlockTag];
export declare function validateParams(params: any[], hash: typeof rpcHash, bool: typeof optionalBoolean): [Uint8Array, boolean | undefined];
export declare function validateParams(params: any[], tag: typeof blockTag, bool: typeof optionalBoolean): [BlockTag, boolean | undefined];
export declare function validateParams(params: any[], tag: typeof blockTag): [BlockTag];
export declare function validateParams(params: any[], value: typeof rpcHash | typeof rpcData): [Uint8Array];
export declare function validateParams(params: any[], tag: typeof blockTag, num: typeof rpcQuantity): [BlockTag, bigint];
export declare function validateParams(params: any[], addr: typeof rpcAddress, slot: typeof rpcQuantity, block: typeof optionalBlockTag): [Uint8Array, bigint, OptionalBlockTag];
export declare function validateParams(params: any[], tx: typeof rpcTransactionRequest): [RpcTransactionRequest];
export declare function validateParams(params: any[], call: typeof rpcCallRequest, block: typeof optionalBlockTag): [RpcCallRequest, OptionalBlockTag];
export declare function validateParams(params: any[], call: typeof rpcTransactionRequest, block: typeof optionalBlockTag): [RpcTransactionRequest, OptionalBlockTag];
export declare function validateParams(params: any[], num: typeof t.number): [number];
export declare function validateParams(params: any[], hash: typeof rpcHash, bool: typeof t.boolean): [Uint8Array, boolean];
export declare function validateParams(params: any[], tag: typeof optionalBlockTag, bool: typeof t.boolean): [OptionalBlockTag, boolean];
export declare function validateParams(params: any[], num: typeof rpcQuantity, bool: typeof t.boolean): [bigint, boolean];
export declare function validateParams(params: any[], num: typeof rpcQuantity): [bigint];
export declare function validateParams(params: any[], hash: typeof rpcHash, num: typeof rpcQuantity): [Uint8Array, bigint];
export declare function validateParams(params: any[], num1: typeof rpcQuantity, num2: typeof rpcQuantity): [bigint, bigint];
export declare function validateParams(params: any[], addr: typeof rpcAddress, data: typeof rpcUnknown): [Uint8Array, any];
export declare function validateParams(params: any[], filterRequest: typeof rpcFilterRequest): [RpcFilterRequest];
export declare function validateParams(params: any[], topics: typeof logTopics): [LogTopics];
export declare function validateParams(params: any[], subscribeRequest: typeof rpcSubscribeRequest): [RpcSubscribeRequest];
export declare function validateParams(params: any[], subscribeRequest: typeof rpcSubscribeRequest, optionalFilterRequest: typeof optionalRpcFilterRequest): [RpcSubscribeRequest, OptionalRpcFilterRequest];
//# sourceMappingURL=input.d.ts.map