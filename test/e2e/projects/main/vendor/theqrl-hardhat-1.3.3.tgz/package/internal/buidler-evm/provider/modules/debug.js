"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const errors_1 = require("../errors");
const input_1 = require("../input");
// tslint:disable only-hardhat-error
class DebugModule {
    constructor(_config, _node) {
        this._config = _config;
        this._node = _node;
    }
    async processRequest(method, params = []) {
        switch (method) {
            case "debug_traceCall":
                return this._traceCallAction(...this._traceCallParams(params));
            case "debug_traceTransaction":
                return this._traceTransactionAction(...this._traceTransactionParams(params));
        }
        throw new errors_1.MethodNotFoundError(`Method ${method} not found`);
    }
    _traceCallParams(params) {
        if (params.length < 1 || params.length > 3) {
            throw new errors_1.InvalidArgumentsError("debug_traceCall expects a call, optional block tag, and optional config");
        }
        const [request, blockTag] = input_1.validateParams(params.slice(0, 2), input_1.rpcCallRequest, input_1.optionalBlockTag);
        return [request, blockTag, parseTraceConfig(params[2])];
    }
    async _traceCallAction(request, blockTag, traceConfig) {
        this._validateStateBlockTag(blockTag);
        const call = await this._createCall(request, blockTag === "pending");
        return this._node.debugTraceCall(call, traceConfig, {
            usePendingState: blockTag === "pending",
        });
    }
    _traceTransactionParams(params) {
        if (params.length < 1 || params.length > 2) {
            throw new errors_1.InvalidArgumentsError("debug_traceTransaction expects a hash and optional config");
        }
        const [hash] = input_1.validateParams([params[0]], input_1.rpcHash);
        return [hash, parseTraceConfig(params[1])];
    }
    async _traceTransactionAction(hash, traceConfig) {
        return this._node.debugTraceTransaction(hash, traceConfig);
    }
    async _createCall(request, usePendingState) {
        var _a, _b, _c, _d, _e;
        if (request.from === undefined) {
            throw new errors_1.InvalidArgumentsError("debug_traceCall requires a QRL from address");
        }
        if (request.to === undefined) {
            throw new errors_1.InvalidArgumentsError("debug_traceCall requires a QRL to address");
        }
        const sender = this._config.addressFromBytes(request.from);
        const nonce = usePendingState
            ? await this._node.getPendingAccountNonce(sender)
            : await this._node.getAccountNonce(sender);
        const gasLimit = resolveGasLimit(request, this._config.defaultGasLimit);
        const transaction = this._config.createTransaction({
            chainId: this._config.chainId,
            nonce,
            gasTipCap: (_a = request.maxPriorityFeePerGas) !== null && _a !== void 0 ? _a : global.BigInt(0),
            gasFeeCap: (_b = request.maxFeePerGas) !== null && _b !== void 0 ? _b : global.BigInt(0),
            gasLimit,
            to: this._config.addressFromBytes(request.to),
            value: (_c = request.value) !== null && _c !== void 0 ? _c : global.BigInt(0),
            data: (_d = request.data) !== null && _d !== void 0 ? _d : new Uint8Array(0),
        });
        const latestBlock = await this._node.getLatestBlock();
        const gasPrice = this._config.effectiveGasPrice(transaction, {
            chainId: this._config.chainId,
            baseFee: latestBlock.header.baseFee,
            coinbase: await this._node.getCoinbaseAddress(),
            blockNumber: latestBlock.header.number,
            timestamp: latestBlock.header.timestamp,
            gasLimit: await this._node.getBlockGasLimit(),
            noBaseFee: (_e = this._config.noBaseFee) !== null && _e !== void 0 ? _e : true,
        });
        return {
            to: transaction.to,
            from: sender,
            gasLimit: transaction.gasLimit,
            gasPrice,
            value: transaction.value,
            data: transaction.data,
        };
    }
    _validateStateBlockTag(blockTag) {
        if (blockTag !== undefined &&
            blockTag !== "latest" &&
            blockTag !== "pending") {
            throw new errors_1.InvalidInputError(`Received unsupported QRL state block param ${blockTag.toString()}. Only latest and pending are supported.`);
        }
    }
}
exports.DebugModule = DebugModule;
function resolveGasLimit(request, defaultGasLimit) {
    var _a, _b;
    if (request.gas !== undefined &&
        request.gasLimit !== undefined &&
        request.gas !== request.gasLimit) {
        throw new errors_1.InvalidArgumentsError("QRL gas and gasLimit cannot differ");
    }
    return (_b = (_a = request.gas) !== null && _a !== void 0 ? _a : request.gasLimit) !== null && _b !== void 0 ? _b : defaultGasLimit;
}
function parseTraceConfig(raw) {
    if (raw === undefined || raw === null) {
        return {};
    }
    if (typeof raw !== "object" || Array.isArray(raw)) {
        throw new errors_1.InvalidArgumentsError("trace config must be an object");
    }
    const config = raw;
    if (config.tracer !== undefined) {
        throw new errors_1.InvalidArgumentsError("custom tracers are not supported");
    }
    if (config.disableStorage === false) {
        throw new errors_1.InvalidArgumentsError("storage capture is not supported");
    }
    validateOptionalBoolean(config, "disableStack");
    validateOptionalBoolean(config, "enableMemory");
    validateOptionalBoolean(config, "disableStorage");
    return {
        disableStack: config.disableStack === true,
        enableMemory: config.enableMemory === true,
        limit: parseTraceLimit(config.limit),
    };
}
function validateOptionalBoolean(config, name) {
    if (config[name] !== undefined && typeof config[name] !== "boolean") {
        throw new errors_1.InvalidArgumentsError(`${name} must be a boolean`);
    }
}
function parseTraceLimit(value) {
    if (value === undefined) {
        return undefined;
    }
    let limit;
    if (typeof value === "number") {
        limit = value;
    }
    else if (typeof value === "string" &&
        (/^0x[0-9a-fA-F]+$/.test(value) || /^[0-9]+$/.test(value))) {
        limit = Number(global.BigInt(value));
    }
    else {
        throw new errors_1.InvalidArgumentsError("trace limit must be a non-negative integer");
    }
    if (!Number.isSafeInteger(limit) || limit < 0) {
        throw new errors_1.InvalidArgumentsError("trace limit must be a non-negative integer");
    }
    return limit;
}
//# sourceMappingURL=debug.js.map