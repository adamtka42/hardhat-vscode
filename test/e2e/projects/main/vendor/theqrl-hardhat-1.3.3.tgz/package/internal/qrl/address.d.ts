export declare function qrlAddressFromSeed(seed: string): string;
export declare function isValidQrlAddress(address: string): boolean;
export declare function toQrlChecksumAddress(address: string): string;
export declare function normalizeQrlAddress(address: string): string;
export declare function qrlAddressToBytes(address: string): Uint8Array;
//# sourceMappingURL=address.d.ts.map