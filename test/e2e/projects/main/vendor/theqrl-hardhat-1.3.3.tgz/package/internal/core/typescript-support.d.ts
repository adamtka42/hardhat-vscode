export declare function isTypescriptSupported(): boolean;
export declare function loadTsNodeIfPresent(): void;
//# sourceMappingURL=typescript-support.d.ts.map