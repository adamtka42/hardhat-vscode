import { QrlStackTraceEntry } from "./vm-trace-decoder";
export declare enum QrlStackTraceEntryType {
    CALLSTACK_ENTRY = 0,
    UNRECOGNIZED_CREATE_CALLSTACK_ENTRY = 1,
    UNRECOGNIZED_CONTRACT_CALLSTACK_ENTRY = 2,
    PRECOMPILE_ERROR = 3,
    REVERT_ERROR = 4,
    FUNCTION_NOT_PAYABLE_ERROR = 5,
    INVALID_PARAMS_ERROR = 6,
    FALLBACK_NOT_PAYABLE_ERROR = 7,
    UNRECOGNIZED_FUNCTION_WITHOUT_FALLBACK_ERROR = 8,
    RETURNDATA_SIZE_ERROR = 9,
    NONCONTRACT_ACCOUNT_CALLED_ERROR = 10,
    CALL_FAILED_ERROR = 11,
    DIRECT_LIBRARY_CALL_ERROR = 12,
    UNRECOGNIZED_CREATE_ERROR = 13,
    UNRECOGNIZED_CONTRACT_ERROR = 14,
    OTHER_EXECUTION_ERROR = 15
}
export interface QrlStackTraceDiagnostic {
    type: QrlStackTraceEntryType;
    sourceReference?: QrlStackTraceEntry;
    message?: Uint8Array;
    value?: any;
    address?: string;
    precompile?: string;
}
//# sourceMappingURL=solidity-stack-trace.d.ts.map