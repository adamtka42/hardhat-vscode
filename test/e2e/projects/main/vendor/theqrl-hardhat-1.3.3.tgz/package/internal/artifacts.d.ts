import { Artifact } from "../types";
/**
 * Retrieves an artifact for the given `contractName` from the compilation output.
 *
 * @param contractName the contract's name.
 * @param contractOutput the contract's compilation output as emitted by Hyperion.
 */
export declare function getArtifactFromContractOutput(contractName: string, contractOutput: any): Artifact;
/**
 * Stores an artifact in the given path.
 *
 * @param artifactsPath the artifacts' directory.
 * @param artifact the artifact to be stored.
 */
export declare function saveArtifact(artifactsPath: string, artifact: Artifact): Promise<void>;
/**
 * Asynchronically reads an artifact with the given `contractName` from the given `artifactPath`.
 *
 * @param artifactsPath the artifacts' directory.
 * @param contractName  the contract's name.
 */
export declare function readArtifact(artifactsPath: string, contractName: string): Promise<Artifact>;
/**
 * Synchronically reads an artifact with the given `contractName` from the given `artifactPath`.
 *
 * @param artifactsPath the artifacts directory.
 * @param contractName  the contract's name.
 */
export declare function readArtifactSync(artifactsPath: string, contractName: string): Artifact;
//# sourceMappingURL=artifacts.d.ts.map