"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const debug_1 = __importDefault(require("debug"));
const path = __importStar(require("path"));
const semver = __importStar(require("semver"));
const errors_1 = require("./errors");
const errors_list_1 = require("./errors-list");
const execution_mode_1 = require("./execution-mode");
const log = debug_1.default("hardhat:core:plugins");
/**
 * Validates a plugin dependencies and loads it.
 * @param pluginName - The plugin name
 * @param hardhatContext - The HardhatContext
 * @param from - Where to resolve plugins and dependencies from. Only for
 * testing purposes.
 */
function usePlugin(hardhatContext, pluginName, from) {
    log("Loading plugin %s", pluginName);
    // We have a special case for `ExecutionMode.EXECUTION_MODE_LINKED`
    //
    // If Hardhat is linked, a require without `from` would be executed in the
    // context of Hardhat, and not find any plugin (linked or not). We workaround
    // this by using the CWD here.
    //
    // This is not ideal, but the only reason to link Hardhat is testing.
    if (from === undefined &&
        execution_mode_1.getExecutionMode() === execution_mode_1.ExecutionMode.EXECUTION_MODE_LINKED) {
        from = process.cwd();
        log("Hardhat is linked, searching for plugin starting from CWD", from);
    }
    let globalFlag = "";
    let globalWarning = "";
    if (execution_mode_1.getExecutionMode() === execution_mode_1.ExecutionMode.EXECUTION_MODE_GLOBAL_INSTALLATION) {
        globalFlag = " --global";
        globalWarning =
            "You are using a global installation of Hardhat. Plugins and their dependencies must also be global.\n";
    }
    const pluginPackageJson = readPackageJson(pluginName, from);
    if (pluginPackageJson === undefined) {
        const installExtraFlags = globalFlag;
        throw new errors_1.HardhatError(errors_list_1.ERRORS.PLUGINS.NOT_INSTALLED, {
            plugin: pluginName,
            extraMessage: globalWarning,
            extraFlags: installExtraFlags,
        });
    }
    // We use the package.json's version of the name, as it is normalized.
    pluginName = pluginPackageJson.name;
    if (hardhatContext.loadedPlugins.includes(pluginName)) {
        return;
    }
    if (pluginPackageJson.peerDependencies !== undefined) {
        for (const [dependencyName, versionSpec] of Object.entries(pluginPackageJson.peerDependencies)) {
            const dependencyPackageJson = readPackageJson(dependencyName, from);
            let installExtraFlags = globalFlag;
            if (versionSpec.match(/^[0-9]/) !== null) {
                installExtraFlags += " --save-exact";
            }
            if (dependencyPackageJson === undefined) {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.PLUGINS.MISSING_DEPENDENCY, {
                    plugin: pluginName,
                    dependency: dependencyName,
                    extraMessage: globalWarning,
                    extraFlags: installExtraFlags,
                    versionSpec,
                });
            }
            const installedVersion = dependencyPackageJson.version;
            if (!semver.satisfies(installedVersion, versionSpec, {
                includePrerelease: true,
            })) {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.PLUGINS.DEPENDENCY_VERSION_MISMATCH, {
                    plugin: pluginName,
                    dependency: dependencyName,
                    extraMessage: globalWarning,
                    extraFlags: installExtraFlags,
                    versionSpec,
                    installedVersion,
                });
            }
        }
    }
    const options = from !== undefined ? { paths: [from] } : undefined;
    const pluginPath = require.resolve(pluginName, options);
    loadPluginFile(pluginPath);
    hardhatContext.setPluginAsLoaded(pluginName);
}
exports.usePlugin = usePlugin;
function loadPluginFile(absolutePluginFilePath) {
    log("Loading plugin file %s", absolutePluginFilePath);
    const imported = require(absolutePluginFilePath);
    const plugin = imported.default !== undefined ? imported.default : imported;
    if (typeof plugin === "function") {
        plugin();
    }
}
exports.loadPluginFile = loadPluginFile;
function readPackageJson(packageName, from) {
    const options = from !== undefined ? { paths: [from] } : undefined;
    try {
        const packageJsonPath = require.resolve(path.join(packageName, "package.json"), options);
        return require(packageJsonPath);
    }
    catch (error) {
        // Packages using the exports field may not expose package.json. Resolve
        // their public entrypoint and walk up to the owning manifest instead.
    }
    try {
        const packageEntryPoint = require.resolve(packageName, options);
        let currentDirectory = path.dirname(packageEntryPoint);
        while (true) {
            try {
                const packageJson = require(path.join(currentDirectory, "package.json"));
                if (packageJson.name === packageName) {
                    return packageJson;
                }
            }
            catch (error) {
                // Keep looking for the package's root manifest.
            }
            const parentDirectory = path.dirname(currentDirectory);
            if (parentDirectory === currentDirectory) {
                return undefined;
            }
            currentDirectory = parentDirectory;
        }
    }
    catch (error) {
        return undefined;
    }
}
exports.readPackageJson = readPackageJson;
function ensurePluginLoadedWithUsePlugin() {
    // No-op. Only here for backwards compatibility
}
exports.ensurePluginLoadedWithUsePlugin = ensurePluginLoadedWithUsePlugin;
//# sourceMappingURL=plugins.js.map