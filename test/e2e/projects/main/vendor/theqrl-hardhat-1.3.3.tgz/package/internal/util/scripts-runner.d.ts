import { HardhatArguments } from "../../types";
export declare function runScript(scriptPath: string, scriptArgs?: string[], extraNodeArgs?: string[], extraEnvVars?: {
    [name: string]: string;
}): Promise<number>;
export declare function runScriptWithHardhat(hardhatArguments: HardhatArguments, scriptPath: string, scriptArgs?: string[], extraNodeArgs?: string[], extraEnvVars?: {
    [name: string]: string;
}): Promise<number>;
/**
 * Ensure hardhat/register source file path is resolved to compiled JS file
 * instead of TS source file, so we don't need to run ts-node unnecessarily.
 */
export declare function resolveHardhatRegisterPath(): string;
//# sourceMappingURL=scripts-runner.d.ts.map