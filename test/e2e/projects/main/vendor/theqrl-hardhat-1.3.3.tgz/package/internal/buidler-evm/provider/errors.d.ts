export declare class BuidlerEVMProviderError extends Error {
    readonly code: number;
    static isBuidlerEVMProviderError(other: any): other is BuidlerEVMProviderError;
    private readonly _isBuidlerEVMProviderError;
    constructor(message: string, code: number);
}
export declare class InvalidJsonInputError extends BuidlerEVMProviderError {
    static readonly CODE = -32700;
    constructor(message: string);
}
export declare class InvalidRequestError extends BuidlerEVMProviderError {
    static readonly CODE = -32600;
    constructor(message: string);
}
export declare class MethodNotFoundError extends BuidlerEVMProviderError {
    static readonly CODE = -32601;
    constructor(message: string);
}
export declare class InvalidArgumentsError extends BuidlerEVMProviderError {
    static readonly CODE = -32602;
    constructor(message: string);
}
export declare class InternalError extends BuidlerEVMProviderError {
    static readonly CODE = -32603;
    constructor(message: string);
}
export declare class InvalidInputError extends BuidlerEVMProviderError {
    static readonly CODE = -32000;
    constructor(message: string);
}
export declare class TransactionExecutionError extends BuidlerEVMProviderError {
    static readonly CODE = -32003;
    parent: Error;
    constructor(parent: Error | string);
}
export declare class QrlExecutionError extends InvalidInputError {
    readonly data?: string | undefined;
    readonly transactionHash?: string | undefined;
    readonly traceFrame?: any;
    constructor(message: string, data?: string | undefined, transactionHash?: string | undefined, traceFrame?: any);
}
export declare class MethodNotSupportedError extends BuidlerEVMProviderError {
    static readonly CODE = -32004;
    constructor(message: string);
}
//# sourceMappingURL=errors.d.ts.map