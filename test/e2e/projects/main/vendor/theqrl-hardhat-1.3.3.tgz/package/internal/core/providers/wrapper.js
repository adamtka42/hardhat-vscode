"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function wrapSend(provider, sendWrapper) {
    const cloningSendWrapper = (method, params = []) => {
        const cloneDeep = require("lodash/cloneDeep");
        return sendWrapper(method, cloneDeep(params));
    };
    return new Proxy(provider, {
        get(target, p, receiver) {
            if (p === "send") {
                return cloningSendWrapper;
            }
            const originalValue = Reflect.get(target, p, receiver);
            if (originalValue instanceof Function) {
                return (...args) => {
                    const returned = Reflect.apply(originalValue, target, args);
                    if (returned !== target) {
                        return returned;
                    }
                    return receiver;
                };
            }
            return originalValue;
        },
    });
}
exports.wrapSend = wrapSend;
//# sourceMappingURL=wrapper.js.map