/**
 * Extracts the import paths of a Hyperion source file.
 *
 * The primary implementation is a small lexer that understands just enough
 * of the language to skip line comments, block comments, and string
 * literals — so text that merely LOOKS like an import inside those never
 * becomes a dependency (a phantom dependency breaks cache checking and
 * flattening). There is no JavaScript parser for Hyperion; the compiler's
 * AST is only available AFTER a successful compilation, while imports are
 * needed to build the dependency graph BEFORE it. Hence a lexer, not a
 * parser — and per the plan, one shared implementation instead of several
 * ad-hoc regular expressions.
 *
 * The legacy regex extractor is kept strictly as a fallback for lexer
 * failures and logs when it is used.
 */
export declare function getImports(fileContent: string): string[];
export interface ImportDirective {
    path: string;
    /** Offset of the `import` keyword. */
    start: number;
    /** Offset just past the directive's terminating semicolon. */
    end: number;
}
/**
 * Full import directives with their exact source ranges, so consumers like
 * `hardhat flatten` can remove PRECISELY the directive — multi-line imports
 * included — without touching surrounding code on the same line.
 */
export declare function getImportDirectives(source: string): ImportDirective[];
//# sourceMappingURL=imports.d.ts.map