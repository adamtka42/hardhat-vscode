"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const caller_package_1 = require("../util/caller-package");
const strings_1 = require("../util/strings");
const errors_list_1 = require("./errors-list");
// For an explanation about these classes constructors go to:
// https://github.com/Microsoft/TypeScript/wiki/Breaking-Changes#extending-built-ins-like-error-array-and-map-may-no-longer-work
class HardhatError extends Error {
    constructor(errorDescriptor, messageArguments = {}, parentError) {
        const prefix = `${errors_list_1.getErrorCode(errorDescriptor)}: `;
        const formattedMessage = applyErrorMessageTemplate(errorDescriptor.message, messageArguments);
        super(prefix + formattedMessage);
        this.errorDescriptor = errorDescriptor;
        this.number = errorDescriptor.number;
        if (parentError instanceof Error) {
            this.parent = parentError;
        }
        this._isHardhatError = true;
        Object.setPrototypeOf(this, HardhatError.prototype);
    }
    static isHardhatError(other) {
        return (other !== undefined && other !== null && other._isHardhatError === true);
    }
}
exports.HardhatError = HardhatError;
/**
 * This class is used to throw errors from Hardhat plugins.
 */
class HardhatPluginError extends Error {
    constructor(pluginNameOrMessage, messageOrParent, parent) {
        if (typeof messageOrParent === "string") {
            super(messageOrParent);
            this.pluginName = pluginNameOrMessage;
            this.parent = parent;
        }
        else {
            super(pluginNameOrMessage);
            this.pluginName = caller_package_1.getClosestCallerPackage();
            this.parent = messageOrParent;
        }
        this._isHardhatPluginError = true;
        Object.setPrototypeOf(this, HardhatPluginError.prototype);
    }
    static isHardhatPluginError(other) {
        return (other !== undefined &&
            other !== null &&
            other._isHardhatPluginError === true);
    }
}
exports.HardhatPluginError = HardhatPluginError;
/**
 * This function applies error messages templates like this:
 *
 *  - Template is a string which contains a variable tags. A variable tag is a
 *    a variable name surrounded by %. Eg: %plugin1%
 *  - A variable name is a string of alphanumeric ascii characters.
 *  - Every variable tag is replaced by its value.
 *  - %% is replaced by %.
 *  - Values can't contain variable tags.
 *  - If a variable is not present in the template, but present in the values
 *    object, an error is thrown.
 *
 * @param template The template string.
 * @param values A map of variable names to their values.
 */
function applyErrorMessageTemplate(template, values) {
    return _applyErrorMessageTemplate(template, values, false);
}
exports.applyErrorMessageTemplate = applyErrorMessageTemplate;
function _applyErrorMessageTemplate(template, values, isRecursiveCall) {
    if (!isRecursiveCall) {
        for (const variableName of Object.keys(values)) {
            if (variableName.match(/^[a-zA-Z][a-zA-Z0-9]*$/) === null) {
                throw new HardhatError(errors_list_1.ERRORS.INTERNAL.TEMPLATE_INVALID_VARIABLE_NAME, {
                    variable: variableName,
                });
            }
            const variableTag = `%${variableName}%`;
            if (!template.includes(variableTag)) {
                throw new HardhatError(errors_list_1.ERRORS.INTERNAL.TEMPLATE_VARIABLE_TAG_MISSING, {
                    variable: variableName,
                });
            }
        }
    }
    if (template.includes("%%")) {
        return template
            .split("%%")
            .map((part) => _applyErrorMessageTemplate(part, values, true))
            .join("%");
    }
    for (const variableName of Object.keys(values)) {
        let value;
        if (values[variableName] === undefined) {
            value = "undefined";
        }
        else if (values[variableName] === null) {
            value = "null";
        }
        else {
            value = values[variableName].toString();
        }
        if (value === undefined) {
            value = "undefined";
        }
        const variableTag = `%${variableName}%`;
        if (value.match(/%([a-zA-Z][a-zA-Z0-9]*)?%/) !== null) {
            throw new HardhatError(errors_list_1.ERRORS.INTERNAL.TEMPLATE_VALUE_CONTAINS_VARIABLE_TAG, { variable: variableName });
        }
        template = strings_1.replaceAll(template, variableTag, value);
    }
    return template;
}
//# sourceMappingURL=errors.js.map