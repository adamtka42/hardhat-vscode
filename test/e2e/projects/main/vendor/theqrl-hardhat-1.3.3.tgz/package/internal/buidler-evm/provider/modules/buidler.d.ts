import { HardhatNode } from "../node";
export declare class BuidlerModule {
    private readonly _node;
    constructor(_node: HardhatNode);
    processRequest(method: string, params?: any[]): Promise<any>;
    private _getStackTraceFailuresCountParams;
    private _getStackTraceFailuresCountAction;
}
//# sourceMappingURL=buidler.d.ts.map