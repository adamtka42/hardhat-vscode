export interface QrlAbiFunction {
    type?: string;
    name?: string;
    inputs?: QrlAbiParam[];
    outputs?: QrlAbiParam[];
    anonymous?: boolean;
}
interface QrlAbiParam {
    type: string;
    name?: string;
    indexed?: boolean;
    components?: QrlAbiParam[];
}
export interface QrlDecodedEventLog {
    eventName: string;
    args: {
        [name: string]: any;
    };
    log: any;
}
export declare function encodeQrlFunctionData(abi: any, functionName: string, args?: any[]): string;
export declare function encodeQrlConstructorArgs(abi: any, args?: any[]): string;
export declare function decodeQrlFunctionResult(abi: any, functionName: string, data: string): any[];
export declare function decodeQrlEventLog(abi: any, eventName: string, log: any): QrlDecodedEventLog;
export declare function decodeQrlReceiptLogs(abi: any, contractAddress: string, receipt: any): QrlDecodedEventLog[];
export declare function getQrlEventTopic(abi: any, eventName: string): string;
export declare function getFunctionSignature(fragment: QrlAbiFunction): string;
export declare function isFullFunctionSignature(identifier: string): boolean;
export declare function findFunctionFragment(abi: any, identifier: string): QrlAbiFunction;
export {};
//# sourceMappingURL=abi.d.ts.map