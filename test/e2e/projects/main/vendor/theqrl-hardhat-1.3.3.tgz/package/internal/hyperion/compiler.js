"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const child_process_1 = require("child_process");
const fs = __importStar(require("fs"));
const fs_extra_1 = __importDefault(require("fs-extra"));
const os = __importStar(require("os"));
const path = __importStar(require("path"));
const util_1 = require("util");
const errors_1 = require("../core/errors");
const errors_list_1 = require("../core/errors-list");
const compiler_downloader_1 = require("./compiler-downloader");
const compiler_version_1 = require("./compiler-version");
const execFileAsync = util_1.promisify(child_process_1.execFile);
exports.HYPERION_COMPILER_REPOSITORY_ENV = "HYPERION_COMPILER_REPOSITORY_URL";
const DEFAULT_HYPERION_COMPILER_REPOSITORY_URL = undefined;
class Compiler {
    constructor(_config, _projectRoot, _cacheDir) {
        this._config = _config;
        this._projectRoot = _projectRoot;
        this._cacheDir = _cacheDir;
    }
    async compile(input) {
        const compiler = await this.getCompiler();
        return compileHyperion(input, this._projectRoot, compiler.path);
    }
    async getCompiler() {
        if (this._resolvedCompiler === undefined) {
            this._resolvedCompiler = this._resolveCompiler();
        }
        return this._resolvedCompiler;
    }
    async _resolveCompiler() {
        var _a, _b;
        const repositoryUrl = (_b = (_a = this._config.compilerRepositoryUrl) !== null && _a !== void 0 ? _a : process.env[exports.HYPERION_COMPILER_REPOSITORY_ENV]) !== null && _b !== void 0 ? _b : DEFAULT_HYPERION_COMPILER_REPOSITORY_URL;
        const hasExplicitLocalCompiler = this._config.compilerPath !== undefined ||
            process.env.HYPERION_HYPC_PATH !== undefined ||
            process.env.HYPC_PATH !== undefined;
        if (this._config.version !== "local" &&
            repositoryUrl !== undefined &&
            !hasExplicitLocalCompiler) {
            const downloader = new compiler_downloader_1.HyperionCompilerDownloader(repositoryUrl, path.join(this._cacheDir, "hyperion-compilers"));
            return downloader.resolve(this._config.version);
        }
        const selectedPath = compiler_version_1.resolveHypcPath(this._config.compilerPath, this._projectRoot);
        const fingerprint = await compiler_version_1.getCompilerFingerprint(selectedPath, this._projectRoot);
        if (fingerprint === undefined) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.HYPERION_COMPILER_NOT_FOUND, {
                path: selectedPath,
            });
        }
        const identity = fingerprint;
        return {
            path: fingerprint.resolvedPath,
            source: "local",
            version: this._config.version === "local" ? undefined : this._config.version,
            longVersion: fingerprint.longVersion,
            identity,
        };
    }
}
exports.Compiler = Compiler;
async function compileHyperion(input, projectRoot, compilerPath) {
    const hypcPath = compiler_version_1.resolveHypcPath(compilerPath, projectRoot);
    // The input IS the standard JSON — passed through verbatim.
    const standardJsonInput = input;
    // The input is passed through a temporary file instead of stdin so the
    // exec call stays a simple argv invocation on every platform.
    const inputDir = fs.mkdtempSync(path.join(os.tmpdir(), "hardhat-hypc-in-"));
    const inputFile = path.join(inputDir, "input.json");
    fs.writeFileSync(inputFile, JSON.stringify(standardJsonInput));
    const args = ["--standard-json", inputFile, "--base-path", projectRoot];
    // Allow library imports from installed packages, e.g.
    // `import "@theqrl/hardhat/console.hyp";`. hypc reports ambiguous imports
    // if the same package exists under both base-path and include-path, so expose
    // a filtered temporary include root instead of the whole node_modules tree.
    const nodeModulesInclude = prepareNodeModulesIncludePath(projectRoot);
    if (nodeModulesInclude !== undefined) {
        args.push("--include-path", nodeModulesInclude.path);
        // hypc canonicalizes import paths before checking them against the
        // allowed directories, so packages installed as symlinks (npm link,
        // file: installs) resolve outside the project and get rejected.
        // Explicitly allow the real paths of symlinked packages.
        if (nodeModulesInclude.allowPaths.length > 0) {
            args.push("--allow-paths", nodeModulesInclude.allowPaths.join(","));
        }
    }
    let stdout = "";
    let stderr = "";
    try {
        const result = await execFileAsync(hypcPath, args, {
            cwd: projectRoot,
            maxBuffer: 1024 * 1024 * 50,
            shell: process.platform === "win32",
        });
        stdout = result.stdout.toString();
        stderr = result.stderr.toString();
    }
    catch (error) {
        const anyError = error;
        const output = [anyError.stdout, anyError.stderr, anyError.message]
            .filter((part) => part !== undefined && part !== "")
            .join("\n");
        return {
            errors: [
                {
                    severity: "error",
                    formattedMessage: output,
                },
            ],
        };
    }
    finally {
        nodeModulesInclude === null || nodeModulesInclude === void 0 ? void 0 : nodeModulesInclude.cleanup();
        fs_extra_1.default.removeSync(inputDir);
    }
    return adaptStandardJsonOutput(stdout, stderr);
}
exports.compileHyperion = compileHyperion;
function adaptStandardJsonOutput(stdout, stderr) {
    var _a;
    const jsonStart = stdout.indexOf("{");
    if (jsonStart === -1) {
        const message = stdout !== ""
            ? stdout
            : stderr !== ""
                ? stderr
                : "hypc did not return JSON output";
        return {
            errors: [
                {
                    severity: "error",
                    formattedMessage: message,
                },
            ],
        };
    }
    const compilerMessages = stdout.slice(0, jsonStart).trim();
    let standardOutput;
    try {
        standardOutput = JSON.parse(stdout.slice(jsonStart));
    }
    catch (error) {
        return {
            errors: [
                {
                    severity: "error",
                    formattedMessage: `hypc returned invalid JSON output: ${error.message}`,
                },
            ],
        };
    }
    const output = {
        contracts: {},
        // Per-source ASTs (and source ids), kept in the cached compiler output
        // for the stack trace decoder.
        sources: standardOutput.sources !== undefined ? standardOutput.sources : {},
    };
    const contracts = standardOutput.contracts !== undefined ? standardOutput.contracts : {};
    for (const sourceName of Object.keys(contracts)) {
        for (const contractName of Object.keys(contracts[sourceName])) {
            const contractOutput = contracts[sourceName][contractName];
            const qrvm = contractOutput.qrvm !== undefined ? contractOutput.qrvm : {};
            if (output.contracts[sourceName] === undefined) {
                output.contracts[sourceName] = {};
            }
            output.contracts[sourceName][contractName] = {
                abi: contractOutput.abi !== undefined ? contractOutput.abi : [],
                metadata: contractOutput.metadata,
                methodIdentifiers: (_a = qrvm.methodIdentifiers) !== null && _a !== void 0 ? _a : {},
                bytecodeOutput: {
                    bytecode: adaptBytecodeOutput(qrvm.bytecode),
                    deployedBytecode: adaptBytecodeOutput(qrvm.deployedBytecode),
                },
            };
        }
    }
    // Standard JSON reports compiler diagnostics in its own errors array; the
    // compile task consumes their severity and formattedMessage directly.
    output.errors = Array.isArray(standardOutput.errors)
        ? [...standardOutput.errors]
        : [];
    const extraMessages = [compilerMessages, stderr].filter((msg) => msg !== "");
    output.errors.push(...extraMessages.map((msg) => ({
        severity: "warning",
        formattedMessage: msg,
    })));
    if (output.errors.length === 0) {
        delete output.errors;
    }
    return output;
}
function adaptBytecodeOutput(bytecodeOutput) {
    return {
        object: stripHexPrefix(bytecodeOutput !== undefined && bytecodeOutput.object !== undefined
            ? bytecodeOutput.object
            : ""),
        linkReferences: bytecodeOutput !== undefined &&
            bytecodeOutput.linkReferences !== undefined
            ? bytecodeOutput.linkReferences
            : {},
        sourceMap: bytecodeOutput !== undefined ? bytecodeOutput.sourceMap : undefined,
        immutableReferences: bytecodeOutput !== undefined &&
            bytecodeOutput.immutableReferences !== undefined
            ? bytecodeOutput.immutableReferences
            : {},
    };
}
function stripHexPrefix(value) {
    return value.startsWith("0x") || value.startsWith("0X")
        ? value.slice(2)
        : value;
}
function prepareNodeModulesIncludePath(projectRoot) {
    const nodeModulesPath = path.join(projectRoot, "node_modules");
    if (!fs.existsSync(nodeModulesPath)) {
        return undefined;
    }
    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), "hardhat-hypc-includes-"));
    const allowPaths = [];
    let linkedPackages = 0;
    const cleanup = () => {
        fs_extra_1.default.removeSync(tempRoot);
    };
    const linkPackage = (packageName, packagePath) => {
        if (fs.existsSync(path.join(projectRoot, packageName))) {
            return;
        }
        const linkPath = path.join(tempRoot, packageName);
        fs_extra_1.default.ensureDirSync(path.dirname(linkPath));
        fs.symlinkSync(packagePath, linkPath, "dir");
        linkedPackages++;
        try {
            if (fs.lstatSync(packagePath).isSymbolicLink()) {
                allowPaths.push(fs.realpathSync(packagePath));
            }
        }
        catch (_a) {
            // Broken symlinks and unreadable entries are ignored.
        }
    };
    let entries;
    try {
        entries = fs.readdirSync(nodeModulesPath);
    }
    catch (_a) {
        cleanup();
        return undefined;
    }
    for (const entry of entries) {
        const entryPath = path.join(nodeModulesPath, entry);
        if (entry.startsWith("@")) {
            let scopedEntries;
            try {
                scopedEntries = fs.readdirSync(entryPath);
            }
            catch (_b) {
                continue;
            }
            for (const scopedEntry of scopedEntries) {
                linkPackage(path.join(entry, scopedEntry), path.join(entryPath, scopedEntry));
            }
        }
        else {
            linkPackage(entry, entryPath);
        }
    }
    if (linkedPackages === 0) {
        cleanup();
        return undefined;
    }
    return {
        path: tempRoot,
        allowPaths,
        cleanup,
    };
}
//# sourceMappingURL=compiler.js.map