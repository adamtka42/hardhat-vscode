"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const provider_1 = require("../../buidler-evm/provider/provider");
const constants_1 = require("../../constants");
const http_1 = require("./http");
function createProvider(networkName, networkConfig, paths) {
    let provider;
    if (networkName === constants_1.HARDHAT_QRLVM_NETWORK_NAME) {
        const hardhatQrlvmConfig = networkConfig;
        provider = new provider_1.HardhatQrlvmProvider(hardhatQrlvmConfig, paths);
    }
    else {
        const httpNetConfig = networkConfig;
        provider = new http_1.HttpProvider(httpNetConfig.url, networkName, httpNetConfig.httpHeaders, httpNetConfig.timeout);
    }
    return wrapQrlProvider(provider, networkConfig);
}
exports.createProvider = createProvider;
function wrapQrlProvider(provider, netConfig) {
    // These dependencies are lazy-loaded because they are really big.
    // We use require() instead of import() here, because we need it to be sync.
    const { createLocalAccountsProvider, createSenderProvider, } = require("./accounts");
    const { createAutomaticGasPriceProvider, createAutomaticGasProvider, createFixedGasPriceProvider, createFixedGasProvider, } = require("./gas-providers");
    const { createChainIdValidationProvider } = require("./chainId");
    const isHttpNetworkConfig = "url" in netConfig;
    if (isHttpNetworkConfig) {
        const httpNetConfig = netConfig;
        const accounts = httpNetConfig.accounts;
        if (Array.isArray(accounts)) {
            provider = createLocalAccountsProvider(provider, accounts);
        }
    }
    provider = createSenderProvider(provider, netConfig.from);
    if (netConfig.gas === undefined || netConfig.gas === "auto") {
        provider = createAutomaticGasProvider(provider, netConfig.gasMultiplier);
    }
    else {
        provider = createFixedGasProvider(provider, netConfig.gas);
    }
    if (netConfig.gasPrice === undefined || netConfig.gasPrice === "auto") {
        provider = createAutomaticGasPriceProvider(provider);
    }
    else {
        provider = createFixedGasPriceProvider(provider, netConfig.gasPrice);
    }
    if (isHttpNetworkConfig) {
        if (netConfig.chainId !== undefined) {
            return createChainIdValidationProvider(provider, netConfig.chainId);
        }
    }
    return provider;
}
exports.wrapQrlProvider = wrapQrlProvider;
//# sourceMappingURL=construction.js.map