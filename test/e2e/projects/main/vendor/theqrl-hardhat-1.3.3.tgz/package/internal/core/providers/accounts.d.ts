import { IQrlProvider } from "../../../types";
export interface JsonRpcTransactionData {
    from?: string;
    to?: string;
    gas?: string | number;
    gasLimit?: string | number;
    gasPrice?: string | number;
    maxFeePerGas?: string | number;
    maxPriorityFeePerGas?: string | number;
    value?: string | number;
    data?: string;
    nonce?: string | number;
    chainId?: string | number;
}
export declare function createLocalAccountsProvider(provider: IQrlProvider, extendedSeeds: string[]): import("../../../types").QrlProvider;
export declare function createSenderProvider(provider: IQrlProvider, from?: string): import("../../../types").QrlProvider;
//# sourceMappingURL=accounts.d.ts.map