import { QrlContractDebugInfo, QrlDebugInfo } from "./compiler-to-model";
export interface QrlStackTraceEntry {
    contractName: string;
    functionName: string;
    sourceName: string;
    line: number;
}
export interface QrlResolvedSourceLocation {
    sourceName: string;
    offset: number;
    length: number;
    jumpType: string;
}
/**
 * Resolves execution frames to Hyperion source locations: identifies the
 * contract by its (placeholder-normalized) code, maps the frame's pc through
 * the instruction source map, and finds the enclosing function in the AST.
 */
export declare class QrlStackTraceDecoder {
    private readonly _debugInfo;
    private readonly _prepared;
    constructor(_debugInfo: QrlDebugInfo);
    /**
     * Decodes one frame into a stack trace entry. `code` is the code that
     * executed in the frame (deployed code for calls, init code for creates);
     * `pc` is the frame's failure point.
     */
    identifyContract(code: string, isCreate: boolean): QrlContractDebugInfo | undefined;
    decodeFrame(code: string, pc: number, isCreate: boolean): QrlStackTraceEntry | undefined;
    getSourceLocation(code: string, pc: number, isCreate: boolean): QrlResolvedSourceLocation | undefined;
    isFunctionStartReference(source: QrlStackTraceEntry): boolean;
    decodeInternalCallTarget(location: QrlResolvedSourceLocation, contractName: string): QrlStackTraceEntry | undefined;
    decodeImplicitCreationStart(code: string): QrlStackTraceEntry | undefined;
    decodeLastModifier(code: string, steps: any[], isCreate: boolean): QrlStackTraceEntry | undefined;
    decodeLastMappedStatement(code: string, steps: any[], isCreate: boolean): QrlStackTraceEntry | undefined;
    decodeUnconditionalModifier(contract: QrlContractDebugInfo, functionIdentifier: string): QrlStackTraceEntry | undefined;
    decodeContractStart(contract: QrlContractDebugInfo, functionIdentifier?: string): QrlStackTraceEntry | undefined;
    private _isModifierReference;
    private _identify;
    private _locationsFor;
    private _pcMapFor;
    private _findFunctionName;
}
//# sourceMappingURL=vm-trace-decoder.d.ts.map