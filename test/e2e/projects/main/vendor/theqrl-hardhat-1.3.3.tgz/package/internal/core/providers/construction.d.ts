import { IQrlProvider, NetworkConfig, ProjectPaths } from "../../../types";
export declare function createProvider(networkName: string, networkConfig: NetworkConfig, paths?: ProjectPaths): IQrlProvider;
export declare function wrapQrlProvider(provider: IQrlProvider, netConfig: Partial<NetworkConfig>): IQrlProvider;
//# sourceMappingURL=construction.d.ts.map