import { ConfigExtender, HardhatConfig, ProjectPaths, ResolvedHardhatConfig } from "../../../types";
/**
 * This functions resolves the Hardhat config by merging the user provided config
 * and the default config.
 *
 * @param userConfigPath the user config filepath
 * @param defaultConfig  the default config object
 * @param userConfig     the user config object
 * @param configExtenders An array of ConfigExtenders
 *
 * @returns the resolved config
 */
export declare function resolveConfig(userConfigPath: string, defaultConfig: HardhatConfig, userConfig: HardhatConfig, configExtenders: ConfigExtender[]): ResolvedHardhatConfig;
/**
 * This function resolves the ProjectPaths object from the user-provided config
 * and its path. The logic of this is not obvious and should well be document.
 * The good thing is that most users will never use this.
 *
 * Explanation:
 *    - paths.configFile is not overridable
 *    - If a path is absolute it is used "as is".
 *    - If the root path is relative, it's resolved from paths.configFile's dir.
 *    - If any other path is relative, it's resolved from paths.root.
 */
export declare function resolveProjectPaths(userConfigPath: string, userPaths?: any): ProjectPaths;
//# sourceMappingURL=config-resolution.d.ts.map