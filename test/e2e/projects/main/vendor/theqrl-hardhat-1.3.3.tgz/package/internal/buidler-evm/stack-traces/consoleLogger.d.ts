/** Address observed by Hardhat for calls emitted from `console.hyp`. */
export declare const QRL_CONSOLE_LOG_ADDRESS: string;
/**
 * Builds a Hardhat-owned observer on top of qrljs's generic frame events.
 * The VM still executes the empty-account call normally; this only surfaces
 * its calldata to local development tooling.
 */
export declare function createQrlConsoleLogTraceListener(listener: ((input: Uint8Array) => void) | undefined): any | undefined;
interface ConsoleLogEntry {
    signature: string;
    types: string[];
}
export declare function getConsoleLogSelectors(): Map<string, ConsoleLogEntry>;
/**
 * Decodes the raw calldata of a contract console log call into a printable
 * line, or returns `undefined` for unknown selectors or undecodable bodies.
 */
export declare function decodeQrlConsoleLog(data: Uint8Array): string | undefined;
/**
 * Decodes and prints one contract console log line. Unknown selectors are
 * surfaced as a short diagnostic instead of being silently dropped.
 * `process.stdout.write` is used so the output escapes test-runner console
 * wrappers.
 */
export declare function printQrlConsoleLog(data: Uint8Array): void;
export {};
//# sourceMappingURL=consoleLogger.d.ts.map