"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var QrlStackTraceEntryType;
(function (QrlStackTraceEntryType) {
    QrlStackTraceEntryType[QrlStackTraceEntryType["CALLSTACK_ENTRY"] = 0] = "CALLSTACK_ENTRY";
    QrlStackTraceEntryType[QrlStackTraceEntryType["UNRECOGNIZED_CREATE_CALLSTACK_ENTRY"] = 1] = "UNRECOGNIZED_CREATE_CALLSTACK_ENTRY";
    QrlStackTraceEntryType[QrlStackTraceEntryType["UNRECOGNIZED_CONTRACT_CALLSTACK_ENTRY"] = 2] = "UNRECOGNIZED_CONTRACT_CALLSTACK_ENTRY";
    QrlStackTraceEntryType[QrlStackTraceEntryType["PRECOMPILE_ERROR"] = 3] = "PRECOMPILE_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["REVERT_ERROR"] = 4] = "REVERT_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["FUNCTION_NOT_PAYABLE_ERROR"] = 5] = "FUNCTION_NOT_PAYABLE_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["INVALID_PARAMS_ERROR"] = 6] = "INVALID_PARAMS_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["FALLBACK_NOT_PAYABLE_ERROR"] = 7] = "FALLBACK_NOT_PAYABLE_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["UNRECOGNIZED_FUNCTION_WITHOUT_FALLBACK_ERROR"] = 8] = "UNRECOGNIZED_FUNCTION_WITHOUT_FALLBACK_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["RETURNDATA_SIZE_ERROR"] = 9] = "RETURNDATA_SIZE_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["NONCONTRACT_ACCOUNT_CALLED_ERROR"] = 10] = "NONCONTRACT_ACCOUNT_CALLED_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["CALL_FAILED_ERROR"] = 11] = "CALL_FAILED_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["DIRECT_LIBRARY_CALL_ERROR"] = 12] = "DIRECT_LIBRARY_CALL_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["UNRECOGNIZED_CREATE_ERROR"] = 13] = "UNRECOGNIZED_CREATE_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["UNRECOGNIZED_CONTRACT_ERROR"] = 14] = "UNRECOGNIZED_CONTRACT_ERROR";
    QrlStackTraceEntryType[QrlStackTraceEntryType["OTHER_EXECUTION_ERROR"] = 15] = "OTHER_EXECUTION_ERROR";
})(QrlStackTraceEntryType = exports.QrlStackTraceEntryType || (exports.QrlStackTraceEntryType = {}));
//# sourceMappingURL=solidity-stack-trace.js.map