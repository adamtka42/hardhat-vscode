import { ActionType, ConfigExtender, ConfigurableTaskDefinition, EnvironmentExtender, TaskArguments } from "../../../types";
import * as argumentTypes from "../params/argumentTypes";
export declare function task<ArgsT extends TaskArguments>(name: string, description?: string, action?: ActionType<ArgsT>): ConfigurableTaskDefinition;
export declare function task<ArgsT extends TaskArguments>(name: string, action: ActionType<ArgsT>): ConfigurableTaskDefinition;
export declare function internalTask<ArgsT extends TaskArguments>(name: string, description?: string, action?: ActionType<ArgsT>): ConfigurableTaskDefinition;
export declare function internalTask<ArgsT extends TaskArguments>(name: string, action: ActionType<ArgsT>): ConfigurableTaskDefinition;
export declare const types: typeof argumentTypes;
/**
 * Register an environment extender what will be run after the
 * Hardhat Runtime Environment is initialized.
 *
 * @param extender A function that receives the Hardhat Runtime
 * Environment.
 */
export declare function extendEnvironment(extender: EnvironmentExtender): void;
export declare function extendConfig(extender: ConfigExtender): void;
/**
 * Loads a Hardhat plugin
 * @param pluginName The plugin name.
 */
export declare function usePlugin(pluginName: string): void;
//# sourceMappingURL=config-env.d.ts.map