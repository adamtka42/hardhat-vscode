import { QrlStackTraceDiagnostic } from "./solidity-stack-trace";
import { QrlStackTraceDecoder } from "./vm-trace-decoder";
export declare function inferQrlStackTrace(rootFrame: any, decoder: QrlStackTraceDecoder): QrlStackTraceDiagnostic[];
//# sourceMappingURL=solidityTracer.d.ts.map