/**
 * Single resolver for the qrljs runtime modules that power `hardhatqrlvm`.
 *
 * Resolution order:
 *
 * 1. Development override — `networks.<name>.qrlJsMonorepoPath` or the
 *    `QRLJS_MONOREPO_PATH` environment variable pointing at a BUILT
 *    qrljs-monorepo checkout. A set override is authoritative: when it is
 *    invalid the error surfaces instead of silently falling through, so a
 *    developer never runs against a stale bundle by accident.
 * 2. Published `@theqrl/*` npm packages — reserved for when the runtime
 *    packages are released to the registry; not active yet.
 * 3. Bundled runtime — a self-contained bundle shipped inside the packed
 *    `@theqrl/hardhat` artifact under `qrljs-runtime/` (built by
 *    `scripts/bundle-qrljs-runtime.js` from a local qrljs checkout).
 *
 * All runtime modules come from ONE source; mixing versions between state,
 * execution, blocks, transactions, and utilities is never allowed.
 */
export interface QrlJsRuntimeModules {
    blockQrl: any;
    evmQrl: any;
    stateQrl: any;
    txQrl: any;
    utilQrl: any;
    vmQrl: any;
}
interface RuntimeSource {
    kind: "override" | "bundled";
    description: string;
}
export interface ResolvedQrlJsRuntime extends QrlJsRuntimeModules {
    source: RuntimeSource;
}
export declare function loadQrlJsRuntime(networkName: string, overridePath?: string): ResolvedQrlJsRuntime;
/**
 * The tx module enables local signing of qrljs transactions on HTTP
 * networks. It always comes from the same source as the rest of the runtime:
 * the resolution already made in this process, the environment override, or
 * the bundle. Absence of ANY source is a feature-detection result
 * (undefined), but a set override that cannot be loaded is an error.
 */
export declare function loadQrlJsTxRuntime(): any | undefined;
/** Exposed for --verbose diagnostics and the compatibility check. */
export declare function readBundledRuntimeManifest(): any | undefined;
/** Test-only: clears the process-wide resolution memo. */
export declare function resetQrlJsRuntimeCacheForTesting(): void;
export {};
//# sourceMappingURL=runtime.d.ts.map