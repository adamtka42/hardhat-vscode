"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const find_up_1 = __importDefault(require("find-up"));
const fs = __importStar(require("fs"));
const path_1 = __importDefault(require("path"));
const errors_1 = require("../../core/errors");
const errors_list_1 = require("../../core/errors-list");
// The bundle directory lives at the package root next to console.hyp. This
// This module runs from the compiled or source internal tree, so the package
// root is located via the closest package.json.
function getBundleDir() {
    const packageJsonPath = find_up_1.default.sync("package.json", { cwd: __dirname });
    return path_1.default.join(path_1.default.dirname(packageJsonPath), "qrljs-runtime");
}
const OVERRIDE_ENV_VAR = "QRLJS_MONOREPO_PATH";
// The most recent successful resolution. Later tx-only lookups (HTTP-network
// signing) reuse it so every consumer in the process sees the same qrljs
// source.
let lastResolvedRuntime;
function loadQrlJsRuntime(networkName, overridePath) {
    const configuredPath = overridePath !== null && overridePath !== void 0 ? overridePath : process.env[OVERRIDE_ENV_VAR];
    const runtime = configuredPath !== undefined
        ? loadOverrideRuntime(path_1.default.resolve(configuredPath), networkName)
        : loadBundledRuntime(networkName);
    lastResolvedRuntime = runtime;
    return runtime;
}
exports.loadQrlJsRuntime = loadQrlJsRuntime;
/**
 * The tx module enables local signing of qrljs transactions on HTTP
 * networks. It always comes from the same source as the rest of the runtime:
 * the resolution already made in this process, the environment override, or
 * the bundle. Absence of ANY source is a feature-detection result
 * (undefined), but a set override that cannot be loaded is an error.
 */
function loadQrlJsTxRuntime() {
    if (lastResolvedRuntime !== undefined) {
        return lastResolvedRuntime.txQrl;
    }
    const configuredPath = process.env[OVERRIDE_ENV_VAR];
    if (configuredPath !== undefined) {
        lastResolvedRuntime = loadOverrideRuntime(path_1.default.resolve(configuredPath), "hardhatqrlvm");
        return lastResolvedRuntime.txQrl;
    }
    if (!fs.existsSync(path_1.default.join(getBundleDir(), "runtime.cjs"))) {
        return undefined;
    }
    lastResolvedRuntime = loadBundledRuntime("hardhatqrlvm");
    return lastResolvedRuntime.txQrl;
}
exports.loadQrlJsTxRuntime = loadQrlJsTxRuntime;
/** Exposed for --verbose diagnostics and the compatibility check. */
function readBundledRuntimeManifest() {
    const manifestPath = path_1.default.join(getBundleDir(), "manifest.json");
    if (!fs.existsSync(manifestPath)) {
        return undefined;
    }
    try {
        return JSON.parse(fs.readFileSync(manifestPath, "utf8"));
    }
    catch (_a) {
        return undefined;
    }
}
exports.readBundledRuntimeManifest = readBundledRuntimeManifest;
/** Test-only: clears the process-wide resolution memo. */
function resetQrlJsRuntimeCacheForTesting() {
    lastResolvedRuntime = undefined;
}
exports.resetQrlJsRuntimeCacheForTesting = resetQrlJsRuntimeCacheForTesting;
function loadOverrideRuntime(monorepoPath, networkName) {
    const block = requireOverrideModule(monorepoPath, "packages/block/dist/cjs/index.js", networkName);
    const evm = requireOverrideModule(monorepoPath, "packages/evm/dist/cjs/index.js", networkName);
    const statemanager = requireOverrideModule(monorepoPath, "packages/statemanager/dist/cjs/index.js", networkName);
    const vm = requireOverrideModule(monorepoPath, "packages/vm/dist/cjs/index.js", networkName);
    const util = requireOverrideModule(monorepoPath, "packages/util/dist/cjs/index.js", networkName);
    const tx = requireOverrideModule(monorepoPath, "packages/tx/dist/cjs/index.js", networkName);
    assertRuntimeExports(block, evm, statemanager, tx, util, vm, monorepoPath, networkName);
    return {
        blockQrl: block.qrl,
        evmQrl: evm.qrl,
        stateQrl: statemanager.qrl,
        txQrl: tx.qrl,
        utilQrl: util.qrl,
        vmQrl: vm.qrl,
        source: { kind: "override", description: monorepoPath },
    };
}
// The runtime ships as ONE bundle so all modules share a single copy of
// every dependency (separate bundles would break instanceof checks across
// their duplicated @theqrl/util copies).
function loadBundledRuntime(networkName) {
    const bundlePath = path_1.default.join(getBundleDir(), "runtime.cjs");
    if (!fs.existsSync(bundlePath)) {
        return throwQrlJsRuntimeUnavailable("<unset>", networkName, "no qrljs runtime bundle is present in this installation and no override is set");
    }
    let bundle;
    try {
        // tslint:disable-next-line: no-var-requires
        bundle = require(bundlePath);
    }
    catch (error) {
        return throwQrlJsRuntimeUnavailable(getBundleDir(), networkName, error.message);
    }
    assertRuntimeExports(bundle.block, bundle.evm, bundle.statemanager, bundle.tx, bundle.util, bundle.vm, getBundleDir(), networkName);
    const manifest = readBundledRuntimeManifest();
    const description = (manifest === null || manifest === void 0 ? void 0 : manifest.qrlJsCommit) !== undefined
        ? `bundled runtime (qrljs ${manifest.qrlJsCommit})`
        : "bundled runtime";
    return {
        blockQrl: bundle.block.qrl,
        evmQrl: bundle.evm.qrl,
        stateQrl: bundle.statemanager.qrl,
        txQrl: bundle.tx.qrl,
        utilQrl: bundle.util.qrl,
        vmQrl: bundle.vm.qrl,
        source: { kind: "bundled", description },
    };
}
function requireOverrideModule(monorepoPath, relativeEntry, networkName) {
    const entryPath = path_1.default.join(monorepoPath, relativeEntry);
    try {
        // tslint:disable-next-line: no-var-requires
        return require(entryPath);
    }
    catch (error) {
        return throwQrlJsRuntimeUnavailable(monorepoPath, networkName, error.message);
    }
}
function assertRuntimeExports(block, evm, statemanager, tx, util, vm, sourcePath, networkName) {
    var _a;
    const requiredExports = [
        [block, "block", "QRLBlock"],
        [evm, "evm", "QRLEVM"],
        [statemanager, "statemanager", "QRLStateManager"],
        [tx, "tx", "QRLDynamicFeeTransaction"],
        [util, "util", "QRLAddress"],
        [vm, "vm", "QRLVM"],
    ];
    for (const [runtimeModule, moduleName, exportName] of requiredExports) {
        if (((_a = runtimeModule === null || runtimeModule === void 0 ? void 0 : runtimeModule.qrl) === null || _a === void 0 ? void 0 : _a[exportName]) === undefined) {
            throwQrlJsRuntimeUnavailable(sourcePath, networkName, `the ${moduleName} module does not export qrl.${exportName}`);
        }
    }
}
function throwQrlJsRuntimeUnavailable(sourcePath, networkName, message) {
    throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.QRLJS_MONOREPO_UNAVAILABLE, {
        path: sourcePath,
        network: networkName,
        message,
    });
}
//# sourceMappingURL=runtime.js.map