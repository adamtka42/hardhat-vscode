"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * This function is a typed version of `Object.keys`. Note that it's type
 * unsafe. You have to be sure that `o` has exactly the same keys as `T`.
 */
exports.unsafeObjectKeys = Object.keys;
//# sourceMappingURL=unsafe.js.map