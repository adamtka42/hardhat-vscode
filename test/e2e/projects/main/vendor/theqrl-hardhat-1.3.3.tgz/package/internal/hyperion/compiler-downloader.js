"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const crypto_1 = require("crypto");
const fs_extra_1 = __importDefault(require("fs-extra"));
const js_sha3_1 = require("js-sha3");
const nodeFetch = require("node-fetch");
const path_1 = __importDefault(require("path"));
const url_1 = require("url");
const errors_1 = require("../core/errors");
const errors_list_1 = require("../core/errors-list");
class HyperionCompilerDownloader {
    constructor(repositoryUrl, compilersCacheDir) {
        this._repositoryUrl = normalizeRepositoryUrl(repositoryUrl);
        const repositoryKey = crypto_1.createHash("sha256")
            .update(this._repositoryUrl)
            .digest("hex")
            .slice(0, 16);
        this._repositoryCacheDir = path_1.default.join(compilersCacheDir, repositoryKey);
    }
    async resolve(version) {
        const manifest = await this._getManifest(version);
        const hasRelease = Object.prototype.hasOwnProperty.call(manifest.releases, version);
        if (!hasRelease) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.HYPERION_COMPILER_VERSION_NOT_FOUND, { version, url: this._repositoryUrl });
        }
        const buildPath = manifest.releases[version];
        if (typeof buildPath !== "string") {
            throw repositoryError(this._repositoryUrl, "Compiler release path must be a string");
        }
        const build = manifest.builds.find((candidate) => candidate !== null &&
            typeof candidate === "object" &&
            candidate.path === buildPath);
        if (build === undefined) {
            throw repositoryError(this._repositoryUrl, "Compiler release references a missing build");
        }
        const validatedBuild = validateBuild(build, version, this._repositoryUrl);
        const destination = path_1.default.join(this._repositoryCacheDir, "builds", safePathSegment(version), path_1.default.posix.basename(validatedBuild.url.pathname));
        if (await fs_extra_1.default.pathExists(destination)) {
            if (await this._verifyCompiler(destination, validatedBuild.checksum)) {
                await this._makeExecutable(destination);
                return resolvedDownloadedCompiler(destination, build, validatedBuild.checksum, this._repositoryUrl);
            }
            await fs_extra_1.default.remove(destination);
        }
        await this._downloadCompiler(build, validatedBuild.url, destination);
        if (!(await this._verifyCompiler(destination, validatedBuild.checksum))) {
            await fs_extra_1.default.remove(destination);
            throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.HYPERION_COMPILER_INVALID_CHECKSUM, {
                version: build.version,
                algorithm: validatedBuild.checksum.algorithm,
            });
        }
        await this._makeExecutable(destination);
        return resolvedDownloadedCompiler(destination, build, validatedBuild.checksum, this._repositoryUrl);
    }
    async _makeExecutable(compilerPath) {
        if (process.platform !== "win32") {
            await fs_extra_1.default.chmod(compilerPath, 0o755);
        }
    }
    async _getManifest(version) {
        const manifestPath = path_1.default.join(this._repositoryCacheDir, "list.json");
        const cachedManifest = await this._readCachedManifest(manifestPath);
        if (cachedManifest !== undefined &&
            Object.prototype.hasOwnProperty.call(cachedManifest.releases, version)) {
            return cachedManifest;
        }
        return this._downloadManifest(manifestPath);
    }
    async _readCachedManifest(manifestPath) {
        if (!(await fs_extra_1.default.pathExists(manifestPath))) {
            return undefined;
        }
        try {
            return validateManifest(await fs_extra_1.default.readJson(manifestPath), this._repositoryUrl);
        }
        catch (_a) {
            await fs_extra_1.default.remove(manifestPath);
            return undefined;
        }
    }
    async _downloadManifest(manifestPath) {
        const temporary = `${manifestPath}.${process.pid}.${Date.now()}.tmp`;
        try {
            const response = await nodeFetch(new url_1.URL("list.json", this._repositoryUrl).href);
            if (!response.ok) {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.HYPERION_COMPILER_REPOSITORY_ERROR, {
                    url: this._repositoryUrl,
                    error: `HTTP ${response.status} ${response.statusText}`,
                });
            }
            const manifest = validateManifest(await response.json(), this._repositoryUrl);
            await fs_extra_1.default.ensureDir(path_1.default.dirname(manifestPath));
            await fs_extra_1.default.writeJson(temporary, manifest, { spaces: 2 });
            await fs_extra_1.default.move(temporary, manifestPath, { overwrite: true });
            return manifest;
        }
        catch (error) {
            await fs_extra_1.default.remove(temporary);
            if (errors_1.HardhatError.isHardhatError(error)) {
                throw error;
            }
            throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.HYPERION_COMPILER_REPOSITORY_ERROR, { url: this._repositoryUrl, error: getErrorMessage(error) }, error);
        }
    }
    async _downloadCompiler(build, buildUrl, destination) {
        const temporary = `${destination}.${process.pid}.${Date.now()}.tmp`;
        try {
            const response = await nodeFetch(buildUrl.href);
            if (!response.ok) {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.HYPERION_COMPILER_DOWNLOAD_FAILED, {
                    version: build.version,
                    error: `HTTP ${response.status} ${response.statusText}`,
                });
            }
            await fs_extra_1.default.ensureDir(path_1.default.dirname(destination));
            const compiler = Buffer.from(await response.arrayBuffer());
            await fs_extra_1.default.writeFile(temporary, compiler);
            await fs_extra_1.default.move(temporary, destination, { overwrite: true });
        }
        catch (error) {
            await fs_extra_1.default.remove(temporary);
            if (errors_1.HardhatError.isHardhatError(error)) {
                throw error;
            }
            throw new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.HYPERION_COMPILER_DOWNLOAD_FAILED, { version: build.version, error: getErrorMessage(error) }, error);
        }
    }
    async _verifyCompiler(compilerPath, checksum) {
        const compiler = await fs_extra_1.default.readFile(compilerPath);
        const actual = calculateChecksum(compiler, checksum.algorithm);
        return actual === normalizeChecksum(checksum.value);
    }
}
exports.HyperionCompilerDownloader = HyperionCompilerDownloader;
function resolvedDownloadedCompiler(compilerPath, build, checksum, repositoryUrl) {
    const identity = {
        source: "downloaded",
        version: build.version,
        longVersion: build.longVersion,
        checksum: normalizeChecksum(checksum.value),
        checksumAlgorithm: checksum.algorithm,
        repositoryUrl,
    };
    return {
        path: compilerPath,
        source: "downloaded",
        version: build.version,
        longVersion: build.longVersion,
        identity,
    };
}
function calculateChecksum(input, algorithm) {
    return algorithm === "sha256"
        ? crypto_1.createHash("sha256").update(input).digest("hex")
        : js_sha3_1.keccak_256(input);
}
function normalizeChecksum(checksum) {
    return checksum.replace(/^0x/i, "").toLowerCase();
}
function validateManifest(value, repositoryUrl) {
    if (value === null ||
        typeof value !== "object" ||
        !Array.isArray(value.builds) ||
        value.releases === null ||
        typeof value.releases !== "object" ||
        Array.isArray(value.releases)) {
        throw repositoryError(repositoryUrl, "Invalid compiler manifest");
    }
    return value;
}
function validateBuild(build, requestedVersion, repositoryUrl) {
    let decodedPath;
    try {
        decodedPath = decodeURIComponent(build.path);
    }
    catch (error) {
        throw repositoryError(repositoryUrl, "Invalid compiler build path", error);
    }
    const pathSegments = decodedPath.split(/[\\/]/);
    if (typeof build.path !== "string" ||
        build.path === "" ||
        build.path.startsWith("/") ||
        build.path.startsWith("\\") ||
        /^[a-zA-Z][a-zA-Z\d+.-]*:/.test(build.path) ||
        pathSegments.includes(".") ||
        pathSegments.includes("..") ||
        build.version !== requestedVersion ||
        typeof build.longVersion !== "string" ||
        build.longVersion === "") {
        throw repositoryError(repositoryUrl, "Invalid compiler build entry");
    }
    const baseUrl = new url_1.URL(repositoryUrl);
    const buildUrl = new url_1.URL(build.path, baseUrl);
    if (buildUrl.origin !== baseUrl.origin ||
        !buildUrl.pathname.startsWith(baseUrl.pathname) ||
        buildUrl.pathname === baseUrl.pathname ||
        buildUrl.pathname.endsWith("/")) {
        throw repositoryError(repositoryUrl, "Compiler build URL is outside repository");
    }
    return {
        url: buildUrl,
        checksum: getBuildChecksum(build, repositoryUrl),
    };
}
function getBuildChecksum(build, repositoryUrl) {
    const checksums = [];
    const hasGenericChecksum = build.checksum !== undefined || build.checksumAlgorithm !== undefined;
    if (hasGenericChecksum) {
        if (typeof build.checksum !== "string" ||
            (build.checksumAlgorithm !== "keccak256" &&
                build.checksumAlgorithm !== "sha256")) {
            throw repositoryError(repositoryUrl, "Invalid compiler checksum");
        }
        checksums.push({
            value: build.checksum,
            algorithm: build.checksumAlgorithm,
        });
    }
    if (build.keccak256 !== undefined) {
        checksums.push({ value: build.keccak256, algorithm: "keccak256" });
    }
    if (build.sha256 !== undefined) {
        checksums.push({ value: build.sha256, algorithm: "sha256" });
    }
    if (checksums.length !== 1 ||
        !/^(0x)?[0-9a-fA-F]{64}$/.test(checksums[0].value)) {
        throw repositoryError(repositoryUrl, "Compiler build must contain exactly one valid checksum");
    }
    return checksums[0];
}
function normalizeRepositoryUrl(repositoryUrl) {
    let url;
    try {
        url = new url_1.URL(repositoryUrl);
    }
    catch (error) {
        throw repositoryError(repositoryUrl, "Invalid repository URL", error);
    }
    if (url.protocol !== "http:" && url.protocol !== "https:") {
        throw repositoryError(repositoryUrl, "Compiler repository must use HTTP or HTTPS");
    }
    if (url.search !== "" || url.hash !== "") {
        throw repositoryError(repositoryUrl, "Compiler repository URL cannot contain a query or fragment");
    }
    if (!url.pathname.endsWith("/")) {
        url.pathname = `${url.pathname}/`;
    }
    return url.href;
}
function repositoryError(repositoryUrl, message, parent) {
    return new errors_1.HardhatError(errors_list_1.ERRORS.BUILTIN_TASKS.HYPERION_COMPILER_REPOSITORY_ERROR, { url: repositoryUrl, error: message }, parent);
}
function getErrorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
function safePathSegment(value) {
    return value.replace(/[^a-zA-Z0-9._-]/g, "_");
}
//# sourceMappingURL=compiler-downloader.js.map