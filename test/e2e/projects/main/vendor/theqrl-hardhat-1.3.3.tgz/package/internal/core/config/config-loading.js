"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = __importDefault(require("path"));
const context_1 = require("../../context");
const plugins_1 = require("../plugins");
const project_structure_1 = require("../project-structure");
const config_resolution_1 = require("./config-resolution");
const config_validation_1 = require("./config-validation");
function importCsjOrEsModule(filePath) {
    const imported = require(filePath);
    return imported.default !== undefined ? imported.default : imported;
}
function loadConfigAndTasks(hardhatArguments) {
    let configPath = hardhatArguments !== undefined ? hardhatArguments.config : undefined;
    if (configPath === undefined) {
        configPath = project_structure_1.getUserConfigPath();
    }
    else {
        if (!path_1.default.isAbsolute(configPath)) {
            configPath = path_1.default.join(process.cwd(), configPath);
            configPath = path_1.default.normalize(configPath);
        }
    }
    // Before loading the builtin tasks, the default and user's config we expose
    // the config env in the global object.
    const configEnv = require("./config-env");
    const globalAsAny = global;
    Object.entries(configEnv).forEach(([key, value]) => (globalAsAny[key] = value));
    plugins_1.loadPluginFile(path_1.default.join(__dirname, "..", "tasks", "builtin-tasks"));
    const defaultConfig = importCsjOrEsModule("./default-config");
    const userConfig = importCsjOrEsModule(configPath);
    config_validation_1.validateConfig(userConfig);
    // To avoid bad practices we remove the previously exported stuff
    Object.keys(configEnv).forEach((key) => (globalAsAny[key] = undefined));
    const resolved = config_resolution_1.resolveConfig(configPath, defaultConfig, userConfig, context_1.HardhatContext.getHardhatContext().configExtenders);
    return resolved;
}
exports.loadConfigAndTasks = loadConfigAndTasks;
//# sourceMappingURL=config-loading.js.map