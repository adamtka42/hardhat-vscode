"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_extra_1 = __importDefault(require("fs-extra"));
const path = __importStar(require("path"));
const errors_1 = require("./core/errors");
const errors_list_1 = require("./core/errors-list");
/**
 * Retrieves an artifact for the given `contractName` from the compilation output.
 *
 * @param contractName the contract's name.
 * @param contractOutput the contract's compilation output as emitted by Hyperion.
 */
function getArtifactFromContractOutput(contractName, contractOutput) {
    const compilerBytecode = contractOutput.bytecodeOutput && contractOutput.bytecodeOutput.bytecode;
    let bytecode = compilerBytecode && compilerBytecode.object ? compilerBytecode.object : "";
    if (bytecode.slice(0, 2).toLowerCase() !== "0x") {
        bytecode = `0x${bytecode}`;
    }
    const compilerDeployedBytecode = contractOutput.bytecodeOutput &&
        contractOutput.bytecodeOutput.deployedBytecode;
    let deployedBytecode = compilerDeployedBytecode && compilerDeployedBytecode.object
        ? compilerDeployedBytecode.object
        : "";
    if (deployedBytecode.slice(0, 2).toLowerCase() !== "0x") {
        deployedBytecode = `0x${deployedBytecode}`;
    }
    const linkReferences = compilerBytecode && compilerBytecode.linkReferences
        ? compilerBytecode.linkReferences
        : {};
    const deployedLinkReferences = compilerDeployedBytecode && compilerDeployedBytecode.linkReferences
        ? compilerDeployedBytecode.linkReferences
        : {};
    return {
        contractName,
        abi: contractOutput.abi,
        bytecode,
        deployedBytecode,
        linkReferences,
        deployedLinkReferences,
    };
}
exports.getArtifactFromContractOutput = getArtifactFromContractOutput;
function getArtifactPath(artifactsPath, contractName) {
    return path.join(artifactsPath, `${contractName}.json`);
}
/**
 * Stores an artifact in the given path.
 *
 * @param artifactsPath the artifacts' directory.
 * @param artifact the artifact to be stored.
 */
async function saveArtifact(artifactsPath, artifact) {
    await fs_extra_1.default.ensureDir(artifactsPath);
    await fs_extra_1.default.writeJSON(path.join(artifactsPath, `${artifact.contractName}.json`), artifact, {
        spaces: 2,
    });
}
exports.saveArtifact = saveArtifact;
/**
 * Asynchronically reads an artifact with the given `contractName` from the given `artifactPath`.
 *
 * @param artifactsPath the artifacts' directory.
 * @param contractName  the contract's name.
 */
async function readArtifact(artifactsPath, contractName) {
    const artifactPath = getArtifactPath(artifactsPath, contractName);
    if (!fs_extra_1.default.pathExistsSync(artifactPath)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.ARTIFACTS.NOT_FOUND, { contractName });
    }
    return fs_extra_1.default.readJson(artifactPath);
}
exports.readArtifact = readArtifact;
/**
 * Synchronically reads an artifact with the given `contractName` from the given `artifactPath`.
 *
 * @param artifactsPath the artifacts directory.
 * @param contractName  the contract's name.
 */
function readArtifactSync(artifactsPath, contractName) {
    const artifactPath = getArtifactPath(artifactsPath, contractName);
    if (!fs_extra_1.default.pathExistsSync(artifactPath)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.ARTIFACTS.NOT_FOUND, { contractName });
    }
    return fs_extra_1.default.readJsonSync(artifactPath);
}
exports.readArtifactSync = readArtifactSync;
//# sourceMappingURL=artifacts.js.map