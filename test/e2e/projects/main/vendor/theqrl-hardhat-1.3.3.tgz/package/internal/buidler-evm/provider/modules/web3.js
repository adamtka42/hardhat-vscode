"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const js_sha3_1 = require("js-sha3");
const errors_1 = require("../errors");
const input_1 = require("../input");
const output_1 = require("../output");
const QRL_CLIENT_VERSION = "QRLLocalProvider/qrljs";
// tslint:disable only-hardhat-error
class Web3Module {
    async processRequest(method, params = []) {
        switch (method) {
            case "web3_clientVersion":
                return this._clientVersionAction(...this._clientVersionParams(params));
            case "web3_sha3":
                return this._sha3Action(...this._sha3Params(params));
        }
        throw new errors_1.MethodNotFoundError(`Method ${method} not found`);
    }
    // web3_clientVersion
    _clientVersionParams(params) {
        return input_1.validateParams(params);
    }
    async _clientVersionAction() {
        return QRL_CLIENT_VERSION;
    }
    // web3_sha3
    _sha3Params(params) {
        return input_1.validateParams(params, input_1.rpcData);
    }
    async _sha3Action(buffer) {
        return output_1.bufferToRpcData(new Uint8Array(js_sha3_1.keccak_256.arrayBuffer(buffer)));
    }
}
exports.Web3Module = Web3Module;
//# sourceMappingURL=web3.js.map