"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const compiler_to_model_1 = require("./compiler-to-model");
exports.loadQrlDebugInfo = compiler_to_model_1.loadQrlDebugInfo;
const solidity_stack_trace_1 = require("./solidity-stack-trace");
exports.QrlStackTraceEntryType = solidity_stack_trace_1.QrlStackTraceEntryType;
const solidityTracer_1 = require("./solidityTracer");
exports.inferQrlStackTrace = solidityTracer_1.inferQrlStackTrace;
const vm_trace_decoder_1 = require("./vm-trace-decoder");
exports.QrlStackTraceDecoder = vm_trace_decoder_1.QrlStackTraceDecoder;
/** Builds source-level Hyperion stack-trace lines for a failed frame tree. */
async function buildQrlStackTraceLines(rootFrame, decoder) {
    const diagnostics = solidityTracer_1.inferQrlStackTrace(rootFrame, decoder);
    const lines = diagnostics
        .map(formatDiagnostic)
        .filter((line) => line !== undefined);
    const cause = formatInferredCause(diagnostics[0]);
    return cause === undefined
        ? lines
        : [["  Error: ", cause].join(""), ...lines];
}
exports.buildQrlStackTraceLines = buildQrlStackTraceLines;
function formatInferredCause(diagnostic) {
    var _a;
    if (diagnostic === undefined) {
        return undefined;
    }
    switch (diagnostic.type) {
        case solidity_stack_trace_1.QrlStackTraceEntryType.PRECOMPILE_ERROR:
            return [
                "call to precompile ",
                (_a = diagnostic.precompile) !== null && _a !== void 0 ? _a : "unknown",
                " failed",
            ].join("");
        case solidity_stack_trace_1.QrlStackTraceEntryType.FUNCTION_NOT_PAYABLE_ERROR:
            return [
                "non-payable function was called with value ",
                String(diagnostic.value),
            ].join("");
        case solidity_stack_trace_1.QrlStackTraceEntryType.INVALID_PARAMS_ERROR:
            return "function was called with incorrect parameters";
        case solidity_stack_trace_1.QrlStackTraceEntryType.FALLBACK_NOT_PAYABLE_ERROR:
            return [
                "fallback function is not payable and was called with value ",
                String(diagnostic.value),
            ].join("");
        case solidity_stack_trace_1.QrlStackTraceEntryType.UNRECOGNIZED_FUNCTION_WITHOUT_FALLBACK_ERROR:
            return "function selector was not recognized and there is no fallback function";
        case solidity_stack_trace_1.QrlStackTraceEntryType.RETURNDATA_SIZE_ERROR:
            return "function returned an unexpected amount of data";
        case solidity_stack_trace_1.QrlStackTraceEntryType.NONCONTRACT_ACCOUNT_CALLED_ERROR:
            return "function call targeted a non-contract account";
        case solidity_stack_trace_1.QrlStackTraceEntryType.CALL_FAILED_ERROR:
            return "function call failed to execute";
        case solidity_stack_trace_1.QrlStackTraceEntryType.DIRECT_LIBRARY_CALL_ERROR:
            return "library was called directly";
        case solidity_stack_trace_1.QrlStackTraceEntryType.OTHER_EXECUTION_ERROR:
            return "execution failed for an unrecognized reason";
        default:
            return undefined;
    }
}
function formatDiagnostic(diagnostic) {
    var _a, _b;
    const source = diagnostic.sourceReference;
    if (source !== undefined) {
        return `  at ${source.contractName}.${source.functionName} (${source.sourceName}:${source.line})`;
    }
    switch (diagnostic.type) {
        case solidity_stack_trace_1.QrlStackTraceEntryType.PRECOMPILE_ERROR:
            return `  at <precompile> (${(_a = diagnostic.precompile) !== null && _a !== void 0 ? _a : "unknown"})`;
        case solidity_stack_trace_1.QrlStackTraceEntryType.UNRECOGNIZED_CREATE_ERROR:
        case solidity_stack_trace_1.QrlStackTraceEntryType.UNRECOGNIZED_CREATE_CALLSTACK_ENTRY:
            return "  at <UnrecognizedContract>.constructor";
        case solidity_stack_trace_1.QrlStackTraceEntryType.UNRECOGNIZED_CONTRACT_ERROR:
        case solidity_stack_trace_1.QrlStackTraceEntryType.UNRECOGNIZED_CONTRACT_CALLSTACK_ENTRY:
            return `  at <UnrecognizedContract> (${(_b = diagnostic.address) !== null && _b !== void 0 ? _b : "unknown"})`;
        default:
            return undefined;
    }
}
//# sourceMappingURL=index.js.map