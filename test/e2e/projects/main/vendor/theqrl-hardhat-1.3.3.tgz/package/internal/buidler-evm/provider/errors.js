"use strict";
// Taken from: https://github.com/ethereum/EIPs/blob/master/EIPS/eip-1474.md#error-codes
//
// Code	  Message	              Meaning	                            Category
//
// -32700	Parse error	          Invalid JSON	                      standard
// -32600	Invalid request	      JSON is not a valid request object  standard
// -32601	Method not found	    Method does not exist	              standard
// -32602	Invalid params	      Invalid method parameters	          standard
// -32603	Internal error	      Internal JSON-RPC error	            standard
// -32004	Method not supported	Method is not implemented	          non-standard
//
// Not implemented:
// -32000	Invalid input	        Missing or invalid parameters	      non-standard
// -32001	Resource not found	  Requested resource not found	      non-standard
// -32002	Resource unavailable	Requested resource not available	  non-standard
// -32003	Transaction rejected	Transaction creation failed	        non-standard
Object.defineProperty(exports, "__esModule", { value: true });
class BuidlerEVMProviderError extends Error {
    constructor(message, code) {
        super(message);
        this.code = code;
        this._isBuidlerEVMProviderError = true;
    }
    static isBuidlerEVMProviderError(other) {
        return (other !== undefined &&
            other !== null &&
            other._isBuidlerEVMProviderError === true);
    }
}
exports.BuidlerEVMProviderError = BuidlerEVMProviderError;
class InvalidJsonInputError extends BuidlerEVMProviderError {
    constructor(message) {
        super(message, InvalidJsonInputError.CODE);
    }
}
exports.InvalidJsonInputError = InvalidJsonInputError;
InvalidJsonInputError.CODE = -32700;
class InvalidRequestError extends BuidlerEVMProviderError {
    constructor(message) {
        super(message, InvalidRequestError.CODE);
    }
}
exports.InvalidRequestError = InvalidRequestError;
InvalidRequestError.CODE = -32600;
class MethodNotFoundError extends BuidlerEVMProviderError {
    constructor(message) {
        super(message, MethodNotFoundError.CODE);
    }
}
exports.MethodNotFoundError = MethodNotFoundError;
MethodNotFoundError.CODE = -32601;
class InvalidArgumentsError extends BuidlerEVMProviderError {
    constructor(message) {
        super(message, InvalidArgumentsError.CODE);
    }
}
exports.InvalidArgumentsError = InvalidArgumentsError;
InvalidArgumentsError.CODE = -32602;
class InternalError extends BuidlerEVMProviderError {
    constructor(message) {
        super(message, InternalError.CODE);
    }
}
exports.InternalError = InternalError;
InternalError.CODE = -32603;
class InvalidInputError extends BuidlerEVMProviderError {
    constructor(message) {
        super(message, InvalidInputError.CODE);
    }
}
exports.InvalidInputError = InvalidInputError;
InvalidInputError.CODE = -32000;
class TransactionExecutionError extends BuidlerEVMProviderError {
    constructor(parent) {
        if (typeof parent === "string") {
            parent = new Error(parent);
        }
        super(parent.message, TransactionExecutionError.CODE);
        this.parent = parent;
        this.stack = parent.stack;
    }
}
exports.TransactionExecutionError = TransactionExecutionError;
TransactionExecutionError.CODE = -32003;
class QrlExecutionError extends InvalidInputError {
    constructor(message, data, transactionHash, traceFrame) {
        super(message);
        this.data = data;
        this.transactionHash = transactionHash;
        this.traceFrame = traceFrame;
    }
}
exports.QrlExecutionError = QrlExecutionError;
class MethodNotSupportedError extends BuidlerEVMProviderError {
    constructor(message) {
        super(message, MethodNotSupportedError.CODE);
    }
}
exports.MethodNotSupportedError = MethodNotSupportedError;
MethodNotSupportedError.CODE = -32004;
//# sourceMappingURL=errors.js.map