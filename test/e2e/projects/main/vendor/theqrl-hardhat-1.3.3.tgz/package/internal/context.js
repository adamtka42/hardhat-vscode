"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const extenders_1 = require("./core/config/extenders");
const errors_1 = require("./core/errors");
const errors_list_1 = require("./core/errors-list");
const dsl_1 = require("./core/tasks/dsl");
class HardhatContext {
    constructor() {
        this.tasksDSL = new dsl_1.TasksDSL();
        this.extendersManager = new extenders_1.ExtenderManager();
        this.loadedPlugins = [];
        this.configExtenders = [];
    }
    static isCreated() {
        const globalWithHardhatContext = global;
        return globalWithHardhatContext.__hardhatContext !== undefined;
    }
    static createHardhatContext() {
        if (this.isCreated()) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.GENERAL.CONTEXT_ALREADY_CREATED);
        }
        const globalWithHardhatContext = global;
        const ctx = new HardhatContext();
        globalWithHardhatContext.__hardhatContext = ctx;
        return ctx;
    }
    static getHardhatContext() {
        const globalWithHardhatContext = global;
        const ctx = globalWithHardhatContext.__hardhatContext;
        if (ctx === undefined) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.GENERAL.CONTEXT_NOT_CREATED);
        }
        return ctx;
    }
    static deleteHardhatContext() {
        const globalAsAny = global;
        globalAsAny.__hardhatContext = undefined;
    }
    setHardhatRuntimeEnvironment(env) {
        if (this.environment !== undefined) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.GENERAL.CONTEXT_BRE_ALREADY_DEFINED);
        }
        this.environment = env;
    }
    getHardhatRuntimeEnvironment() {
        if (this.environment === undefined) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.GENERAL.CONTEXT_BRE_NOT_DEFINED);
        }
        return this.environment;
    }
    setPluginAsLoaded(pluginName) {
        this.loadedPlugins.push(pluginName);
    }
}
exports.HardhatContext = HardhatContext;
//# sourceMappingURL=context.js.map