import { IQrlProvider } from "../../../types";
export declare function rpcQuantityToNumber(quantity?: string): number;
export declare function numberToRpcQuantity(n: number): string;
export declare function rpcQuantityFrom(value: string | number | bigint): string;
export declare function normalizeQrlTransactionQuantities(tx: any): void;
export declare function createChainIdGetter(provider: IQrlProvider): () => Promise<number>;
//# sourceMappingURL=provider-utils.d.ts.map