"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chalk_1 = __importDefault(require("chalk"));
const debug_1 = __importDefault(require("debug"));
const events_1 = require("events");
const fs_extra_1 = __importDefault(require("fs-extra"));
const path_1 = __importDefault(require("path"));
const util_1 = __importDefault(require("util"));
const errors_1 = require("../../core/errors");
const errors_list_1 = require("../../core/errors-list");
const abi_1 = require("../../qrl/abi");
const address_1 = require("../../qrl/address");
const stack_traces_1 = require("../stack-traces");
const consoleLogger_1 = require("../stack-traces/consoleLogger");
const await_semaphore_1 = require("../vendor/await-semaphore");
const errors_2 = require("./errors");
const input_1 = require("./input");
const buidler_1 = require("./modules/buidler");
const debug_2 = require("./modules/debug");
const evm_1 = require("./modules/evm");
const logger_1 = require("./modules/logger");
const net_1 = require("./modules/net");
const qrl_1 = require("./modules/qrl");
const web3_1 = require("./modules/web3");
const node_1 = require("./node");
const output_1 = require("./output");
const runtime_1 = require("./runtime");
// tslint:disable-next-line: no-var-requires
const ansiEscapes = require("ansi-escapes");
const log = debug_1.default("buidler:core:qrl:stack-traces");
const DEFAULT_CHAIN_ID = 1;
const DEFAULT_BLOCK_GAS_LIMIT = 30000000;
const PRIVATE_RPC_METHODS = new Set(["qrl_getStackTraceFailuresCount"]);
const QRL_EVM_METHODS = new Set([
    "qrl_increaseTime",
    "qrl_setNextBlockTimestamp",
    "qrl_mine",
    "qrl_revert",
    "qrl_snapshot",
]);
class HardhatQrlvmProvider extends events_1.EventEmitter {
    constructor(config, paths) {
        var _a, _b, _c, _d;
        super();
        this._accounts = [];
        this._stackTracesEnabled = false;
        this._mutex = new await_semaphore_1.Mutex();
        this._logger = new logger_1.ModulesLogger();
        this._methodCollapsedCount = 0;
        this._consoleLogMessages = [];
        this._config = config;
        this._cachePath = paths === null || paths === void 0 ? void 0 : paths.cache;
        this._projectRoot = paths === null || paths === void 0 ? void 0 : paths.root;
        this._chainId = (_a = config.chainId) !== null && _a !== void 0 ? _a : DEFAULT_CHAIN_ID;
        this._blockGasLimit = (_b = config.blockGasLimit) !== null && _b !== void 0 ? _b : DEFAULT_BLOCK_GAS_LIMIT;
        this._accountConfigs = (_c = config.accounts) !== null && _c !== void 0 ? _c : [];
        this._loggingEnabled = (_d = config.loggingEnabled) !== null && _d !== void 0 ? _d : false;
    }
    async send(method, params = []) {
        const release = await this._mutex.acquire();
        try {
            if (this._loggingEnabled && !PRIVATE_RPC_METHODS.has(method)) {
                return await this._sendWithLogging(method, params);
            }
            return await this._send(method, params);
        }
        finally {
            release();
        }
    }
    async _sendWithLogging(method, params = []) {
        this._logger.clearLogs();
        this._consoleLogMessages = [];
        try {
            const result = await this._send(method, params);
            if (this._shouldCollapseMethod(method)) {
                this._logCollapsedMethod(method);
            }
            else {
                this._startCollapsingMethod(method);
                this._log(method, false, chalk_1.default.green);
            }
            const loggedSomething = this._logModuleMessages();
            if (loggedSomething) {
                this._stopCollapsingMethod();
                this._log("");
            }
            return result;
        }
        catch (error) {
            this._stopCollapsingMethod();
            if (error instanceof errors_2.MethodNotFoundError ||
                error instanceof errors_2.MethodNotSupportedError) {
                this._log(`${method} - Method not supported`, false, chalk_1.default.red);
                // tslint:disable-next-line only-hardhat-error
                throw error;
            }
            this._log(method, false, chalk_1.default.red);
            const loggedSomething = this._logModuleMessages();
            if (loggedSomething) {
                this._log("");
            }
            if (errors_2.BuidlerEVMProviderError.isBuidlerEVMProviderError(error) ||
                errors_1.HardhatError.isHardhatError(error)) {
                this._log(error.message, true);
            }
            else {
                this._logError(error, true);
                this._log("");
                this._log("If you think this is a bug in Hardhat, please report it to the project maintainers.", true);
            }
            this._log("");
            // tslint:disable-next-line only-hardhat-error
            throw error;
        }
    }
    _logCollapsedMethod(method) {
        this._methodCollapsedCount += 1;
        process.stdout.write(
        // tslint:disable-next-line:prefer-template
        ansiEscapes.cursorHide +
            ansiEscapes.cursorPrevLine +
            chalk_1.default.green(`${method} (${this._methodCollapsedCount})`) +
            "\n" +
            ansiEscapes.eraseEndLine +
            ansiEscapes.cursorShow);
    }
    _startCollapsingMethod(method) {
        this._methodBeingCollapsed = method;
        this._methodCollapsedCount = 1;
    }
    _stopCollapsingMethod() {
        this._methodBeingCollapsed = undefined;
        this._methodCollapsedCount = 0;
    }
    _shouldCollapseMethod(method) {
        return (method === this._methodBeingCollapsed &&
            !this._logger.hasLogs() &&
            this._methodCollapsedCount > 0);
    }
    async _send(method, params = []) {
        await this._init();
        try {
            return await this._routeRequest(method, params);
        }
        catch (error) {
            const enriched = enrichQrlProviderError(error);
            if (this._stackTracesEnabled) {
                try {
                    await this._appendStackTrace(enriched);
                }
                catch (stackTraceError) {
                    this._node.recordStackTraceFailure();
                    log("Failed to generate a QRL stack trace: %O", stackTraceError);
                    // Stack trace decoding must never mask the original error.
                }
            }
            // tslint:disable-next-line only-hardhat-error
            throw enriched;
        }
    }
    async _routeRequest(method, params) {
        if (method === "qrl_requestAccounts") {
            return [...this._accounts];
        }
        if (method === "qrl_sign") {
            return this._signWithLocalSeed(params);
        }
        if (method === "qrl_getStackTraceFailuresCount") {
            return this._buidlerModule.processRequest(method, params);
        }
        if (QRL_EVM_METHODS.has(method)) {
            return this._evmModule.processRequest(method, params);
        }
        if (method.startsWith("debug_")) {
            return this._debugModule.processRequest(method, params);
        }
        if (method.startsWith("qrl_")) {
            return this._qrlModule.processRequest(method, params);
        }
        if (method.startsWith("net_")) {
            return this._netModule.processRequest(method, params);
        }
        if (method.startsWith("web3_")) {
            return this._web3Module.processRequest(method, params);
        }
        // tslint:disable-next-line only-hardhat-error
        throw new errors_2.MethodNotFoundError(`Method ${method} not found`);
    }
    async _init() {
        var _a, _b, _c;
        if (this._node !== undefined) {
            return;
        }
        const config = this._config;
        const { blockQrl, evmQrl, stateQrl, txQrl, utilQrl, vmQrl, } = runtime_1.loadQrlJsRuntime("hardhatqrlvm", config.qrlJsMonorepoPath);
        const stackTracesSupported = typeof vmQrl.createFrameCollector === "function";
        if (config.stackTraces === true && !stackTracesSupported) {
            // tslint:disable-next-line: no-console
            console.warn("The loaded QRL runtime does not support execution tracing. Update the bundled runtime or rebuild the qrljs-monorepo override to enable stack traces.");
        }
        this._stackTracesEnabled =
            config.stackTraces !== false && stackTracesSupported;
        const initialTimestamp = config.initialDate === undefined
            ? undefined
            : parseInitialDate(config.initialDate);
        const accounts = this._accountConfigs.map((account) => ({
            address: utilQrl.QRLAddress.fromString(account.address),
            balance: parseLocalAccountBalance(account.balance),
            nonce: account.nonce === undefined
                ? undefined
                : toRuntimeBigInt(account.nonce),
        }));
        this._accounts = this._accountConfigs.map((account) => normalizeLocalAccountAddress(utilQrl, account));
        const rawTransactionSigner = createRawTransactionSigner(utilQrl, this._chainId);
        const context = {
            chainId: toRuntimeBigInt(this._chainId),
            gasLimit: toRuntimeBigInt(this._blockGasLimit),
            noBaseFee: true,
        };
        const consoleLogListener = config.consoleLog === false
            ? undefined
            : (data) => this._loggingEnabled
                ? this._logConsoleLog(data)
                : consoleLogger_1.printQrlConsoleLog(data);
        const node = await node_1.HardhatNode.create({ blockQrl, evmQrl, stateQrl, txQrl, vmQrl }, {
            accounts,
            automine: (_a = config.automine) !== null && _a !== void 0 ? _a : true,
            genesisHeader: initialTimestamp === undefined
                ? undefined
                : { timestamp: initialTimestamp },
            rawTransactionSigner,
            context,
            allowUnlimitedContractSize: config.allowUnlimitedContractSize,
            consoleLogListener,
        });
        const qrlModuleConfig = {
            chainId: toRuntimeBigInt(this._chainId),
            addressFromBytes: (value) => utilQrl.QRLAddress.fromBytes(value),
            defaultGasLimit: toRuntimeBigInt(this._blockGasLimit),
            noBaseFee: true,
            createTransaction: (data) => new txQrl.QRLDynamicFeeTransaction(data),
            transactionFromSerialized: (data) => txQrl.QRLDynamicFeeTransaction.fromSerialized(data),
            effectiveGasPrice: (transaction, executionContext) => vmQrl.effectiveQrlGasPrice(transaction, executionContext),
        };
        this._qrlModule = new qrl_1.QrlModule(qrlModuleConfig, node, (_b = config.throwOnTransactionFailures) !== null && _b !== void 0 ? _b : true, (_c = config.throwOnCallFailures) !== null && _c !== void 0 ? _c : true, this._loggingEnabled ? this._logger : undefined, this._stackTracesEnabled);
        this._debugModule = new debug_2.DebugModule(qrlModuleConfig, node);
        this._netModule = new net_1.NetModule(toRuntimeBigInt(this._chainId));
        this._web3Module = new web3_1.Web3Module();
        this._evmModule = new evm_1.EvmModule(node, {
            addressFromBytes: (value) => utilQrl.QRLAddress.fromBytes(value),
        });
        this._buidlerModule = new buidler_1.BuidlerModule(node);
        const listener = (payload) => {
            this.emit("notification", {
                subscription: output_1.numberToRpcQuantity(payload.filterId),
                result: payload.result,
            });
        };
        // Handle qrl_subscribe events and proxy them to JSON-RPC/Web3 consumers.
        node.addListener("ethEvent", listener);
        this._node = node;
    }
    async _appendStackTrace(error) {
        if (error === undefined ||
            error === null ||
            typeof error.message !== "string" ||
            error.code !== -32000) {
            return;
        }
        let rootFrame = error.traceFrame;
        if (rootFrame === undefined) {
            if (typeof error.transactionHash !== "string") {
                return;
            }
            rootFrame = await this._node.traceTransactionFrames(input_1.validateParams([error.transactionHash], input_1.rpcHash)[0]);
        }
        if (typeof (rootFrame === null || rootFrame === void 0 ? void 0 : rootFrame.traceError) === "string") {
            log("QRL frame collector failed: %s", rootFrame.traceError);
            return;
        }
        const decoder = this._getStackTraceDecoder();
        if (decoder === undefined) {
            return;
        }
        const lines = await stack_traces_1.buildQrlStackTraceLines(rootFrame, decoder);
        if (lines.length > 0) {
            error.message = `${error.message}\n${lines.join("\n")}`;
        }
    }
    async _signWithLocalSeed(params) {
        const [address, data] = params;
        if (typeof address !== "string" || !address_1.isValidQrlAddress(address)) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ADDRESS, {
                address: String(address),
            });
        }
        if (data === undefined) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.QRLSIGN_MISSING_DATA_PARAM);
        }
        if (typeof data !== "string" || !QRL_HEX_DATA_REGEX.test(data)) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_HEX_DATA, { value: data });
        }
        const normalizedData = data.startsWith("0x") || data.startsWith("0X") ? data.slice(2) : data;
        if (normalizedData.length % 2 !== 0) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_HEX_DATA, { value: data });
        }
        const account = this._accountConfigs.find((candidate) => typeof address === "string" &&
            candidate.address.toLowerCase() === address.toLowerCase());
        if (account === undefined || account.seed === undefined) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.NOT_LOCAL_ACCOUNT, {
                account: `${address}`,
            });
        }
        const { seedToAccount } = require("@theqrl/web3-qrl-accounts");
        let wallet;
        try {
            wallet = seedToAccount(account.seed);
        }
        catch (_a) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.NOT_LOCAL_ACCOUNT, {
                account: `${address} (the configured seed is invalid)`,
            });
        }
        if (wallet.address.toLowerCase() !== account.address.toLowerCase()) {
            // The configured seed derives a DIFFERENT address — a config mistake
            // that must fail loudly instead of signing as someone else.
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.NOT_LOCAL_ACCOUNT, {
                account: `${address} (the configured seed derives ${wallet.address})`,
            });
        }
        return wallet.sign(data).signature;
    }
    _getStackTraceDecoder() {
        var _a;
        if (this._cachePath === undefined) {
            return undefined;
        }
        // Reload when the compile cache changes (or first appears), so a
        // recompilation within the same HRE refreshes the source maps.
        let mtime;
        try {
            mtime = fs_extra_1.default.statSync(path_1.default.join(this._cachePath, "compiler-output.json")).mtimeMs;
        }
        catch (_b) {
            mtime = undefined;
        }
        if (this._stackTraceDecoder === undefined ||
            mtime !== this._stackTraceCacheMtime) {
            this._stackTraceCacheMtime = mtime;
            const debugInfo = stack_traces_1.loadQrlDebugInfo(this._cachePath, this._projectRoot);
            this._stackTraceDecoder =
                debugInfo === undefined ? null : new stack_traces_1.QrlStackTraceDecoder(debugInfo);
        }
        return (_a = this._stackTraceDecoder) !== null && _a !== void 0 ? _a : undefined;
    }
    _logModuleMessages() {
        if (this._consoleLogMessages.length > 0) {
            this._logger.log("");
            this._logger.log("console.log:");
            for (const message of this._consoleLogMessages) {
                this._logger.log(`  ${message}`);
            }
            this._consoleLogMessages = [];
        }
        const logs = this._logger.getLogs();
        if (logs.length === 0) {
            return false;
        }
        for (const msg of logs) {
            this._log(msg, true);
        }
        return true;
    }
    _logConsoleLog(data) {
        let line = consoleLogger_1.decodeQrlConsoleLog(data);
        if (line === undefined) {
            const selector = data.length >= 4
                ? `0x${Buffer.from(data.slice(0, 4)).toString("hex")}`
                : `0x${Buffer.from(data).toString("hex")}`;
            line = `console.log <unknown selector ${selector}>`;
        }
        this._consoleLogMessages.push(line);
    }
    _logError(err, logInRed = false) {
        this._log(util_1.default.inspect(err), true, logInRed ? chalk_1.default.red : undefined);
    }
    _log(msg, indent = false, color) {
        if (indent) {
            msg = msg
                .split("\n")
                .map((line) => `  ${line}`)
                .join("\n");
        }
        if (color !== undefined) {
            // tslint:disable-next-line: no-console
            console.log(color(msg));
            return;
        }
        // tslint:disable-next-line: no-console
        console.log(msg);
    }
}
exports.HardhatQrlvmProvider = HardhatQrlvmProvider;
const ERROR_STRING_SELECTOR = "0x08c379a0";
const QRL_HEX_DATA_REGEX = /^(0x|0X)?[0-9a-fA-F]*$/;
function createRawTransactionSigner(utilQrl, chainId) {
    const accountsEntry = require.resolve("@theqrl/web3-qrl-accounts");
    const { addressFromPublicKeyAndDescriptor, descriptorFromBytes, verifyMLDSA87Signature, } = require(path_1.default.join(path_1.default.dirname(accountsEntry), "qrl_wallet.js"));
    return {
        chainId: toRuntimeBigInt(chainId),
        hash: (tx) => tx.getMessageToSign(),
        verify: (tx) => verifyMLDSA87Signature(tx.signature, tx.getMessageToSign(), tx.publicKey, descriptorFromBytes(tx.descriptor)),
        sender: (tx) => utilQrl.QRLAddress.fromBytes(Uint8Array.from(addressFromPublicKeyAndDescriptor(tx.publicKey, descriptorFromBytes(tx.descriptor)))),
    };
}
const PANIC_SELECTOR = "0x4e487b71";
const PANIC_DESCRIPTIONS = {
    "0": "generic compiler panic",
    "1": "assertion failed",
    "17": "arithmetic underflow or overflow",
    "18": "division or modulo by zero",
    "33": "invalid enum conversion",
    "34": "incorrectly encoded storage byte array",
    "49": "pop on an empty array",
    "50": "array index out of bounds",
    "65": "too much memory allocated",
    "81": "call to an uninitialized internal function",
};
/**
 * Adds the decoded revert reason and the failed transaction hash to local
 * provider errors, keeping `code`, `data`, and `transactionHash` intact so
 * callers can still decode custom errors and fetch the receipt.
 */
function enrichQrlProviderError(error) {
    if (error === undefined || error === null || typeof error !== "object") {
        return error;
    }
    const details = [];
    const reason = decodeQrlRevertReason(error.data);
    if (reason !== undefined) {
        details.push(reason);
    }
    if (typeof error.transactionHash === "string") {
        details.push(`tx: ${error.transactionHash}`);
    }
    if (details.length > 0 && typeof error.message === "string") {
        error.message = `${error.message} (${details.join(", ")})`;
    }
    return error;
}
function decodeQrlRevertReason(data) {
    if (typeof data !== "string" || !data.startsWith("0x")) {
        return undefined;
    }
    const body = `0x${data.slice(ERROR_STRING_SELECTOR.length)}`;
    try {
        if (data.startsWith(ERROR_STRING_SELECTOR)) {
            const [reason] = abi_1.decodeQrlFunctionResult(REVERT_REASON_ABI, "Error(string)", body);
            return `reason: '${reason}'`;
        }
        if (data.startsWith(PANIC_SELECTOR)) {
            const [code] = abi_1.decodeQrlFunctionResult(REVERT_PANIC_ABI, "Panic(uint256)", body);
            const description = PANIC_DESCRIPTIONS[code.toString(10)];
            const suffix = description === undefined ? "" : ` (${description})`;
            return `panic code: 0x${code.toString(16)}${suffix}`;
        }
    }
    catch (_a) {
        return undefined;
    }
    return undefined;
}
// Synthetic fragments reusing the standard QRL ABI machinery, mirroring the
// console-log approach: the revert payload types double as outputs so
// `decodeQrlFunctionResult` can decode the error body.
const REVERT_REASON_ABI = [
    {
        type: "function",
        name: "Error",
        inputs: [{ name: "reason", type: "string" }],
        outputs: [{ name: "reason", type: "string" }],
        stateMutability: "view",
    },
];
const REVERT_PANIC_ABI = [
    {
        type: "function",
        name: "Panic",
        inputs: [{ name: "code", type: "uint256" }],
        outputs: [{ name: "code", type: "uint256" }],
        stateMutability: "view",
    },
];
function normalizeLocalAccountAddress(utilQrl, account) {
    return utilQrl.QRLAddress.fromString(account.address).toString();
}
function parseLocalAccountBalance(balance) {
    if (balance === undefined) {
        return toRuntimeBigInt(0);
    }
    if (typeof balance === "number") {
        return toRuntimeBigInt(balance);
    }
    return toRuntimeBigInt(balance);
}
function toRuntimeBigInt(value) {
    return global.BigInt(value);
}
function parseInitialDate(initialDate) {
    const milliseconds = Date.parse(initialDate);
    if (Number.isNaN(milliseconds)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_INITIAL_DATE, {
            value: initialDate,
        });
    }
    return toRuntimeBigInt(Math.floor(milliseconds / 1000));
}
//# sourceMappingURL=provider.js.map