"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const errors_1 = require("../errors");
const errors_list_1 = require("../errors-list");
function rpcQuantityToNumber(quantity) {
    if (quantity === undefined) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_RPC_QUANTITY_VALUE, {
            value: quantity,
        });
    }
    if (typeof quantity !== "string" ||
        quantity.match(/^0x(?:0|(?:[1-9a-fA-F][0-9a-fA-F]*))$/) === null) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_RPC_QUANTITY_VALUE, {
            value: quantity,
        });
    }
    return parseInt(quantity.substring(2), 16);
}
exports.rpcQuantityToNumber = rpcQuantityToNumber;
function numberToRpcQuantity(n) {
    const hex = n.toString(16);
    return `0x${hex}`;
}
exports.numberToRpcQuantity = numberToRpcQuantity;
function rpcQuantityFrom(value) {
    if (typeof value === "string") {
        if (value.match(/^0x[0-9a-fA-F]+$/) !== null) {
            return value;
        }
        if (isDecimalRpcQuantity(value)) {
            return `0x${decimalStringToHex(value)}`;
        }
        return value;
    }
    return `0x${value.toString(16)}`;
}
exports.rpcQuantityFrom = rpcQuantityFrom;
function isDecimalRpcQuantity(value) {
    return typeof value === "string" && value.match(/^[0-9]+$/) !== null;
}
function decimalStringToHex(value) {
    let digits = value.replace(/^0+/, "");
    if (digits === "") {
        return "0";
    }
    let hex = "";
    while (digits.length > 0) {
        let carry = 0;
        let quotient = "";
        for (const char of digits) {
            const digit = char.charCodeAt(0) - "0".charCodeAt(0);
            const current = carry * 10 + digit;
            const quotientDigit = Math.floor(current / 16);
            carry = current % 16;
            if (quotient !== "" || quotientDigit !== 0) {
                quotient += quotientDigit.toString(10);
            }
        }
        hex = carry.toString(16) + hex;
        digits = quotient;
    }
    return hex;
}
const QRL_TRANSACTION_QUANTITY_FIELDS = [
    "gas",
    "gasLimit",
    "gasPrice",
    "maxFeePerGas",
    "maxPriorityFeePerGas",
    "value",
    "nonce",
    "chainId",
];
function normalizeQrlTransactionQuantities(tx) {
    if (tx === undefined || tx === null) {
        return;
    }
    for (const field of QRL_TRANSACTION_QUANTITY_FIELDS) {
        const value = tx[field];
        if (typeof value === "number" ||
            typeof value === "bigint" ||
            isDecimalRpcQuantity(value)) {
            tx[field] = rpcQuantityFrom(value);
        }
    }
}
exports.normalizeQrlTransactionQuantities = normalizeQrlTransactionQuantities;
function createChainIdGetter(provider) {
    let cachedChainId;
    return async function getRealChainId() {
        if (cachedChainId === undefined) {
            const id = await provider.send("qrl_chainId");
            cachedChainId = rpcQuantityToNumber(id);
        }
        return cachedChainId;
    };
}
exports.createChainIdGetter = createChainIdGetter;
//# sourceMappingURL=provider-utils.js.map