"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const chalk_1 = __importDefault(require("chalk"));
const fs_extra_1 = __importDefault(require("fs-extra"));
const path_1 = __importDefault(require("path"));
const constants_1 = require("../constants");
const execution_mode_1 = require("../core/execution-mode");
const project_structure_1 = require("../core/project-structure");
const packageInfo_1 = require("../util/packageInfo");
const emoji_1 = require("./emoji");
const CREATE_SAMPLE_PROJECT_ACTION = "Create a sample project";
const CREATE_EMPTY_HARDHAT_CONFIG_ACTION = "Create an empty hardhat.config.js";
const QUIT_ACTION = "Quit";
async function removeProjectDirIfPresent(projectRoot, dirName) {
    const dirPath = path_1.default.join(projectRoot, dirName);
    if (await fs_extra_1.default.pathExists(dirPath)) {
        await fs_extra_1.default.remove(dirPath);
    }
}
async function removeTempFilesIfPresent(projectRoot) {
    await removeProjectDirIfPresent(projectRoot, "cache");
    await removeProjectDirIfPresent(projectRoot, "artifacts");
}
function printAsciiLogo() {
    console.log(chalk_1.default.blue(`888               d8b      888 888`));
    console.log(chalk_1.default.blue(`888               Y8P      888 888`));
    console.log(chalk_1.default.blue("888                        888 888"));
    console.log(chalk_1.default.blue("88888b.  888  888 888  .d88888 888  .d88b.  888d888"));
    console.log(chalk_1.default.blue('888 "88b 888  888 888 d88" 888 888 d8P  Y8b 888P"'));
    console.log(chalk_1.default.blue("888  888 888  888 888 888  888 888 88888888 888"));
    console.log(chalk_1.default.blue("888 d88P Y88b 888 888 Y88b 888 888 Y8b.     888"));
    console.log(chalk_1.default.blue(`88888P"   "Y88888 888  "Y88888 888  "Y8888  888`));
    console.log("");
}
async function printWelcomeMessage() {
    const packageJson = await packageInfo_1.getPackageJson();
    console.log(chalk_1.default.cyan(`${emoji_1.emoji("👷 ")}Welcome to ${constants_1.HARDHAT_NAME} v${packageJson.version}${emoji_1.emoji(" 👷‍")}‍\n`));
}
async function copySampleProject(projectRoot) {
    const packageRoot = await packageInfo_1.getPackageRoot();
    await fs_extra_1.default.ensureDir(projectRoot);
    await fs_extra_1.default.copy(path_1.default.join(packageRoot, "sample-project"), projectRoot);
    // This is just in case we have been using the sample project for dev/testing
    await removeTempFilesIfPresent(projectRoot);
    await fs_extra_1.default.remove(path_1.default.join(projectRoot, "LICENSE.md"));
}
async function addGitIgnore(projectRoot) {
    const gitIgnorePath = path_1.default.join(projectRoot, ".gitignore");
    let content = await project_structure_1.getRecommendedGitIgnore();
    if (await fs_extra_1.default.pathExists(gitIgnorePath)) {
        const existingContent = await fs_extra_1.default.readFile(gitIgnorePath, "utf-8");
        content = `${existingContent}
${content}`;
    }
    await fs_extra_1.default.writeFile(gitIgnorePath, content);
}
async function addGitAttributes(projectRoot) {
    const gitAttributesPath = path_1.default.join(projectRoot, ".gitattributes");
    let content = "*.hyp linguist-language=Hyperion";
    if (await fs_extra_1.default.pathExists(gitAttributesPath)) {
        const existingContent = await fs_extra_1.default.readFile(gitAttributesPath, "utf-8");
        if (existingContent.includes(content)) {
            return;
        }
        content = `${existingContent}
${content}`;
    }
    await fs_extra_1.default.writeFile(gitAttributesPath, content);
}
function printSuggestedCommands() {
    const npx = execution_mode_1.getExecutionMode() === execution_mode_1.ExecutionMode.EXECUTION_MODE_GLOBAL_INSTALLATION
        ? ""
        : "npx ";
    console.log(`Try running some of the following tasks:`);
    console.log(`  ${npx}hardhat accounts`);
    console.log(`  ${npx}hardhat compile`);
    console.log(`  ${npx}hardhat test`);
    console.log(`  ${npx}hardhat run scripts/sample-script.js --network qrl`);
    console.log(`  ${npx}hardhat help`);
}
async function printSampleProjectInfo() {
    console.log(`The sample project uses Hardhat's built-in QRL helpers.`);
}
async function writeEmptyHardhatConfig() {
    return fs_extra_1.default.writeFile("hardhat.config.js", "module.exports = {};\n", "utf-8");
}
async function getAction() {
    const { default: enquirer } = await Promise.resolve().then(() => __importStar(require("enquirer")));
    try {
        const actionResponse = await enquirer.prompt([
            {
                name: "action",
                type: "select",
                message: "What do you want to do?",
                initial: 0,
                choices: [
                    {
                        name: CREATE_SAMPLE_PROJECT_ACTION,
                        message: CREATE_SAMPLE_PROJECT_ACTION,
                        value: CREATE_SAMPLE_PROJECT_ACTION,
                    },
                    {
                        name: CREATE_EMPTY_HARDHAT_CONFIG_ACTION,
                        message: CREATE_EMPTY_HARDHAT_CONFIG_ACTION,
                        value: CREATE_EMPTY_HARDHAT_CONFIG_ACTION,
                    },
                    { name: QUIT_ACTION, message: QUIT_ACTION, value: QUIT_ACTION },
                ],
            },
        ]);
        return actionResponse.action;
    }
    catch (e) {
        if (e === "") {
            return QUIT_ACTION;
        }
        // tslint:disable-next-line only-hardhat-error
        throw e;
    }
}
async function createProject() {
    const { default: enquirer } = await Promise.resolve().then(() => __importStar(require("enquirer")));
    printAsciiLogo();
    await printWelcomeMessage();
    const action = await getAction();
    if (action === QUIT_ACTION) {
        return;
    }
    if (action === CREATE_EMPTY_HARDHAT_CONFIG_ACTION) {
        await writeEmptyHardhatConfig();
        console.log(`${emoji_1.emoji("✨ ")}${chalk_1.default.cyan(`Config file created`)}${emoji_1.emoji(" ✨")}`);
        return;
    }
    let responses;
    try {
        responses = await enquirer.prompt([
            {
                name: "projectRoot",
                type: "input",
                initial: process.cwd(),
                message: "Hardhat project root:",
            },
            createConfirmationPrompt("shouldAddGitIgnore", "Do you want to add a .gitignore?"),
            createConfirmationPrompt("shouldAddGitAttributes", "Do you want to add a .gitattributes to enable Hyperion highlighting on GitHub?"),
        ]);
    }
    catch (e) {
        if (e === "") {
            return;
        }
        // tslint:disable-next-line only-hardhat-error
        throw e;
    }
    const { projectRoot, shouldAddGitIgnore, shouldAddGitAttributes } = responses;
    await copySampleProject(projectRoot);
    if (shouldAddGitIgnore) {
        await addGitIgnore(projectRoot);
    }
    if (shouldAddGitAttributes) {
        await addGitAttributes(projectRoot);
    }
    console.log(``);
    await printSampleProjectInfo();
    console.log(`\n${emoji_1.emoji("✨ ")}${chalk_1.default.cyan("Project created")}${emoji_1.emoji(" ✨")}`);
    console.log(``);
    printSuggestedCommands();
}
exports.createProject = createProject;
function createConfirmationPrompt(name, message) {
    return {
        type: "confirm",
        name,
        message,
        initial: "y",
        default: "(Y/n)",
        isTrue(input) {
            if (typeof input === "string") {
                return input.toLowerCase() === "y";
            }
            return input;
        },
        isFalse(input) {
            if (typeof input === "string") {
                return input.toLowerCase() === "n";
            }
            return input;
        },
        format() {
            const that = this;
            const value = that.value === true ? "y" : "n";
            if (that.state.submitted === true) {
                return that.styles.submitted(value);
            }
            return value;
        },
    };
}
//# sourceMappingURL=project-creation.js.map