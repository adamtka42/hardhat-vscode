"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const imports_1 = require("./imports");
class DependencyGraph {
    constructor() {
        this.dependenciesPerFile = new Map();
        this._visitedFiles = new Set();
    }
    static async createFromResolvedFiles(resolver, resolvedFiles) {
        const graph = new DependencyGraph();
        for (const resolvedFile of resolvedFiles) {
            await graph._addDependenciesFrom(resolver, resolvedFile);
        }
        return graph;
    }
    getResolvedFiles() {
        return Array.from(this.dependenciesPerFile.keys());
    }
    async _addDependenciesFrom(resolver, file) {
        if (this._visitedFiles.has(file.absolutePath)) {
            return;
        }
        this._visitedFiles.add(file.absolutePath);
        const dependencies = new Set();
        this.dependenciesPerFile.set(file, dependencies);
        const imports = imports_1.getImports(file.content);
        for (const imp of imports) {
            const dependency = await resolver.resolveImport(file, imp);
            dependencies.add(dependency);
            await this._addDependenciesFrom(resolver, dependency);
        }
    }
}
exports.DependencyGraph = DependencyGraph;
//# sourceMappingURL=dependencyGraph.js.map