import { ActionType, TaskArguments, TaskDefinition, TasksMap } from "../../../types";
/**
 * This class defines the DSL used in Hardhat config files
 * for creating and overriding tasks.
 */
export declare class TasksDSL {
    private readonly _tasks;
    /**
     * Creates a task, overrdining any previous task with the same name.
     *
     * @remarks The action must await every async call made within it.
     *
     * @param name The task's name.
     * @param description The task's description.
     * @param action The task's action.
     * @returns A task definition.
     */
    task<ArgsT extends TaskArguments>(name: string, description?: string, action?: ActionType<ArgsT>): TaskDefinition;
    /**
     * Creates a task without description, overrdining any previous task
     * with the same name.
     *
     * @remarks The action must await every async call made within it.
     *
     * @param name The task's name.
     * @param action The task's action.
     *
     * @returns A task definition.
     */
    task<ArgsT extends TaskArguments>(name: string, action: ActionType<ArgsT>): TaskDefinition;
    /**
     * Creates an internal task, overrdining any previous task with the same name.
     *
     * @remarks The internal tasks won't be displayed in the CLI help messages.
     * @remarks The action must await every async call made within it.
     *
     * @param name The task's name.
     * @param description The task's description.
     * @param action The task's action.
     * @returns A task definition.
     */
    internalTask<ArgsT extends TaskArguments>(name: string, description?: string, action?: ActionType<ArgsT>): TaskDefinition;
    /**
     * Creates an internal task without description, overrdining any previous
     * task with the same name.
     *
     * @remarks The internal tasks won't be displayed in the CLI help messages.
     * @remarks The action must await every async call made within it.
     *
     * @param name The task's name.
     * @param action The task's action.
     * @returns A task definition.
     */
    internalTask<ArgsT extends TaskArguments>(name: string, action: ActionType<ArgsT>): TaskDefinition;
    /**
     * Retrieves the task definitions.
     *
     * @returns The tasks container.
     */
    getTaskDefinitions(): TasksMap;
    private _addTask;
}
//# sourceMappingURL=dsl.d.ts.map