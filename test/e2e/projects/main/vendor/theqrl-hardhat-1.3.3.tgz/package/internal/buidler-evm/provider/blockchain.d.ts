export declare type Block = any;
declare type Callback<ResultT = void> = (error: Error | null, result?: ResultT) => void;
export declare class Blockchain {
    private readonly _blocks;
    private readonly _blockNumberByHash;
    getLatestBlock(callback: Callback<Block>): void;
    putBlock(block: Block, callback: Callback<Block>): void;
    delBlock(blockHash: Uint8Array, callback: Callback): void;
    getBlock(hashOrBlockNumber: Uint8Array | bigint, callback: Callback<Block>): void;
    iterator(_name: string, onBlock: (block: Block, reorg: boolean, callback: (error?: Error | null) => void) => void, callback: Callback): void;
    getDetails(_name: string, callback: Callback): void;
    deleteAllFollowingBlocks(block: Block): void;
    private _deleteFrom;
}
export {};
//# sourceMappingURL=blockchain.d.ts.map