import { ResolvedFile, Resolver } from "./resolver";
export declare class DependencyGraph {
    static createFromResolvedFiles(resolver: Resolver, resolvedFiles: ResolvedFile[]): Promise<DependencyGraph>;
    readonly dependenciesPerFile: Map<ResolvedFile, Set<ResolvedFile>>;
    private readonly _visitedFiles;
    private constructor();
    getResolvedFiles(): ResolvedFile[];
    private _addDependenciesFrom;
}
//# sourceMappingURL=dependencyGraph.d.ts.map