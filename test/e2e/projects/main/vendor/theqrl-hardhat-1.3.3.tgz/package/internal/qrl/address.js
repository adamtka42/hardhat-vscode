"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const js_sha3_1 = require("js-sha3");
const errors_1 = require("../core/errors");
const errors_list_1 = require("../core/errors-list");
const QRL_ADDRESS_REGEX = /^Q[0-9a-fA-F]{128}$/;
const HEX_REGEX = /^(0x)?[0-9a-fA-F]+$/;
function qrlAddressFromSeed(seed) {
    if (!HEX_REGEX.test(seed)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ADDRESS, {
            address: seed,
        });
    }
    try {
        const { seedToAccount } = require("@theqrl/web3-qrl-accounts");
        return normalizeQrlAddress(seedToAccount(seed).address);
    }
    catch (_error) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ADDRESS, {
            address: seed,
        });
    }
}
exports.qrlAddressFromSeed = qrlAddressFromSeed;
function isValidQrlAddress(address) {
    if (!QRL_ADDRESS_REGEX.test(address)) {
        return false;
    }
    const body = address.slice(1);
    if (body === body.toLowerCase() || body === body.toUpperCase()) {
        return true;
    }
    return address === toQrlChecksumAddress(address);
}
exports.isValidQrlAddress = isValidQrlAddress;
function toQrlChecksumAddress(address) {
    if (!QRL_ADDRESS_REGEX.test(address)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ADDRESS, { address });
    }
    const body = address.slice(1).toLowerCase();
    const hash = js_sha3_1.shake256(body, 512);
    let result = "Q";
    for (let i = 0; i < body.length; i++) {
        const char = body[i];
        result +=
            /[a-f]/.test(char) && parseInt(hash[i], 16) >= 8
                ? char.toUpperCase()
                : char;
    }
    return result;
}
exports.toQrlChecksumAddress = toQrlChecksumAddress;
function normalizeQrlAddress(address) {
    if (!isValidQrlAddress(address)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ADDRESS, { address });
    }
    return toQrlChecksumAddress(address);
}
exports.normalizeQrlAddress = normalizeQrlAddress;
function qrlAddressToBytes(address) {
    if (!isValidQrlAddress(address)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ADDRESS, { address });
    }
    return Uint8Array.from(Buffer.from(address.slice(1), "hex"));
}
exports.qrlAddressToBytes = qrlAddressToBytes;
//# sourceMappingURL=address.js.map