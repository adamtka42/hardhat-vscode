import { HardhatRuntimeEnvironment, QrlRuntimeHelpers, QrlTransactionReceipt, QrlTransactionRequest, QrlTransactionResponse } from "../../types";
export declare function createQrlRuntimeHelpers(bre: HardhatRuntimeEnvironment): QrlRuntimeHelpers;
/**
 * Wraps a transaction hash in a response object with a `wait()` helper that
 * polls for the mined receipt. Building block for the ergonomic contract API;
 * not part of the documented `hre.qrl` surface.
 */
export declare function createTransactionResponse(hash: string, waitForTransaction: (txHash: string, timeoutMs?: number, pollIntervalMs?: number) => Promise<QrlTransactionReceipt>): QrlTransactionResponse;
/**
 * Sends a transaction and returns a `QrlTransactionResponse` instead of a raw
 * hash string. Internal sender variant used by direct contract method
 * aliases; the public `sendTransaction` helper is unchanged.
 */
export declare function sendTransactionWithResponse(sendTransaction: (tx: QrlTransactionRequest) => Promise<string>, waitForTransaction: (txHash: string, timeoutMs?: number, pollIntervalMs?: number) => Promise<QrlTransactionReceipt>, tx: QrlTransactionRequest): Promise<QrlTransactionResponse>;
//# sourceMappingURL=helpers.d.ts.map