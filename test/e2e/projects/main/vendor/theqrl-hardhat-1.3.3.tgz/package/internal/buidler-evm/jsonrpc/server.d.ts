import { IQrlProvider } from "../../../types";
export interface JsonRpcServerConfig {
    hostname: string;
    port: number;
    provider: IQrlProvider;
}
export declare class JsonRpcServer {
    private _config;
    private _httpServer;
    private _wsServer;
    constructor(config: JsonRpcServerConfig);
    getProvider: (name?: string) => import("../../../types").QrlProvider;
    listen: () => Promise<{
        address: string;
        port: number;
    }>;
    waitUntilClosed: () => Promise<[unknown, unknown]>;
    close: () => Promise<[unknown, unknown]>;
}
/** Brackets IPv6 addresses so they are valid inside URLs. */
export declare function formatHost(address: string): string;
//# sourceMappingURL=server.d.ts.map