"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const source_maps_1 = require("./source-maps");
const PLACEHOLDER_PATTERN = /__\$[0-9a-f]{122}\$__/g;
const PLACEHOLDER_FILLER = "0".repeat(128);
/**
 * Resolves execution frames to Hyperion source locations: identifies the
 * contract by its (placeholder-normalized) code, maps the frame's pc through
 * the instruction source map, and finds the enclosing function in the AST.
 */
class QrlStackTraceDecoder {
    constructor(_debugInfo) {
        this._debugInfo = _debugInfo;
        this._prepared = _debugInfo.contracts.map((info) => {
            const deployedRanges = [
                ...linkReferenceRanges(info.deployedLinkReferences),
                ...immutableReferenceRanges(info.immutableReferences),
            ];
            if (info.contractKind === "library") {
                deployedRanges.push({ start: 1, length: 64 });
            }
            const bytecodeRanges = linkReferenceRanges(info.linkReferences);
            return {
                info,
                hasLocalConstructor: contractHasLocalConstructor(info, _debugInfo),
                deployedRanges,
                bytecodeRanges,
                deployedNormalized: normalizeCode(info.deployedBytecode, deployedRanges),
                bytecodeNormalized: normalizeCode(info.bytecode, bytecodeRanges),
            };
        });
    }
    /**
     * Decodes one frame into a stack trace entry. `code` is the code that
     * executed in the frame (deployed code for calls, init code for creates);
     * `pc` is the frame's failure point.
     */
    identifyContract(code, isCreate) {
        var _a;
        return (_a = this._identify(code, isCreate)) === null || _a === void 0 ? void 0 : _a.info;
    }
    decodeFrame(code, pc, isCreate) {
        var _a;
        const contract = this._identify(code, isCreate);
        if (contract === undefined) {
            return undefined;
        }
        const locations = this._locationsFor(contract, isCreate);
        const pcMap = this._pcMapFor(contract, isCreate);
        if (locations === undefined || pcMap === undefined) {
            return undefined;
        }
        const instruction = pcMap[pc];
        if (instruction === undefined || instruction < 0) {
            return undefined;
        }
        const location = locations[instruction];
        if (location === undefined || location.sourceIndex < 0) {
            return undefined;
        }
        const sourceName = this._debugInfo.sourceNamesByIndex.get(location.sourceIndex);
        if (sourceName === undefined) {
            return undefined;
        }
        const content = this._debugInfo.sourceContent.get(sourceName);
        const line = content === undefined ? 0 : source_maps_1.offsetToLine(content, location.offset);
        const functionName = (_a = this._findFunctionName(sourceName, location.offset)) !== null && _a !== void 0 ? _a : (isCreate ? "constructor" : "<unknown>");
        return {
            contractName: contract.info.contractName,
            functionName,
            sourceName,
            line,
        };
    }
    getSourceLocation(code, pc, isCreate) {
        const contract = this._identify(code, isCreate);
        if (contract === undefined) {
            return undefined;
        }
        const locations = this._locationsFor(contract, isCreate);
        const pcMap = this._pcMapFor(contract, isCreate);
        if (locations === undefined || pcMap === undefined) {
            return undefined;
        }
        const instruction = pcMap[pc];
        const location = instruction === undefined ? undefined : locations[instruction];
        if (location === undefined || location.sourceIndex < 0) {
            return undefined;
        }
        const sourceName = this._debugInfo.sourceNamesByIndex.get(location.sourceIndex);
        return sourceName === undefined
            ? undefined
            : {
                sourceName,
                offset: location.offset,
                length: location.length,
                jumpType: location.jumpType,
            };
    }
    isFunctionStartReference(source) {
        const ast = this._debugInfo.astBySourceName.get(source.sourceName);
        const content = this._debugInfo.sourceContent.get(source.sourceName);
        let matches = false;
        visitAstNodes(ast, (node) => {
            if (matches ||
                (node.nodeType !== "FunctionDefinition" &&
                    node.nodeType !== "ModifierDefinition")) {
                return;
            }
            const name = node.nodeType === "ModifierDefinition"
                ? node.name
                : node.kind === "constructor"
                    ? "constructor"
                    : node.kind === "fallback"
                        ? "<fallback>"
                        : node.kind === "receive"
                            ? "<receive>"
                            : node.name;
            const location = parseSrc(node.src);
            matches =
                name === source.functionName &&
                    location !== undefined &&
                    content !== undefined &&
                    source_maps_1.offsetToLine(content, location.offset) === source.line;
        });
        return matches;
    }
    decodeInternalCallTarget(location, contractName) {
        const ast = this._debugInfo.astBySourceName.get(location.sourceName);
        let referencedDeclaration;
        let bestLength = Number.MAX_SAFE_INTEGER;
        visitAstNodes(ast, (node) => {
            var _a;
            if (node.nodeType !== "FunctionCall") {
                return;
            }
            const callLocation = parseSrc(node.src);
            const expression = node.expression;
            const isInternalCall = (expression === null || expression === void 0 ? void 0 : expression.nodeType) === "Identifier" ||
                ((expression === null || expression === void 0 ? void 0 : expression.nodeType) === "MemberAccess" &&
                    ((_a = expression.expression) === null || _a === void 0 ? void 0 : _a.nodeType) === "Identifier" &&
                    expression.expression.name === "super");
            const reference = expression === null || expression === void 0 ? void 0 : expression.referencedDeclaration;
            if (callLocation === undefined ||
                !isInternalCall ||
                typeof reference !== "number" ||
                location.offset < callLocation.offset ||
                location.offset + location.length >
                    callLocation.offset + callLocation.length ||
                callLocation.length >= bestLength) {
                return;
            }
            referencedDeclaration = reference;
            bestLength = callLocation.length;
        });
        if (referencedDeclaration === undefined) {
            return undefined;
        }
        for (const [sourceName, sourceAst] of this._debugInfo.astBySourceName) {
            let result;
            visitAstNodes(sourceAst, (node) => {
                if (result !== undefined ||
                    node.nodeType !== "FunctionDefinition" ||
                    node.id !== referencedDeclaration) {
                    return;
                }
                const declaration = parseSrc(node.src);
                const content = this._debugInfo.sourceContent.get(sourceName);
                if (declaration === undefined || content === undefined) {
                    return;
                }
                result = {
                    contractName,
                    functionName: node.kind === "constructor"
                        ? "constructor"
                        : node.kind === "fallback"
                            ? "<fallback>"
                            : node.kind === "receive"
                                ? "<receive>"
                                : node.name,
                    sourceName,
                    line: source_maps_1.offsetToLine(content, declaration.offset),
                };
            });
            if (result !== undefined) {
                return result;
            }
        }
        return undefined;
    }
    decodeImplicitCreationStart(code) {
        const contract = this.identifyContract(code, true);
        if (contract === undefined) {
            return undefined;
        }
        const explicit = this.decodeContractStart(contract, "constructor");
        if (explicit !== undefined && explicit.sourceName === contract.sourceName) {
            return undefined;
        }
        const ast = this._debugInfo.astBySourceName.get(contract.sourceName);
        const content = this._debugInfo.sourceContent.get(contract.sourceName);
        let contractNode;
        visitAstNodes(ast, (node) => {
            if (contractNode === undefined &&
                node.nodeType === "ContractDefinition" &&
                node.name === contract.contractName) {
                contractNode = node;
            }
        });
        const location = parseSrc(contractNode === null || contractNode === void 0 ? void 0 : contractNode.src);
        if (location === undefined || content === undefined) {
            return undefined;
        }
        return {
            contractName: contract.contractName,
            functionName: "constructor",
            sourceName: contract.sourceName,
            line: source_maps_1.offsetToLine(content, location.offset),
        };
    }
    decodeLastModifier(code, steps, isCreate) {
        for (let index = steps.length - 1; index >= 0; index--) {
            const step = steps[index];
            if (step === null || typeof (step === null || step === void 0 ? void 0 : step.pc) !== "number") {
                continue;
            }
            const source = this.decodeFrame(code, step.pc, isCreate);
            if (source !== undefined && this._isModifierReference(source)) {
                return source;
            }
        }
        return undefined;
    }
    decodeLastMappedStatement(code, steps, isCreate) {
        for (let index = steps.length - 1; index >= 0; index--) {
            const step = steps[index];
            if (step === null || typeof (step === null || step === void 0 ? void 0 : step.pc) !== "number") {
                continue;
            }
            const source = this.decodeFrame(code, step.pc, isCreate);
            if (source !== undefined &&
                source.functionName !== "<unknown>" &&
                source.sourceName !== "@theqrl/hardhat/console.hyp" &&
                !this.isFunctionStartReference(source)) {
                return source;
            }
        }
        return undefined;
    }
    decodeUnconditionalModifier(contract, functionIdentifier) {
        var _a, _b, _c, _d;
        const ast = this._debugInfo.astBySourceName.get(contract.sourceName);
        let contractNode;
        visitAstNodes(ast, (node) => {
            if (contractNode === undefined &&
                node.nodeType === "ContractDefinition" &&
                node.name === contract.contractName) {
                contractNode = node;
            }
        });
        const declaration = (_a = findContractDeclaration(contractNode, functionIdentifier, contract.sourceName)) !== null && _a !== void 0 ? _a : findInheritedDeclaration(this._debugInfo, contractNode, functionIdentifier);
        for (const invocation of (_c = (_b = declaration === null || declaration === void 0 ? void 0 : declaration.node) === null || _b === void 0 ? void 0 : _b.modifiers) !== null && _c !== void 0 ? _c : []) {
            const modifierId = (_d = invocation.modifierName) === null || _d === void 0 ? void 0 : _d.referencedDeclaration;
            if (typeof modifierId !== "number") {
                continue;
            }
            for (const [sourceName, sourceAst] of this._debugInfo.astBySourceName) {
                let result;
                visitAstNodes(sourceAst, (node) => {
                    var _a, _b, _c;
                    if (result !== undefined ||
                        node.nodeType !== "ModifierDefinition" ||
                        node.id !== modifierId) {
                        return;
                    }
                    for (const statement of (_b = (_a = node.body) === null || _a === void 0 ? void 0 : _a.statements) !== null && _b !== void 0 ? _b : []) {
                        if (statement.nodeType === "PlaceholderStatement") {
                            break;
                        }
                        const expression = statement.expression;
                        const isRevert = statement.nodeType === "RevertStatement" ||
                            (statement.nodeType === "ExpressionStatement" &&
                                (expression === null || expression === void 0 ? void 0 : expression.nodeType) === "FunctionCall" &&
                                ((_c = expression.expression) === null || _c === void 0 ? void 0 : _c.name) === "revert");
                        if (!isRevert) {
                            continue;
                        }
                        const location = parseSrc(statement.src);
                        const content = this._debugInfo.sourceContent.get(sourceName);
                        if (location !== undefined && content !== undefined) {
                            result = {
                                contractName: contract.contractName,
                                functionName: node.name,
                                sourceName,
                                line: source_maps_1.offsetToLine(content, location.offset),
                            };
                        }
                        break;
                    }
                });
                if (result !== undefined) {
                    return result;
                }
            }
        }
        return undefined;
    }
    decodeContractStart(contract, functionIdentifier) {
        var _a;
        const ast = this._debugInfo.astBySourceName.get(contract.sourceName);
        let selectedSourceName = contract.sourceName;
        let contractNode;
        visitAstNodes(ast, (node) => {
            if (contractNode === undefined &&
                node.nodeType === "ContractDefinition" &&
                node.name === contract.contractName) {
                contractNode = node;
            }
        });
        if (contractNode === undefined) {
            return undefined;
        }
        let selected = contractNode;
        if (functionIdentifier !== undefined) {
            const normalized = functionIdentifier === "<fallback>" ? "fallback" : functionIdentifier;
            const declaration = (_a = findContractDeclaration(contractNode, normalized, contract.sourceName)) !== null && _a !== void 0 ? _a : findInheritedDeclaration(this._debugInfo, contractNode, normalized);
            if (declaration === undefined) {
                return undefined;
            }
            selected = declaration.node;
            selectedSourceName = declaration.sourceName;
        }
        const content = this._debugInfo.sourceContent.get(selectedSourceName);
        const location = parseSrc(selected.src);
        if (location === undefined) {
            return undefined;
        }
        return {
            contractName: contract.contractName,
            functionName: functionIdentifier === undefined
                ? "<unknown>"
                : identifierFunctionName(functionIdentifier) === "fallback"
                    ? "<fallback>"
                    : identifierFunctionName(functionIdentifier) === "receive"
                        ? "<receive>"
                        : identifierFunctionName(functionIdentifier),
            sourceName: selectedSourceName,
            line: content === undefined ? 0 : source_maps_1.offsetToLine(content, location.offset),
        };
    }
    _isModifierReference(source) {
        const ast = this._debugInfo.astBySourceName.get(source.sourceName);
        let matches = false;
        visitAstNodes(ast, (node) => {
            if (!matches &&
                node.nodeType === "ModifierDefinition" &&
                node.name === source.functionName) {
                matches = true;
            }
        });
        return matches;
    }
    _identify(code, isCreate) {
        const stripped = stripHexPrefix(code).toLowerCase();
        if (stripped === "") {
            return undefined;
        }
        let match;
        let matchLength = -1;
        for (const candidate of this._prepared) {
            const reference = isCreate
                ? candidate.bytecodeNormalized
                : candidate.deployedNormalized;
            if (reference === "") {
                continue;
            }
            const normalized = normalizeAgainst(stripped, isCreate ? candidate.bytecodeRanges : candidate.deployedRanges);
            const matches = isCreate
                ? normalized.startsWith(reference)
                : normalized === reference;
            if (!matches || reference.length < matchLength) {
                continue;
            }
            if (isCreate &&
                reference.length === matchLength &&
                match !== undefined &&
                !match.hasLocalConstructor &&
                candidate.hasLocalConstructor) {
                continue;
            }
            // Prefer the most specific init-code prefix and keep the last exact tie.
            // An implicitly derived constructor wins a tie with its explicit base.
            match = candidate;
            matchLength = reference.length;
        }
        return match;
    }
    _locationsFor(contract, isCreate) {
        if (isCreate) {
            if (contract.bytecodeLocations === undefined &&
                contract.info.bytecodeSourceMap !== undefined) {
                contract.bytecodeLocations = source_maps_1.decodeQrlSourceMap(contract.info.bytecodeSourceMap);
            }
            return contract.bytecodeLocations;
        }
        if (contract.deployedLocations === undefined &&
            contract.info.deployedSourceMap !== undefined) {
            contract.deployedLocations = source_maps_1.decodeQrlSourceMap(contract.info.deployedSourceMap);
        }
        return contract.deployedLocations;
    }
    _pcMapFor(contract, isCreate) {
        if (isCreate) {
            if (contract.bytecodePcMap === undefined) {
                contract.bytecodePcMap = source_maps_1.buildQrlPcToInstruction(hexToBytes(contract.info.bytecode));
            }
            return contract.bytecodePcMap;
        }
        if (contract.deployedPcMap === undefined) {
            contract.deployedPcMap = source_maps_1.buildQrlPcToInstruction(hexToBytes(contract.info.deployedBytecode));
        }
        return contract.deployedPcMap;
    }
    _findFunctionName(sourceName, offset) {
        const ast = this._debugInfo.astBySourceName.get(sourceName);
        if (ast === undefined) {
            return undefined;
        }
        let best;
        visitAstNodes(ast, (node) => {
            if (node.nodeType !== "FunctionDefinition" &&
                node.nodeType !== "ModifierDefinition") {
                return;
            }
            const src = parseSrc(node.src);
            if (src === undefined) {
                return;
            }
            if (offset < src.offset || offset >= src.offset + src.length) {
                return;
            }
            if (best === undefined || src.length < best.length) {
                const name = node.nodeType === "ModifierDefinition"
                    ? node.name
                    : node.kind === "constructor"
                        ? "constructor"
                        : node.kind === "fallback"
                            ? "<fallback>"
                            : node.kind === "receive"
                                ? "<receive>"
                                : node.name;
                if (typeof name === "string" && name !== "") {
                    best = { name, length: src.length };
                }
            }
        });
        return best === null || best === void 0 ? void 0 : best.name;
    }
}
exports.QrlStackTraceDecoder = QrlStackTraceDecoder;
function contractHasLocalConstructor(contract, debugInfo) {
    const ast = debugInfo.astBySourceName.get(contract.sourceName);
    let result = false;
    visitAstNodes(ast, (node) => {
        var _a;
        if (node.nodeType === "ContractDefinition" &&
            node.name === contract.contractName) {
            result = ((_a = node.nodes) !== null && _a !== void 0 ? _a : []).some((child) => child.nodeType === "FunctionDefinition" &&
                child.kind === "constructor");
        }
    });
    return result;
}
function findContractDeclaration(contractNode, normalized, sourceName) {
    var _a, _b;
    const functionName = identifierFunctionName(normalized);
    const candidates = ((_a = contractNode === null || contractNode === void 0 ? void 0 : contractNode.nodes) !== null && _a !== void 0 ? _a : []).filter((candidate) => {
        if (candidate.nodeType === "VariableDeclaration") {
            return (candidate.stateVariable === true &&
                candidate.visibility === "public" &&
                candidate.name === functionName);
        }
        if (candidate.nodeType !== "FunctionDefinition") {
            return false;
        }
        if (functionName === "constructor" ||
            functionName === "fallback" ||
            functionName === "receive") {
            return candidate.kind === functionName;
        }
        return candidate.name === functionName;
    });
    const node = (_b = candidates.find((candidate) => functionNodeSignature(candidate) === normalized)) !== null && _b !== void 0 ? _b : candidates[0];
    return node === undefined ? undefined : { node, sourceName };
}
function findInheritedDeclaration(debugInfo, contractNode, normalized) {
    const baseIds = Array.isArray(contractNode === null || contractNode === void 0 ? void 0 : contractNode.linearizedBaseContracts)
        ? contractNode.linearizedBaseContracts.slice(1)
        : [];
    for (const baseId of baseIds) {
        for (const [sourceName, ast] of debugInfo.astBySourceName) {
            let declaration;
            visitAstNodes(ast, (node) => {
                if (declaration === undefined &&
                    node.nodeType === "ContractDefinition" &&
                    node.id === baseId) {
                    declaration = findContractDeclaration(node, normalized, sourceName);
                }
            });
            if (declaration !== undefined) {
                return declaration;
            }
        }
    }
    return undefined;
}
function identifierFunctionName(identifier) {
    const open = identifier.indexOf("(");
    return open === -1 ? identifier : identifier.slice(0, open);
}
function functionNodeSignature(node) {
    var _a;
    if (typeof node.name !== "string" || node.name === "") {
        return undefined;
    }
    const parameters = (_a = node.parameters) === null || _a === void 0 ? void 0 : _a.parameters;
    if (!Array.isArray(parameters)) {
        return undefined;
    }
    const types = [];
    for (const parameter of parameters) {
        const type = canonicalAstParameterType(parameter);
        if (type === undefined) {
            return undefined;
        }
        types.push(type);
    }
    return [node.name, "(", types.join(","), ")"].join("");
}
function canonicalAstParameterType(parameter) {
    var _a;
    const typeString = (_a = parameter === null || parameter === void 0 ? void 0 : parameter.typeDescriptions) === null || _a === void 0 ? void 0 : _a.typeString;
    if (typeof typeString !== "string") {
        return undefined;
    }
    return typeString
        .replace(/\s+(memory|calldata|storage)(\s+ref)?/g, "")
        .replace(/^contract\s+[^\[]+/, "address")
        .replace(/\s+/g, "");
}
function linkReferenceRanges(linkReferences) {
    var _a;
    const ranges = [];
    for (const sourceName of Object.keys(linkReferences !== null && linkReferences !== void 0 ? linkReferences : {})) {
        for (const libraryName of Object.keys(linkReferences[sourceName])) {
            for (const position of linkReferences[sourceName][libraryName]) {
                ranges.push({ start: position.start, length: (_a = position.length) !== null && _a !== void 0 ? _a : 64 });
            }
        }
    }
    return ranges;
}
// Hyperion currently emits length 32 for immutable PUSH64 operands. Accept
// that legacy metadata as a 64-byte QRL word while preserving explicit
// non-legacy lengths for forward compatibility.
function immutableReferenceRanges(immutableReferences) {
    const ranges = [];
    for (const references of Object.values(immutableReferences !== null && immutableReferences !== void 0 ? immutableReferences : {})) {
        for (const reference of references) {
            ranges.push({
                start: reference.start,
                length: reference.length === 32 ? 64 : reference.length,
            });
        }
    }
    return ranges;
}
/** Zeroes compiler-patched regions so compiled and executed code compare equal. */
function normalizeCode(code, ranges) {
    let normalized = stripHexPrefix(code)
        .toLowerCase()
        .replace(PLACEHOLDER_PATTERN, PLACEHOLDER_FILLER);
    for (const range of ranges) {
        const from = range.start * 2;
        const length = range.length * 2;
        if (from + length > normalized.length) {
            continue;
        }
        normalized =
            normalized.slice(0, from) +
                "0".repeat(length) +
                normalized.slice(from + length);
    }
    return normalized;
}
/** Zeroes compiler-patched regions inside executed code before comparing. */
function normalizeAgainst(code, ranges) {
    let normalized = code;
    for (const range of ranges) {
        const from = range.start * 2;
        const length = range.length * 2;
        if (from + length > normalized.length) {
            continue;
        }
        normalized =
            normalized.slice(0, from) +
                "0".repeat(length) +
                normalized.slice(from + length);
    }
    return normalized;
}
function visitAstNodes(node, visit) {
    if (node === null || typeof node !== "object") {
        return;
    }
    if (Array.isArray(node)) {
        for (const child of node) {
            visitAstNodes(child, visit);
        }
        return;
    }
    if (typeof node.nodeType === "string") {
        visit(node);
    }
    for (const key of Object.keys(node)) {
        visitAstNodes(node[key], visit);
    }
}
function parseSrc(src) {
    if (typeof src !== "string") {
        return undefined;
    }
    const [offset, length] = src.split(":").map((part) => parseInt(part, 10));
    if (Number.isNaN(offset) || Number.isNaN(length)) {
        return undefined;
    }
    return { offset, length };
}
function stripHexPrefix(value) {
    return value.startsWith("0x") || value.startsWith("0X")
        ? value.slice(2)
        : value;
}
function hexToBytes(value) {
    const stripped = stripHexPrefix(value);
    const bytes = new Uint8Array(stripped.length / 2);
    for (let index = 0; index < bytes.length; index++) {
        bytes[index] = parseInt(stripped.slice(index * 2, index * 2 + 2), 16);
    }
    return bytes;
}
//# sourceMappingURL=vm-trace-decoder.js.map