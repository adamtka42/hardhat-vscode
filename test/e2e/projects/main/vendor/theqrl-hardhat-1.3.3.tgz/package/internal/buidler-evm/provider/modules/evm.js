"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const errors_1 = require("../errors");
const input_1 = require("../input");
const output_1 = require("../output");
// tslint:disable only-hardhat-error
class EvmModule {
    constructor(_node, _config) {
        this._node = _node;
        this._config = _config;
    }
    async processRequest(method, params = []) {
        switch (method) {
            case "qrl_increaseTime":
                return this._increaseTimeAction(...this._increaseTimeParams(params));
            case "qrl_setNextBlockTimestamp":
                return this._setNextBlockTimestampAction(...this._setNextBlockTimestampParams(params));
            case "qrl_mine":
                return this._mineAction(...this._mineParams(params));
            case "qrl_revert":
                return this._revertAction(...this._revertParams(params));
            case "qrl_snapshot":
                return this._snapshotAction(...this._snapshotParams(params));
        }
        throw new errors_1.MethodNotFoundError(`Method ${method} not found`);
    }
    // qrl_setNextBlockTimestamp
    _setNextBlockTimestampParams(params) {
        return [parseSingleQuantity(params, "timestamp")];
    }
    async _setNextBlockTimestampAction(timestamp) {
        try {
            await this._node.setNextBlockTimestamp(timestamp);
        }
        catch (error) {
            throw new errors_1.InvalidArgumentsError(error.message);
        }
        return timestamp.toString();
    }
    // qrl_increaseTime
    _increaseTimeParams(params) {
        return [parseSingleQuantity(params, "seconds")];
    }
    async _increaseTimeAction(increment) {
        try {
            return (await this._node.increaseTime(increment)).toString();
        }
        catch (error) {
            throw new errors_1.InvalidArgumentsError(error.message);
        }
    }
    // qrl_mine
    _mineParams(params) {
        if (params.length > 1) {
            throw new errors_1.InvalidArgumentsError("qrl_mine expects at most one options object");
        }
        if (params.length === 0 || params[0] === undefined) {
            return [{}];
        }
        const options = params[0];
        if (typeof options !== "object" ||
            options === null ||
            Array.isArray(options)) {
            throw new errors_1.InvalidArgumentsError("qrl_mine options must be an object");
        }
        return [
            {
                timestamp: parseOptionalQuantity(options.timestamp, "timestamp"),
                gasLimit: parseOptionalQuantity(options.gasLimit, "gasLimit"),
                baseFee: parseOptionalQuantity(options.baseFee, "baseFee"),
                coinbase: options.coinbase === undefined
                    ? undefined
                    : this._config.addressFromBytes(input_1.validateParams([options.coinbase], input_1.rpcAddress)[0]),
            },
        ];
    }
    async _mineAction(options) {
        const block = await this._node.mineBlock(options);
        return output_1.bufferToRpcData(block.hash());
    }
    // qrl_revert
    _revertParams(params) {
        return [parseSingleQuantity(params, "snapshot id")];
    }
    async _revertAction(snapshotId) {
        return this._node.revertToSnapshot(snapshotId);
    }
    // qrl_snapshot
    _snapshotParams(params) {
        return input_1.validateParams(params);
    }
    async _snapshotAction() {
        return output_1.numberToRpcQuantity(await this._node.takeSnapshot());
    }
}
exports.EvmModule = EvmModule;
function parseSingleQuantity(params, name) {
    if (params.length !== 1) {
        throw new errors_1.InvalidArgumentsError(`Expected one ${name} argument`);
    }
    return parseQrlControlQuantity(params[0], name);
}
function parseOptionalQuantity(value, name) {
    return value === undefined ? undefined : parseQrlControlQuantity(value, name);
}
function parseQrlControlQuantity(value, name) {
    if (typeof value === "bigint") {
        // tslint:disable-next-line:strict-comparisons
        if (value >= global.BigInt(0)) {
            return value;
        }
    }
    else if (typeof value === "number") {
        if (Number.isSafeInteger(value) && value >= 0) {
            return global.BigInt(value);
        }
    }
    else if (typeof value === "string") {
        if (/^0x[0-9a-fA-F]+$/.test(value) || /^[0-9]+$/.test(value)) {
            return global.BigInt(value);
        }
    }
    throw new errors_1.InvalidArgumentsError(`QRL ${name} must be a non-negative integer or quantity`);
}
//# sourceMappingURL=evm.js.map