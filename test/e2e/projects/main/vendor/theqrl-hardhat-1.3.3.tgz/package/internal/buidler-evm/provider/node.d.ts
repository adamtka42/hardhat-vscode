/// <reference types="node" />
import EventEmitter from "events";
import { Block } from "./blockchain";
import { QRLLogFilter } from "./filter";
import { RpcLogOutput } from "./output";
export interface QrlNodeRuntime {
    blockQrl: {
        QRLBlock: new (data?: any) => Block;
        genQRLTransactionsRoot: (transactions: readonly any[]) => Promise<Uint8Array>;
        genQRLReceiptsRoot: (receipts: readonly any[]) => Promise<Uint8Array>;
    };
    evmQrl: {
        QRLEVM: new (options?: any) => any;
    };
    stateQrl: {
        QRLStateManager: new (options?: any) => any;
    };
    txQrl?: {
        QRLDynamicFeeTransaction: new (data?: any) => any;
    };
    vmQrl: {
        QRLVM: new (options?: any) => any;
        createQRLReceiptFromRunTxResult: (options: any) => any;
        createFrameCollector?: (root: QrlTraceFrame) => {
            listener: any;
            readonly lastError?: Error;
        };
        createRawStructLogCollector?: (config: QrlTraceConfig) => {
            listener: any;
            finish: (rootExecutionGas?: any) => any[];
        };
        qrlOpcodeName?: (opcode: number) => string;
    };
}
export interface HardhatNodeOptions {
    genesis?: Record<string, any>;
    genesisHeader?: Record<string, any>;
    context?: Record<string, any>;
    accounts?: LocalAccount[];
    automine?: boolean;
    rawTransactionSigner?: QrlNodeSigner;
    allowUnlimitedContractSize?: boolean;
    consoleLogListener?: (input: any) => void;
    filterNow?: () => number;
}
export interface QrlNodeSigner {
    chainId: bigint;
    hash: (transaction: any) => Uint8Array;
    verify: (transaction: any) => boolean | Promise<boolean>;
    sender: (transaction: any) => any | Promise<any>;
}
export interface LocalAccount {
    address: any;
    balance?: bigint | string;
    nonce?: bigint | number;
}
export interface CallParams {
    to: any;
    from: any;
    gasLimit: bigint;
    gasPrice: bigint;
    value: bigint;
    data: Uint8Array;
}
export interface RunCallOptions {
    usePendingState?: boolean;
    traceListener?: any;
    emitConsoleLogs?: boolean;
}
export interface RunTransactionResult {
    transaction: any;
    runTxResult: any;
    receipt?: any;
    block?: Block;
}
export interface RunTransactionInNewBlockResult {
    transaction: any;
    runTxResult: any;
    receipt: any;
    block: Block;
}
export interface IndexedQrlTransaction {
    transaction: any;
    sender: any;
}
export interface MineBlockOptions {
    timestamp?: bigint;
    gasLimit?: bigint;
    baseFee?: bigint;
    coinbase?: any;
}
export interface EstimateGasOptions {
    usePendingState?: boolean;
}
export interface EstimateGasResult {
    estimation: bigint;
    runTxResult?: any;
    error?: Error;
}
export interface QrlTraceConfig {
    disableStack?: boolean;
    enableMemory?: boolean;
    limit?: number;
}
export interface QrlTransactionReplayResult {
    gasUsed: bigint;
    gasLimit: bigint;
    returnValue: Uint8Array;
    failed: boolean;
    errorMessage?: string;
}
export interface QrlTraceFrame {
    kind: "call" | "staticcall" | "delegatecall" | "create" | "create2";
    depth: number;
    from?: any;
    target?: any;
    createdAddress?: any;
    precompile?: any;
    input: Uint8Array;
    value: bigint;
    gasLimit: bigint;
    code?: Uint8Array;
    returnValue?: Uint8Array;
    gasUsed?: bigint;
    errorMessage?: string;
    traceError?: string;
    lastPc?: number;
    steps: Array<{
        pc: number;
    } | QrlTraceFrame>;
    children: QrlTraceFrame[];
}
export declare class HardhatNode extends EventEmitter {
    private readonly _runtime;
    private readonly _blockchain;
    private readonly _rawTransactionSigner?;
    private readonly _context;
    private readonly _automine;
    private readonly _consoleLogListener?;
    private readonly _allowUnlimitedContractSize?;
    private readonly _filterNow;
    static create(runtime: QrlNodeRuntime, options?: HardhatNodeOptions): Promise<HardhatNode>;
    private readonly _localAccounts;
    private readonly _transactionsByHash;
    private readonly _receiptsByTransactionHash;
    private readonly _transactionHashToBlockHash;
    private readonly _stateBeforeByBlock;
    private _pendingTimeIncrease;
    private _totalTimeIncrement;
    private _nextBlockTimestamp?;
    private _pendingStateManager?;
    private _pendingVm?;
    private _pendingBlockTimestamp?;
    private readonly _pendingTransactions;
    private _nextSnapshotId;
    private readonly _snapshots;
    private _nextFilterId;
    private readonly _filters;
    private _filterExpiryTimer?;
    private _nextSubscriptionId;
    private _failedStackTraces;
    private readonly _subscriptions;
    private _vm;
    private _stateManager;
    private readonly _getLatestBlock;
    private readonly _getBlock;
    private constructor();
    getLatestBlock(): Promise<Block>;
    getLatestBlockNumber(): Promise<bigint>;
    getBlockByNumber(blockNumber: bigint): Promise<Block | undefined>;
    getBlockByHash(hash: Uint8Array): Promise<Block | undefined>;
    getBlockByTransactionHash(hash: Uint8Array): Promise<Block | undefined>;
    getTransactionByHash(hash: Uint8Array): Promise<any | undefined>;
    getIndexedTransactionByHash(hash: Uint8Array): Promise<IndexedQrlTransaction | undefined>;
    getTransactionReceipt(hash: Uint8Array): Promise<any | undefined>;
    replayTransaction(hash: Uint8Array, traceListener: any): Promise<QrlTransactionReplayResult>;
    traceTransactionFrames(hash: Uint8Array): Promise<QrlTraceFrame>;
    traceCallFrames(call: CallParams, options?: {
        usePendingState?: boolean;
    }): Promise<QrlTraceFrame>;
    traceEstimateGasFrames(transaction: any, sender: any, options?: EstimateGasOptions): Promise<QrlTraceFrame>;
    debugTraceCall(call: CallParams, config?: QrlTraceConfig, options?: {
        usePendingState?: boolean;
    }): Promise<any>;
    debugTraceTransaction(hash: Uint8Array, config?: QrlTraceConfig): Promise<any>;
    recordStackTraceFailure(): void;
    getStackTraceFailuresCount(): Promise<number>;
    getAccountBalance(address: any): Promise<bigint>;
    getAccountNonce(address: any): Promise<bigint>;
    getCode(address: any): Promise<Uint8Array>;
    getStorageAt(address: any, key: Uint8Array): Promise<Uint8Array>;
    getPendingCode(address: any): Promise<Uint8Array>;
    getPendingStorageAt(address: any, key: Uint8Array): Promise<Uint8Array>;
    getBlockGasLimit(): Promise<bigint>;
    getCoinbaseAddress(): Promise<any>;
    getGasPrice(): Promise<bigint>;
    newFilter(criteria: QRLLogFilter): Promise<bigint>;
    newBlockFilter(): Promise<bigint>;
    newPendingTransactionFilter(): Promise<bigint>;
    uninstallFilter(filterId: bigint): boolean;
    getFilterChanges(filterId: bigint): Promise<string[] | RpcLogOutput[] | undefined>;
    getFilterLogs(filterId: bigint): Promise<RpcLogOutput[] | undefined>;
    getLogs(filter: QRLLogFilter): Promise<RpcLogOutput[]>;
    newHeadsSubscription(): bigint;
    newPendingTransactionsSubscription(fullObjects?: boolean): bigint;
    newLogsSubscription(criteria: QRLLogFilter): bigint;
    unsubscribe(subscriptionId: bigint): boolean;
    installedSubscriptionCount(): number;
    installedFilterCount(): number;
    estimateGas(transaction: any, sender: any, options?: EstimateGasOptions): Promise<EstimateGasResult>;
    getLocalAccountAddresses(): Promise<string[]>;
    runTransaction(transaction: any, sender: any): Promise<RunTransactionResult>;
    runRawTransaction(transaction: any): Promise<RunTransactionResult>;
    runTransactionInNewBlock(transaction: any, sender: any): Promise<RunTransactionInNewBlockResult>;
    runRawTransactionInNewBlock(transaction: any): Promise<RunTransactionInNewBlockResult>;
    getPendingTransactions(): Promise<any[]>;
    getPendingAccountBalance(address: any): Promise<bigint>;
    getPendingAccountNonce(address: any): Promise<bigint>;
    getPendingBlock(): Promise<Block>;
    mineBlock(options?: MineBlockOptions): Promise<Block>;
    setNextBlockTimestamp(timestamp: bigint): Promise<void>;
    increaseTime(increment: bigint): Promise<bigint>;
    getTimeIncrement(): Promise<bigint>;
    getNextBlockTimestamp(): Promise<bigint | undefined>;
    takeSnapshot(): Promise<bigint>;
    revertToSnapshot(id: bigint): Promise<boolean>;
    mineEmptyBlock(options?: MineBlockOptions): Promise<Block>;
    runCall(call: CallParams, options?: RunCallOptions): Promise<any>;
    private _correctInitialEstimation;
    private _binarySearchEstimation;
    private _runTxAndRevertMutations;
    private _copyTransactionWithGasLimit;
    private _buildBlockFromPending;
    private _minePendingBlock;
    private _getRawTransactionSender;
    private _runTransactionInPendingBlock;
    private _runTransactionInNewBlock;
    private _createVm;
    private _replaceStateManager;
    private _rememberStateBeforeBlock;
    private _indexMinedTransaction;
    private _calculateNextBlockTimestamp;
    private _consumeTimeControls;
    private _resetFilterCursors;
    private _registerSubscription;
    private _notifyPendingTransactionSubscriptions;
    private _notifyBlockSubscriptions;
    private _notifyRemovedLogSubscriptions;
    private _emitSubscription;
    private _getBlocksAfter;
    private _hasLogSubscriptions;
    private _registerFilter;
    private _lookupFilter;
    private _filterDeadline;
    private _sweepExpiredFilters;
    private _scheduleFilterSweep;
    private _putBlock;
    private _initLocalAccounts;
    private _getLocalAccount;
    private _deleteBlock;
}
//# sourceMappingURL=node.d.ts.map