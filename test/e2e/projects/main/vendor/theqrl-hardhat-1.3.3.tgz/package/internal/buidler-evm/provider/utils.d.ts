export declare function getCurrentTimestamp(): number;
//# sourceMappingURL=utils.d.ts.map