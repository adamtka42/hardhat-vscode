"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = __importDefault(require("util"));
async function glob(pattern) {
    const { default: globModule } = await Promise.resolve().then(() => __importStar(require("glob")));
    return util_1.default.promisify(globModule)(pattern, { realpath: true });
}
exports.glob = glob;
function globSync(pattern) {
    return require("glob").sync(pattern, { realpath: true });
}
exports.globSync = globSync;
//# sourceMappingURL=glob.js.map