"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const js_sha3_1 = require("js-sha3");
const address_1 = require("../../qrl/address");
const errors_1 = require("./errors");
const input_1 = require("./input");
const output_1 = require("./output");
// tslint:disable only-hardhat-error no-bitwise strict-comparisons
const BIGINT_ZERO = global.BigInt(0);
const BIGINT_ONE = global.BigInt(1);
const QRL_LOGS_BLOOM_BYTES = 256;
const MAX_LOG_TOPIC_POSITIONS = 4;
const MAX_LOG_TOPIC_ALTERNATIVES = 1000;
exports.LATEST_BLOCK = global.BigInt(-1);
exports.QRL_FILTER_DEADLINE_MS = 5 * 60 * 1000;
function parseLogFilter(value) {
    if (!isRecord(value)) {
        throw new errors_1.InvalidArgumentsError("QRL log filter must be an object");
    }
    const request = input_1.validateParams([value], input_1.rpcFilterRequest)[0];
    if (request.blockHash !== undefined &&
        (request.fromBlock !== undefined || request.toBlock !== undefined)) {
        throw new errors_1.InvalidArgumentsError("QRL log filter blockHash cannot be combined with fromBlock or toBlock");
    }
    return {
        fromBlock: request.fromBlock,
        toBlock: request.toBlock,
        blockHash: request.blockHash,
        addresses: normalizeLogAddresses(request.address),
        topics: normalizeLogTopics(request.topics),
    };
}
exports.parseLogFilter = parseLogFilter;
function serializeLogCriteria(criteria) {
    var _a;
    return {
        fromBlock: serializeBlockTag(criteria.fromBlock),
        toBlock: serializeBlockTag(criteria.toBlock),
        address: criteria.addresses,
        topics: (_a = criteria.topics) === null || _a === void 0 ? void 0 : _a.map((topic) => topic === null ? null : Array.from(topic)),
    };
}
exports.serializeLogCriteria = serializeLogCriteria;
function parseSubscriptionBound(value, name) {
    if (value === undefined || value === "latest") {
        return { kind: "latest" };
    }
    if (value === "earliest") {
        return { kind: "number", value: BIGINT_ZERO };
    }
    if (value === "pending") {
        throw new errors_1.InvalidArgumentsError(`qrl_subscribe logs ${name} cannot be 'pending'`);
    }
    return { kind: "number", value };
}
exports.parseSubscriptionBound = parseSubscriptionBound;
function resolveLogFilterBlock(value, fallback, latest) {
    if (value === undefined) {
        return { number: fallback, includesPending: false };
    }
    if (value === "latest") {
        return { number: latest, includesPending: false };
    }
    if (value === "pending") {
        return { number: latest + BIGINT_ONE, includesPending: true };
    }
    if (value === "earliest") {
        return { number: BIGINT_ZERO, includesPending: false };
    }
    return { number: value, includesPending: false };
}
exports.resolveLogFilterBlock = resolveLogFilterBlock;
function resolveInstalledFilterStart(value, latest) {
    if (value === undefined || value === "latest" || value === "pending") {
        return latest + BIGINT_ONE;
    }
    if (value === "earliest") {
        return BIGINT_ZERO;
    }
    return value;
}
exports.resolveInstalledFilterStart = resolveInstalledFilterStart;
function resolveInstalledFilterMinimum(value) {
    if (value === undefined ||
        value === "latest" ||
        value === "pending" ||
        value === "earliest") {
        return BIGINT_ZERO;
    }
    return value;
}
exports.resolveInstalledFilterMinimum = resolveInstalledFilterMinimum;
function maxBigInt(left, right) {
    return left > right ? left : right;
}
exports.maxBigInt = maxBigInt;
function collectMatchingLogs(block, filter) {
    const logs = [];
    for (const receipt of block.receipts) {
        for (const log of receipt.logs) {
            if (matchesLogFilter(log, filter)) {
                logs.push(log);
            }
        }
    }
    return logs;
}
exports.collectMatchingLogs = collectMatchingLogs;
function matchesLogFilter(log, filter) {
    if (filter.addresses !== undefined &&
        !filter.addresses.includes(log.address.toString())) {
        return false;
    }
    if (filter.topics === undefined) {
        return true;
    }
    return topicMatched(filter.topics, log.topics.map((topic) => output_1.bufferToRpcData(topic)));
}
exports.matchesLogFilter = matchesLogFilter;
function filterLogs(logs, criteria) {
    const filteredLogs = [];
    for (const log of logs) {
        if (log.blockNumber === undefined) {
            continue;
        }
        const blockNumber = global.BigInt(log.blockNumber);
        if (blockNumber < criteria.fromBlock) {
            continue;
        }
        if (criteria.toBlock !== exports.LATEST_BLOCK && blockNumber > criteria.toBlock) {
            continue;
        }
        if (criteria.addresses.length !== 0 &&
            !criteria.addresses.includes(log.address)) {
            continue;
        }
        if (!topicMatched(criteria.normalizedTopics, log.topics)) {
            continue;
        }
        filteredLogs.push(log);
    }
    return filteredLogs;
}
exports.filterLogs = filterLogs;
function topicMatched(normalizedTopics, logTopics) {
    if (normalizedTopics.length > logTopics.length) {
        return false;
    }
    for (let i = 0; i < normalizedTopics.length; i++) {
        const acceptedTopics = normalizedTopics[i];
        if (acceptedTopics === null || acceptedTopics.size === 0) {
            continue;
        }
        if (!acceptedTopics.has(logTopics[i])) {
            return false;
        }
    }
    return true;
}
exports.topicMatched = topicMatched;
function bloomFilter(bloom, addresses, normalizedTopics) {
    if (bloom.length !== QRL_LOGS_BLOOM_BYTES) {
        throw new Error(`Invalid QRL logs bloom length=${bloom.length}`);
    }
    if (addresses.length > 0 &&
        !addresses.some((address) => bloomContains(bloom, address))) {
        return false;
    }
    for (const alternatives of normalizedTopics) {
        if (alternatives === null || alternatives.length === 0) {
            continue;
        }
        if (!alternatives.some((topic) => topic !== null && bloomContains(bloom, topic))) {
            return false;
        }
    }
    return true;
}
exports.bloomFilter = bloomFilter;
function normalizeLogAddresses(addresses) {
    if (addresses === undefined) {
        return undefined;
    }
    const values = Array.isArray(addresses) ? addresses : [addresses];
    if (values.length === 0) {
        return undefined;
    }
    return values.map((address) => address_1.toQrlChecksumAddress(`Q${Buffer.from(address).toString("hex")}`));
}
function normalizeLogTopics(topics) {
    if (topics === undefined) {
        return undefined;
    }
    if (topics.length > MAX_LOG_TOPIC_POSITIONS) {
        throw new errors_1.InvalidArgumentsError(`QRL log filter allows at most ${MAX_LOG_TOPIC_POSITIONS} topic positions`);
    }
    return topics.map((entry) => {
        if (entry === null) {
            return null;
        }
        if (entry instanceof Uint8Array) {
            return new Set([output_1.bufferToRpcData(entry)]);
        }
        if (entry.length > MAX_LOG_TOPIC_ALTERNATIVES) {
            throw new errors_1.InvalidArgumentsError(`QRL log filter allows at most ${MAX_LOG_TOPIC_ALTERNATIVES} topic alternatives`);
        }
        if (entry.length === 0 || entry.some((topic) => topic === null)) {
            return null;
        }
        return new Set(entry.map((topic) => output_1.bufferToRpcData(topic)));
    });
}
function bloomContains(bloom, value) {
    const hash = new Uint8Array(js_sha3_1.keccak_256.arrayBuffer(value));
    for (let index = 0; index < 6; index += 2) {
        const bit = ((hash[index] << 8) | hash[index + 1]) & 0x7ff;
        const byteIndex = QRL_LOGS_BLOOM_BYTES - (bit >> 3) - 1;
        if ((bloom[byteIndex] & (1 << (hash[index + 1] & 0x07))) === 0) {
            return false;
        }
    }
    return true;
}
function serializeBlockTag(value) {
    return typeof value === "bigint" ? output_1.numberToRpcQuantity(value) : value;
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
//# sourceMappingURL=filter.js.map