export default function (): void;
//# sourceMappingURL=builtin-tasks.d.ts.map