import { ResolvedHyperionCompiler } from "./compiler-types";
export interface HyperionCompilerBuild {
    path: string;
    version: string;
    longVersion: string;
    checksum?: string;
    checksumAlgorithm?: "keccak256" | "sha256";
    keccak256?: string;
    sha256?: string;
}
export interface HyperionCompilersManifest {
    builds: HyperionCompilerBuild[];
    releases: {
        [version: string]: string;
    };
    latestRelease?: string;
}
export declare class HyperionCompilerDownloader {
    private readonly _repositoryUrl;
    private readonly _repositoryCacheDir;
    constructor(repositoryUrl: string, compilersCacheDir: string);
    resolve(version: string): Promise<ResolvedHyperionCompiler>;
    private _makeExecutable;
    private _getManifest;
    private _readCachedManifest;
    private _downloadManifest;
    private _downloadCompiler;
    private _verifyCompiler;
}
//# sourceMappingURL=compiler-downloader.d.ts.map