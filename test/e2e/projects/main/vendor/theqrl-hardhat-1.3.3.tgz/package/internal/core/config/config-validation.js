"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const t = __importStar(require("io-ts"));
const lib_1 = require("io-ts/lib");
const constants_1 = require("../../constants");
const address_1 = require("../../qrl/address");
const errors_1 = require("../errors");
const errors_list_1 = require("../errors-list");
function stringify(v) {
    if (typeof v === "function") {
        return lib_1.getFunctionName(v);
    }
    if (typeof v === "number" && !isFinite(v)) {
        if (isNaN(v)) {
            return "NaN";
        }
        return v > 0 ? "Infinity" : "-Infinity";
    }
    return JSON.stringify(v);
}
function getContextPath(context) {
    const keysPath = context
        .slice(1)
        .map((c) => c.key)
        .join(".");
    return `${context[0].type.name}.${keysPath}`;
}
function getMessage(e) {
    const lastContext = e.context[e.context.length - 1];
    return e.message !== undefined
        ? e.message
        : getErrorMessage(getContextPath(e.context), e.value, lastContext.type.name);
}
function getErrorMessage(path, value, expectedType) {
    return `Invalid value ${stringify(value)} for ${path} - Expected a value of type ${expectedType}.`;
}
function failure(es) {
    return es.map(getMessage);
}
exports.failure = failure;
function success() {
    return [];
}
exports.success = success;
exports.DotPathReporter = {
    report: (validation) => validation.fold(failure, success),
};
function optional(codec, name = `${codec.name} | undefined`) {
    return new t.Type(name, (u) => u === undefined || codec.is(u), (u, c) => (u === undefined ? t.success(u) : codec.validate(u, c)), (a) => (a === undefined ? undefined : codec.encode(a)));
}
// IMPORTANT: This t.types MUST be kept in sync with the actual types.
const OtherAccountsConfig = t.type({
    type: t.string,
});
const NetworkConfigAccounts = t.union([
    t.literal("remote"),
    t.array(t.string),
    OtherAccountsConfig,
]);
const QRL_EXTENDED_SEED_REGEX = /^0x[0-9a-fA-F]{102}$/;
const HARDHAT_QRLVM_BALANCE_REGEX = /^(0x[0-9a-fA-F]+|[0-9]+)$/;
const HttpHeaders = t.record(t.string, t.string, "httpHeaders");
const HttpNetworkConfig = t.type({
    chainId: optional(t.number),
    from: optional(t.string),
    gas: optional(t.union([t.literal("auto"), t.number])),
    gasPrice: optional(t.union([t.literal("auto"), t.number])),
    gasMultiplier: optional(t.number),
    consoleLog: optional(t.boolean),
    url: optional(t.string),
    accounts: optional(NetworkConfigAccounts),
    httpHeaders: optional(HttpHeaders),
});
const HardhatQrlvmAccountConfig = t.type({
    address: t.string,
    balance: optional(t.union([t.string, t.number])),
    seed: optional(t.string),
    nonce: optional(t.number),
});
const HardhatQrlvmNetworkConfig = t.type({
    chainId: optional(t.number),
    from: optional(t.string),
    gas: optional(t.union([t.literal("auto"), t.number])),
    gasPrice: optional(t.union([t.literal("auto"), t.number])),
    gasMultiplier: optional(t.number),
    accounts: optional(t.array(HardhatQrlvmAccountConfig)),
    automine: optional(t.boolean),
    loggingEnabled: optional(t.boolean),
    consoleLog: optional(t.boolean),
    blockGasLimit: optional(t.number),
    initialDate: optional(t.string),
    throwOnTransactionFailures: optional(t.boolean),
    throwOnCallFailures: optional(t.boolean),
    allowUnlimitedContractSize: optional(t.boolean),
    stackTraces: optional(t.boolean),
    qrlJsMonorepoPath: optional(t.string),
});
const NetworkConfig = t.union([HttpNetworkConfig, HardhatQrlvmNetworkConfig]);
const Networks = t.record(t.string, NetworkConfig);
const ProjectPaths = t.type({
    root: optional(t.string),
    cache: optional(t.string),
    artifacts: optional(t.string),
    sources: optional(t.string),
    tests: optional(t.string),
});
const HyperionOptimizerConfig = t.type({
    enabled: optional(t.boolean),
    runs: optional(t.number),
});
const HyperionConfig = t.type({
    version: optional(t.string),
    compilerPath: optional(t.string),
    compilerRepositoryUrl: optional(t.string),
    optimizer: optional(HyperionOptimizerConfig),
});
const HardhatConfig = t.type({
    defaultNetwork: optional(t.string),
    networks: optional(Networks),
    paths: optional(ProjectPaths),
    hyperion: optional(HyperionConfig),
}, "HardhatConfig");
/**
 * Validates the config, throwing a HardhatError if invalid.
 * @param config
 */
function validateConfig(config) {
    const errors = getValidationErrors(config);
    if (errors.length === 0) {
        return;
    }
    let errorList = errors.join("\n  * ");
    errorList = `  * ${errorList}`;
    throw new errors_1.HardhatError(errors_list_1.ERRORS.GENERAL.INVALID_CONFIG, { errors: errorList });
}
exports.validateConfig = validateConfig;
function getValidationErrors(config) {
    const errors = [];
    // These can't be validated with io-ts
    if (config !== undefined && typeof config.networks === "object") {
        for (const [networkName, netConfig] of Object.entries(config.networks)) {
            if (networkName === constants_1.HARDHAT_QRLVM_NETWORK_NAME) {
                if (netConfig.url !== undefined) {
                    errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.url`, netConfig.url, "undefined"));
                }
                if (netConfig.accounts !== undefined) {
                    if (!Array.isArray(netConfig.accounts)) {
                        errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.accounts`, netConfig.accounts, "Hardhat QRLVM account array"));
                    }
                    else {
                        for (const [accountIndex, account,] of netConfig.accounts.entries()) {
                            if (account === undefined ||
                                account === null ||
                                typeof account !== "object") {
                                errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.accounts.${accountIndex}`, account, "Hardhat QRLVM account"));
                                continue;
                            }
                            if (typeof account.address !== "string" ||
                                !address_1.isValidQrlAddress(account.address)) {
                                errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.accounts.${accountIndex}.address`, account.address, "64-byte QRL address"));
                            }
                            if (account.balance !== undefined &&
                                ((typeof account.balance !== "string" &&
                                    typeof account.balance !== "number") ||
                                    (typeof account.balance === "string" &&
                                        !HARDHAT_QRLVM_BALANCE_REGEX.test(account.balance)) ||
                                    (typeof account.balance === "number" &&
                                        (!Number.isSafeInteger(account.balance) ||
                                            account.balance < 0)))) {
                                errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.accounts.${accountIndex}.balance`, account.balance, "non-negative integer balance"));
                            }
                            if (account.seed !== undefined &&
                                (typeof account.seed !== "string" ||
                                    !QRL_EXTENDED_SEED_REGEX.test(account.seed))) {
                                errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.accounts.${accountIndex}.seed`, account.seed, "51-byte QRL extended seed hex string"));
                            }
                            if (account.nonce !== undefined &&
                                (!Number.isSafeInteger(account.nonce) || account.nonce < 0)) {
                                errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.accounts.${accountIndex}.nonce`, account.nonce, "non-negative safe integer"));
                            }
                        }
                    }
                }
                if (typeof netConfig.from === "string" &&
                    !address_1.isValidQrlAddress(netConfig.from)) {
                    errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.from`, netConfig.from, "64-byte QRL address"));
                }
                continue;
            }
            if (typeof netConfig.url !== "string") {
                errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.url`, netConfig.url, "string"));
            }
            const netConfigResult = HttpNetworkConfig.decode(netConfig);
            if (netConfigResult.isLeft()) {
                errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}`, netConfig, "HttpNetworkConfig"));
            }
            if (Array.isArray(netConfig.accounts)) {
                for (const [accountIndex, account] of netConfig.accounts.entries()) {
                    if (typeof account === "string" &&
                        !QRL_EXTENDED_SEED_REGEX.test(account)) {
                        errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.accounts.${accountIndex}`, account, "51-byte QRL extended seed hex string"));
                    }
                }
            }
            if (typeof netConfig.from === "string" &&
                !address_1.isValidQrlAddress(netConfig.from)) {
                errors.push(getErrorMessage(`HardhatConfig.networks.${networkName}.from`, netConfig.from, "64-byte QRL address"));
            }
        }
    }
    // io-ts can get confused by unsupported legacy network configs and report
    // noisy HTTPConfig errors. Return the clearer QRL-only error instead.
    if (errors.length > 0) {
        return errors;
    }
    const result = HardhatConfig.decode(config);
    if (result.isRight()) {
        return errors;
    }
    const ioTsErrors = exports.DotPathReporter.report(result);
    return [...errors, ...ioTsErrors];
}
exports.getValidationErrors = getValidationErrors;
//# sourceMappingURL=config-validation.js.map