export declare const ERROR_PREFIX = "BDLR";
export interface ErrorDescriptor {
    number: number;
    message: string;
    title: string;
    description: string;
}
export declare function getErrorCode(error: ErrorDescriptor): string;
export declare const ERROR_RANGES: {
    GENERAL: {
        min: number;
        max: number;
        title: string;
    };
    NETWORK: {
        min: number;
        max: number;
        title: string;
    };
    TASK_DEFINITIONS: {
        min: number;
        max: number;
        title: string;
    };
    ARGUMENTS: {
        min: number;
        max: number;
        title: string;
    };
    RESOLVER: {
        min: number;
        max: number;
        title: string;
    };
    BUILTIN_TASKS: {
        min: number;
        max: number;
        title: string;
    };
    ARTIFACTS: {
        min: number;
        max: number;
        title: string;
    };
    PLUGINS: {
        min: number;
        max: number;
        title: string;
    };
    INTERNAL: {
        min: number;
        max: number;
        title: string;
    };
};
export declare const ERRORS: {
    [category in keyof typeof ERROR_RANGES]: {
        [errorName: string]: ErrorDescriptor;
    };
};
//# sourceMappingURL=errors-list.d.ts.map