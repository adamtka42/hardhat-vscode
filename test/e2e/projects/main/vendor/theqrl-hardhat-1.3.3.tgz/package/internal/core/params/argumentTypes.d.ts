/**
 * Provides an interface for every valid task argument type.
 */
export interface ArgumentType<T> {
    /**
     * Type's name.
     */
    name: string;
    /**
     * Parses strValue. This function MUST throw BDLR301 if it
     * can parse the given value.
     *
     * @param argName argument's name - used for context in case of error.
     * @param strValue argument's string value to be parsed.
     *
     * @throws BDLR301 if an invalid value is given.
     * @returns the parsed value.
     */
    parse(argName: string, strValue: string): T;
    /**
     * Check if argument value is of type <T>. Optional method.
     *
     * @param argName {string} argument's name - used for context in case of error.
     * @param argumentValue - value to be validated
     *
     * @throws BDLR301 if value is not of type <t>
     */
    validate?(argName: string, argumentValue: any): void;
}
/**
 * String type.
 *
 * Accepts any kind of string.
 */
export declare const string: ArgumentType<string>;
/**
 * Boolean type.
 *
 * Accepts only 'true' or 'false' (case-insensitive).
 * @throws BDLR301
 */
export declare const boolean: ArgumentType<boolean>;
/**
 * Int type.
 * Accepts either a decimal string integer or hexadecimal string integer.
 * @throws BDLR301
 */
export declare const int: ArgumentType<number>;
/**
 * Float type.
 * Accepts either a decimal string number or hexadecimal string number.
 * @throws BDLR301
 */
export declare const float: ArgumentType<number>;
/**
 * Input file type.
 * Accepts a path to a readable file..
 * @throws BDLR302
 */
export declare const inputFile: ArgumentType<string>;
export declare const json: ArgumentType<any>;
//# sourceMappingURL=argumentTypes.d.ts.map