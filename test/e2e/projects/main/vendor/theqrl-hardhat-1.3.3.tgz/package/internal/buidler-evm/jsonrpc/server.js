"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const debug_1 = __importDefault(require("debug"));
const http_1 = __importDefault(require("http"));
const ws_1 = require("ws");
const http_2 = require("../../core/providers/http");
const handler_1 = __importDefault(require("./handler"));
const log = debug_1.default("buidler:core:qrl:jsonrpc");
class JsonRpcServer {
    constructor(config) {
        this.getProvider = (name = "json-rpc") => {
            const { address, port } = this._httpServer.address();
            return new http_2.HttpProvider(`http://${formatHost(address)}:${port}/`, name);
        };
        this.listen = () => {
            return new Promise((resolve, reject) => {
                log(`Starting JSON-RPC server on port ${this._config.port}`);
                // Bind failures (e.g. EADDRINUSE) are emitted as server errors and
                // must reject instead of leaving the promise pending forever. The
                // shared WebSocket server RE-EMITS them, so it needs a handler too —
                // otherwise Node crashes with an unhandled 'error' event.
                this._httpServer.once("error", reject);
                this._wsServer.once("error", reject);
                this._httpServer.listen(this._config.port, this._config.hostname, () => {
                    this._httpServer.removeListener("error", reject);
                    this._wsServer.removeListener("error", reject);
                    // Post-startup errors must never crash the node process.
                    this._httpServer.on("error", (error) => log(`http server error: ${error.message}`));
                    this._wsServer.on("error", (error) => log(`ws server error: ${error.message}`));
                    // The actual address and port come from the server itself to
                    // support random port allocation with port `0`.
                    const { address, port } = this._httpServer.address();
                    resolve({ address: formatHost(address), port });
                });
            });
        };
        this.waitUntilClosed = async () => {
            const httpServerClosed = new Promise((resolve) => {
                this._httpServer.once("close", resolve);
            });
            const wsServerClosed = new Promise((resolve) => {
                this._wsServer.once("close", resolve);
            });
            return Promise.all([httpServerClosed, wsServerClosed]);
        };
        this.close = async () => {
            return Promise.all([
                new Promise((resolve, reject) => {
                    log("Closing JSON-RPC server");
                    this._httpServer.close((err) => {
                        if (err !== null && err !== undefined) {
                            log("Failed to close JSON-RPC server");
                            reject(err);
                            return;
                        }
                        log("JSON-RPC server closed");
                        resolve(undefined);
                    });
                }),
                new Promise((resolve, reject) => {
                    log("Closing websocket server");
                    this._wsServer.close((err) => {
                        if (err !== null && err !== undefined) {
                            log("Failed to close websocket server");
                            reject(err);
                            return;
                        }
                        log("Websocket server closed");
                        resolve(undefined);
                    });
                }),
            ]);
        };
        this._config = config;
        const handler = new handler_1.default(config.provider);
        this._httpServer = http_1.default.createServer();
        this._wsServer = new ws_1.Server({
            server: this._httpServer,
        });
        this._httpServer.on("request", handler.handleHttp);
        this._wsServer.on("connection", handler.handleWs);
    }
}
exports.JsonRpcServer = JsonRpcServer;
/** Brackets IPv6 addresses so they are valid inside URLs. */
function formatHost(address) {
    return address.includes(":") ? `[${address}]` : address;
}
exports.formatHost = formatHost;
//# sourceMappingURL=server.js.map