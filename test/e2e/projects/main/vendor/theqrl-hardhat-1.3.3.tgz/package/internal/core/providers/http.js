"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const jsonrpc_1 = require("../../util/jsonrpc");
const errors_1 = require("../errors");
const errors_list_1 = require("../errors-list");
function isErrorResponse(response) {
    return typeof response.error !== "undefined";
}
class HttpProvider extends events_1.EventEmitter {
    constructor(_url, _networkName, _extraHeaders = {}, _timeout = 20000) {
        super();
        this._url = _url;
        this._networkName = _networkName;
        this._extraHeaders = _extraHeaders;
        this._timeout = _timeout;
        this._nextRequestId = 1;
    }
    async send(method, params) {
        // We create the error here to capture the stack traces at this point,
        // the async call that follows would probably loose of the stack trace
        const error = new Error();
        const jsonRpcRequest = this._getJsonRpcRequest(method, params);
        const jsonRpcResponse = await this._fetchJsonRpcResponse(jsonRpcRequest);
        if (isErrorResponse(jsonRpcResponse)) {
            error.message = jsonRpcResponse.error.message;
            error.code = jsonRpcResponse.error.code;
            error.data = jsonRpcResponse.error.data;
            // tslint:disable-next-line only-hardhat-error
            throw error;
        }
        return jsonRpcResponse.result;
    }
    async _fetchJsonRpcResponse(request) {
        const { default: fetch } = await Promise.resolve().then(() => __importStar(require("node-fetch")));
        try {
            const response = await fetch(this._url, {
                method: "POST",
                body: JSON.stringify(request),
                redirect: "follow",
                timeout: this._timeout,
                headers: Object.assign({ "Content-Type": "application/json" }, this._extraHeaders),
            });
            return jsonrpc_1.parseJsonResponse(await response.text());
        }
        catch (error) {
            if (error.code === "ECONNREFUSED") {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.NODE_IS_NOT_RUNNING, { network: this._networkName }, error);
            }
            if (error.type === "request-timeout") {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.NETWORK_TIMEOUT, {}, error);
            }
            // tslint:disable-next-line only-hardhat-error
            throw error;
        }
    }
    _getJsonRpcRequest(method, params = []) {
        return {
            jsonrpc: "2.0",
            method,
            params,
            id: this._nextRequestId++,
        };
    }
}
exports.HttpProvider = HttpProvider;
//# sourceMappingURL=http.js.map