/**
 * This module defines different Hardhat execution modes and autodetects them.
 *
 * IMPORTANT: This will have to be revisited once Yarn PnP and npm's tink get
 * widely adopted.
 */
export declare enum ExecutionMode {
    EXECUTION_MODE_TS_NODE_TESTS = 0,
    EXECUTION_MODE_LINKED = 1,
    EXECUTION_MODE_GLOBAL_INSTALLATION = 2,
    EXECUTION_MODE_LOCAL_INSTALLATION = 3
}
export declare function getExecutionMode(): ExecutionMode;
//# sourceMappingURL=execution-mode.d.ts.map