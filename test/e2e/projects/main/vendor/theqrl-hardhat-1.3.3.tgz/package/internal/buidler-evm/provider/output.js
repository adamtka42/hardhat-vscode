"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// tslint:disable only-hardhat-error
function numberToRpcQuantity(n) {
    const normalized = typeof n === "number" ? global.BigInt(n) : n;
    if (normalized < global.BigInt(0)) {
        throw new Error("QRL quantity cannot be negative");
    }
    return `0x${normalized.toString(16)}`;
}
exports.numberToRpcQuantity = numberToRpcQuantity;
function bufferToRpcData(buffer, pad = 0) {
    let value = `0x${Buffer.from(buffer).toString("hex")}`;
    if (pad > 0 && value.length < pad + 2) {
        value = `0x${"0".repeat(pad + 2 - value.length)}${value.slice(2)}`;
    }
    return value;
}
exports.bufferToRpcData = bufferToRpcData;
function getRpcBlock(block, includeTransactions = true) {
    return {
        hash: bufferToRpcData(block.hash()),
        parentHash: bufferToRpcData(block.header.parentHash),
        number: numberToRpcQuantity(block.header.number),
        timestamp: numberToRpcQuantity(block.header.timestamp),
        gasLimit: numberToRpcQuantity(block.header.gasLimit),
        gasUsed: numberToRpcQuantity(block.header.gasUsed),
        baseFeePerGas: numberToRpcQuantity(block.header.baseFee),
        miner: block.header.coinbase.toString(),
        stateRoot: bufferToRpcData(block.header.stateRoot),
        transactionsRoot: bufferToRpcData(block.header.transactionsRoot),
        receiptsRoot: bufferToRpcData(block.header.receiptsRoot),
        logsBloom: bufferToRpcData(block.header.logsBloom),
        transactions: includeTransactions
            ? block.transactions.map((tx, index) => {
                var _a;
                return getRpcTransaction(tx, block, index, false, (_a = block.receipts[index]) === null || _a === void 0 ? void 0 : _a.from);
            })
            : block.transactions.map((tx) => bufferToRpcData(tx.hash())),
        receipts: block.receipts.map((receipt) => getRpcTransactionReceipt(receipt)),
    };
}
exports.getRpcBlock = getRpcBlock;
function getRpcTransaction(tx, block, index, txHashOnly = false, from) {
    var _a;
    if (txHashOnly) {
        return bufferToRpcData(tx.hash());
    }
    return {
        hash: bufferToRpcData(tx.hash()),
        type: numberToRpcQuantity(tx.type),
        chainId: numberToRpcQuantity(tx.chainId),
        nonce: numberToRpcQuantity(tx.nonce),
        from: from === null || from === void 0 ? void 0 : from.toString(),
        to: (_a = tx.to) === null || _a === void 0 ? void 0 : _a.toString(),
        gas: numberToRpcQuantity(tx.gasLimit),
        gasLimit: numberToRpcQuantity(tx.gasLimit),
        gasFeeCap: numberToRpcQuantity(tx.gasFeeCap),
        gasTipCap: numberToRpcQuantity(tx.gasTipCap),
        maxFeePerGas: numberToRpcQuantity(tx.gasFeeCap),
        maxPriorityFeePerGas: numberToRpcQuantity(tx.gasTipCap),
        value: numberToRpcQuantity(tx.value),
        input: bufferToRpcData(tx.data),
        data: bufferToRpcData(tx.data),
        blockHash: block === undefined ? undefined : bufferToRpcData(block.hash()),
        blockNumber: block === undefined
            ? undefined
            : numberToRpcQuantity(block.header.number),
        transactionIndex: index === undefined ? undefined : numberToRpcQuantity(index),
    };
}
exports.getRpcTransaction = getRpcTransaction;
function getRpcTransactionReceipt(receipt) {
    var _a, _b;
    return {
        transactionHash: bufferToRpcData(receipt.txHash),
        blockHash: receipt.blockHash === undefined
            ? undefined
            : bufferToRpcData(receipt.blockHash),
        blockNumber: receipt.blockNumber === undefined
            ? undefined
            : numberToRpcQuantity(receipt.blockNumber),
        transactionIndex: receipt.transactionIndex === undefined
            ? undefined
            : numberToRpcQuantity(receipt.transactionIndex),
        from: receipt.from.toString(),
        to: (_a = receipt.to) === null || _a === void 0 ? void 0 : _a.toString(),
        contractAddress: (_b = receipt.createdAddress) === null || _b === void 0 ? void 0 : _b.toString(),
        status: numberToRpcQuantity(receipt.status),
        gasUsed: numberToRpcQuantity(receipt.gasUsed),
        cumulativeGasUsed: numberToRpcQuantity(receipt.cumulativeGasUsed),
        effectiveGasPrice: receipt.effectiveGasPrice === undefined
            ? undefined
            : numberToRpcQuantity(receipt.effectiveGasPrice),
        logsBloom: bufferToRpcData(receipt.logsBloom),
        logs: receipt.logs.map((log) => getRpcLog(log)),
    };
}
exports.getRpcTransactionReceipt = getRpcTransactionReceipt;
function getRpcLog(log) {
    return {
        address: log.address.toString(),
        topics: log.topics.map((topic) => bufferToRpcData(topic)),
        data: bufferToRpcData(log.data),
        blockNumber: log.blockNumber === undefined
            ? undefined
            : numberToRpcQuantity(log.blockNumber),
        transactionHash: log.txHash === undefined ? undefined : bufferToRpcData(log.txHash),
        transactionIndex: log.txIndex === undefined ? undefined : numberToRpcQuantity(log.txIndex),
        blockHash: log.blockHash === undefined ? undefined : bufferToRpcData(log.blockHash),
        logIndex: log.index === undefined ? undefined : numberToRpcQuantity(log.index),
        removed: log.removed,
    };
}
exports.getRpcLog = getRpcLog;
function getRpcDebugTrace(result, steps, opcodeName) {
    return {
        gas: Number(result.gasUsed),
        failed: result.failed,
        returnValue: Buffer.from(result.returnValue).toString("hex"),
        structLogs: steps.map((step) => {
            const output = {
                pc: step.pc,
                op: opcodeName(step.opcode),
                gas: Number(step.gasLeft),
                gasCost: Number(step.gasCost),
                depth: step.depth + 1,
            };
            if (step.stack !== undefined) {
                output.stack = step.stack.map((value) => `0x${value.toString(16)}`);
            }
            if (step.memory !== undefined) {
                output.memory = getRpcTraceMemory(step.memory);
            }
            return output;
        }),
    };
}
exports.getRpcDebugTrace = getRpcDebugTrace;
function getRpcTraceMemory(memory) {
    const words = [];
    for (let offset = 0; offset < memory.length; offset += 64) {
        words.push(Buffer.from(memory.slice(offset, offset + 64))
            .toString("hex")
            .padEnd(128, "0"));
    }
    return words;
}
//# sourceMappingURL=output.js.map