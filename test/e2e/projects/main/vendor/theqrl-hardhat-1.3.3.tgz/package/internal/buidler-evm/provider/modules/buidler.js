"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const errors_1 = require("../errors");
const input_1 = require("../input");
// tslint:disable only-hardhat-error
class BuidlerModule {
    constructor(_node) {
        this._node = _node;
    }
    async processRequest(method, params = []) {
        switch (method) {
            case "qrl_getStackTraceFailuresCount":
                return this._getStackTraceFailuresCountAction(...this._getStackTraceFailuresCountParams(params));
        }
        throw new errors_1.MethodNotFoundError(`Method ${method} not found`);
    }
    // qrl_getStackTraceFailuresCount
    _getStackTraceFailuresCountParams(params) {
        return input_1.validateParams(params);
    }
    async _getStackTraceFailuresCountAction() {
        return this._node.getStackTraceFailuresCount();
    }
}
exports.BuidlerModule = BuidlerModule;
//# sourceMappingURL=buidler.js.map