"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = __importDefault(require("path"));
const runtime_1 = require("../../buidler-evm/provider/runtime");
const address_1 = require("../../qrl/address");
const errors_1 = require("../errors");
const errors_list_1 = require("../errors-list");
const provider_utils_1 = require("./provider-utils");
const wrapper_1 = require("./wrapper");
const ML_DSA_87_DESCRIPTOR = new Uint8Array([0x01, 0x00, 0x00]);
const EMPTY_EXTRA_PARAMS = new Uint8Array();
const HEX_DATA_REGEX = /^(0x)?[0-9a-fA-F]*$/;
function createLocalAccountsProvider(provider, extendedSeeds) {
    const seeds = [...extendedSeeds];
    const addresses = seeds.map(address_1.qrlAddressFromSeed);
    const getChainId = provider_utils_1.createChainIdGetter(provider);
    function getSeed(address) {
        for (let i = 0; i < addresses.length; i++) {
            if (addresses[i].toLowerCase() === address.toLowerCase()) {
                return seeds[i];
            }
        }
    }
    return wrapper_1.wrapSend(provider, async (method, params) => {
        if (method === "qrl_accounts" || method === "qrl_requestAccounts") {
            return [...addresses];
        }
        if (method === "qrl_sign") {
            const [address, data] = params;
            if (address !== undefined) {
                validateTransactionAddress(address);
                if (data === undefined) {
                    throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.QRLSIGN_MISSING_DATA_PARAM);
                }
                validateHexData(data);
                const seed = getSeed(address);
                if (seed === undefined) {
                    throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.NOT_LOCAL_ACCOUNT, {
                        account: address,
                    });
                }
                return signQrlMessage(data, seed);
            }
        }
        if (method === "qrl_sendTransaction" && params.length > 0) {
            const tx = params[0];
            if (tx.gas === undefined && tx.gasLimit === undefined) {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.MISSING_TX_PARAM_TO_SIGN_LOCALLY, { param: "gas" });
            }
            if (tx.maxFeePerGas === undefined && tx.gasPrice === undefined) {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.MISSING_TX_PARAM_TO_SIGN_LOCALLY, { param: "maxFeePerGas" });
            }
            if (tx.maxPriorityFeePerGas === undefined && tx.gasPrice === undefined) {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.MISSING_TX_PARAM_TO_SIGN_LOCALLY, { param: "maxPriorityFeePerGas" });
            }
            validateTransactionAddress(tx.from);
            validateTransactionAddress(tx.to);
            if (tx.from === undefined) {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.MISSING_TX_PARAM_TO_SIGN_LOCALLY, { param: "from" });
            }
            if (tx.nonce === undefined) {
                tx.nonce = await provider.send("qrl_getTransactionCount", [
                    tx.from,
                    "pending",
                ]);
            }
            const seed = getSeed(tx.from);
            if (seed === undefined) {
                throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.NOT_LOCAL_ACCOUNT, {
                    account: tx.from,
                });
            }
            const chainId = await getChainId();
            const rawTransaction = await getSignedTransaction(tx, chainId, seed);
            return provider.send("qrl_sendRawTransaction", [rawTransaction]);
        }
        return provider.send(method, params);
    });
}
exports.createLocalAccountsProvider = createLocalAccountsProvider;
function createSenderProvider(provider, from) {
    let addresses = from === undefined ? undefined : [address_1.normalizeQrlAddress(from)];
    return wrapper_1.wrapSend(provider, async (method, params) => {
        if (method === "qrl_sendTransaction" ||
            method === "qrl_call" ||
            method === "qrl_estimateGas") {
            const tx = params[0];
            if (tx !== undefined && tx.from === undefined) {
                const [senderAccount] = await getAccounts();
                if (senderAccount !== undefined) {
                    tx.from = senderAccount;
                }
                else if (method === "qrl_sendTransaction") {
                    throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.NO_REMOTE_ACCOUNT_AVAILABLE);
                }
            }
            if (tx !== undefined) {
                validateTransactionAddress(tx.from);
                validateTransactionAddress(tx.to);
            }
        }
        return provider.send(method, params);
    });
    async function getAccounts() {
        if (addresses !== undefined) {
            return addresses;
        }
        addresses = (await provider.send("qrl_accounts")).map(address_1.normalizeQrlAddress);
        return addresses;
    }
}
exports.createSenderProvider = createSenderProvider;
function validateTransactionAddress(address) {
    if (address !== undefined && !address_1.isValidQrlAddress(address)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ADDRESS, { address });
    }
}
function validateHexData(value) {
    if (typeof value !== "string" || !HEX_DATA_REGEX.test(value)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_HEX_DATA, { value });
    }
    const normalized = value.startsWith("0x") || value.startsWith("0X") ? value.slice(2) : value;
    if (normalized.length % 2 !== 0) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_HEX_DATA, { value });
    }
}
async function getSignedTransaction(tx, chainId, seed) {
    const transaction = createQrlDynamicFeeTransaction(tx, chainId);
    if (isQrlJsTransaction(transaction)) {
        return signQrlJsTransaction(transaction, seed);
    }
    const { signTransaction } = require("@theqrl/web3-qrl-accounts");
    const signed = await signTransaction(transaction, seed);
    return signed.rawTransaction;
}
function createQrlDynamicFeeTransaction(tx, chainId) {
    var _a, _b, _c, _d, _e;
    const data = (_a = tx.data) !== null && _a !== void 0 ? _a : "0x";
    validateHexData(data);
    const qrlJsTransaction = createQrlJsDynamicFeeTransaction(tx, chainId, data);
    if (qrlJsTransaction !== undefined) {
        return qrlJsTransaction;
    }
    const { FeeMarketEIP1559Transaction } = require("@theqrl/web3-qrl-accounts");
    const to = tx.to === undefined ? undefined : address_1.qrlAddressToBytes(tx.to);
    return FeeMarketEIP1559Transaction.fromTxData({
        type: "0x2",
        chainId: (_b = tx.chainId) !== null && _b !== void 0 ? _b : chainId,
        nonce: tx.nonce,
        gasLimit: (_c = tx.gasLimit) !== null && _c !== void 0 ? _c : tx.gas,
        maxFeePerGas: (_d = tx.maxFeePerGas) !== null && _d !== void 0 ? _d : tx.gasPrice,
        maxPriorityFeePerGas: (_e = tx.maxPriorityFeePerGas) !== null && _e !== void 0 ? _e : tx.gasPrice,
        to,
        value: tx.value,
        data,
        accessList: [],
    });
}
function createQrlJsDynamicFeeTransaction(tx, chainId, data) {
    var _a, _b, _c, _d, _e;
    const txQrl = runtime_1.loadQrlJsTxRuntime();
    if (txQrl === undefined) {
        return undefined;
    }
    return new txQrl.QRLDynamicFeeTransaction({
        chainId: toBigInt((_a = tx.chainId) !== null && _a !== void 0 ? _a : chainId),
        nonce: toBigInt(tx.nonce),
        gasLimit: toBigInt((_b = tx.gasLimit) !== null && _b !== void 0 ? _b : tx.gas),
        gasFeeCap: toBigInt((_c = tx.maxFeePerGas) !== null && _c !== void 0 ? _c : tx.gasPrice),
        gasTipCap: toBigInt((_d = tx.maxPriorityFeePerGas) !== null && _d !== void 0 ? _d : tx.gasPrice),
        to: tx.to,
        value: toBigInt((_e = tx.value) !== null && _e !== void 0 ? _e : 0),
        data: hexDataToBytes(data),
        descriptor: ML_DSA_87_DESCRIPTOR,
        extraParams: EMPTY_EXTRA_PARAMS,
    });
}
function isQrlJsTransaction(transaction) {
    return (transaction !== undefined &&
        typeof transaction.serialize === "function" &&
        typeof transaction.getMessageToSign === "function" &&
        typeof transaction._processAuthValues !== "function");
}
function signQrlJsTransaction(transaction, seed) {
    const wallet = newQrlWalletFromSeed(seed);
    const signature = wallet.sign(transaction.getMessageToSign());
    return serializeQrlJsSignedTransaction(transaction, signature, wallet.getPK());
}
function serializeQrlJsSignedTransaction(transaction, signature, publicKey) {
    const signed = new transaction.constructor({
        chainId: transaction.chainId,
        nonce: transaction.nonce,
        gasLimit: transaction.gasLimit,
        gasFeeCap: transaction.gasFeeCap,
        gasTipCap: transaction.gasTipCap,
        to: transaction.to,
        value: transaction.value,
        data: transaction.data,
        accessList: transaction.accessList,
        descriptor: ML_DSA_87_DESCRIPTOR,
        extraParams: EMPTY_EXTRA_PARAMS,
        signature,
        publicKey,
    });
    return `0x${Buffer.from(signed.serialize()).toString("hex")}`;
}
function newQrlWalletFromSeed(seed) {
    const accountsEntry = require.resolve("@theqrl/web3-qrl-accounts");
    const { newMLDSA87WalletFromExtendedSeed } = require(path_1.default.join(path_1.default.dirname(accountsEntry), "qrl_wallet.js"));
    return newMLDSA87WalletFromExtendedSeed(hexDataToBytes(seed));
}
function toBigInt(value) {
    if (value === undefined) {
        return global.BigInt(0);
    }
    return global.BigInt(value);
}
function hexDataToBytes(value) {
    const normalized = value.startsWith("0x") || value.startsWith("0X") ? value.slice(2) : value;
    return Uint8Array.from(Buffer.from(normalized, "hex"));
}
function seedToQrlAccount(seed) {
    const { seedToAccount } = require("@theqrl/web3-qrl-accounts");
    return seedToAccount(seed);
}
function signQrlMessage(data, seed) {
    return seedToQrlAccount(seed).sign(data).signature;
}
//# sourceMappingURL=accounts.js.map