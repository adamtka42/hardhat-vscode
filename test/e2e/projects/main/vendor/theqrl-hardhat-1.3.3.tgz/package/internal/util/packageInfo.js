"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const find_up_1 = __importDefault(require("find-up"));
const fs_extra_1 = __importDefault(require("fs-extra"));
const path_1 = __importDefault(require("path"));
async function getPackageJsonPath() {
    return findClosestPackageJson(__filename);
}
async function getPackageRoot() {
    const packageJsonPath = await getPackageJsonPath();
    return path_1.default.dirname(packageJsonPath);
}
exports.getPackageRoot = getPackageRoot;
function findClosestPackageJson(file) {
    return find_up_1.default.sync("package.json", { cwd: path_1.default.dirname(file) });
}
async function getPackageJson() {
    const root = await getPackageRoot();
    return fs_extra_1.default.readJSON(path_1.default.join(root, "package.json"));
}
exports.getPackageJson = getPackageJson;
//# sourceMappingURL=packageInfo.js.map