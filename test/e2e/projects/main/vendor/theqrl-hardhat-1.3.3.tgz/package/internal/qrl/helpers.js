"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const artifacts_1 = require("../artifacts");
const errors_1 = require("../core/errors");
const errors_list_1 = require("../core/errors-list");
const provider_utils_1 = require("../core/providers/provider-utils");
const abi_1 = require("./abi");
const address_1 = require("./address");
const linking_1 = require("./linking");
const DEFAULT_POLL_INTERVAL_MS = 1000;
const DEFAULT_TIMEOUT_MS = 120000;
const HEX_DATA_REGEX = /^(0x)?[0-9a-fA-F]*$/;
/**
 * Wrapper fields that must never be shadowed by a direct ABI method alias.
 * Includes deployment metadata fields attached by the contract factory so
 * that ABI functions with realistic names like `hash()` or `receipt()`
 * cannot overwrite them. Colliding functions stay reachable through the
 * `functions`/`callStatic`/`send` maps and full-signature entries.
 */
const RESERVED_QRL_CONTRACT_PROPERTIES = new Set([
    "address",
    "artifact",
    "contractName",
    "deployTransactionHash",
    "deployReceipt",
    "hash",
    "receipt",
    "deployed",
    "waitForDeployment",
    "then",
    "catch",
    "finally",
    "functions",
    "callStatic",
    "send",
    "call",
    "sendTransaction",
    "callFunction",
    "sendFunction",
    "encodeFunctionData",
    "decodeFunctionResult",
    "decodeEventLog",
    "decodeReceiptLogs",
]);
const DIRECT_ALIAS_OVERRIDE_KEYS = new Set([
    "from",
    "gas",
    "gasLimit",
    "gasPrice",
    "maxFeePerGas",
    "maxPriorityFeePerGas",
    "value",
    "nonce",
    "chainId",
]);
function createQrlRuntimeHelpers(bre) {
    async function readQrlArtifact(contractName) {
        return artifacts_1.readArtifact(bre.config.paths.artifacts, contractName);
    }
    async function getContractFactory(contractName, options = {}) {
        const artifact = await readQrlArtifact(contractName);
        // The factory holds already-linked bytecode, so `deploy` needs no
        // library handling of its own.
        const linkedArtifact = options.libraries !== undefined
            ? Object.assign(Object.assign({}, artifact), { bytecode: linking_1.linkQrlBytecode(artifact, options.libraries) }) : artifact;
        return {
            contractName,
            artifact,
            bytecode: linkedArtifact.bytecode,
            deploy: async (tx = {}, constructorDataOrArgs = "0x", waitOptions = {}) => {
                assertFactoryDeployArguments(tx, constructorDataOrArgs);
                const resolvedTx = await resolveDefaultSender(tx);
                const deployment = await deployArtifact(linkedArtifact, resolvedTx, constructorDataOrArgs, waitOptions);
                const contract = getContractFromArtifact(artifact, deployment.address, call, sendTransaction, waitForTransaction, resolveDefaultSender);
                attachDeploymentMetadata(contract, deployment);
                return contract;
            },
            attach: (address) => getContractFromArtifact(artifact, address, call, sendTransaction, waitForTransaction, resolveDefaultSender),
        };
    }
    async function getContractAt(contractName, address) {
        const artifact = await readQrlArtifact(contractName);
        return getContractFromArtifact(artifact, address, call, sendTransaction, waitForTransaction, resolveDefaultSender);
    }
    async function sendTransaction(tx) {
        const rpcTransaction = Object.assign({}, tx);
        provider_utils_1.normalizeQrlTransactionQuantities(rpcTransaction);
        return bre.network.provider.send("qrl_sendTransaction", [rpcTransaction]);
    }
    /**
     * Resolves the sender for transactions sent through the ergonomic contract
     * helpers (direct method aliases and `factory.deploy()`). Resolution order:
     * explicit `tx.from`, the network's `from` config field, and finally the
     * first account returned by `qrl_accounts`. The explicit helpers
     * (`sendTransaction`, `functions.*`, `send.*`, `deployContract`) keep their
     * original validation and are not affected.
     */
    async function resolveDefaultSender(tx) {
        var _a, _b, _c, _d;
        if (tx.from !== undefined) {
            return tx;
        }
        const configFrom = (_b = (_a = bre.network) === null || _a === void 0 ? void 0 : _a.config) === null || _b === void 0 ? void 0 : _b.from;
        if (typeof configFrom === "string" && configFrom !== "") {
            return Object.assign(Object.assign({}, tx), { from: configFrom });
        }
        let accounts;
        try {
            accounts = await bre.network.provider.send("qrl_accounts");
        }
        catch (_e) {
            accounts = undefined;
        }
        if (Array.isArray(accounts) && accounts.length > 0) {
            return Object.assign(Object.assign({}, tx), { from: accounts[0] });
        }
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.MISSING_QRL_SENDER, {
            network: (_d = (_c = bre.network) === null || _c === void 0 ? void 0 : _c.name) !== null && _d !== void 0 ? _d : "unknown",
        });
    }
    async function call(tx, blockTag = "latest") {
        const rpcTransaction = Object.assign({}, tx);
        provider_utils_1.normalizeQrlTransactionQuantities(rpcTransaction);
        return bre.network.provider.send("qrl_call", [rpcTransaction, blockTag]);
    }
    async function waitForTransaction(txHash, timeoutMs = DEFAULT_TIMEOUT_MS, pollIntervalMs = DEFAULT_POLL_INTERVAL_MS) {
        const startedAt = Date.now();
        while (Date.now() - startedAt <= timeoutMs) {
            const receipt = await bre.network.provider.send("qrl_getTransactionReceipt", [txHash]);
            if (receipt !== null && receipt !== undefined) {
                assertReceiptMatchesTransaction(receipt, txHash);
                return receipt;
            }
            await sleep(pollIntervalMs);
        }
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.NETWORK_TIMEOUT);
    }
    async function deployContract(contractName, tx = {}, constructorDataOrArgs = "0x", deployOptions = {}) {
        const artifact = await readQrlArtifact(contractName);
        const linkedArtifact = deployOptions.libraries !== undefined
            ? Object.assign(Object.assign({}, artifact), { bytecode: linking_1.linkQrlBytecode(artifact, deployOptions.libraries) }) : artifact;
        return deployArtifact(linkedArtifact, tx, constructorDataOrArgs, deployOptions);
    }
    async function deployArtifact(artifact, tx = {}, constructorDataOrArgs = "0x", waitOptions = {}) {
        linking_1.assertDeployableBytecode(artifact, artifact.bytecode);
        const constructorData = Array.isArray(constructorDataOrArgs)
            ? abi_1.encodeQrlConstructorArgs(artifact.abi, constructorDataOrArgs)
            : constructorDataOrArgs;
        const data = joinHexData(artifact.bytecode, constructorData);
        const hash = await sendTransaction(Object.assign(Object.assign({}, tx), { data }));
        const receipt = await waitForTransaction(hash, waitOptions.timeoutMs, waitOptions.pollIntervalMs);
        if (isFailedReceipt(receipt)) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.DEPLOYMENT_FAILED, {
                status: receipt.status,
                txHash: hash,
            });
        }
        if (receipt.contractAddress === undefined ||
            receipt.contractAddress === null) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.MISSING_CONTRACT_ADDRESS, {
                txHash: hash,
            });
        }
        const contractAddress = address_1.normalizeQrlAddress(receipt.contractAddress);
        return {
            hash,
            receipt,
            address: contractAddress,
        };
    }
    return {
        call,
        deployContract,
        getContractAt,
        getContractFactory,
        readArtifact: readQrlArtifact,
        sendTransaction,
        waitForTransaction,
    };
}
exports.createQrlRuntimeHelpers = createQrlRuntimeHelpers;
/**
 * Wraps a transaction hash in a response object with a `wait()` helper that
 * polls for the mined receipt. Building block for the ergonomic contract API;
 * not part of the documented `hre.qrl` surface.
 */
function createTransactionResponse(hash, waitForTransaction) {
    return {
        hash,
        wait: (timeoutMs, pollIntervalMs) => waitForTransaction(hash, timeoutMs, pollIntervalMs),
    };
}
exports.createTransactionResponse = createTransactionResponse;
/**
 * Sends a transaction and returns a `QrlTransactionResponse` instead of a raw
 * hash string. Internal sender variant used by direct contract method
 * aliases; the public `sendTransaction` helper is unchanged.
 */
async function sendTransactionWithResponse(sendTransaction, waitForTransaction, tx) {
    const hash = await sendTransaction(tx);
    return createTransactionResponse(hash, waitForTransaction);
}
exports.sendTransactionWithResponse = sendTransactionWithResponse;
function isFailedReceipt(receipt) {
    return (receipt.status === false || receipt.status === "0x0" || receipt.status === 0);
}
function assertReceiptMatchesTransaction(receipt, txHash) {
    if (receipt.transactionHash === undefined ||
        receipt.transactionHash === null) {
        return;
    }
    if (String(receipt.transactionHash).toLowerCase() !== txHash.toLowerCase()) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.TRANSACTION_RECEIPT_MISMATCH, {
            actual: receipt.transactionHash,
            expected: txHash,
        });
    }
}
function getContractFromArtifact(artifact, address, call, sendTransaction, waitForTransaction, resolveSender) {
    const contractAddress = address_1.normalizeQrlAddress(address);
    const callFunction = async (functionName, args = [], tx = {}, blockTag) => {
        const data = abi_1.encodeQrlFunctionData(artifact.abi, functionName, args);
        const result = await call(Object.assign(Object.assign({}, tx), { to: contractAddress, data }), blockTag);
        return abi_1.decodeQrlFunctionResult(artifact.abi, functionName, result);
    };
    const sendFunction = (functionName, args = [], tx = {}) => {
        const data = abi_1.encodeQrlFunctionData(artifact.abi, functionName, args);
        return sendTransaction(Object.assign(Object.assign({}, tx), { to: contractAddress, data }));
    };
    const functionMaps = createContractFunctionMaps(artifact, callFunction, sendFunction);
    const contract = {
        address: contractAddress,
        artifact,
        contractName: artifact.contractName,
        callStatic: functionMaps.callStatic,
        encodeFunctionData: (functionName, args = []) => abi_1.encodeQrlFunctionData(artifact.abi, functionName, args),
        decodeFunctionResult: (functionName, data) => abi_1.decodeQrlFunctionResult(artifact.abi, functionName, data),
        decodeEventLog: (eventName, log) => abi_1.decodeQrlEventLog(artifact.abi, eventName, log),
        decodeReceiptLogs: (receipt) => abi_1.decodeQrlReceiptLogs(artifact.abi, contractAddress, receipt),
        callFunction,
        functions: functionMaps.functions,
        send: functionMaps.send,
        sendFunction,
        call: (data, tx = {}, blockTag) => {
            assertHexData(data);
            return call(Object.assign(Object.assign({}, tx), { to: contractAddress, data }), blockTag);
        },
        sendTransaction: (data, tx = {}) => {
            assertHexData(data);
            return sendTransaction(Object.assign(Object.assign({}, tx), { to: contractAddress, data }));
        },
    };
    addDirectFunctionAliases(contract, artifact, callFunction, sendFunction, waitForTransaction, resolveSender);
    return contract;
}
/**
 * Guards the QRL factory deploy argument order. The QRL signature is
 * `deploy(txOverrides?, constructorArgsOrData?, waitOptions?)` — a deliberate
 * decision to avoid the ambiguity of ethers-style
 * `deploy(...args, overrides)` with object/tuple constructor arguments.
 * Without this guard, an ethers-style call like `deploy("Hello", { from })`
 * would silently spread the string into a garbage transaction object.
 */
function assertFactoryDeployArguments(tx, constructorDataOrArgs) {
    if (tx === null || typeof tx !== "object" || Array.isArray(tx)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ABI, {
            message: `Factory deploy() expects transaction overrides as its first argument and constructor arguments as its second, e.g. deploy({ from }, [constructorArg1, constructorArg2])`,
        });
    }
    if (typeof constructorDataOrArgs !== "string" &&
        !Array.isArray(constructorDataOrArgs)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ABI, {
            message: `Factory deploy() expects constructor arguments as an array (or raw hex data string) in its second argument, e.g. deploy({ from }, [constructorArg1])`,
        });
    }
}
/**
 * Attaches deployment metadata to a contract wrapper returned by
 * `factory.deploy()`. The `hash` and `receipt` fields are transitional
 * aliases for `deployTransactionHash`/`deployReceipt` so existing code
 * destructuring the old `QrlDeploymentResult` shape keeps working; they are
 * deprecated and scheduled for removal in the next major version.
 *
 * `deployed()` and `waitForDeployment()` resolve immediately because
 * `deployContract()` already waits for the mined receipt and validates the
 * deployment status and contract address.
 */
function attachDeploymentMetadata(contract, deployment) {
    const writable = contract;
    writable.deployTransactionHash = deployment.hash;
    writable.deployReceipt = deployment.receipt;
    writable.hash = deployment.hash;
    writable.receipt = deployment.receipt;
    writable.deployed = async () => contract;
    writable.waitForDeployment = async () => contract;
}
/**
 * Attaches ergonomic direct method aliases (`contract.foo(...)`) for
 * unambiguous ABI functions:
 * - `view`/`pure` functions perform a call; a single output is unwrapped to
 *   a scalar, zero or multiple outputs return the decoded result array;
 * - state-changing functions send a transaction and return a
 *   `QrlTransactionResponse` with a receipt-polling `wait()`.
 *
 * Overloaded names and names colliding with reserved wrapper fields are
 * skipped; those functions stay reachable through the `functions`,
 * `callStatic`, and `send` maps.
 */
function addDirectFunctionAliases(contract, artifact, callFunction, sendFunction, waitForTransaction, resolveSender) {
    const fragments = getFunctionFragments(artifact.abi);
    const functionNameCounts = countFunctionNames(fragments);
    for (const fragment of fragments) {
        const name = fragment.name;
        if (name === undefined) {
            continue;
        }
        if (functionNameCounts[name] !== 1) {
            continue;
        }
        if (RESERVED_QRL_CONTRACT_PROPERTIES.has(name) || name in contract) {
            continue;
        }
        const signature = abi_1.getFunctionSignature(fragment);
        if (isReadOnlyFunction(fragment)) {
            contract[name] = async (...args) => {
                var _a, _b;
                const parsed = parseDirectAliasArgs(fragment, args);
                const decoded = await callFunction(signature, parsed.abiArgs, parsed.tx);
                return ((_b = (_a = fragment.outputs) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0) === 1 ? decoded[0] : decoded;
            };
        }
        else {
            contract[name] = async (...args) => {
                const parsed = parseDirectAliasArgs(fragment, args);
                const resolvedTx = await resolveSender(parsed.tx);
                const hash = await sendFunction(signature, parsed.abiArgs, resolvedTx);
                return createTransactionResponse(hash, waitForTransaction);
            };
        }
    }
}
function parseDirectAliasArgs(fragment, args) {
    const inputCount = getInputCount(fragment);
    if (args.length === inputCount) {
        return { abiArgs: args, tx: {} };
    }
    if (args.length === inputCount + 1) {
        const overrides = args[inputCount];
        assertDirectAliasOverrides(fragment, overrides);
        return { abiArgs: args.slice(0, inputCount), tx: overrides };
    }
    throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ABI, {
        message: `Function ${fragment.name} expects ${inputCount} ABI arguments and an optional transaction overrides object, got ${args.length} arguments`,
    });
}
function assertDirectAliasOverrides(fragment, overrides) {
    if (overrides === null ||
        typeof overrides !== "object" ||
        Array.isArray(overrides)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ABI, {
            message: `Function ${fragment.name} expects a plain transaction overrides object as its final argument`,
        });
    }
    for (const key of Object.keys(overrides)) {
        if (!DIRECT_ALIAS_OVERRIDE_KEYS.has(key)) {
            throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ABI, {
                message: `Unknown transaction override "${key}" for function ${fragment.name}; allowed overrides are: ${[...DIRECT_ALIAS_OVERRIDE_KEYS].join(", ")}`,
            });
        }
    }
}
function createContractFunctionMaps(artifact, callFunction, sendFunction) {
    const callStatic = {};
    const functions = {};
    const send = {};
    const fragments = getFunctionFragments(artifact.abi);
    const functionNameCounts = countFunctionNames(fragments);
    for (const fragment of fragments) {
        if (fragment.name === undefined) {
            continue;
        }
        const signature = abi_1.getFunctionSignature(fragment);
        const names = [signature];
        if (functionNameCounts[fragment.name] === 1) {
            names.push(fragment.name);
        }
        for (const name of names) {
            callStatic[name] = (...args) => {
                const parsed = parseCallArgs(fragment, args);
                return callFunction(signature, parsed.abiArgs, parsed.tx, parsed.blockTag);
            };
            send[name] = (...args) => {
                const parsed = parseSendArgs(fragment, args);
                return sendFunction(signature, parsed.abiArgs, parsed.tx);
            };
            functions[name] = (...args) => {
                if (isReadOnlyFunction(fragment)) {
                    const callArgs = parseCallArgs(fragment, args);
                    return callFunction(signature, callArgs.abiArgs, callArgs.tx, callArgs.blockTag);
                }
                const sendArgs = parseSendArgs(fragment, args);
                return sendFunction(signature, sendArgs.abiArgs, sendArgs.tx);
            };
        }
    }
    return { callStatic, functions, send };
}
function getFunctionFragments(abi) {
    if (!Array.isArray(abi)) {
        return [];
    }
    return abi.filter((entry) => entry.type === "function" && typeof entry.name === "string");
}
function countFunctionNames(fragments) {
    var _a;
    const counts = {};
    for (const fragment of fragments) {
        if (fragment.name !== undefined) {
            counts[fragment.name] = ((_a = counts[fragment.name]) !== null && _a !== void 0 ? _a : 0) + 1;
        }
    }
    return counts;
}
function parseCallArgs(fragment, args) {
    var _a;
    const inputCount = getInputCount(fragment);
    assertFunctionArgCount(fragment, args.length, inputCount, inputCount + 2);
    return {
        abiArgs: args.slice(0, inputCount),
        blockTag: args[inputCount + 1],
        tx: (_a = args[inputCount]) !== null && _a !== void 0 ? _a : {},
    };
}
function parseSendArgs(fragment, args) {
    var _a;
    const inputCount = getInputCount(fragment);
    assertFunctionArgCount(fragment, args.length, inputCount, inputCount + 1);
    return {
        abiArgs: args.slice(0, inputCount),
        tx: (_a = args[inputCount]) !== null && _a !== void 0 ? _a : {},
    };
}
function assertFunctionArgCount(fragment, received, min, max) {
    if (received < min || received > max) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_QRL_ABI, {
            message: `Function ${fragment.name} expects ${min} ABI arguments and up to ${max - min} call options, got ${received}`,
        });
    }
}
function getInputCount(fragment) {
    var _a, _b;
    return (_b = (_a = fragment.inputs) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0;
}
function isReadOnlyFunction(fragment) {
    return (fragment.constant === true ||
        fragment.stateMutability === "view" ||
        fragment.stateMutability === "pure");
}
function joinHexData(bytecode, extraData) {
    const normalizedBytecode = normalizeHex(bytecode);
    const normalizedExtraData = normalizeHex(extraData);
    return `0x${normalizedBytecode}${normalizedExtraData}`;
}
function normalizeHex(value) {
    assertHexData(value);
    if (value === "0x" || value === "") {
        return "";
    }
    return value.startsWith("0x") || value.startsWith("0X")
        ? value.slice(2)
        : value;
}
function assertHexData(value) {
    if (!HEX_DATA_REGEX.test(value)) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_HEX_DATA, { value });
    }
    const normalized = value.startsWith("0x") || value.startsWith("0X") ? value.slice(2) : value;
    if (normalized.length % 2 !== 0) {
        throw new errors_1.HardhatError(errors_list_1.ERRORS.NETWORK.INVALID_HEX_DATA, { value });
    }
}
async function sleep(ms) {
    await new Promise((resolve) => setTimeout(resolve, ms));
}
//# sourceMappingURL=helpers.js.map