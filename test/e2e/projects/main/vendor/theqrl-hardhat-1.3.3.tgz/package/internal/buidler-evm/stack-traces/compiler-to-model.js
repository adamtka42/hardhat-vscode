"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_extra_1 = __importDefault(require("fs-extra"));
const path_1 = __importDefault(require("path"));
const constants_1 = require("../../constants");
/**
 * Loads the debug information the stack trace decoder needs from the cached
 * compiler input/output JSON files. Returns `undefined` when the cache is
 * missing or unreadable — stack traces then degrade gracefully.
 */
function loadQrlDebugInfo(cachePath, projectRoot) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x;
    try {
        const output = fs_extra_1.default.readJsonSync(path_1.default.join(cachePath, constants_1.COMPILER_OUTPUT_FILENAME));
        const input = fs_extra_1.default.readJsonSync(path_1.default.join(cachePath, constants_1.COMPILER_INPUT_FILENAME));
        const contracts = [];
        const fallbackCompilerVersion = readCachedCompilerVersion(cachePath);
        for (const sourceName of Object.keys((_a = output.contracts) !== null && _a !== void 0 ? _a : {})) {
            for (const contractName of Object.keys(output.contracts[sourceName])) {
                const contractOutput = output.contracts[sourceName][contractName];
                const bytecodeOutput = (_b = contractOutput.bytecodeOutput) !== null && _b !== void 0 ? _b : {};
                contracts.push({
                    sourceName,
                    contractName,
                    abi: (_c = contractOutput.abi) !== null && _c !== void 0 ? _c : [],
                    contractKind: findContractKind((_e = (_d = output.sources) === null || _d === void 0 ? void 0 : _d[sourceName]) === null || _e === void 0 ? void 0 : _e.ast, contractName),
                    bytecode: (_g = (_f = bytecodeOutput.bytecode) === null || _f === void 0 ? void 0 : _f.object) !== null && _g !== void 0 ? _g : "",
                    bytecodeSourceMap: (_h = bytecodeOutput.bytecode) === null || _h === void 0 ? void 0 : _h.sourceMap,
                    deployedBytecode: (_k = (_j = bytecodeOutput.deployedBytecode) === null || _j === void 0 ? void 0 : _j.object) !== null && _k !== void 0 ? _k : "",
                    deployedSourceMap: (_l = bytecodeOutput.deployedBytecode) === null || _l === void 0 ? void 0 : _l.sourceMap,
                    linkReferences: (_o = (_m = bytecodeOutput.bytecode) === null || _m === void 0 ? void 0 : _m.linkReferences) !== null && _o !== void 0 ? _o : {},
                    deployedLinkReferences: (_q = (_p = bytecodeOutput.deployedBytecode) === null || _p === void 0 ? void 0 : _p.linkReferences) !== null && _q !== void 0 ? _q : {},
                    immutableReferences: (_s = (_r = bytecodeOutput.deployedBytecode) === null || _r === void 0 ? void 0 : _r.immutableReferences) !== null && _s !== void 0 ? _s : {},
                    methodIdentifiers: (_t = contractOutput.methodIdentifiers) !== null && _t !== void 0 ? _t : {},
                    compilerVersion: (_u = readCompilerVersion(contractOutput.metadata)) !== null && _u !== void 0 ? _u : fallbackCompilerVersion,
                });
            }
        }
        const sourceContent = new Map();
        for (const sourceName of Object.keys((_v = input.sources) !== null && _v !== void 0 ? _v : {})) {
            const content = (_w = input.sources[sourceName]) === null || _w === void 0 ? void 0 : _w.content;
            if (typeof content === "string") {
                sourceContent.set(sourceName, content);
            }
        }
        const sourceNamesByIndex = new Map();
        const astBySourceName = new Map();
        for (const sourceName of Object.keys((_x = output.sources) !== null && _x !== void 0 ? _x : {})) {
            const source = output.sources[sourceName];
            if (typeof (source === null || source === void 0 ? void 0 : source.id) === "number") {
                sourceNamesByIndex.set(source.id, sourceName);
            }
            if ((source === null || source === void 0 ? void 0 : source.ast) !== undefined) {
                astBySourceName.set(sourceName, source.ast);
            }
            // Older or externally generated compiler caches may omit source
            // content. Recover it from disk so library frames still get real line
            // numbers.
            if (!sourceContent.has(sourceName) && projectRoot !== undefined) {
                const candidates = [
                    path_1.default.join(projectRoot, sourceName),
                    path_1.default.join(projectRoot, "node_modules", sourceName),
                ];
                for (const candidate of candidates) {
                    try {
                        sourceContent.set(sourceName, fs_extra_1.default.readFileSync(candidate, "utf8"));
                        break;
                    }
                    catch (_y) {
                        // Try the next candidate; missing content degrades to line 0.
                    }
                }
            }
        }
        return { contracts, sourceContent, sourceNamesByIndex, astBySourceName };
    }
    catch (_z) {
        return undefined;
    }
}
exports.loadQrlDebugInfo = loadQrlDebugInfo;
function findContractKind(ast, contractName) {
    let kind;
    visitNodes(ast, (node) => {
        if (kind === undefined &&
            node.nodeType === "ContractDefinition" &&
            node.name === contractName &&
            typeof node.contractKind === "string") {
            kind = node.contractKind;
        }
    });
    return kind;
}
function visitNodes(node, visit) {
    if (node === null || typeof node !== "object") {
        return;
    }
    if (Array.isArray(node)) {
        for (const child of node) {
            visitNodes(child, visit);
        }
        return;
    }
    visit(node);
    for (const child of Object.values(node)) {
        visitNodes(child, visit);
    }
}
function readCachedCompilerVersion(cachePath) {
    var _a, _b;
    try {
        const config = fs_extra_1.default.readJsonSync(path_1.default.join(cachePath, "last-compiler-config.json"));
        if (typeof ((_a = config === null || config === void 0 ? void 0 : config.compiler) === null || _a === void 0 ? void 0 : _a.longVersion) === "string") {
            return config.compiler.longVersion;
        }
        const configured = (_b = config === null || config === void 0 ? void 0 : config.hyperion) === null || _b === void 0 ? void 0 : _b.version;
        return typeof configured === "string" && configured !== "local"
            ? configured
            : undefined;
    }
    catch (_c) {
        return undefined;
    }
}
function readCompilerVersion(metadata) {
    var _a;
    if (typeof metadata !== "string") {
        return undefined;
    }
    try {
        const parsed = JSON.parse(metadata);
        return typeof ((_a = parsed === null || parsed === void 0 ? void 0 : parsed.compiler) === null || _a === void 0 ? void 0 : _a.version) === "string"
            ? parsed.compiler.version
            : undefined;
    }
    catch (_b) {
        return undefined;
    }
}
//# sourceMappingURL=compiler-to-model.js.map