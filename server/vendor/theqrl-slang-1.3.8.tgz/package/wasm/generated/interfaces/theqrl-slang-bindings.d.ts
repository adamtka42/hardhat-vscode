// This file is generated automatically by infrastructure scripts. Please don't edit by hand.

export namespace TheqrlSlangBindings {
  export { BindingGraph };
  export { Definition };
  export { Reference };
  export { UserFileLocation };
  export { BuiltInLocation };
  export { BindingLocation };
  export { BindingLocationType };
}
import type { Cursor } from "./theqrl-slang-cst.js";
export { Cursor };
/**
 * A `BindingLocation` is used to point the user to a definition or reference in the parse tree.
 * A `BindingLocation` can either be a `UserFile` or a `BuiltIn`. Only `UserFile`'s give the user
 * a `Cursor` into a location in the parse tree.
 */
export type BindingLocation = UserFileLocation | BuiltInLocation;

/**
 * Enumerates different variants of the `BindingLocation` type.
 */
export enum BindingLocationType {
  /**
   * Represents a variant of type `UserFileLocation`.
   */
  UserFileLocation = "UserFileLocation",

  /**
   * Represents a variant of type `BuiltInLocation`.
   */
  BuiltInLocation = "BuiltInLocation",
}

/**
 * A graph that contains name binding information for all source files within the compilation unit.
 * It stores cursors to all definitions and references, and can resolve the edges between them.
 *
 * Most cursors pointing to identifier terminals will resolve to either a definition or a reference.
 * For example, in `contract A is B {}`, the cursor to identifier `A` will resolve to a definition,
 * and the cursor to identifier `B` will resolve to a reference.
 *
 * However, in some cases, cursors to identifiers can resolve to both at the same time.
 * For example, in `import {X} from "library"`, the cursor to identifier `X` will resolve to a
 * definition (the local import), and also to a reference (to the symbol exported from `"library"`).
 *
 * This graph is error-tolerant, and will return `undefined` for any identifiers that cannot be resolved.
 * For example, when there are syntactic/semantic errors, or missing source files.
 *
 * For more information on identifier terminals, see the `TerminalKindExtensions.isIdentifier()` API.
 */

export class BindingGraph {
  /**
   * This type does not have a public constructor.
   */
  private constructor();
  /**
   * Tries to resolve the identifier terminal pointed at by the provided cursor to a definition.
   * If successful, returns the definition. Otherwise, returns `undefined`.
   *
   * For more information on identifier terminals, see the `TerminalKindExtensions.isIdentifier()` API.
   */
  definitionAt(cursor: Cursor): Definition | undefined;
  /**
   * Tries to resolve the identifier terminal pointed at by the provided cursor to a reference.
   * If successful, returns the reference. Otherwise, returns `undefined`.
   *
   * For more information on identifier terminals, see the `TerminalKindExtensions.isIdentifier()` API.
   */
  referenceAt(cursor: Cursor): Reference | undefined;
}

/**
 * Represents a location of a built-in symbol in the language.
 */

export class BuiltInLocation {
  /**
   * This type does not have a public constructor.
   */
  private constructor();

  /**
   * The variant of `BindingLocationType` that corresponds to this class.
   */
  readonly type = BindingLocationType.BuiltInLocation;

  /**
   * Coerce this variant to a `BuiltInLocation`, or `undefined` if this is not the correct type.
   */
  asBuiltInLocation(): this;

  /**
   * Return `true` if this object is an instance of `BuiltInLocation`.
   */
  isBuiltInLocation(): this is BuiltInLocation;

  /**
   * Coerce this variant to a `UserFileLocation`, or `undefined` if this is not the correct type.
   */
  asUserFileLocation(): undefined;

  /**
   * Return `true` if this object is an instance of `UserFileLocation`.
   */
  isUserFileLocation(): false;
}

/**
 * A `Definition` represents the location where a symbol is originally defined. From this you
 * can find more information about the location of this definition in the parse tree, or navigate to
 * references to this defintion.
 */

export class Definition {
  /**
   * This type does not have a public constructor.
   */
  private constructor();
  /**
   * Returns a unique numerical identifier of the definition.
   * It is only valid for the lifetime of the binding graph.
   * It can change between multiple graphs, even for the same source code input.
   */
  get id(): number;
  /**
   * Returns the location of the definition's name.
   * For `contract X {}`, that is the location of the `X` `Identifier` node.
   */
  get nameLocation(): BindingLocation;
  /**
   * Returns the location of the definition's definiens.
   * For `contract X {}`, that is the location of the parent `ContractDefinition` node.
   */
  get definiensLocation(): BindingLocation;
  /**
   * Returns a list of all references that bind to this definition.
   */
  references(): Array<Reference>;
}

/**
 * A `Reference` represents a location where a symbol definition is referenced, i.e. anywhere
 * a symbol is 'used' in a piece of code. From this you can find more information about the location
 * of the reference in the parse tree, or you can navigate to the `Definition` this
 * references.
 *
 * Note that most references have a single definition, but some have multiple, such as when a symbol
 * is imported from another file, and renamed (re-defined) in the current file.
 */

export class Reference {
  /**
   * This type does not have a public constructor.
   */
  private constructor();
  /**
   * Returns a unique numerical identifier of the reference.
   * It is only valid for the lifetime of the binding graph.
   * It can change between multiple graphs, even for the same source code input.
   */
  get id(): number;
  /**
   * Returns the location of the reference.
   * For `new X()`, that is the location of the `X` `Identifier` node.
   */
  get location(): BindingLocation;
  /**
   * Returns a list of all definitions related to this reference.
   * Most references have a single definition, but some have multiple, such as when a symbol
   * is imported from another file, and renamed (re-defined) in the current file.
   */
  definitions(): Array<Definition>;
}

/**
 * `UserFileLocation` provides a `Cursor` pointing to a `Node` in the
 * parse tree where the referenced `Definition` or `Reference` is located.
 */

export class UserFileLocation {
  /**
   * This type does not have a public constructor.
   */
  private constructor();

  /**
   * The variant of `BindingLocationType` that corresponds to this class.
   */
  readonly type = BindingLocationType.UserFileLocation;

  /**
   * Coerce this variant to a `UserFileLocation`, or `undefined` if this is not the correct type.
   */
  asUserFileLocation(): this;

  /**
   * Return `true` if this object is an instance of `UserFileLocation`.
   */
  isUserFileLocation(): this is UserFileLocation;

  /**
   * Coerce this variant to a `BuiltInLocation`, or `undefined` if this is not the correct type.
   */
  asBuiltInLocation(): undefined;

  /**
   * Return `true` if this object is an instance of `BuiltInLocation`.
   */
  isBuiltInLocation(): false;

  /**
   * Returns the ID of the file that contains the symbol.
   */
  get fileId(): string;
  /**
   * Returns a cursor to the CST node that contains the symbol.
   */
  get cursor(): Cursor;
}
