// @ts-nocheck

import { environment, exit as exit$1, stderr, stdin, stdout } from '@bytecodealliance/preview2-shim/cli';
import { preopens, types } from '@bytecodealliance/preview2-shim/filesystem';
import { error, streams } from '@bytecodealliance/preview2-shim/io';
import { random } from '@bytecodealliance/preview2-shim/random';
const { getEnvironment } = environment;
const { exit } = exit$1;
const { getStderr } = stderr;
const { getStdin } = stdin;
const { getStdout } = stdout;
const { getDirectories } = preopens;
const { Descriptor,
  filesystemErrorCode } = types;
const { Error: Error$1 } = error;
const { InputStream,
  OutputStream } = streams;
const { getRandomBytes } = random;

let curResourceBorrows = [];

let dv = new DataView(new ArrayBuffer());
const dataView = mem => dv.buffer === mem.buffer ? dv : dv = new DataView(mem.buffer);

const emptyFunc = () => {};

const isNode = typeof process !== 'undefined' && process.versions && process.versions.node;
let _fs;
async function fetchCompile (url) {
  if (isNode) {
    _fs = _fs || await import('node:fs/promises');
    return WebAssembly.compile(await _fs.readFile(url));
  }
  return fetch(url).then(WebAssembly.compileStreaming);
}

function finalizationRegistryCreate (unregister) {
  if (typeof FinalizationRegistry === 'undefined') {
    return { unregister () {} };
  }
  return new FinalizationRegistry(unregister);
}

function getErrorPayload(e) {
  if (e && hasOwnProperty.call(e, 'payload')) return e.payload;
  if (e instanceof Error) throw e;
  return e;
}

const handleTables = [];

const hasOwnProperty = Object.prototype.hasOwnProperty;

const instantiateCore = WebAssembly.instantiate;

const T_FLAG = 1 << 30;

function rscTableCreateOwn (table, rep) {
  const free = table[0] & ~T_FLAG;
  if (free === 0) {
    table.push(0);
    table.push(rep | T_FLAG);
    return (table.length >> 1) - 1;
  }
  table[0] = table[free << 1];
  table[free << 1] = 0;
  table[(free << 1) + 1] = rep | T_FLAG;
  return free;
}

function rscTableRemove (table, handle) {
  const scope = table[handle << 1];
  const val = table[(handle << 1) + 1];
  const own = (val & T_FLAG) !== 0;
  const rep = val & ~T_FLAG;
  if (val === 0 || (scope & T_FLAG) !== 0) throw new TypeError('Invalid handle');
  table[handle << 1] = table[0] | T_FLAG;
  table[0] = handle | T_FLAG;
  return { rep, scope, own };
}

const symbolCabiDispose = Symbol.for('cabiDispose');

const symbolRscHandle = Symbol('handle');

const symbolRscRep = Symbol.for('cabiRep');

const symbolDispose = Symbol.dispose || Symbol.for('dispose');

const toUint64 = val => BigInt.asUintN(64, BigInt(val));

function toUint32(val) {
  return val >>> 0;
}

const utf8Decoder = new TextDecoder();

const utf8Encoder = new TextEncoder();

let utf8EncodedLen = 0;
function utf8Encode(s, realloc, memory) {
  if (typeof s !== 'string') throw new TypeError('expected a string');
  if (s.length === 0) {
    utf8EncodedLen = 0;
    return 1;
  }
  let buf = utf8Encoder.encode(s);
  let ptr = realloc(0, 0, 1, buf.length);
  new Uint8Array(memory.buffer).set(buf, ptr);
  utf8EncodedLen = buf.length;
  return ptr;
}

const nodeJSCustomInspectSymbol = Symbol.for("nodejs.util.inspect.custom");


let exports0;
let exports1;
const handleTable1 = [T_FLAG, 0];
const captureTable1= new Map();
let captureCnt1 = 0;
handleTables[1] = handleTable1;

function trampoline43() {
  const ret = getStderr();
  if (!(ret instanceof OutputStream)) {
    throw new TypeError('Resource error: Not a valid "OutputStream" resource.');
  }
  var handle0 = ret[symbolRscHandle];
  if (!handle0) {
    const rep = ret[symbolRscRep] || ++captureCnt1;
    captureTable1.set(rep, ret);
    handle0 = rscTableCreateOwn(handleTable1, rep);
  }
  return handle0;
}

const handleTable2 = [T_FLAG, 0];
const captureTable2= new Map();
let captureCnt2 = 0;
handleTables[2] = handleTable2;

function trampoline44() {
  const ret = getStdin();
  if (!(ret instanceof InputStream)) {
    throw new TypeError('Resource error: Not a valid "InputStream" resource.');
  }
  var handle0 = ret[symbolRscHandle];
  if (!handle0) {
    const rep = ret[symbolRscRep] || ++captureCnt2;
    captureTable2.set(rep, ret);
    handle0 = rscTableCreateOwn(handleTable2, rep);
  }
  return handle0;
}


function trampoline45() {
  const ret = getStdout();
  if (!(ret instanceof OutputStream)) {
    throw new TypeError('Resource error: Not a valid "OutputStream" resource.');
  }
  var handle0 = ret[symbolRscHandle];
  if (!handle0) {
    const rep = ret[symbolRscRep] || ++captureCnt1;
    captureTable1.set(rep, ret);
    handle0 = rscTableCreateOwn(handleTable1, rep);
  }
  return handle0;
}


function trampoline46(arg0) {
  let variant0;
  if (arg0) {
    variant0= {
      tag: 'err',
      val: undefined
    };
  } else {
    variant0= {
      tag: 'ok',
      val: undefined
    };
  }
  exit(variant0);
}

let exports2;
let memory0;
let realloc0;

function trampoline47(arg0) {
  const ret = getEnvironment();
  var vec3 = ret;
  var len3 = vec3.length;
  var result3 = realloc0(0, 0, 4, len3 * 16);
  for (let i = 0; i < vec3.length; i++) {
    const e = vec3[i];
    const base = result3 + i * 16;var [tuple0_0, tuple0_1] = e;
    var ptr1 = utf8Encode(tuple0_0, realloc0, memory0);
    var len1 = utf8EncodedLen;
    dataView(memory0).setInt32(base + 4, len1, true);
    dataView(memory0).setInt32(base + 0, ptr1, true);
    var ptr2 = utf8Encode(tuple0_1, realloc0, memory0);
    var len2 = utf8EncodedLen;
    dataView(memory0).setInt32(base + 12, len2, true);
    dataView(memory0).setInt32(base + 8, ptr2, true);
  }
  dataView(memory0).setInt32(arg0 + 4, len3, true);
  dataView(memory0).setInt32(arg0 + 0, result3, true);
}

const handleTable3 = [T_FLAG, 0];
const captureTable3= new Map();
let captureCnt3 = 0;
handleTables[3] = handleTable3;

function trampoline48(arg0, arg1, arg2) {
  var handle1 = arg0;
  var rep2 = handleTable3[(handle1 << 1) + 1] & ~T_FLAG;
  var rsc0 = captureTable3.get(rep2);
  if (!rsc0) {
    rsc0 = Object.create(Descriptor.prototype);
    Object.defineProperty(rsc0, symbolRscHandle, { writable: true, value: handle1});
    Object.defineProperty(rsc0, symbolRscRep, { writable: true, value: rep2});
  }
  curResourceBorrows.push(rsc0);
  let ret;
  try {
    ret = { tag: 'ok', val: rsc0.writeViaStream(BigInt.asUintN(64, arg1))};
  } catch (e) {
    ret = { tag: 'err', val: getErrorPayload(e) };
  }
  for (const rsc of curResourceBorrows) {
    rsc[symbolRscHandle] = undefined;
  }
  curResourceBorrows = [];
  var variant5 = ret;
  switch (variant5.tag) {
    case 'ok': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg2 + 0, 0, true);
      if (!(e instanceof OutputStream)) {
        throw new TypeError('Resource error: Not a valid "OutputStream" resource.');
      }
      var handle3 = e[symbolRscHandle];
      if (!handle3) {
        const rep = e[symbolRscRep] || ++captureCnt1;
        captureTable1.set(rep, e);
        handle3 = rscTableCreateOwn(handleTable1, rep);
      }
      dataView(memory0).setInt32(arg2 + 4, handle3, true);
      break;
    }
    case 'err': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg2 + 0, 1, true);
      var val4 = e;
      let enum4;
      switch (val4) {
        case 'access': {
          enum4 = 0;
          break;
        }
        case 'would-block': {
          enum4 = 1;
          break;
        }
        case 'already': {
          enum4 = 2;
          break;
        }
        case 'bad-descriptor': {
          enum4 = 3;
          break;
        }
        case 'busy': {
          enum4 = 4;
          break;
        }
        case 'deadlock': {
          enum4 = 5;
          break;
        }
        case 'quota': {
          enum4 = 6;
          break;
        }
        case 'exist': {
          enum4 = 7;
          break;
        }
        case 'file-too-large': {
          enum4 = 8;
          break;
        }
        case 'illegal-byte-sequence': {
          enum4 = 9;
          break;
        }
        case 'in-progress': {
          enum4 = 10;
          break;
        }
        case 'interrupted': {
          enum4 = 11;
          break;
        }
        case 'invalid': {
          enum4 = 12;
          break;
        }
        case 'io': {
          enum4 = 13;
          break;
        }
        case 'is-directory': {
          enum4 = 14;
          break;
        }
        case 'loop': {
          enum4 = 15;
          break;
        }
        case 'too-many-links': {
          enum4 = 16;
          break;
        }
        case 'message-size': {
          enum4 = 17;
          break;
        }
        case 'name-too-long': {
          enum4 = 18;
          break;
        }
        case 'no-device': {
          enum4 = 19;
          break;
        }
        case 'no-entry': {
          enum4 = 20;
          break;
        }
        case 'no-lock': {
          enum4 = 21;
          break;
        }
        case 'insufficient-memory': {
          enum4 = 22;
          break;
        }
        case 'insufficient-space': {
          enum4 = 23;
          break;
        }
        case 'not-directory': {
          enum4 = 24;
          break;
        }
        case 'not-empty': {
          enum4 = 25;
          break;
        }
        case 'not-recoverable': {
          enum4 = 26;
          break;
        }
        case 'unsupported': {
          enum4 = 27;
          break;
        }
        case 'no-tty': {
          enum4 = 28;
          break;
        }
        case 'no-such-device': {
          enum4 = 29;
          break;
        }
        case 'overflow': {
          enum4 = 30;
          break;
        }
        case 'not-permitted': {
          enum4 = 31;
          break;
        }
        case 'pipe': {
          enum4 = 32;
          break;
        }
        case 'read-only': {
          enum4 = 33;
          break;
        }
        case 'invalid-seek': {
          enum4 = 34;
          break;
        }
        case 'text-file-busy': {
          enum4 = 35;
          break;
        }
        case 'cross-device': {
          enum4 = 36;
          break;
        }
        default: {
          
          throw new TypeError(`"${val4}" is not one of the cases of error-code`);
        }
      }
      dataView(memory0).setInt8(arg2 + 4, enum4, true);
      break;
    }
    default: {
      throw new TypeError('invalid variant specified for result');
    }
  }
}


function trampoline49(arg0, arg1) {
  var handle1 = arg0;
  var rep2 = handleTable3[(handle1 << 1) + 1] & ~T_FLAG;
  var rsc0 = captureTable3.get(rep2);
  if (!rsc0) {
    rsc0 = Object.create(Descriptor.prototype);
    Object.defineProperty(rsc0, symbolRscHandle, { writable: true, value: handle1});
    Object.defineProperty(rsc0, symbolRscRep, { writable: true, value: rep2});
  }
  curResourceBorrows.push(rsc0);
  let ret;
  try {
    ret = { tag: 'ok', val: rsc0.appendViaStream()};
  } catch (e) {
    ret = { tag: 'err', val: getErrorPayload(e) };
  }
  for (const rsc of curResourceBorrows) {
    rsc[symbolRscHandle] = undefined;
  }
  curResourceBorrows = [];
  var variant5 = ret;
  switch (variant5.tag) {
    case 'ok': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg1 + 0, 0, true);
      if (!(e instanceof OutputStream)) {
        throw new TypeError('Resource error: Not a valid "OutputStream" resource.');
      }
      var handle3 = e[symbolRscHandle];
      if (!handle3) {
        const rep = e[symbolRscRep] || ++captureCnt1;
        captureTable1.set(rep, e);
        handle3 = rscTableCreateOwn(handleTable1, rep);
      }
      dataView(memory0).setInt32(arg1 + 4, handle3, true);
      break;
    }
    case 'err': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg1 + 0, 1, true);
      var val4 = e;
      let enum4;
      switch (val4) {
        case 'access': {
          enum4 = 0;
          break;
        }
        case 'would-block': {
          enum4 = 1;
          break;
        }
        case 'already': {
          enum4 = 2;
          break;
        }
        case 'bad-descriptor': {
          enum4 = 3;
          break;
        }
        case 'busy': {
          enum4 = 4;
          break;
        }
        case 'deadlock': {
          enum4 = 5;
          break;
        }
        case 'quota': {
          enum4 = 6;
          break;
        }
        case 'exist': {
          enum4 = 7;
          break;
        }
        case 'file-too-large': {
          enum4 = 8;
          break;
        }
        case 'illegal-byte-sequence': {
          enum4 = 9;
          break;
        }
        case 'in-progress': {
          enum4 = 10;
          break;
        }
        case 'interrupted': {
          enum4 = 11;
          break;
        }
        case 'invalid': {
          enum4 = 12;
          break;
        }
        case 'io': {
          enum4 = 13;
          break;
        }
        case 'is-directory': {
          enum4 = 14;
          break;
        }
        case 'loop': {
          enum4 = 15;
          break;
        }
        case 'too-many-links': {
          enum4 = 16;
          break;
        }
        case 'message-size': {
          enum4 = 17;
          break;
        }
        case 'name-too-long': {
          enum4 = 18;
          break;
        }
        case 'no-device': {
          enum4 = 19;
          break;
        }
        case 'no-entry': {
          enum4 = 20;
          break;
        }
        case 'no-lock': {
          enum4 = 21;
          break;
        }
        case 'insufficient-memory': {
          enum4 = 22;
          break;
        }
        case 'insufficient-space': {
          enum4 = 23;
          break;
        }
        case 'not-directory': {
          enum4 = 24;
          break;
        }
        case 'not-empty': {
          enum4 = 25;
          break;
        }
        case 'not-recoverable': {
          enum4 = 26;
          break;
        }
        case 'unsupported': {
          enum4 = 27;
          break;
        }
        case 'no-tty': {
          enum4 = 28;
          break;
        }
        case 'no-such-device': {
          enum4 = 29;
          break;
        }
        case 'overflow': {
          enum4 = 30;
          break;
        }
        case 'not-permitted': {
          enum4 = 31;
          break;
        }
        case 'pipe': {
          enum4 = 32;
          break;
        }
        case 'read-only': {
          enum4 = 33;
          break;
        }
        case 'invalid-seek': {
          enum4 = 34;
          break;
        }
        case 'text-file-busy': {
          enum4 = 35;
          break;
        }
        case 'cross-device': {
          enum4 = 36;
          break;
        }
        default: {
          
          throw new TypeError(`"${val4}" is not one of the cases of error-code`);
        }
      }
      dataView(memory0).setInt8(arg1 + 4, enum4, true);
      break;
    }
    default: {
      throw new TypeError('invalid variant specified for result');
    }
  }
}


function trampoline50(arg0, arg1) {
  var handle1 = arg0;
  var rep2 = handleTable3[(handle1 << 1) + 1] & ~T_FLAG;
  var rsc0 = captureTable3.get(rep2);
  if (!rsc0) {
    rsc0 = Object.create(Descriptor.prototype);
    Object.defineProperty(rsc0, symbolRscHandle, { writable: true, value: handle1});
    Object.defineProperty(rsc0, symbolRscRep, { writable: true, value: rep2});
  }
  curResourceBorrows.push(rsc0);
  let ret;
  try {
    ret = { tag: 'ok', val: rsc0.getType()};
  } catch (e) {
    ret = { tag: 'err', val: getErrorPayload(e) };
  }
  for (const rsc of curResourceBorrows) {
    rsc[symbolRscHandle] = undefined;
  }
  curResourceBorrows = [];
  var variant5 = ret;
  switch (variant5.tag) {
    case 'ok': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg1 + 0, 0, true);
      var val3 = e;
      let enum3;
      switch (val3) {
        case 'unknown': {
          enum3 = 0;
          break;
        }
        case 'block-device': {
          enum3 = 1;
          break;
        }
        case 'character-device': {
          enum3 = 2;
          break;
        }
        case 'directory': {
          enum3 = 3;
          break;
        }
        case 'fifo': {
          enum3 = 4;
          break;
        }
        case 'symbolic-link': {
          enum3 = 5;
          break;
        }
        case 'regular-file': {
          enum3 = 6;
          break;
        }
        case 'socket': {
          enum3 = 7;
          break;
        }
        default: {
          
          throw new TypeError(`"${val3}" is not one of the cases of descriptor-type`);
        }
      }
      dataView(memory0).setInt8(arg1 + 1, enum3, true);
      break;
    }
    case 'err': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg1 + 0, 1, true);
      var val4 = e;
      let enum4;
      switch (val4) {
        case 'access': {
          enum4 = 0;
          break;
        }
        case 'would-block': {
          enum4 = 1;
          break;
        }
        case 'already': {
          enum4 = 2;
          break;
        }
        case 'bad-descriptor': {
          enum4 = 3;
          break;
        }
        case 'busy': {
          enum4 = 4;
          break;
        }
        case 'deadlock': {
          enum4 = 5;
          break;
        }
        case 'quota': {
          enum4 = 6;
          break;
        }
        case 'exist': {
          enum4 = 7;
          break;
        }
        case 'file-too-large': {
          enum4 = 8;
          break;
        }
        case 'illegal-byte-sequence': {
          enum4 = 9;
          break;
        }
        case 'in-progress': {
          enum4 = 10;
          break;
        }
        case 'interrupted': {
          enum4 = 11;
          break;
        }
        case 'invalid': {
          enum4 = 12;
          break;
        }
        case 'io': {
          enum4 = 13;
          break;
        }
        case 'is-directory': {
          enum4 = 14;
          break;
        }
        case 'loop': {
          enum4 = 15;
          break;
        }
        case 'too-many-links': {
          enum4 = 16;
          break;
        }
        case 'message-size': {
          enum4 = 17;
          break;
        }
        case 'name-too-long': {
          enum4 = 18;
          break;
        }
        case 'no-device': {
          enum4 = 19;
          break;
        }
        case 'no-entry': {
          enum4 = 20;
          break;
        }
        case 'no-lock': {
          enum4 = 21;
          break;
        }
        case 'insufficient-memory': {
          enum4 = 22;
          break;
        }
        case 'insufficient-space': {
          enum4 = 23;
          break;
        }
        case 'not-directory': {
          enum4 = 24;
          break;
        }
        case 'not-empty': {
          enum4 = 25;
          break;
        }
        case 'not-recoverable': {
          enum4 = 26;
          break;
        }
        case 'unsupported': {
          enum4 = 27;
          break;
        }
        case 'no-tty': {
          enum4 = 28;
          break;
        }
        case 'no-such-device': {
          enum4 = 29;
          break;
        }
        case 'overflow': {
          enum4 = 30;
          break;
        }
        case 'not-permitted': {
          enum4 = 31;
          break;
        }
        case 'pipe': {
          enum4 = 32;
          break;
        }
        case 'read-only': {
          enum4 = 33;
          break;
        }
        case 'invalid-seek': {
          enum4 = 34;
          break;
        }
        case 'text-file-busy': {
          enum4 = 35;
          break;
        }
        case 'cross-device': {
          enum4 = 36;
          break;
        }
        default: {
          
          throw new TypeError(`"${val4}" is not one of the cases of error-code`);
        }
      }
      dataView(memory0).setInt8(arg1 + 1, enum4, true);
      break;
    }
    default: {
      throw new TypeError('invalid variant specified for result');
    }
  }
}


function trampoline51(arg0, arg1) {
  var handle1 = arg0;
  var rep2 = handleTable3[(handle1 << 1) + 1] & ~T_FLAG;
  var rsc0 = captureTable3.get(rep2);
  if (!rsc0) {
    rsc0 = Object.create(Descriptor.prototype);
    Object.defineProperty(rsc0, symbolRscHandle, { writable: true, value: handle1});
    Object.defineProperty(rsc0, symbolRscRep, { writable: true, value: rep2});
  }
  curResourceBorrows.push(rsc0);
  let ret;
  try {
    ret = { tag: 'ok', val: rsc0.stat()};
  } catch (e) {
    ret = { tag: 'err', val: getErrorPayload(e) };
  }
  for (const rsc of curResourceBorrows) {
    rsc[symbolRscHandle] = undefined;
  }
  curResourceBorrows = [];
  var variant12 = ret;
  switch (variant12.tag) {
    case 'ok': {
      const e = variant12.val;
      dataView(memory0).setInt8(arg1 + 0, 0, true);
      var {type: v3_0, linkCount: v3_1, size: v3_2, dataAccessTimestamp: v3_3, dataModificationTimestamp: v3_4, statusChangeTimestamp: v3_5 } = e;
      var val4 = v3_0;
      let enum4;
      switch (val4) {
        case 'unknown': {
          enum4 = 0;
          break;
        }
        case 'block-device': {
          enum4 = 1;
          break;
        }
        case 'character-device': {
          enum4 = 2;
          break;
        }
        case 'directory': {
          enum4 = 3;
          break;
        }
        case 'fifo': {
          enum4 = 4;
          break;
        }
        case 'symbolic-link': {
          enum4 = 5;
          break;
        }
        case 'regular-file': {
          enum4 = 6;
          break;
        }
        case 'socket': {
          enum4 = 7;
          break;
        }
        default: {
          
          throw new TypeError(`"${val4}" is not one of the cases of descriptor-type`);
        }
      }
      dataView(memory0).setInt8(arg1 + 8, enum4, true);
      dataView(memory0).setBigInt64(arg1 + 16, toUint64(v3_1), true);
      dataView(memory0).setBigInt64(arg1 + 24, toUint64(v3_2), true);
      var variant6 = v3_3;
      if (variant6 === null || variant6=== undefined) {
        dataView(memory0).setInt8(arg1 + 32, 0, true);
      } else {
        const e = variant6;
        dataView(memory0).setInt8(arg1 + 32, 1, true);
        var {seconds: v5_0, nanoseconds: v5_1 } = e;
        dataView(memory0).setBigInt64(arg1 + 40, toUint64(v5_0), true);
        dataView(memory0).setInt32(arg1 + 48, toUint32(v5_1), true);
      }
      var variant8 = v3_4;
      if (variant8 === null || variant8=== undefined) {
        dataView(memory0).setInt8(arg1 + 56, 0, true);
      } else {
        const e = variant8;
        dataView(memory0).setInt8(arg1 + 56, 1, true);
        var {seconds: v7_0, nanoseconds: v7_1 } = e;
        dataView(memory0).setBigInt64(arg1 + 64, toUint64(v7_0), true);
        dataView(memory0).setInt32(arg1 + 72, toUint32(v7_1), true);
      }
      var variant10 = v3_5;
      if (variant10 === null || variant10=== undefined) {
        dataView(memory0).setInt8(arg1 + 80, 0, true);
      } else {
        const e = variant10;
        dataView(memory0).setInt8(arg1 + 80, 1, true);
        var {seconds: v9_0, nanoseconds: v9_1 } = e;
        dataView(memory0).setBigInt64(arg1 + 88, toUint64(v9_0), true);
        dataView(memory0).setInt32(arg1 + 96, toUint32(v9_1), true);
      }
      break;
    }
    case 'err': {
      const e = variant12.val;
      dataView(memory0).setInt8(arg1 + 0, 1, true);
      var val11 = e;
      let enum11;
      switch (val11) {
        case 'access': {
          enum11 = 0;
          break;
        }
        case 'would-block': {
          enum11 = 1;
          break;
        }
        case 'already': {
          enum11 = 2;
          break;
        }
        case 'bad-descriptor': {
          enum11 = 3;
          break;
        }
        case 'busy': {
          enum11 = 4;
          break;
        }
        case 'deadlock': {
          enum11 = 5;
          break;
        }
        case 'quota': {
          enum11 = 6;
          break;
        }
        case 'exist': {
          enum11 = 7;
          break;
        }
        case 'file-too-large': {
          enum11 = 8;
          break;
        }
        case 'illegal-byte-sequence': {
          enum11 = 9;
          break;
        }
        case 'in-progress': {
          enum11 = 10;
          break;
        }
        case 'interrupted': {
          enum11 = 11;
          break;
        }
        case 'invalid': {
          enum11 = 12;
          break;
        }
        case 'io': {
          enum11 = 13;
          break;
        }
        case 'is-directory': {
          enum11 = 14;
          break;
        }
        case 'loop': {
          enum11 = 15;
          break;
        }
        case 'too-many-links': {
          enum11 = 16;
          break;
        }
        case 'message-size': {
          enum11 = 17;
          break;
        }
        case 'name-too-long': {
          enum11 = 18;
          break;
        }
        case 'no-device': {
          enum11 = 19;
          break;
        }
        case 'no-entry': {
          enum11 = 20;
          break;
        }
        case 'no-lock': {
          enum11 = 21;
          break;
        }
        case 'insufficient-memory': {
          enum11 = 22;
          break;
        }
        case 'insufficient-space': {
          enum11 = 23;
          break;
        }
        case 'not-directory': {
          enum11 = 24;
          break;
        }
        case 'not-empty': {
          enum11 = 25;
          break;
        }
        case 'not-recoverable': {
          enum11 = 26;
          break;
        }
        case 'unsupported': {
          enum11 = 27;
          break;
        }
        case 'no-tty': {
          enum11 = 28;
          break;
        }
        case 'no-such-device': {
          enum11 = 29;
          break;
        }
        case 'overflow': {
          enum11 = 30;
          break;
        }
        case 'not-permitted': {
          enum11 = 31;
          break;
        }
        case 'pipe': {
          enum11 = 32;
          break;
        }
        case 'read-only': {
          enum11 = 33;
          break;
        }
        case 'invalid-seek': {
          enum11 = 34;
          break;
        }
        case 'text-file-busy': {
          enum11 = 35;
          break;
        }
        case 'cross-device': {
          enum11 = 36;
          break;
        }
        default: {
          
          throw new TypeError(`"${val11}" is not one of the cases of error-code`);
        }
      }
      dataView(memory0).setInt8(arg1 + 8, enum11, true);
      break;
    }
    default: {
      throw new TypeError('invalid variant specified for result');
    }
  }
}

const handleTable0 = [T_FLAG, 0];
const captureTable0= new Map();
let captureCnt0 = 0;
handleTables[0] = handleTable0;

function trampoline52(arg0, arg1) {
  var handle1 = arg0;
  var rep2 = handleTable0[(handle1 << 1) + 1] & ~T_FLAG;
  var rsc0 = captureTable0.get(rep2);
  if (!rsc0) {
    rsc0 = Object.create(Error$1.prototype);
    Object.defineProperty(rsc0, symbolRscHandle, { writable: true, value: handle1});
    Object.defineProperty(rsc0, symbolRscRep, { writable: true, value: rep2});
  }
  curResourceBorrows.push(rsc0);
  const ret = filesystemErrorCode(rsc0);
  for (const rsc of curResourceBorrows) {
    rsc[symbolRscHandle] = undefined;
  }
  curResourceBorrows = [];
  var variant4 = ret;
  if (variant4 === null || variant4=== undefined) {
    dataView(memory0).setInt8(arg1 + 0, 0, true);
  } else {
    const e = variant4;
    dataView(memory0).setInt8(arg1 + 0, 1, true);
    var val3 = e;
    let enum3;
    switch (val3) {
      case 'access': {
        enum3 = 0;
        break;
      }
      case 'would-block': {
        enum3 = 1;
        break;
      }
      case 'already': {
        enum3 = 2;
        break;
      }
      case 'bad-descriptor': {
        enum3 = 3;
        break;
      }
      case 'busy': {
        enum3 = 4;
        break;
      }
      case 'deadlock': {
        enum3 = 5;
        break;
      }
      case 'quota': {
        enum3 = 6;
        break;
      }
      case 'exist': {
        enum3 = 7;
        break;
      }
      case 'file-too-large': {
        enum3 = 8;
        break;
      }
      case 'illegal-byte-sequence': {
        enum3 = 9;
        break;
      }
      case 'in-progress': {
        enum3 = 10;
        break;
      }
      case 'interrupted': {
        enum3 = 11;
        break;
      }
      case 'invalid': {
        enum3 = 12;
        break;
      }
      case 'io': {
        enum3 = 13;
        break;
      }
      case 'is-directory': {
        enum3 = 14;
        break;
      }
      case 'loop': {
        enum3 = 15;
        break;
      }
      case 'too-many-links': {
        enum3 = 16;
        break;
      }
      case 'message-size': {
        enum3 = 17;
        break;
      }
      case 'name-too-long': {
        enum3 = 18;
        break;
      }
      case 'no-device': {
        enum3 = 19;
        break;
      }
      case 'no-entry': {
        enum3 = 20;
        break;
      }
      case 'no-lock': {
        enum3 = 21;
        break;
      }
      case 'insufficient-memory': {
        enum3 = 22;
        break;
      }
      case 'insufficient-space': {
        enum3 = 23;
        break;
      }
      case 'not-directory': {
        enum3 = 24;
        break;
      }
      case 'not-empty': {
        enum3 = 25;
        break;
      }
      case 'not-recoverable': {
        enum3 = 26;
        break;
      }
      case 'unsupported': {
        enum3 = 27;
        break;
      }
      case 'no-tty': {
        enum3 = 28;
        break;
      }
      case 'no-such-device': {
        enum3 = 29;
        break;
      }
      case 'overflow': {
        enum3 = 30;
        break;
      }
      case 'not-permitted': {
        enum3 = 31;
        break;
      }
      case 'pipe': {
        enum3 = 32;
        break;
      }
      case 'read-only': {
        enum3 = 33;
        break;
      }
      case 'invalid-seek': {
        enum3 = 34;
        break;
      }
      case 'text-file-busy': {
        enum3 = 35;
        break;
      }
      case 'cross-device': {
        enum3 = 36;
        break;
      }
      default: {
        
        throw new TypeError(`"${val3}" is not one of the cases of error-code`);
      }
    }
    dataView(memory0).setInt8(arg1 + 1, enum3, true);
  }
}


function trampoline53(arg0, arg1) {
  var handle1 = arg0;
  var rep2 = handleTable1[(handle1 << 1) + 1] & ~T_FLAG;
  var rsc0 = captureTable1.get(rep2);
  if (!rsc0) {
    rsc0 = Object.create(OutputStream.prototype);
    Object.defineProperty(rsc0, symbolRscHandle, { writable: true, value: handle1});
    Object.defineProperty(rsc0, symbolRscRep, { writable: true, value: rep2});
  }
  curResourceBorrows.push(rsc0);
  let ret;
  try {
    ret = { tag: 'ok', val: rsc0.checkWrite()};
  } catch (e) {
    ret = { tag: 'err', val: getErrorPayload(e) };
  }
  for (const rsc of curResourceBorrows) {
    rsc[symbolRscHandle] = undefined;
  }
  curResourceBorrows = [];
  var variant5 = ret;
  switch (variant5.tag) {
    case 'ok': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg1 + 0, 0, true);
      dataView(memory0).setBigInt64(arg1 + 8, toUint64(e), true);
      break;
    }
    case 'err': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg1 + 0, 1, true);
      var variant4 = e;
      switch (variant4.tag) {
        case 'last-operation-failed': {
          const e = variant4.val;
          dataView(memory0).setInt8(arg1 + 8, 0, true);
          if (!(e instanceof Error$1)) {
            throw new TypeError('Resource error: Not a valid "Error" resource.');
          }
          var handle3 = e[symbolRscHandle];
          if (!handle3) {
            const rep = e[symbolRscRep] || ++captureCnt0;
            captureTable0.set(rep, e);
            handle3 = rscTableCreateOwn(handleTable0, rep);
          }
          dataView(memory0).setInt32(arg1 + 12, handle3, true);
          break;
        }
        case 'closed': {
          dataView(memory0).setInt8(arg1 + 8, 1, true);
          break;
        }
        default: {
          throw new TypeError(`invalid variant tag value \`${JSON.stringify(variant4.tag)}\` (received \`${variant4}\`) specified for \`StreamError\``);
        }
      }
      break;
    }
    default: {
      throw new TypeError('invalid variant specified for result');
    }
  }
}


function trampoline54(arg0, arg1, arg2, arg3) {
  var handle1 = arg0;
  var rep2 = handleTable1[(handle1 << 1) + 1] & ~T_FLAG;
  var rsc0 = captureTable1.get(rep2);
  if (!rsc0) {
    rsc0 = Object.create(OutputStream.prototype);
    Object.defineProperty(rsc0, symbolRscHandle, { writable: true, value: handle1});
    Object.defineProperty(rsc0, symbolRscRep, { writable: true, value: rep2});
  }
  curResourceBorrows.push(rsc0);
  var ptr3 = arg1;
  var len3 = arg2;
  var result3 = new Uint8Array(memory0.buffer.slice(ptr3, ptr3 + len3 * 1));
  let ret;
  try {
    ret = { tag: 'ok', val: rsc0.write(result3)};
  } catch (e) {
    ret = { tag: 'err', val: getErrorPayload(e) };
  }
  for (const rsc of curResourceBorrows) {
    rsc[symbolRscHandle] = undefined;
  }
  curResourceBorrows = [];
  var variant6 = ret;
  switch (variant6.tag) {
    case 'ok': {
      const e = variant6.val;
      dataView(memory0).setInt8(arg3 + 0, 0, true);
      break;
    }
    case 'err': {
      const e = variant6.val;
      dataView(memory0).setInt8(arg3 + 0, 1, true);
      var variant5 = e;
      switch (variant5.tag) {
        case 'last-operation-failed': {
          const e = variant5.val;
          dataView(memory0).setInt8(arg3 + 4, 0, true);
          if (!(e instanceof Error$1)) {
            throw new TypeError('Resource error: Not a valid "Error" resource.');
          }
          var handle4 = e[symbolRscHandle];
          if (!handle4) {
            const rep = e[symbolRscRep] || ++captureCnt0;
            captureTable0.set(rep, e);
            handle4 = rscTableCreateOwn(handleTable0, rep);
          }
          dataView(memory0).setInt32(arg3 + 8, handle4, true);
          break;
        }
        case 'closed': {
          dataView(memory0).setInt8(arg3 + 4, 1, true);
          break;
        }
        default: {
          throw new TypeError(`invalid variant tag value \`${JSON.stringify(variant5.tag)}\` (received \`${variant5}\`) specified for \`StreamError\``);
        }
      }
      break;
    }
    default: {
      throw new TypeError('invalid variant specified for result');
    }
  }
}


function trampoline55(arg0, arg1, arg2, arg3) {
  var handle1 = arg0;
  var rep2 = handleTable1[(handle1 << 1) + 1] & ~T_FLAG;
  var rsc0 = captureTable1.get(rep2);
  if (!rsc0) {
    rsc0 = Object.create(OutputStream.prototype);
    Object.defineProperty(rsc0, symbolRscHandle, { writable: true, value: handle1});
    Object.defineProperty(rsc0, symbolRscRep, { writable: true, value: rep2});
  }
  curResourceBorrows.push(rsc0);
  var ptr3 = arg1;
  var len3 = arg2;
  var result3 = new Uint8Array(memory0.buffer.slice(ptr3, ptr3 + len3 * 1));
  let ret;
  try {
    ret = { tag: 'ok', val: rsc0.blockingWriteAndFlush(result3)};
  } catch (e) {
    ret = { tag: 'err', val: getErrorPayload(e) };
  }
  for (const rsc of curResourceBorrows) {
    rsc[symbolRscHandle] = undefined;
  }
  curResourceBorrows = [];
  var variant6 = ret;
  switch (variant6.tag) {
    case 'ok': {
      const e = variant6.val;
      dataView(memory0).setInt8(arg3 + 0, 0, true);
      break;
    }
    case 'err': {
      const e = variant6.val;
      dataView(memory0).setInt8(arg3 + 0, 1, true);
      var variant5 = e;
      switch (variant5.tag) {
        case 'last-operation-failed': {
          const e = variant5.val;
          dataView(memory0).setInt8(arg3 + 4, 0, true);
          if (!(e instanceof Error$1)) {
            throw new TypeError('Resource error: Not a valid "Error" resource.');
          }
          var handle4 = e[symbolRscHandle];
          if (!handle4) {
            const rep = e[symbolRscRep] || ++captureCnt0;
            captureTable0.set(rep, e);
            handle4 = rscTableCreateOwn(handleTable0, rep);
          }
          dataView(memory0).setInt32(arg3 + 8, handle4, true);
          break;
        }
        case 'closed': {
          dataView(memory0).setInt8(arg3 + 4, 1, true);
          break;
        }
        default: {
          throw new TypeError(`invalid variant tag value \`${JSON.stringify(variant5.tag)}\` (received \`${variant5}\`) specified for \`StreamError\``);
        }
      }
      break;
    }
    default: {
      throw new TypeError('invalid variant specified for result');
    }
  }
}


function trampoline56(arg0, arg1) {
  var handle1 = arg0;
  var rep2 = handleTable1[(handle1 << 1) + 1] & ~T_FLAG;
  var rsc0 = captureTable1.get(rep2);
  if (!rsc0) {
    rsc0 = Object.create(OutputStream.prototype);
    Object.defineProperty(rsc0, symbolRscHandle, { writable: true, value: handle1});
    Object.defineProperty(rsc0, symbolRscRep, { writable: true, value: rep2});
  }
  curResourceBorrows.push(rsc0);
  let ret;
  try {
    ret = { tag: 'ok', val: rsc0.blockingFlush()};
  } catch (e) {
    ret = { tag: 'err', val: getErrorPayload(e) };
  }
  for (const rsc of curResourceBorrows) {
    rsc[symbolRscHandle] = undefined;
  }
  curResourceBorrows = [];
  var variant5 = ret;
  switch (variant5.tag) {
    case 'ok': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg1 + 0, 0, true);
      break;
    }
    case 'err': {
      const e = variant5.val;
      dataView(memory0).setInt8(arg1 + 0, 1, true);
      var variant4 = e;
      switch (variant4.tag) {
        case 'last-operation-failed': {
          const e = variant4.val;
          dataView(memory0).setInt8(arg1 + 4, 0, true);
          if (!(e instanceof Error$1)) {
            throw new TypeError('Resource error: Not a valid "Error" resource.');
          }
          var handle3 = e[symbolRscHandle];
          if (!handle3) {
            const rep = e[symbolRscRep] || ++captureCnt0;
            captureTable0.set(rep, e);
            handle3 = rscTableCreateOwn(handleTable0, rep);
          }
          dataView(memory0).setInt32(arg1 + 8, handle3, true);
          break;
        }
        case 'closed': {
          dataView(memory0).setInt8(arg1 + 4, 1, true);
          break;
        }
        default: {
          throw new TypeError(`invalid variant tag value \`${JSON.stringify(variant4.tag)}\` (received \`${variant4}\`) specified for \`StreamError\``);
        }
      }
      break;
    }
    default: {
      throw new TypeError('invalid variant specified for result');
    }
  }
}


function trampoline57(arg0, arg1) {
  const ret = getRandomBytes(BigInt.asUintN(64, arg0));
  var val0 = ret;
  var len0 = val0.byteLength;
  var ptr0 = realloc0(0, 0, 1, len0 * 1);
  var src0 = new Uint8Array(val0.buffer || val0, val0.byteOffset, len0 * 1);
  (new Uint8Array(memory0.buffer, ptr0, len0 * 1)).set(src0);
  dataView(memory0).setInt32(arg1 + 4, len0, true);
  dataView(memory0).setInt32(arg1 + 0, ptr0, true);
}


function trampoline58(arg0) {
  const ret = getDirectories();
  var vec3 = ret;
  var len3 = vec3.length;
  var result3 = realloc0(0, 0, 4, len3 * 12);
  for (let i = 0; i < vec3.length; i++) {
    const e = vec3[i];
    const base = result3 + i * 12;var [tuple0_0, tuple0_1] = e;
    if (!(tuple0_0 instanceof Descriptor)) {
      throw new TypeError('Resource error: Not a valid "Descriptor" resource.');
    }
    var handle1 = tuple0_0[symbolRscHandle];
    if (!handle1) {
      const rep = tuple0_0[symbolRscRep] || ++captureCnt3;
      captureTable3.set(rep, tuple0_0);
      handle1 = rscTableCreateOwn(handleTable3, rep);
    }
    dataView(memory0).setInt32(base + 0, handle1, true);
    var ptr2 = utf8Encode(tuple0_1, realloc0, memory0);
    var len2 = utf8EncodedLen;
    dataView(memory0).setInt32(base + 8, len2, true);
    dataView(memory0).setInt32(base + 4, ptr2, true);
  }
  dataView(memory0).setInt32(arg0 + 4, len3, true);
  dataView(memory0).setInt32(arg0 + 0, result3, true);
}

let exports3;
let realloc1;
let postReturn0;
let postReturn1;
let postReturn2;
let postReturn3;
let postReturn4;
let postReturn5;
let postReturn6;
let postReturn7;
let postReturn8;
let postReturn9;
let postReturn10;
let postReturn11;
let postReturn12;
let postReturn13;
let postReturn14;
let postReturn15;
let postReturn16;
let postReturn17;
let postReturn18;
let postReturn19;
let postReturn20;
let postReturn21;
let postReturn22;
let postReturn23;
let postReturn24;
let postReturn25;
let postReturn26;
let postReturn27;
let postReturn28;
let postReturn29;
let cstStaticTerminalKindExtensionsIsIdentifier;

class TerminalKindExtensions{
  constructor () {
    throw new Error('"TerminalKindExtensions" resource does not define a constructor');
  }
}

TerminalKindExtensions.isIdentifier = function isIdentifier(arg0) {
  const ret = cstStaticTerminalKindExtensionsIsIdentifier(terminalKindCABI[arg0]);
  var bool0 = ret;
  return !!bool0;
};
let cstStaticTerminalKindExtensionsIsTrivia;

TerminalKindExtensions.isTrivia = function isTrivia(arg0) {
  const ret = cstStaticTerminalKindExtensionsIsTrivia(terminalKindCABI[arg0]);
  var bool0 = ret;
  return !!bool0;
};
let cstStaticTerminalKindExtensionsIsValid;

TerminalKindExtensions.isValid = function isValid(arg0) {
  const ret = cstStaticTerminalKindExtensionsIsValid(terminalKindCABI[arg0]);
  var bool0 = ret;
  return !!bool0;
};
const handleTable6 = [T_FLAG, 0];
const finalizationRegistry6 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable6, handle);
  exports0['20'](rep);
});

handleTables[6] = handleTable6;
const handleTable4 = [T_FLAG, 0];
const finalizationRegistry4 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable4, handle);
  exports0['18'](rep);
});

handleTables[4] = handleTable4;
let cstStaticNonterminalNodeCreate;

class NonterminalNode{
  constructor () {
    throw new Error('"NonterminalNode" resource does not define a constructor');
  }
}

NonterminalNode.prototype[nodeJSCustomInspectSymbol] = function(depth, options, inspect) {
  const original = Object.getPrototypeOf(this)[nodeJSCustomInspectSymbol];
  
  try {
    // Temporarily remove the custom inspect form the object's prototype to avoid infinite recursion:
    delete Object.getPrototypeOf(this)[nodeJSCustomInspectSymbol];
    
    return inspect(this, {
      ...options,
      depth,
      getters: true,
      showHidden: true,
    });
  } finally {
    Object.getPrototypeOf(this)[nodeJSCustomInspectSymbol] = original;
  }
}


NonterminalNode.create = function create(arg0, arg1) {
  var vec1 = arg1;
  var len1 = vec1.length;
  var result1 = realloc1(0, 0, 4, len1 * 4);
  for (let i = 0; i < vec1.length; i++) {
    const e = vec1[i];
    const base = result1 + i * 4;var handle0 = e[symbolRscHandle];
    if (!handle0) {
      throw new TypeError('Resource error: Not a valid "Edge" resource.');
    }
    finalizationRegistry6.unregister(e);
    e[symbolDispose] = emptyFunc;
    e[symbolRscHandle] = undefined;
    dataView(memory0).setInt32(base + 0, handle0, true);
  }
  const ret = cstStaticNonterminalNodeCreate(nonterminalKindCABI[arg0], result1, len1);
  var handle3 = ret;
  var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry4.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry4.unregister(rsc2);
    rscTableRemove(handleTable4, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
let cstMethodNonterminalNodeId;

Object.defineProperty(NonterminalNode.prototype, "id", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodNonterminalNodeId(handle0);
  return ret >>> 0;
}});
let cstMethodNonterminalNodeKind;

Object.defineProperty(NonterminalNode.prototype, "kind", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodNonterminalNodeKind(handle0);
  return nonterminalKindCABI[ret];
}});
let cstMethodNonterminalNodeTextLength;

Object.defineProperty(NonterminalNode.prototype, "textLength", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodNonterminalNodeTextLength(handle0);
  return {
    utf8: dataView(memory0).getInt32(ret + 0, true) >>> 0,
    utf16: dataView(memory0).getInt32(ret + 4, true) >>> 0,
    line: dataView(memory0).getInt32(ret + 8, true) >>> 0,
    column: dataView(memory0).getInt32(ret + 12, true) >>> 0,
  };
}});
let cstMethodNonterminalNodeChildren;

NonterminalNode.prototype.children = function children() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodNonterminalNodeChildren(handle0);
  var len4 = dataView(memory0).getInt32(ret + 4, true);
  var base4 = dataView(memory0).getInt32(ret + 0, true);
  var result4 = [];
  for (let i = 0; i < len4; i++) {
    const base = base4 + i * 4;
    var handle3 = dataView(memory0).getInt32(base + 0, true);
    var rsc2 = new.target === Edge ? this : Object.create(Edge.prototype);
    Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
    finalizationRegistry6.register(rsc2, handle3, rsc2);
    Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
      finalizationRegistry6.unregister(rsc2);
      rscTableRemove(handleTable6, handle3);
      rsc2[symbolDispose] = emptyFunc;
      rsc2[symbolRscHandle] = undefined;
      exports0['20'](handleTable6[(handle3 << 1) + 1] & ~T_FLAG);
    }});
    result4.push(rsc2);
  }
  const retVal = result4;
  postReturn0(ret);
  return retVal;
};
const handleTable8 = [T_FLAG, 0];
const finalizationRegistry8 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable8, handle);
  exports0['22'](rep);
});

handleTables[8] = handleTable8;
let cstMethodNonterminalNodeDescendants;

NonterminalNode.prototype.descendants = function descendants() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodNonterminalNodeDescendants(handle0);
  var handle3 = ret;
  var rsc2 = new.target === CursorIterator ? this : Object.create(CursorIterator.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry8.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry8.unregister(rsc2);
    rscTableRemove(handleTable8, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['22'](handleTable8[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
let cstMethodNonterminalNodeUnparse;

NonterminalNode.prototype.unparse = function unparse() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodNonterminalNodeUnparse(handle0);
  var ptr2 = dataView(memory0).getInt32(ret + 0, true);
  var len2 = dataView(memory0).getInt32(ret + 4, true);
  var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
  const retVal = result2;
  postReturn1(ret);
  return retVal;
};
let cstMethodNonterminalNodeToJson;

NonterminalNode.prototype.toJson = function toJson() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodNonterminalNodeToJson(handle0);
  var ptr2 = dataView(memory0).getInt32(ret + 0, true);
  var len2 = dataView(memory0).getInt32(ret + 4, true);
  var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
  const retVal = result2;
  postReturn2(ret);
  return retVal;
};
const handleTable7 = [T_FLAG, 0];
const finalizationRegistry7 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable7, handle);
  exports0['21'](rep);
});

handleTables[7] = handleTable7;
let cstMethodNonterminalNodeCreateCursor;

NonterminalNode.prototype.createCursor = function createCursor(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  var {utf8: v2_0, utf16: v2_1, line: v2_2, column: v2_3 } = arg1;
  const ret = cstMethodNonterminalNodeCreateCursor(handle0, toUint32(v2_0), toUint32(v2_1), toUint32(v2_2), toUint32(v2_3));
  var handle4 = ret;
  var rsc3 = new.target === Cursor ? this : Object.create(Cursor.prototype);
  Object.defineProperty(rsc3, symbolRscHandle, { writable: true, value: handle4});
  finalizationRegistry7.register(rsc3, handle4, rsc3);
  Object.defineProperty(rsc3, symbolDispose, { writable: true, value: function () {
    finalizationRegistry7.unregister(rsc3);
    rscTableRemove(handleTable7, handle4);
    rsc3[symbolDispose] = emptyFunc;
    rsc3[symbolRscHandle] = undefined;
    exports0['21'](handleTable7[(handle4 << 1) + 1] & ~T_FLAG);
  }});
  return rsc3;
};
const handleTable5 = [T_FLAG, 0];
const finalizationRegistry5 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable5, handle);
  exports0['19'](rep);
});

handleTables[5] = handleTable5;
let cstStaticTerminalNodeCreate;

class TerminalNode{
  constructor () {
    throw new Error('"TerminalNode" resource does not define a constructor');
  }
}

TerminalNode.prototype[nodeJSCustomInspectSymbol] = function(depth, options, inspect) {
  const original = Object.getPrototypeOf(this)[nodeJSCustomInspectSymbol];
  
  try {
    // Temporarily remove the custom inspect form the object's prototype to avoid infinite recursion:
    delete Object.getPrototypeOf(this)[nodeJSCustomInspectSymbol];
    
    return inspect(this, {
      ...options,
      depth,
      getters: true,
      showHidden: true,
    });
  } finally {
    Object.getPrototypeOf(this)[nodeJSCustomInspectSymbol] = original;
  }
}


TerminalNode.create = function create(arg0, arg1) {
  var ptr0 = utf8Encode(arg1, realloc1, memory0);
  var len0 = utf8EncodedLen;
  const ret = cstStaticTerminalNodeCreate(terminalKindCABI[arg0], ptr0, len0);
  var handle2 = ret;
  var rsc1 = new.target === TerminalNode ? this : Object.create(TerminalNode.prototype);
  Object.defineProperty(rsc1, symbolRscHandle, { writable: true, value: handle2});
  finalizationRegistry5.register(rsc1, handle2, rsc1);
  Object.defineProperty(rsc1, symbolDispose, { writable: true, value: function () {
    finalizationRegistry5.unregister(rsc1);
    rscTableRemove(handleTable5, handle2);
    rsc1[symbolDispose] = emptyFunc;
    rsc1[symbolRscHandle] = undefined;
    exports0['19'](handleTable5[(handle2 << 1) + 1] & ~T_FLAG);
  }});
  return rsc1;
};
let cstMethodTerminalNodeId;

Object.defineProperty(TerminalNode.prototype, "id", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable5[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "TerminalNode" resource.');
  }
  var handle0 = handleTable5[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodTerminalNodeId(handle0);
  return ret >>> 0;
}});
let cstMethodTerminalNodeKind;

Object.defineProperty(TerminalNode.prototype, "kind", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable5[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "TerminalNode" resource.');
  }
  var handle0 = handleTable5[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodTerminalNodeKind(handle0);
  return terminalKindCABI[ret];
}});
let cstMethodTerminalNodeTextLength;

Object.defineProperty(TerminalNode.prototype, "textLength", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable5[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "TerminalNode" resource.');
  }
  var handle0 = handleTable5[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodTerminalNodeTextLength(handle0);
  return {
    utf8: dataView(memory0).getInt32(ret + 0, true) >>> 0,
    utf16: dataView(memory0).getInt32(ret + 4, true) >>> 0,
    line: dataView(memory0).getInt32(ret + 8, true) >>> 0,
    column: dataView(memory0).getInt32(ret + 12, true) >>> 0,
  };
}});
let cstMethodTerminalNodeChildren;

TerminalNode.prototype.children = function children() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable5[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "TerminalNode" resource.');
  }
  var handle0 = handleTable5[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodTerminalNodeChildren(handle0);
  var len4 = dataView(memory0).getInt32(ret + 4, true);
  var base4 = dataView(memory0).getInt32(ret + 0, true);
  var result4 = [];
  for (let i = 0; i < len4; i++) {
    const base = base4 + i * 4;
    var handle3 = dataView(memory0).getInt32(base + 0, true);
    var rsc2 = new.target === Edge ? this : Object.create(Edge.prototype);
    Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
    finalizationRegistry6.register(rsc2, handle3, rsc2);
    Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
      finalizationRegistry6.unregister(rsc2);
      rscTableRemove(handleTable6, handle3);
      rsc2[symbolDispose] = emptyFunc;
      rsc2[symbolRscHandle] = undefined;
      exports0['20'](handleTable6[(handle3 << 1) + 1] & ~T_FLAG);
    }});
    result4.push(rsc2);
  }
  const retVal = result4;
  postReturn3(ret);
  return retVal;
};
let cstMethodTerminalNodeDescendants;

TerminalNode.prototype.descendants = function descendants() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable5[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "TerminalNode" resource.');
  }
  var handle0 = handleTable5[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodTerminalNodeDescendants(handle0);
  var handle3 = ret;
  var rsc2 = new.target === CursorIterator ? this : Object.create(CursorIterator.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry8.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry8.unregister(rsc2);
    rscTableRemove(handleTable8, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['22'](handleTable8[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
let cstMethodTerminalNodeUnparse;

TerminalNode.prototype.unparse = function unparse() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable5[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "TerminalNode" resource.');
  }
  var handle0 = handleTable5[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodTerminalNodeUnparse(handle0);
  var ptr2 = dataView(memory0).getInt32(ret + 0, true);
  var len2 = dataView(memory0).getInt32(ret + 4, true);
  var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
  const retVal = result2;
  postReturn4(ret);
  return retVal;
};
let cstMethodTerminalNodeToJson;

TerminalNode.prototype.toJson = function toJson() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable5[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "TerminalNode" resource.');
  }
  var handle0 = handleTable5[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodTerminalNodeToJson(handle0);
  var ptr2 = dataView(memory0).getInt32(ret + 0, true);
  var len2 = dataView(memory0).getInt32(ret + 4, true);
  var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
  const retVal = result2;
  postReturn5(ret);
  return retVal;
};
let cstStaticEdgeCreateWithTerminal;

class Edge{
  constructor () {
    throw new Error('"Edge" resource does not define a constructor');
  }
}

Edge.createWithTerminal = function createWithTerminal(arg0, arg1) {
  var handle0 = arg1[symbolRscHandle];
  if (!handle0) {
    throw new TypeError('Resource error: Not a valid "TerminalNode" resource.');
  }
  finalizationRegistry5.unregister(arg1);
  arg1[symbolDispose] = emptyFunc;
  arg1[symbolRscHandle] = undefined;
  const ret = cstStaticEdgeCreateWithTerminal(edgeLabelCABI[arg0], handle0);
  var handle2 = ret;
  var rsc1 = new.target === Edge ? this : Object.create(Edge.prototype);
  Object.defineProperty(rsc1, symbolRscHandle, { writable: true, value: handle2});
  finalizationRegistry6.register(rsc1, handle2, rsc1);
  Object.defineProperty(rsc1, symbolDispose, { writable: true, value: function () {
    finalizationRegistry6.unregister(rsc1);
    rscTableRemove(handleTable6, handle2);
    rsc1[symbolDispose] = emptyFunc;
    rsc1[symbolRscHandle] = undefined;
    exports0['20'](handleTable6[(handle2 << 1) + 1] & ~T_FLAG);
  }});
  return rsc1;
};
let cstStaticEdgeCreateWithNonterminal;

Edge.createWithNonterminal = function createWithNonterminal(arg0, arg1) {
  var handle0 = arg1[symbolRscHandle];
  if (!handle0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  finalizationRegistry4.unregister(arg1);
  arg1[symbolDispose] = emptyFunc;
  arg1[symbolRscHandle] = undefined;
  const ret = cstStaticEdgeCreateWithNonterminal(edgeLabelCABI[arg0], handle0);
  var handle2 = ret;
  var rsc1 = new.target === Edge ? this : Object.create(Edge.prototype);
  Object.defineProperty(rsc1, symbolRscHandle, { writable: true, value: handle2});
  finalizationRegistry6.register(rsc1, handle2, rsc1);
  Object.defineProperty(rsc1, symbolDispose, { writable: true, value: function () {
    finalizationRegistry6.unregister(rsc1);
    rscTableRemove(handleTable6, handle2);
    rsc1[symbolDispose] = emptyFunc;
    rsc1[symbolRscHandle] = undefined;
    exports0['20'](handleTable6[(handle2 << 1) + 1] & ~T_FLAG);
  }});
  return rsc1;
};
let cstMethodEdgeLabel;

Object.defineProperty(Edge.prototype, "label", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable6[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Edge" resource.');
  }
  var handle0 = handleTable6[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodEdgeLabel(handle0);
  return edgeLabelCABI[ret];
}});
let cstMethodEdgeNode;

Object.defineProperty(Edge.prototype, "node", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable6[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Edge" resource.');
  }
  var handle0 = handleTable6[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodEdgeNode(handle0);
  let variant6;
  switch (dataView(memory0).getUint8(ret + 0, true)) {
    case 0: {
      var handle3 = dataView(memory0).getInt32(ret + 4, true);
      var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
      Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
      finalizationRegistry4.register(rsc2, handle3, rsc2);
      Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
        finalizationRegistry4.unregister(rsc2);
        rscTableRemove(handleTable4, handle3);
        rsc2[symbolDispose] = emptyFunc;
        rsc2[symbolRscHandle] = undefined;
        exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc2;
      break;
    }
    case 1: {
      var handle5 = dataView(memory0).getInt32(ret + 4, true);
      var rsc4 = new.target === TerminalNode ? this : Object.create(TerminalNode.prototype);
      Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
      finalizationRegistry5.register(rsc4, handle5, rsc4);
      Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
        finalizationRegistry5.unregister(rsc4);
        rscTableRemove(handleTable5, handle5);
        rsc4[symbolDispose] = emptyFunc;
        rsc4[symbolRscHandle] = undefined;
        exports0['19'](handleTable5[(handle5 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc4;
      break;
    }
  }
  return variant6;
}});
let cstMethodCursorReset;

class Cursor{
  constructor () {
    throw new Error('"Cursor" resource does not define a constructor');
  }
}

Cursor.prototype.reset = function reset() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  cstMethodCursorReset(handle0);
};
let cstMethodCursorComplete;

Cursor.prototype.complete = function complete() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  cstMethodCursorComplete(handle0);
};
let cstMethodCursorIsCompleted;

Cursor.prototype.isCompleted = function isCompleted() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorIsCompleted(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorClone;

Cursor.prototype.clone = function clone() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorClone(handle0);
  var handle3 = ret;
  var rsc2 = new.target === Cursor ? this : Object.create(Cursor.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry7.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry7.unregister(rsc2);
    rscTableRemove(handleTable7, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['21'](handleTable7[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
let cstMethodCursorSpawn;

Cursor.prototype.spawn = function spawn() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorSpawn(handle0);
  var handle3 = ret;
  var rsc2 = new.target === Cursor ? this : Object.create(Cursor.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry7.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry7.unregister(rsc2);
    rscTableRemove(handleTable7, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['21'](handleTable7[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
let cstMethodCursorNode;

Object.defineProperty(Cursor.prototype, "node", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorNode(handle0);
  let variant6;
  switch (dataView(memory0).getUint8(ret + 0, true)) {
    case 0: {
      var handle3 = dataView(memory0).getInt32(ret + 4, true);
      var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
      Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
      finalizationRegistry4.register(rsc2, handle3, rsc2);
      Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
        finalizationRegistry4.unregister(rsc2);
        rscTableRemove(handleTable4, handle3);
        rsc2[symbolDispose] = emptyFunc;
        rsc2[symbolRscHandle] = undefined;
        exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc2;
      break;
    }
    case 1: {
      var handle5 = dataView(memory0).getInt32(ret + 4, true);
      var rsc4 = new.target === TerminalNode ? this : Object.create(TerminalNode.prototype);
      Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
      finalizationRegistry5.register(rsc4, handle5, rsc4);
      Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
        finalizationRegistry5.unregister(rsc4);
        rscTableRemove(handleTable5, handle5);
        rsc4[symbolDispose] = emptyFunc;
        rsc4[symbolRscHandle] = undefined;
        exports0['19'](handleTable5[(handle5 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc4;
      break;
    }
  }
  return variant6;
}});
let cstMethodCursorLabel;

Object.defineProperty(Cursor.prototype, "label", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorLabel(handle0);
  return edgeLabelCABI[ret];
}});
let cstMethodCursorTextOffset;

Object.defineProperty(Cursor.prototype, "textOffset", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorTextOffset(handle0);
  return {
    utf8: dataView(memory0).getInt32(ret + 0, true) >>> 0,
    utf16: dataView(memory0).getInt32(ret + 4, true) >>> 0,
    line: dataView(memory0).getInt32(ret + 8, true) >>> 0,
    column: dataView(memory0).getInt32(ret + 12, true) >>> 0,
  };
}});
let cstMethodCursorTextRange;

Object.defineProperty(Cursor.prototype, "textRange", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorTextRange(handle0);
  return {
    start: {
      utf8: dataView(memory0).getInt32(ret + 0, true) >>> 0,
      utf16: dataView(memory0).getInt32(ret + 4, true) >>> 0,
      line: dataView(memory0).getInt32(ret + 8, true) >>> 0,
      column: dataView(memory0).getInt32(ret + 12, true) >>> 0,
    },
    end: {
      utf8: dataView(memory0).getInt32(ret + 16, true) >>> 0,
      utf16: dataView(memory0).getInt32(ret + 20, true) >>> 0,
      line: dataView(memory0).getInt32(ret + 24, true) >>> 0,
      column: dataView(memory0).getInt32(ret + 28, true) >>> 0,
    },
  };
}});
let cstMethodCursorDepth;

Object.defineProperty(Cursor.prototype, "depth", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorDepth(handle0);
  return ret >>> 0;
}});
let cstMethodCursorChildren;

Cursor.prototype.children = function children() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorChildren(handle0);
  var len4 = dataView(memory0).getInt32(ret + 4, true);
  var base4 = dataView(memory0).getInt32(ret + 0, true);
  var result4 = [];
  for (let i = 0; i < len4; i++) {
    const base = base4 + i * 4;
    var handle3 = dataView(memory0).getInt32(base + 0, true);
    var rsc2 = new.target === Edge ? this : Object.create(Edge.prototype);
    Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
    finalizationRegistry6.register(rsc2, handle3, rsc2);
    Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
      finalizationRegistry6.unregister(rsc2);
      rscTableRemove(handleTable6, handle3);
      rsc2[symbolDispose] = emptyFunc;
      rsc2[symbolRscHandle] = undefined;
      exports0['20'](handleTable6[(handle3 << 1) + 1] & ~T_FLAG);
    }});
    result4.push(rsc2);
  }
  const retVal = result4;
  postReturn6(ret);
  return retVal;
};
let cstMethodCursorDescendants;

Cursor.prototype.descendants = function descendants() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorDescendants(handle0);
  var handle3 = ret;
  var rsc2 = new.target === CursorIterator ? this : Object.create(CursorIterator.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry8.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry8.unregister(rsc2);
    rscTableRemove(handleTable8, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['22'](handleTable8[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
let cstMethodCursorRemainingNodes;

Cursor.prototype.remainingNodes = function remainingNodes() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorRemainingNodes(handle0);
  var handle3 = ret;
  var rsc2 = new.target === CursorIterator ? this : Object.create(CursorIterator.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry8.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry8.unregister(rsc2);
    rscTableRemove(handleTable8, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['22'](handleTable8[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
const handleTable9 = [T_FLAG, 0];
const finalizationRegistry9 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable9, handle);
  exports0['23'](rep);
});

handleTables[9] = handleTable9;
let cstMethodCursorAncestors;

Cursor.prototype.ancestors = function ancestors() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorAncestors(handle0);
  var handle3 = ret;
  var rsc2 = new.target === AncestorsIterator ? this : Object.create(AncestorsIterator.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry9.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry9.unregister(rsc2);
    rscTableRemove(handleTable9, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['23'](handleTable9[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
let cstMethodCursorGoToNext;

Cursor.prototype.goToNext = function goToNext() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToNext(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToNextNonDescendant;

Cursor.prototype.goToNextNonDescendant = function goToNextNonDescendant() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToNextNonDescendant(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToPrevious;

Cursor.prototype.goToPrevious = function goToPrevious() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToPrevious(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToParent;

Cursor.prototype.goToParent = function goToParent() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToParent(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToFirstChild;

Cursor.prototype.goToFirstChild = function goToFirstChild() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToFirstChild(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToLastChild;

Cursor.prototype.goToLastChild = function goToLastChild() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToLastChild(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToNthChild;

Cursor.prototype.goToNthChild = function goToNthChild(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToNthChild(handle0, toUint32(arg1));
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToNextSibling;

Cursor.prototype.goToNextSibling = function goToNextSibling() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToNextSibling(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToPreviousSibling;

Cursor.prototype.goToPreviousSibling = function goToPreviousSibling() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToPreviousSibling(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToNextTerminal;

Cursor.prototype.goToNextTerminal = function goToNextTerminal() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToNextTerminal(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToNextTerminalWithKind;

Cursor.prototype.goToNextTerminalWithKind = function goToNextTerminalWithKind(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToNextTerminalWithKind(handle0, terminalKindCABI[arg1]);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToNextTerminalWithKinds;

Cursor.prototype.goToNextTerminalWithKinds = function goToNextTerminalWithKinds(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  var vec2 = arg1;
  var len2 = vec2.length;
  var result2 = realloc1(0, 0, 1, len2 * 1);
  for (let i = 0; i < vec2.length; i++) {
    const e = vec2[i];
    const base = result2 + i * 1;dataView(memory0).setInt8(base + 0, terminalKindCABI[e], true);
  }
  const ret = cstMethodCursorGoToNextTerminalWithKinds(handle0, result2, len2);
  var bool3 = ret;
  return !!bool3;
};
let cstMethodCursorGoToNextNonterminal;

Cursor.prototype.goToNextNonterminal = function goToNextNonterminal() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToNextNonterminal(handle0);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToNextNonterminalWithKind;

Cursor.prototype.goToNextNonterminalWithKind = function goToNextNonterminalWithKind(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorGoToNextNonterminalWithKind(handle0, nonterminalKindCABI[arg1]);
  var bool2 = ret;
  return !!bool2;
};
let cstMethodCursorGoToNextNonterminalWithKinds;

Cursor.prototype.goToNextNonterminalWithKinds = function goToNextNonterminalWithKinds(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  var vec2 = arg1;
  var len2 = vec2.length;
  var result2 = realloc1(0, 0, 1, len2 * 1);
  for (let i = 0; i < vec2.length; i++) {
    const e = vec2[i];
    const base = result2 + i * 1;dataView(memory0).setInt8(base + 0, nonterminalKindCABI[e], true);
  }
  const ret = cstMethodCursorGoToNextNonterminalWithKinds(handle0, result2, len2);
  var bool3 = ret;
  return !!bool3;
};
const handleTable10 = [T_FLAG, 0];
const finalizationRegistry10 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable10, handle);
  exports0['24'](rep);
});

handleTables[10] = handleTable10;
const handleTable11 = [T_FLAG, 0];
const finalizationRegistry11 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable11, handle);
  exports0['25'](rep);
});

handleTables[11] = handleTable11;
let cstMethodCursorQuery;

Cursor.prototype.query = function query(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable7[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle0 = handleTable7[(handle1 << 1) + 1] & ~T_FLAG;
  var vec4 = arg1;
  var len4 = vec4.length;
  var result4 = realloc1(0, 0, 4, len4 * 4);
  for (let i = 0; i < vec4.length; i++) {
    const e = vec4[i];
    const base = result4 + i * 4;var handle3 = e[symbolRscHandle];
    if (!handle3 || (handleTable10[(handle3 << 1) + 1] & T_FLAG) === 0) {
      throw new TypeError('Resource error: Not a valid "Query" resource.');
    }
    var handle2 = handleTable10[(handle3 << 1) + 1] & ~T_FLAG;
    dataView(memory0).setInt32(base + 0, handle2, true);
  }
  const ret = cstMethodCursorQuery(handle0, result4, len4);
  var handle6 = ret;
  var rsc5 = new.target === QueryMatchIterator ? this : Object.create(QueryMatchIterator.prototype);
  Object.defineProperty(rsc5, symbolRscHandle, { writable: true, value: handle6});
  finalizationRegistry11.register(rsc5, handle6, rsc5);
  Object.defineProperty(rsc5, symbolDispose, { writable: true, value: function () {
    finalizationRegistry11.unregister(rsc5);
    rscTableRemove(handleTable11, handle6);
    rsc5[symbolDispose] = emptyFunc;
    rsc5[symbolRscHandle] = undefined;
    exports0['25'](handleTable11[(handle6 << 1) + 1] & ~T_FLAG);
  }});
  return rsc5;
};
let cstMethodCursorIteratorNext;

class CursorIterator{
  constructor () {
    throw new Error('"CursorIterator" resource does not define a constructor');
  }
}

CursorIterator.prototype[Symbol.iterator] = function () {
  return {
    next: () => {
      const value = this.next();
      return { done: value == undefined, value };
    }
  }
}


CursorIterator.prototype.next = function next() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable8[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "CursorIterator" resource.');
  }
  var handle0 = handleTable8[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodCursorIteratorNext(handle0);
  let variant4;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var handle3 = dataView(memory0).getInt32(ret + 4, true);
    var rsc2 = new.target === Edge ? this : Object.create(Edge.prototype);
    Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
    finalizationRegistry6.register(rsc2, handle3, rsc2);
    Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
      finalizationRegistry6.unregister(rsc2);
      rscTableRemove(handleTable6, handle3);
      rsc2[symbolDispose] = emptyFunc;
      rsc2[symbolRscHandle] = undefined;
      exports0['20'](handleTable6[(handle3 << 1) + 1] & ~T_FLAG);
    }});
    variant4 = rsc2;
  } else {
    variant4 = undefined;
  }
  return variant4;
};
let cstMethodAncestorsIteratorNext;

class AncestorsIterator{
  constructor () {
    throw new Error('"AncestorsIterator" resource does not define a constructor');
  }
}

AncestorsIterator.prototype[Symbol.iterator] = function () {
  return {
    next: () => {
      const value = this.next();
      return { done: value == undefined, value };
    }
  }
}


AncestorsIterator.prototype.next = function next() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable9[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "AncestorsIterator" resource.');
  }
  var handle0 = handleTable9[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodAncestorsIteratorNext(handle0);
  let variant4;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var handle3 = dataView(memory0).getInt32(ret + 4, true);
    var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
    Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
    finalizationRegistry4.register(rsc2, handle3, rsc2);
    Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
      finalizationRegistry4.unregister(rsc2);
      rscTableRemove(handleTable4, handle3);
      rsc2[symbolDispose] = emptyFunc;
      rsc2[symbolRscHandle] = undefined;
      exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
    }});
    variant4 = rsc2;
  } else {
    variant4 = undefined;
  }
  return variant4;
};
let cstStaticQueryCreate;

class Query{
  constructor () {
    throw new Error('"Query" resource does not define a constructor');
  }
}

Query.create = function create(arg0) {
  var ptr0 = utf8Encode(arg0, realloc1, memory0);
  var len0 = utf8EncodedLen;
  const ret = cstStaticQueryCreate(ptr0, len0);
  let variant4;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var ptr3 = dataView(memory0).getInt32(ret + 4, true);
    var len3 = dataView(memory0).getInt32(ret + 8, true);
    var result3 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr3, len3));
    variant4= {
      tag: 'err',
      val: {
        message: result3,
        textRange: {
          start: {
            utf8: dataView(memory0).getInt32(ret + 12, true) >>> 0,
            utf16: dataView(memory0).getInt32(ret + 16, true) >>> 0,
            line: dataView(memory0).getInt32(ret + 20, true) >>> 0,
            column: dataView(memory0).getInt32(ret + 24, true) >>> 0,
          },
          end: {
            utf8: dataView(memory0).getInt32(ret + 28, true) >>> 0,
            utf16: dataView(memory0).getInt32(ret + 32, true) >>> 0,
            line: dataView(memory0).getInt32(ret + 36, true) >>> 0,
            column: dataView(memory0).getInt32(ret + 40, true) >>> 0,
          },
        },
      }
    };
  } else {
    var handle2 = dataView(memory0).getInt32(ret + 4, true);
    var rsc1 = new.target === Query ? this : Object.create(Query.prototype);
    Object.defineProperty(rsc1, symbolRscHandle, { writable: true, value: handle2});
    finalizationRegistry10.register(rsc1, handle2, rsc1);
    Object.defineProperty(rsc1, symbolDispose, { writable: true, value: function () {
      finalizationRegistry10.unregister(rsc1);
      rscTableRemove(handleTable10, handle2);
      rsc1[symbolDispose] = emptyFunc;
      rsc1[symbolRscHandle] = undefined;
      exports0['24'](handleTable10[(handle2 << 1) + 1] & ~T_FLAG);
    }});
    variant4= {
      tag: 'ok',
      val: rsc1
    };
  }
  const retVal = variant4;
  postReturn7(ret);
  if (typeof retVal === 'object' && retVal.tag === 'err') {
    throw retVal.val;
  }
  return retVal.val;
};
let cstMethodQueryMatchIteratorNext;

class QueryMatchIterator{
  constructor () {
    throw new Error('"QueryMatchIterator" resource does not define a constructor');
  }
}

QueryMatchIterator.prototype[Symbol.iterator] = function () {
  return {
    next: () => {
      const value = this.next();
      return { done: value == undefined, value };
    }
  }
}


QueryMatchIterator.prototype.next = function next() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable11[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "QueryMatchIterator" resource.');
  }
  var handle0 = handleTable11[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = cstMethodQueryMatchIteratorNext(handle0);
  let variant9;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var handle3 = dataView(memory0).getInt32(ret + 8, true);
    var rsc2 = new.target === Cursor ? this : Object.create(Cursor.prototype);
    Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
    finalizationRegistry7.register(rsc2, handle3, rsc2);
    Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
      finalizationRegistry7.unregister(rsc2);
      rscTableRemove(handleTable7, handle3);
      rsc2[symbolDispose] = emptyFunc;
      rsc2[symbolRscHandle] = undefined;
      exports0['21'](handleTable7[(handle3 << 1) + 1] & ~T_FLAG);
    }});
    var len8 = dataView(memory0).getInt32(ret + 16, true);
    var base8 = dataView(memory0).getInt32(ret + 12, true);
    var result8 = [];
    for (let i = 0; i < len8; i++) {
      const base = base8 + i * 16;
      var ptr4 = dataView(memory0).getInt32(base + 0, true);
      var len4 = dataView(memory0).getInt32(base + 4, true);
      var result4 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr4, len4));
      var len7 = dataView(memory0).getInt32(base + 12, true);
      var base7 = dataView(memory0).getInt32(base + 8, true);
      var result7 = [];
      for (let i = 0; i < len7; i++) {
        const base = base7 + i * 4;
        var handle6 = dataView(memory0).getInt32(base + 0, true);
        var rsc5 = new.target === Cursor ? this : Object.create(Cursor.prototype);
        Object.defineProperty(rsc5, symbolRscHandle, { writable: true, value: handle6});
        finalizationRegistry7.register(rsc5, handle6, rsc5);
        Object.defineProperty(rsc5, symbolDispose, { writable: true, value: function () {
          finalizationRegistry7.unregister(rsc5);
          rscTableRemove(handleTable7, handle6);
          rsc5[symbolDispose] = emptyFunc;
          rsc5[symbolRscHandle] = undefined;
          exports0['21'](handleTable7[(handle6 << 1) + 1] & ~T_FLAG);
        }});
        result7.push(rsc5);
      }
      result8.push([result4, result7]);
    }
    variant9 = {
      queryIndex: dataView(memory0).getInt32(ret + 4, true) >>> 0,
      root: rsc2,
      captures: result8.reduce((acc, val) => { acc[val[0]] = val[1]; return acc; }, {}),
    };
  } else {
    variant9 = undefined;
  }
  const retVal = variant9;
  postReturn8(ret);
  return retVal;
};
let cstStaticTextIndexExtensionsZero;

class TextIndexExtensions{
  constructor () {
    throw new Error('"TextIndexExtensions" resource does not define a constructor');
  }
}

TextIndexExtensions.zero = function zero() {
  const ret = cstStaticTextIndexExtensionsZero();
  return {
    utf8: dataView(memory0).getInt32(ret + 0, true) >>> 0,
    utf16: dataView(memory0).getInt32(ret + 4, true) >>> 0,
    line: dataView(memory0).getInt32(ret + 8, true) >>> 0,
    column: dataView(memory0).getInt32(ret + 12, true) >>> 0,
  };
};
var nonterminalKind = {};
nonterminalKind['AbicoderPragma'] = 'AbicoderPragma';
nonterminalKind['AbicoderVersion'] = 'AbicoderVersion';
nonterminalKind['AdditiveExpression'] = 'AdditiveExpression';
nonterminalKind['AddressType'] = 'AddressType';
nonterminalKind['AndExpression'] = 'AndExpression';
nonterminalKind['ArgumentsDeclaration'] = 'ArgumentsDeclaration';
nonterminalKind['ArrayExpression'] = 'ArrayExpression';
nonterminalKind['ArrayTypeName'] = 'ArrayTypeName';
nonterminalKind['ArrayValues'] = 'ArrayValues';
nonterminalKind['AssemblyFlags'] = 'AssemblyFlags';
nonterminalKind['AssemblyFlagsDeclaration'] = 'AssemblyFlagsDeclaration';
nonterminalKind['AssemblyStatement'] = 'AssemblyStatement';
nonterminalKind['AssignmentExpression'] = 'AssignmentExpression';
nonterminalKind['BitwiseAndExpression'] = 'BitwiseAndExpression';
nonterminalKind['BitwiseOrExpression'] = 'BitwiseOrExpression';
nonterminalKind['BitwiseXorExpression'] = 'BitwiseXorExpression';
nonterminalKind['Block'] = 'Block';
nonterminalKind['BreakStatement'] = 'BreakStatement';
nonterminalKind['CallOptions'] = 'CallOptions';
nonterminalKind['CallOptionsExpression'] = 'CallOptionsExpression';
nonterminalKind['CatchClause'] = 'CatchClause';
nonterminalKind['CatchClauseError'] = 'CatchClauseError';
nonterminalKind['CatchClauses'] = 'CatchClauses';
nonterminalKind['ConditionalExpression'] = 'ConditionalExpression';
nonterminalKind['ConstantDefinition'] = 'ConstantDefinition';
nonterminalKind['ConstructorAttribute'] = 'ConstructorAttribute';
nonterminalKind['ConstructorAttributes'] = 'ConstructorAttributes';
nonterminalKind['ConstructorDefinition'] = 'ConstructorDefinition';
nonterminalKind['ContinueStatement'] = 'ContinueStatement';
nonterminalKind['ContractDefinition'] = 'ContractDefinition';
nonterminalKind['ContractMember'] = 'ContractMember';
nonterminalKind['ContractMembers'] = 'ContractMembers';
nonterminalKind['ContractSpecifier'] = 'ContractSpecifier';
nonterminalKind['ContractSpecifiers'] = 'ContractSpecifiers';
nonterminalKind['DecimalNumberExpression'] = 'DecimalNumberExpression';
nonterminalKind['DoWhileStatement'] = 'DoWhileStatement';
nonterminalKind['ElementaryType'] = 'ElementaryType';
nonterminalKind['ElseBranch'] = 'ElseBranch';
nonterminalKind['EmitStatement'] = 'EmitStatement';
nonterminalKind['EnumDefinition'] = 'EnumDefinition';
nonterminalKind['EnumMembers'] = 'EnumMembers';
nonterminalKind['EqualityExpression'] = 'EqualityExpression';
nonterminalKind['ErrorDefinition'] = 'ErrorDefinition';
nonterminalKind['ErrorParameter'] = 'ErrorParameter';
nonterminalKind['ErrorParameters'] = 'ErrorParameters';
nonterminalKind['ErrorParametersDeclaration'] = 'ErrorParametersDeclaration';
nonterminalKind['EventDefinition'] = 'EventDefinition';
nonterminalKind['EventParameter'] = 'EventParameter';
nonterminalKind['EventParameters'] = 'EventParameters';
nonterminalKind['EventParametersDeclaration'] = 'EventParametersDeclaration';
nonterminalKind['ExperimentalFeature'] = 'ExperimentalFeature';
nonterminalKind['ExperimentalPragma'] = 'ExperimentalPragma';
nonterminalKind['ExponentiationExpression'] = 'ExponentiationExpression';
nonterminalKind['Expression'] = 'Expression';
nonterminalKind['ExpressionStatement'] = 'ExpressionStatement';
nonterminalKind['FallbackFunctionAttribute'] = 'FallbackFunctionAttribute';
nonterminalKind['FallbackFunctionAttributes'] = 'FallbackFunctionAttributes';
nonterminalKind['FallbackFunctionDefinition'] = 'FallbackFunctionDefinition';
nonterminalKind['ForStatement'] = 'ForStatement';
nonterminalKind['ForStatementCondition'] = 'ForStatementCondition';
nonterminalKind['ForStatementInitialization'] = 'ForStatementInitialization';
nonterminalKind['FunctionAttribute'] = 'FunctionAttribute';
nonterminalKind['FunctionAttributes'] = 'FunctionAttributes';
nonterminalKind['FunctionBody'] = 'FunctionBody';
nonterminalKind['FunctionCallExpression'] = 'FunctionCallExpression';
nonterminalKind['FunctionDefinition'] = 'FunctionDefinition';
nonterminalKind['FunctionName'] = 'FunctionName';
nonterminalKind['FunctionType'] = 'FunctionType';
nonterminalKind['FunctionTypeAttribute'] = 'FunctionTypeAttribute';
nonterminalKind['FunctionTypeAttributes'] = 'FunctionTypeAttributes';
nonterminalKind['HexNumberExpression'] = 'HexNumberExpression';
nonterminalKind['HexStringLiteral'] = 'HexStringLiteral';
nonterminalKind['HexStringLiterals'] = 'HexStringLiterals';
nonterminalKind['IdentifierPath'] = 'IdentifierPath';
nonterminalKind['IfStatement'] = 'IfStatement';
nonterminalKind['ImportAlias'] = 'ImportAlias';
nonterminalKind['ImportClause'] = 'ImportClause';
nonterminalKind['ImportDeconstruction'] = 'ImportDeconstruction';
nonterminalKind['ImportDeconstructionSymbol'] = 'ImportDeconstructionSymbol';
nonterminalKind['ImportDeconstructionSymbols'] = 'ImportDeconstructionSymbols';
nonterminalKind['ImportDirective'] = 'ImportDirective';
nonterminalKind['IndexAccessEnd'] = 'IndexAccessEnd';
nonterminalKind['IndexAccessExpression'] = 'IndexAccessExpression';
nonterminalKind['InequalityExpression'] = 'InequalityExpression';
nonterminalKind['InheritanceSpecifier'] = 'InheritanceSpecifier';
nonterminalKind['InheritanceType'] = 'InheritanceType';
nonterminalKind['InheritanceTypes'] = 'InheritanceTypes';
nonterminalKind['InterfaceDefinition'] = 'InterfaceDefinition';
nonterminalKind['InterfaceMembers'] = 'InterfaceMembers';
nonterminalKind['LibraryDefinition'] = 'LibraryDefinition';
nonterminalKind['LibraryMembers'] = 'LibraryMembers';
nonterminalKind['MappingKey'] = 'MappingKey';
nonterminalKind['MappingKeyType'] = 'MappingKeyType';
nonterminalKind['MappingType'] = 'MappingType';
nonterminalKind['MappingValue'] = 'MappingValue';
nonterminalKind['MemberAccessExpression'] = 'MemberAccessExpression';
nonterminalKind['ModifierAttribute'] = 'ModifierAttribute';
nonterminalKind['ModifierAttributes'] = 'ModifierAttributes';
nonterminalKind['ModifierDefinition'] = 'ModifierDefinition';
nonterminalKind['ModifierInvocation'] = 'ModifierInvocation';
nonterminalKind['MultiplicativeExpression'] = 'MultiplicativeExpression';
nonterminalKind['NamedArgument'] = 'NamedArgument';
nonterminalKind['NamedArgumentGroup'] = 'NamedArgumentGroup';
nonterminalKind['NamedArguments'] = 'NamedArguments';
nonterminalKind['NamedArgumentsDeclaration'] = 'NamedArgumentsDeclaration';
nonterminalKind['NamedImport'] = 'NamedImport';
nonterminalKind['NewExpression'] = 'NewExpression';
nonterminalKind['NumberUnit'] = 'NumberUnit';
nonterminalKind['OrExpression'] = 'OrExpression';
nonterminalKind['OverridePaths'] = 'OverridePaths';
nonterminalKind['OverridePathsDeclaration'] = 'OverridePathsDeclaration';
nonterminalKind['OverrideSpecifier'] = 'OverrideSpecifier';
nonterminalKind['Parameter'] = 'Parameter';
nonterminalKind['Parameters'] = 'Parameters';
nonterminalKind['ParametersDeclaration'] = 'ParametersDeclaration';
nonterminalKind['PathImport'] = 'PathImport';
nonterminalKind['PositionalArguments'] = 'PositionalArguments';
nonterminalKind['PositionalArgumentsDeclaration'] = 'PositionalArgumentsDeclaration';
nonterminalKind['PostfixExpression'] = 'PostfixExpression';
nonterminalKind['Pragma'] = 'Pragma';
nonterminalKind['PragmaDirective'] = 'PragmaDirective';
nonterminalKind['PrefixExpression'] = 'PrefixExpression';
nonterminalKind['ReceiveFunctionAttribute'] = 'ReceiveFunctionAttribute';
nonterminalKind['ReceiveFunctionAttributes'] = 'ReceiveFunctionAttributes';
nonterminalKind['ReceiveFunctionDefinition'] = 'ReceiveFunctionDefinition';
nonterminalKind['ReturnStatement'] = 'ReturnStatement';
nonterminalKind['ReturnsDeclaration'] = 'ReturnsDeclaration';
nonterminalKind['RevertStatement'] = 'RevertStatement';
nonterminalKind['ShiftExpression'] = 'ShiftExpression';
nonterminalKind['SimpleVersionLiteral'] = 'SimpleVersionLiteral';
nonterminalKind['SourceUnit'] = 'SourceUnit';
nonterminalKind['SourceUnitMember'] = 'SourceUnitMember';
nonterminalKind['SourceUnitMembers'] = 'SourceUnitMembers';
nonterminalKind['StateVariableAttribute'] = 'StateVariableAttribute';
nonterminalKind['StateVariableAttributes'] = 'StateVariableAttributes';
nonterminalKind['StateVariableDefinition'] = 'StateVariableDefinition';
nonterminalKind['StateVariableDefinitionValue'] = 'StateVariableDefinitionValue';
nonterminalKind['Statement'] = 'Statement';
nonterminalKind['Statements'] = 'Statements';
nonterminalKind['StorageLocation'] = 'StorageLocation';
nonterminalKind['StringExpression'] = 'StringExpression';
nonterminalKind['StringLiteral'] = 'StringLiteral';
nonterminalKind['StringLiterals'] = 'StringLiterals';
nonterminalKind['StructDefinition'] = 'StructDefinition';
nonterminalKind['StructMember'] = 'StructMember';
nonterminalKind['StructMembers'] = 'StructMembers';
nonterminalKind['TryStatement'] = 'TryStatement';
nonterminalKind['TupleDeconstructionElement'] = 'TupleDeconstructionElement';
nonterminalKind['TupleDeconstructionElements'] = 'TupleDeconstructionElements';
nonterminalKind['TupleDeconstructionStatement'] = 'TupleDeconstructionStatement';
nonterminalKind['TupleExpression'] = 'TupleExpression';
nonterminalKind['TupleMember'] = 'TupleMember';
nonterminalKind['TupleValue'] = 'TupleValue';
nonterminalKind['TupleValues'] = 'TupleValues';
nonterminalKind['TypeExpression'] = 'TypeExpression';
nonterminalKind['TypeName'] = 'TypeName';
nonterminalKind['TypedTupleMember'] = 'TypedTupleMember';
nonterminalKind['UncheckedBlock'] = 'UncheckedBlock';
nonterminalKind['UnicodeStringLiteral'] = 'UnicodeStringLiteral';
nonterminalKind['UnicodeStringLiterals'] = 'UnicodeStringLiterals';
nonterminalKind['UntypedTupleMember'] = 'UntypedTupleMember';
nonterminalKind['UserDefinedValueTypeDefinition'] = 'UserDefinedValueTypeDefinition';
nonterminalKind['UsingAlias'] = 'UsingAlias';
nonterminalKind['UsingClause'] = 'UsingClause';
nonterminalKind['UsingDeconstruction'] = 'UsingDeconstruction';
nonterminalKind['UsingDeconstructionSymbol'] = 'UsingDeconstructionSymbol';
nonterminalKind['UsingDeconstructionSymbols'] = 'UsingDeconstructionSymbols';
nonterminalKind['UsingDirective'] = 'UsingDirective';
nonterminalKind['UsingOperator'] = 'UsingOperator';
nonterminalKind['UsingTarget'] = 'UsingTarget';
nonterminalKind['VariableDeclarationStatement'] = 'VariableDeclarationStatement';
nonterminalKind['VariableDeclarationType'] = 'VariableDeclarationType';
nonterminalKind['VariableDeclarationValue'] = 'VariableDeclarationValue';
nonterminalKind['VersionExpression'] = 'VersionExpression';
nonterminalKind['VersionExpressionSet'] = 'VersionExpressionSet';
nonterminalKind['VersionExpressionSets'] = 'VersionExpressionSets';
nonterminalKind['VersionLiteral'] = 'VersionLiteral';
nonterminalKind['VersionOperator'] = 'VersionOperator';
nonterminalKind['VersionPragma'] = 'VersionPragma';
nonterminalKind['VersionRange'] = 'VersionRange';
nonterminalKind['VersionTerm'] = 'VersionTerm';
nonterminalKind['WhileStatement'] = 'WhileStatement';
nonterminalKind['YulArguments'] = 'YulArguments';
nonterminalKind['YulAssignmentOperator'] = 'YulAssignmentOperator';
nonterminalKind['YulBlock'] = 'YulBlock';
nonterminalKind['YulBreakStatement'] = 'YulBreakStatement';
nonterminalKind['YulContinueStatement'] = 'YulContinueStatement';
nonterminalKind['YulDefaultCase'] = 'YulDefaultCase';
nonterminalKind['YulExpression'] = 'YulExpression';
nonterminalKind['YulForStatement'] = 'YulForStatement';
nonterminalKind['YulFunctionCallExpression'] = 'YulFunctionCallExpression';
nonterminalKind['YulFunctionDefinition'] = 'YulFunctionDefinition';
nonterminalKind['YulIfStatement'] = 'YulIfStatement';
nonterminalKind['YulLeaveStatement'] = 'YulLeaveStatement';
nonterminalKind['YulLiteral'] = 'YulLiteral';
nonterminalKind['YulParameters'] = 'YulParameters';
nonterminalKind['YulParametersDeclaration'] = 'YulParametersDeclaration';
nonterminalKind['YulPath'] = 'YulPath';
nonterminalKind['YulPaths'] = 'YulPaths';
nonterminalKind['YulReturnsDeclaration'] = 'YulReturnsDeclaration';
nonterminalKind['YulStatement'] = 'YulStatement';
nonterminalKind['YulStatements'] = 'YulStatements';
nonterminalKind['YulSwitchCase'] = 'YulSwitchCase';
nonterminalKind['YulSwitchCases'] = 'YulSwitchCases';
nonterminalKind['YulSwitchStatement'] = 'YulSwitchStatement';
nonterminalKind['YulValueCase'] = 'YulValueCase';
nonterminalKind['YulVariableAssignmentStatement'] = 'YulVariableAssignmentStatement';
nonterminalKind['YulVariableDeclarationStatement'] = 'YulVariableDeclarationStatement';
nonterminalKind['YulVariableDeclarationValue'] = 'YulVariableDeclarationValue';
nonterminalKind['YulVariableNames'] = 'YulVariableNames';

var nonterminalKindCABI = {};
nonterminalKindCABI[nonterminalKindCABI['AbicoderPragma'] = 0] = 'AbicoderPragma';
nonterminalKindCABI[nonterminalKindCABI['AbicoderVersion'] = 1] = 'AbicoderVersion';
nonterminalKindCABI[nonterminalKindCABI['AdditiveExpression'] = 2] = 'AdditiveExpression';
nonterminalKindCABI[nonterminalKindCABI['AddressType'] = 3] = 'AddressType';
nonterminalKindCABI[nonterminalKindCABI['AndExpression'] = 4] = 'AndExpression';
nonterminalKindCABI[nonterminalKindCABI['ArgumentsDeclaration'] = 5] = 'ArgumentsDeclaration';
nonterminalKindCABI[nonterminalKindCABI['ArrayExpression'] = 6] = 'ArrayExpression';
nonterminalKindCABI[nonterminalKindCABI['ArrayTypeName'] = 7] = 'ArrayTypeName';
nonterminalKindCABI[nonterminalKindCABI['ArrayValues'] = 8] = 'ArrayValues';
nonterminalKindCABI[nonterminalKindCABI['AssemblyFlags'] = 9] = 'AssemblyFlags';
nonterminalKindCABI[nonterminalKindCABI['AssemblyFlagsDeclaration'] = 10] = 'AssemblyFlagsDeclaration';
nonterminalKindCABI[nonterminalKindCABI['AssemblyStatement'] = 11] = 'AssemblyStatement';
nonterminalKindCABI[nonterminalKindCABI['AssignmentExpression'] = 12] = 'AssignmentExpression';
nonterminalKindCABI[nonterminalKindCABI['BitwiseAndExpression'] = 13] = 'BitwiseAndExpression';
nonterminalKindCABI[nonterminalKindCABI['BitwiseOrExpression'] = 14] = 'BitwiseOrExpression';
nonterminalKindCABI[nonterminalKindCABI['BitwiseXorExpression'] = 15] = 'BitwiseXorExpression';
nonterminalKindCABI[nonterminalKindCABI['Block'] = 16] = 'Block';
nonterminalKindCABI[nonterminalKindCABI['BreakStatement'] = 17] = 'BreakStatement';
nonterminalKindCABI[nonterminalKindCABI['CallOptions'] = 18] = 'CallOptions';
nonterminalKindCABI[nonterminalKindCABI['CallOptionsExpression'] = 19] = 'CallOptionsExpression';
nonterminalKindCABI[nonterminalKindCABI['CatchClause'] = 20] = 'CatchClause';
nonterminalKindCABI[nonterminalKindCABI['CatchClauseError'] = 21] = 'CatchClauseError';
nonterminalKindCABI[nonterminalKindCABI['CatchClauses'] = 22] = 'CatchClauses';
nonterminalKindCABI[nonterminalKindCABI['ConditionalExpression'] = 23] = 'ConditionalExpression';
nonterminalKindCABI[nonterminalKindCABI['ConstantDefinition'] = 24] = 'ConstantDefinition';
nonterminalKindCABI[nonterminalKindCABI['ConstructorAttribute'] = 25] = 'ConstructorAttribute';
nonterminalKindCABI[nonterminalKindCABI['ConstructorAttributes'] = 26] = 'ConstructorAttributes';
nonterminalKindCABI[nonterminalKindCABI['ConstructorDefinition'] = 27] = 'ConstructorDefinition';
nonterminalKindCABI[nonterminalKindCABI['ContinueStatement'] = 28] = 'ContinueStatement';
nonterminalKindCABI[nonterminalKindCABI['ContractDefinition'] = 29] = 'ContractDefinition';
nonterminalKindCABI[nonterminalKindCABI['ContractMember'] = 30] = 'ContractMember';
nonterminalKindCABI[nonterminalKindCABI['ContractMembers'] = 31] = 'ContractMembers';
nonterminalKindCABI[nonterminalKindCABI['ContractSpecifier'] = 32] = 'ContractSpecifier';
nonterminalKindCABI[nonterminalKindCABI['ContractSpecifiers'] = 33] = 'ContractSpecifiers';
nonterminalKindCABI[nonterminalKindCABI['DecimalNumberExpression'] = 34] = 'DecimalNumberExpression';
nonterminalKindCABI[nonterminalKindCABI['DoWhileStatement'] = 35] = 'DoWhileStatement';
nonterminalKindCABI[nonterminalKindCABI['ElementaryType'] = 36] = 'ElementaryType';
nonterminalKindCABI[nonterminalKindCABI['ElseBranch'] = 37] = 'ElseBranch';
nonterminalKindCABI[nonterminalKindCABI['EmitStatement'] = 38] = 'EmitStatement';
nonterminalKindCABI[nonterminalKindCABI['EnumDefinition'] = 39] = 'EnumDefinition';
nonterminalKindCABI[nonterminalKindCABI['EnumMembers'] = 40] = 'EnumMembers';
nonterminalKindCABI[nonterminalKindCABI['EqualityExpression'] = 41] = 'EqualityExpression';
nonterminalKindCABI[nonterminalKindCABI['ErrorDefinition'] = 42] = 'ErrorDefinition';
nonterminalKindCABI[nonterminalKindCABI['ErrorParameter'] = 43] = 'ErrorParameter';
nonterminalKindCABI[nonterminalKindCABI['ErrorParameters'] = 44] = 'ErrorParameters';
nonterminalKindCABI[nonterminalKindCABI['ErrorParametersDeclaration'] = 45] = 'ErrorParametersDeclaration';
nonterminalKindCABI[nonterminalKindCABI['EventDefinition'] = 46] = 'EventDefinition';
nonterminalKindCABI[nonterminalKindCABI['EventParameter'] = 47] = 'EventParameter';
nonterminalKindCABI[nonterminalKindCABI['EventParameters'] = 48] = 'EventParameters';
nonterminalKindCABI[nonterminalKindCABI['EventParametersDeclaration'] = 49] = 'EventParametersDeclaration';
nonterminalKindCABI[nonterminalKindCABI['ExperimentalFeature'] = 50] = 'ExperimentalFeature';
nonterminalKindCABI[nonterminalKindCABI['ExperimentalPragma'] = 51] = 'ExperimentalPragma';
nonterminalKindCABI[nonterminalKindCABI['ExponentiationExpression'] = 52] = 'ExponentiationExpression';
nonterminalKindCABI[nonterminalKindCABI['Expression'] = 53] = 'Expression';
nonterminalKindCABI[nonterminalKindCABI['ExpressionStatement'] = 54] = 'ExpressionStatement';
nonterminalKindCABI[nonterminalKindCABI['FallbackFunctionAttribute'] = 55] = 'FallbackFunctionAttribute';
nonterminalKindCABI[nonterminalKindCABI['FallbackFunctionAttributes'] = 56] = 'FallbackFunctionAttributes';
nonterminalKindCABI[nonterminalKindCABI['FallbackFunctionDefinition'] = 57] = 'FallbackFunctionDefinition';
nonterminalKindCABI[nonterminalKindCABI['ForStatement'] = 58] = 'ForStatement';
nonterminalKindCABI[nonterminalKindCABI['ForStatementCondition'] = 59] = 'ForStatementCondition';
nonterminalKindCABI[nonterminalKindCABI['ForStatementInitialization'] = 60] = 'ForStatementInitialization';
nonterminalKindCABI[nonterminalKindCABI['FunctionAttribute'] = 61] = 'FunctionAttribute';
nonterminalKindCABI[nonterminalKindCABI['FunctionAttributes'] = 62] = 'FunctionAttributes';
nonterminalKindCABI[nonterminalKindCABI['FunctionBody'] = 63] = 'FunctionBody';
nonterminalKindCABI[nonterminalKindCABI['FunctionCallExpression'] = 64] = 'FunctionCallExpression';
nonterminalKindCABI[nonterminalKindCABI['FunctionDefinition'] = 65] = 'FunctionDefinition';
nonterminalKindCABI[nonterminalKindCABI['FunctionName'] = 66] = 'FunctionName';
nonterminalKindCABI[nonterminalKindCABI['FunctionType'] = 67] = 'FunctionType';
nonterminalKindCABI[nonterminalKindCABI['FunctionTypeAttribute'] = 68] = 'FunctionTypeAttribute';
nonterminalKindCABI[nonterminalKindCABI['FunctionTypeAttributes'] = 69] = 'FunctionTypeAttributes';
nonterminalKindCABI[nonterminalKindCABI['HexNumberExpression'] = 70] = 'HexNumberExpression';
nonterminalKindCABI[nonterminalKindCABI['HexStringLiteral'] = 71] = 'HexStringLiteral';
nonterminalKindCABI[nonterminalKindCABI['HexStringLiterals'] = 72] = 'HexStringLiterals';
nonterminalKindCABI[nonterminalKindCABI['IdentifierPath'] = 73] = 'IdentifierPath';
nonterminalKindCABI[nonterminalKindCABI['IfStatement'] = 74] = 'IfStatement';
nonterminalKindCABI[nonterminalKindCABI['ImportAlias'] = 75] = 'ImportAlias';
nonterminalKindCABI[nonterminalKindCABI['ImportClause'] = 76] = 'ImportClause';
nonterminalKindCABI[nonterminalKindCABI['ImportDeconstruction'] = 77] = 'ImportDeconstruction';
nonterminalKindCABI[nonterminalKindCABI['ImportDeconstructionSymbol'] = 78] = 'ImportDeconstructionSymbol';
nonterminalKindCABI[nonterminalKindCABI['ImportDeconstructionSymbols'] = 79] = 'ImportDeconstructionSymbols';
nonterminalKindCABI[nonterminalKindCABI['ImportDirective'] = 80] = 'ImportDirective';
nonterminalKindCABI[nonterminalKindCABI['IndexAccessEnd'] = 81] = 'IndexAccessEnd';
nonterminalKindCABI[nonterminalKindCABI['IndexAccessExpression'] = 82] = 'IndexAccessExpression';
nonterminalKindCABI[nonterminalKindCABI['InequalityExpression'] = 83] = 'InequalityExpression';
nonterminalKindCABI[nonterminalKindCABI['InheritanceSpecifier'] = 84] = 'InheritanceSpecifier';
nonterminalKindCABI[nonterminalKindCABI['InheritanceType'] = 85] = 'InheritanceType';
nonterminalKindCABI[nonterminalKindCABI['InheritanceTypes'] = 86] = 'InheritanceTypes';
nonterminalKindCABI[nonterminalKindCABI['InterfaceDefinition'] = 87] = 'InterfaceDefinition';
nonterminalKindCABI[nonterminalKindCABI['InterfaceMembers'] = 88] = 'InterfaceMembers';
nonterminalKindCABI[nonterminalKindCABI['LibraryDefinition'] = 89] = 'LibraryDefinition';
nonterminalKindCABI[nonterminalKindCABI['LibraryMembers'] = 90] = 'LibraryMembers';
nonterminalKindCABI[nonterminalKindCABI['MappingKey'] = 91] = 'MappingKey';
nonterminalKindCABI[nonterminalKindCABI['MappingKeyType'] = 92] = 'MappingKeyType';
nonterminalKindCABI[nonterminalKindCABI['MappingType'] = 93] = 'MappingType';
nonterminalKindCABI[nonterminalKindCABI['MappingValue'] = 94] = 'MappingValue';
nonterminalKindCABI[nonterminalKindCABI['MemberAccessExpression'] = 95] = 'MemberAccessExpression';
nonterminalKindCABI[nonterminalKindCABI['ModifierAttribute'] = 96] = 'ModifierAttribute';
nonterminalKindCABI[nonterminalKindCABI['ModifierAttributes'] = 97] = 'ModifierAttributes';
nonterminalKindCABI[nonterminalKindCABI['ModifierDefinition'] = 98] = 'ModifierDefinition';
nonterminalKindCABI[nonterminalKindCABI['ModifierInvocation'] = 99] = 'ModifierInvocation';
nonterminalKindCABI[nonterminalKindCABI['MultiplicativeExpression'] = 100] = 'MultiplicativeExpression';
nonterminalKindCABI[nonterminalKindCABI['NamedArgument'] = 101] = 'NamedArgument';
nonterminalKindCABI[nonterminalKindCABI['NamedArgumentGroup'] = 102] = 'NamedArgumentGroup';
nonterminalKindCABI[nonterminalKindCABI['NamedArguments'] = 103] = 'NamedArguments';
nonterminalKindCABI[nonterminalKindCABI['NamedArgumentsDeclaration'] = 104] = 'NamedArgumentsDeclaration';
nonterminalKindCABI[nonterminalKindCABI['NamedImport'] = 105] = 'NamedImport';
nonterminalKindCABI[nonterminalKindCABI['NewExpression'] = 106] = 'NewExpression';
nonterminalKindCABI[nonterminalKindCABI['NumberUnit'] = 107] = 'NumberUnit';
nonterminalKindCABI[nonterminalKindCABI['OrExpression'] = 108] = 'OrExpression';
nonterminalKindCABI[nonterminalKindCABI['OverridePaths'] = 109] = 'OverridePaths';
nonterminalKindCABI[nonterminalKindCABI['OverridePathsDeclaration'] = 110] = 'OverridePathsDeclaration';
nonterminalKindCABI[nonterminalKindCABI['OverrideSpecifier'] = 111] = 'OverrideSpecifier';
nonterminalKindCABI[nonterminalKindCABI['Parameter'] = 112] = 'Parameter';
nonterminalKindCABI[nonterminalKindCABI['Parameters'] = 113] = 'Parameters';
nonterminalKindCABI[nonterminalKindCABI['ParametersDeclaration'] = 114] = 'ParametersDeclaration';
nonterminalKindCABI[nonterminalKindCABI['PathImport'] = 115] = 'PathImport';
nonterminalKindCABI[nonterminalKindCABI['PositionalArguments'] = 116] = 'PositionalArguments';
nonterminalKindCABI[nonterminalKindCABI['PositionalArgumentsDeclaration'] = 117] = 'PositionalArgumentsDeclaration';
nonterminalKindCABI[nonterminalKindCABI['PostfixExpression'] = 118] = 'PostfixExpression';
nonterminalKindCABI[nonterminalKindCABI['Pragma'] = 119] = 'Pragma';
nonterminalKindCABI[nonterminalKindCABI['PragmaDirective'] = 120] = 'PragmaDirective';
nonterminalKindCABI[nonterminalKindCABI['PrefixExpression'] = 121] = 'PrefixExpression';
nonterminalKindCABI[nonterminalKindCABI['ReceiveFunctionAttribute'] = 122] = 'ReceiveFunctionAttribute';
nonterminalKindCABI[nonterminalKindCABI['ReceiveFunctionAttributes'] = 123] = 'ReceiveFunctionAttributes';
nonterminalKindCABI[nonterminalKindCABI['ReceiveFunctionDefinition'] = 124] = 'ReceiveFunctionDefinition';
nonterminalKindCABI[nonterminalKindCABI['ReturnStatement'] = 125] = 'ReturnStatement';
nonterminalKindCABI[nonterminalKindCABI['ReturnsDeclaration'] = 126] = 'ReturnsDeclaration';
nonterminalKindCABI[nonterminalKindCABI['RevertStatement'] = 127] = 'RevertStatement';
nonterminalKindCABI[nonterminalKindCABI['ShiftExpression'] = 128] = 'ShiftExpression';
nonterminalKindCABI[nonterminalKindCABI['SimpleVersionLiteral'] = 129] = 'SimpleVersionLiteral';
nonterminalKindCABI[nonterminalKindCABI['SourceUnit'] = 130] = 'SourceUnit';
nonterminalKindCABI[nonterminalKindCABI['SourceUnitMember'] = 131] = 'SourceUnitMember';
nonterminalKindCABI[nonterminalKindCABI['SourceUnitMembers'] = 132] = 'SourceUnitMembers';
nonterminalKindCABI[nonterminalKindCABI['StateVariableAttribute'] = 133] = 'StateVariableAttribute';
nonterminalKindCABI[nonterminalKindCABI['StateVariableAttributes'] = 134] = 'StateVariableAttributes';
nonterminalKindCABI[nonterminalKindCABI['StateVariableDefinition'] = 135] = 'StateVariableDefinition';
nonterminalKindCABI[nonterminalKindCABI['StateVariableDefinitionValue'] = 136] = 'StateVariableDefinitionValue';
nonterminalKindCABI[nonterminalKindCABI['Statement'] = 137] = 'Statement';
nonterminalKindCABI[nonterminalKindCABI['Statements'] = 138] = 'Statements';
nonterminalKindCABI[nonterminalKindCABI['StorageLocation'] = 139] = 'StorageLocation';
nonterminalKindCABI[nonterminalKindCABI['StringExpression'] = 140] = 'StringExpression';
nonterminalKindCABI[nonterminalKindCABI['StringLiteral'] = 141] = 'StringLiteral';
nonterminalKindCABI[nonterminalKindCABI['StringLiterals'] = 142] = 'StringLiterals';
nonterminalKindCABI[nonterminalKindCABI['StructDefinition'] = 143] = 'StructDefinition';
nonterminalKindCABI[nonterminalKindCABI['StructMember'] = 144] = 'StructMember';
nonterminalKindCABI[nonterminalKindCABI['StructMembers'] = 145] = 'StructMembers';
nonterminalKindCABI[nonterminalKindCABI['TryStatement'] = 146] = 'TryStatement';
nonterminalKindCABI[nonterminalKindCABI['TupleDeconstructionElement'] = 147] = 'TupleDeconstructionElement';
nonterminalKindCABI[nonterminalKindCABI['TupleDeconstructionElements'] = 148] = 'TupleDeconstructionElements';
nonterminalKindCABI[nonterminalKindCABI['TupleDeconstructionStatement'] = 149] = 'TupleDeconstructionStatement';
nonterminalKindCABI[nonterminalKindCABI['TupleExpression'] = 150] = 'TupleExpression';
nonterminalKindCABI[nonterminalKindCABI['TupleMember'] = 151] = 'TupleMember';
nonterminalKindCABI[nonterminalKindCABI['TupleValue'] = 152] = 'TupleValue';
nonterminalKindCABI[nonterminalKindCABI['TupleValues'] = 153] = 'TupleValues';
nonterminalKindCABI[nonterminalKindCABI['TypeExpression'] = 154] = 'TypeExpression';
nonterminalKindCABI[nonterminalKindCABI['TypeName'] = 155] = 'TypeName';
nonterminalKindCABI[nonterminalKindCABI['TypedTupleMember'] = 156] = 'TypedTupleMember';
nonterminalKindCABI[nonterminalKindCABI['UncheckedBlock'] = 157] = 'UncheckedBlock';
nonterminalKindCABI[nonterminalKindCABI['UnicodeStringLiteral'] = 158] = 'UnicodeStringLiteral';
nonterminalKindCABI[nonterminalKindCABI['UnicodeStringLiterals'] = 159] = 'UnicodeStringLiterals';
nonterminalKindCABI[nonterminalKindCABI['UntypedTupleMember'] = 160] = 'UntypedTupleMember';
nonterminalKindCABI[nonterminalKindCABI['UserDefinedValueTypeDefinition'] = 161] = 'UserDefinedValueTypeDefinition';
nonterminalKindCABI[nonterminalKindCABI['UsingAlias'] = 162] = 'UsingAlias';
nonterminalKindCABI[nonterminalKindCABI['UsingClause'] = 163] = 'UsingClause';
nonterminalKindCABI[nonterminalKindCABI['UsingDeconstruction'] = 164] = 'UsingDeconstruction';
nonterminalKindCABI[nonterminalKindCABI['UsingDeconstructionSymbol'] = 165] = 'UsingDeconstructionSymbol';
nonterminalKindCABI[nonterminalKindCABI['UsingDeconstructionSymbols'] = 166] = 'UsingDeconstructionSymbols';
nonterminalKindCABI[nonterminalKindCABI['UsingDirective'] = 167] = 'UsingDirective';
nonterminalKindCABI[nonterminalKindCABI['UsingOperator'] = 168] = 'UsingOperator';
nonterminalKindCABI[nonterminalKindCABI['UsingTarget'] = 169] = 'UsingTarget';
nonterminalKindCABI[nonterminalKindCABI['VariableDeclarationStatement'] = 170] = 'VariableDeclarationStatement';
nonterminalKindCABI[nonterminalKindCABI['VariableDeclarationType'] = 171] = 'VariableDeclarationType';
nonterminalKindCABI[nonterminalKindCABI['VariableDeclarationValue'] = 172] = 'VariableDeclarationValue';
nonterminalKindCABI[nonterminalKindCABI['VersionExpression'] = 173] = 'VersionExpression';
nonterminalKindCABI[nonterminalKindCABI['VersionExpressionSet'] = 174] = 'VersionExpressionSet';
nonterminalKindCABI[nonterminalKindCABI['VersionExpressionSets'] = 175] = 'VersionExpressionSets';
nonterminalKindCABI[nonterminalKindCABI['VersionLiteral'] = 176] = 'VersionLiteral';
nonterminalKindCABI[nonterminalKindCABI['VersionOperator'] = 177] = 'VersionOperator';
nonterminalKindCABI[nonterminalKindCABI['VersionPragma'] = 178] = 'VersionPragma';
nonterminalKindCABI[nonterminalKindCABI['VersionRange'] = 179] = 'VersionRange';
nonterminalKindCABI[nonterminalKindCABI['VersionTerm'] = 180] = 'VersionTerm';
nonterminalKindCABI[nonterminalKindCABI['WhileStatement'] = 181] = 'WhileStatement';
nonterminalKindCABI[nonterminalKindCABI['YulArguments'] = 182] = 'YulArguments';
nonterminalKindCABI[nonterminalKindCABI['YulAssignmentOperator'] = 183] = 'YulAssignmentOperator';
nonterminalKindCABI[nonterminalKindCABI['YulBlock'] = 184] = 'YulBlock';
nonterminalKindCABI[nonterminalKindCABI['YulBreakStatement'] = 185] = 'YulBreakStatement';
nonterminalKindCABI[nonterminalKindCABI['YulContinueStatement'] = 186] = 'YulContinueStatement';
nonterminalKindCABI[nonterminalKindCABI['YulDefaultCase'] = 187] = 'YulDefaultCase';
nonterminalKindCABI[nonterminalKindCABI['YulExpression'] = 188] = 'YulExpression';
nonterminalKindCABI[nonterminalKindCABI['YulForStatement'] = 189] = 'YulForStatement';
nonterminalKindCABI[nonterminalKindCABI['YulFunctionCallExpression'] = 190] = 'YulFunctionCallExpression';
nonterminalKindCABI[nonterminalKindCABI['YulFunctionDefinition'] = 191] = 'YulFunctionDefinition';
nonterminalKindCABI[nonterminalKindCABI['YulIfStatement'] = 192] = 'YulIfStatement';
nonterminalKindCABI[nonterminalKindCABI['YulLeaveStatement'] = 193] = 'YulLeaveStatement';
nonterminalKindCABI[nonterminalKindCABI['YulLiteral'] = 194] = 'YulLiteral';
nonterminalKindCABI[nonterminalKindCABI['YulParameters'] = 195] = 'YulParameters';
nonterminalKindCABI[nonterminalKindCABI['YulParametersDeclaration'] = 196] = 'YulParametersDeclaration';
nonterminalKindCABI[nonterminalKindCABI['YulPath'] = 197] = 'YulPath';
nonterminalKindCABI[nonterminalKindCABI['YulPaths'] = 198] = 'YulPaths';
nonterminalKindCABI[nonterminalKindCABI['YulReturnsDeclaration'] = 199] = 'YulReturnsDeclaration';
nonterminalKindCABI[nonterminalKindCABI['YulStatement'] = 200] = 'YulStatement';
nonterminalKindCABI[nonterminalKindCABI['YulStatements'] = 201] = 'YulStatements';
nonterminalKindCABI[nonterminalKindCABI['YulSwitchCase'] = 202] = 'YulSwitchCase';
nonterminalKindCABI[nonterminalKindCABI['YulSwitchCases'] = 203] = 'YulSwitchCases';
nonterminalKindCABI[nonterminalKindCABI['YulSwitchStatement'] = 204] = 'YulSwitchStatement';
nonterminalKindCABI[nonterminalKindCABI['YulValueCase'] = 205] = 'YulValueCase';
nonterminalKindCABI[nonterminalKindCABI['YulVariableAssignmentStatement'] = 206] = 'YulVariableAssignmentStatement';
nonterminalKindCABI[nonterminalKindCABI['YulVariableDeclarationStatement'] = 207] = 'YulVariableDeclarationStatement';
nonterminalKindCABI[nonterminalKindCABI['YulVariableDeclarationValue'] = 208] = 'YulVariableDeclarationValue';
nonterminalKindCABI[nonterminalKindCABI['YulVariableNames'] = 209] = 'YulVariableNames';

var terminalKind = {};
terminalKind['Unrecognized'] = 'Unrecognized';
terminalKind['Missing'] = 'Missing';
terminalKind['ABIEncoderV2Keyword'] = 'ABIEncoderV2Keyword';
terminalKind['AbicoderKeyword'] = 'AbicoderKeyword';
terminalKind['AbicoderV1Keyword'] = 'AbicoderV1Keyword';
terminalKind['AbicoderV2Keyword'] = 'AbicoderV2Keyword';
terminalKind['AbstractKeyword'] = 'AbstractKeyword';
terminalKind['AddressKeyword'] = 'AddressKeyword';
terminalKind['AddressLiteral'] = 'AddressLiteral';
terminalKind['AfterKeyword'] = 'AfterKeyword';
terminalKind['AliasKeyword'] = 'AliasKeyword';
terminalKind['Ampersand'] = 'Ampersand';
terminalKind['AmpersandAmpersand'] = 'AmpersandAmpersand';
terminalKind['AmpersandEqual'] = 'AmpersandEqual';
terminalKind['AnonymousKeyword'] = 'AnonymousKeyword';
terminalKind['ApplyKeyword'] = 'ApplyKeyword';
terminalKind['AsKeyword'] = 'AsKeyword';
terminalKind['AssemblyKeyword'] = 'AssemblyKeyword';
terminalKind['Asterisk'] = 'Asterisk';
terminalKind['AsteriskAsterisk'] = 'AsteriskAsterisk';
terminalKind['AsteriskEqual'] = 'AsteriskEqual';
terminalKind['AutoKeyword'] = 'AutoKeyword';
terminalKind['Bang'] = 'Bang';
terminalKind['BangEqual'] = 'BangEqual';
terminalKind['Bar'] = 'Bar';
terminalKind['BarBar'] = 'BarBar';
terminalKind['BarEqual'] = 'BarEqual';
terminalKind['BoolKeyword'] = 'BoolKeyword';
terminalKind['BreakKeyword'] = 'BreakKeyword';
terminalKind['ByteKeyword'] = 'ByteKeyword';
terminalKind['BytesKeyword'] = 'BytesKeyword';
terminalKind['CallDataKeyword'] = 'CallDataKeyword';
terminalKind['Caret'] = 'Caret';
terminalKind['CaretEqual'] = 'CaretEqual';
terminalKind['CaseKeyword'] = 'CaseKeyword';
terminalKind['CatchKeyword'] = 'CatchKeyword';
terminalKind['CloseBrace'] = 'CloseBrace';
terminalKind['CloseBracket'] = 'CloseBracket';
terminalKind['CloseParen'] = 'CloseParen';
terminalKind['Colon'] = 'Colon';
terminalKind['ColonEqual'] = 'ColonEqual';
terminalKind['Comma'] = 'Comma';
terminalKind['ConstantKeyword'] = 'ConstantKeyword';
terminalKind['ConstructorKeyword'] = 'ConstructorKeyword';
terminalKind['ContinueKeyword'] = 'ContinueKeyword';
terminalKind['ContractKeyword'] = 'ContractKeyword';
terminalKind['CopyOfKeyword'] = 'CopyOfKeyword';
terminalKind['DaysKeyword'] = 'DaysKeyword';
terminalKind['DecimalLiteral'] = 'DecimalLiteral';
terminalKind['DefaultKeyword'] = 'DefaultKeyword';
terminalKind['DefineKeyword'] = 'DefineKeyword';
terminalKind['DeleteKeyword'] = 'DeleteKeyword';
terminalKind['DoKeyword'] = 'DoKeyword';
terminalKind['DoubleQuotedHexStringLiteral'] = 'DoubleQuotedHexStringLiteral';
terminalKind['DoubleQuotedStringLiteral'] = 'DoubleQuotedStringLiteral';
terminalKind['DoubleQuotedUnicodeStringLiteral'] = 'DoubleQuotedUnicodeStringLiteral';
terminalKind['DoubleQuotedVersionLiteral'] = 'DoubleQuotedVersionLiteral';
terminalKind['ElseKeyword'] = 'ElseKeyword';
terminalKind['EmitKeyword'] = 'EmitKeyword';
terminalKind['EndOfLine'] = 'EndOfLine';
terminalKind['EnumKeyword'] = 'EnumKeyword';
terminalKind['Equal'] = 'Equal';
terminalKind['EqualEqual'] = 'EqualEqual';
terminalKind['EqualGreaterThan'] = 'EqualGreaterThan';
terminalKind['ErrorKeyword'] = 'ErrorKeyword';
terminalKind['EventKeyword'] = 'EventKeyword';
terminalKind['ExperimentalKeyword'] = 'ExperimentalKeyword';
terminalKind['ExternalKeyword'] = 'ExternalKeyword';
terminalKind['FallbackKeyword'] = 'FallbackKeyword';
terminalKind['FalseKeyword'] = 'FalseKeyword';
terminalKind['FinalKeyword'] = 'FinalKeyword';
terminalKind['FixedKeyword'] = 'FixedKeyword';
terminalKind['ForKeyword'] = 'ForKeyword';
terminalKind['FromKeyword'] = 'FromKeyword';
terminalKind['FunctionKeyword'] = 'FunctionKeyword';
terminalKind['GlobalKeyword'] = 'GlobalKeyword';
terminalKind['GreaterThan'] = 'GreaterThan';
terminalKind['GreaterThanEqual'] = 'GreaterThanEqual';
terminalKind['GreaterThanGreaterThan'] = 'GreaterThanGreaterThan';
terminalKind['GreaterThanGreaterThanEqual'] = 'GreaterThanGreaterThanEqual';
terminalKind['GreaterThanGreaterThanGreaterThan'] = 'GreaterThanGreaterThanGreaterThan';
terminalKind['GreaterThanGreaterThanGreaterThanEqual'] = 'GreaterThanGreaterThanGreaterThanEqual';
terminalKind['HexKeyword'] = 'HexKeyword';
terminalKind['HexLiteral'] = 'HexLiteral';
terminalKind['HoursKeyword'] = 'HoursKeyword';
terminalKind['HyperionKeyword'] = 'HyperionKeyword';
terminalKind['Identifier'] = 'Identifier';
terminalKind['IfKeyword'] = 'IfKeyword';
terminalKind['ImmutableKeyword'] = 'ImmutableKeyword';
terminalKind['ImplementsKeyword'] = 'ImplementsKeyword';
terminalKind['ImportKeyword'] = 'ImportKeyword';
terminalKind['InKeyword'] = 'InKeyword';
terminalKind['IndexedKeyword'] = 'IndexedKeyword';
terminalKind['InlineKeyword'] = 'InlineKeyword';
terminalKind['IntKeyword'] = 'IntKeyword';
terminalKind['InterfaceKeyword'] = 'InterfaceKeyword';
terminalKind['InternalKeyword'] = 'InternalKeyword';
terminalKind['IsKeyword'] = 'IsKeyword';
terminalKind['LessThan'] = 'LessThan';
terminalKind['LessThanEqual'] = 'LessThanEqual';
terminalKind['LessThanLessThan'] = 'LessThanLessThan';
terminalKind['LessThanLessThanEqual'] = 'LessThanLessThanEqual';
terminalKind['LetKeyword'] = 'LetKeyword';
terminalKind['LibraryKeyword'] = 'LibraryKeyword';
terminalKind['MacroKeyword'] = 'MacroKeyword';
terminalKind['MappingKeyword'] = 'MappingKeyword';
terminalKind['MatchKeyword'] = 'MatchKeyword';
terminalKind['MemoryKeyword'] = 'MemoryKeyword';
terminalKind['Minus'] = 'Minus';
terminalKind['MinusEqual'] = 'MinusEqual';
terminalKind['MinusGreaterThan'] = 'MinusGreaterThan';
terminalKind['MinusMinus'] = 'MinusMinus';
terminalKind['MinutesKeyword'] = 'MinutesKeyword';
terminalKind['ModifierKeyword'] = 'ModifierKeyword';
terminalKind['MultiLineComment'] = 'MultiLineComment';
terminalKind['MultiLineNatSpecComment'] = 'MultiLineNatSpecComment';
terminalKind['MutableKeyword'] = 'MutableKeyword';
terminalKind['NewKeyword'] = 'NewKeyword';
terminalKind['NullKeyword'] = 'NullKeyword';
terminalKind['OfKeyword'] = 'OfKeyword';
terminalKind['OpenBrace'] = 'OpenBrace';
terminalKind['OpenBracket'] = 'OpenBracket';
terminalKind['OpenParen'] = 'OpenParen';
terminalKind['OverrideKeyword'] = 'OverrideKeyword';
terminalKind['PartialKeyword'] = 'PartialKeyword';
terminalKind['PayableKeyword'] = 'PayableKeyword';
terminalKind['Percent'] = 'Percent';
terminalKind['PercentEqual'] = 'PercentEqual';
terminalKind['Period'] = 'Period';
terminalKind['PlanckKeyword'] = 'PlanckKeyword';
terminalKind['Plus'] = 'Plus';
terminalKind['PlusEqual'] = 'PlusEqual';
terminalKind['PlusPlus'] = 'PlusPlus';
terminalKind['PragmaKeyword'] = 'PragmaKeyword';
terminalKind['PrivateKeyword'] = 'PrivateKeyword';
terminalKind['PromiseKeyword'] = 'PromiseKeyword';
terminalKind['PublicKeyword'] = 'PublicKeyword';
terminalKind['PureKeyword'] = 'PureKeyword';
terminalKind['QuantaKeyword'] = 'QuantaKeyword';
terminalKind['QuestionMark'] = 'QuestionMark';
terminalKind['ReceiveKeyword'] = 'ReceiveKeyword';
terminalKind['ReferenceKeyword'] = 'ReferenceKeyword';
terminalKind['RelocatableKeyword'] = 'RelocatableKeyword';
terminalKind['ReturnKeyword'] = 'ReturnKeyword';
terminalKind['ReturnsKeyword'] = 'ReturnsKeyword';
terminalKind['RevertKeyword'] = 'RevertKeyword';
terminalKind['SMTCheckerKeyword'] = 'SMTCheckerKeyword';
terminalKind['SealedKeyword'] = 'SealedKeyword';
terminalKind['SecondsKeyword'] = 'SecondsKeyword';
terminalKind['Semicolon'] = 'Semicolon';
terminalKind['ShorKeyword'] = 'ShorKeyword';
terminalKind['SingleLineComment'] = 'SingleLineComment';
terminalKind['SingleLineNatSpecComment'] = 'SingleLineNatSpecComment';
terminalKind['SingleQuotedHexStringLiteral'] = 'SingleQuotedHexStringLiteral';
terminalKind['SingleQuotedStringLiteral'] = 'SingleQuotedStringLiteral';
terminalKind['SingleQuotedUnicodeStringLiteral'] = 'SingleQuotedUnicodeStringLiteral';
terminalKind['SingleQuotedVersionLiteral'] = 'SingleQuotedVersionLiteral';
terminalKind['SizeOfKeyword'] = 'SizeOfKeyword';
terminalKind['Slash'] = 'Slash';
terminalKind['SlashEqual'] = 'SlashEqual';
terminalKind['StaticKeyword'] = 'StaticKeyword';
terminalKind['StorageKeyword'] = 'StorageKeyword';
terminalKind['StringKeyword'] = 'StringKeyword';
terminalKind['StructKeyword'] = 'StructKeyword';
terminalKind['SuperKeyword'] = 'SuperKeyword';
terminalKind['SupportsKeyword'] = 'SupportsKeyword';
terminalKind['SwitchKeyword'] = 'SwitchKeyword';
terminalKind['ThisKeyword'] = 'ThisKeyword';
terminalKind['Tilde'] = 'Tilde';
terminalKind['TrueKeyword'] = 'TrueKeyword';
terminalKind['TryKeyword'] = 'TryKeyword';
terminalKind['TypeDefKeyword'] = 'TypeDefKeyword';
terminalKind['TypeKeyword'] = 'TypeKeyword';
terminalKind['TypeOfKeyword'] = 'TypeOfKeyword';
terminalKind['UfixedKeyword'] = 'UfixedKeyword';
terminalKind['UintKeyword'] = 'UintKeyword';
terminalKind['UncheckedKeyword'] = 'UncheckedKeyword';
terminalKind['UsingKeyword'] = 'UsingKeyword';
terminalKind['VarKeyword'] = 'VarKeyword';
terminalKind['VersionSpecifier'] = 'VersionSpecifier';
terminalKind['ViewKeyword'] = 'ViewKeyword';
terminalKind['VirtualKeyword'] = 'VirtualKeyword';
terminalKind['WeeksKeyword'] = 'WeeksKeyword';
terminalKind['WhileKeyword'] = 'WhileKeyword';
terminalKind['Whitespace'] = 'Whitespace';
terminalKind['YulBreakKeyword'] = 'YulBreakKeyword';
terminalKind['YulCaseKeyword'] = 'YulCaseKeyword';
terminalKind['YulContinueKeyword'] = 'YulContinueKeyword';
terminalKind['YulDecimalLiteral'] = 'YulDecimalLiteral';
terminalKind['YulDefaultKeyword'] = 'YulDefaultKeyword';
terminalKind['YulFalseKeyword'] = 'YulFalseKeyword';
terminalKind['YulForKeyword'] = 'YulForKeyword';
terminalKind['YulFunctionKeyword'] = 'YulFunctionKeyword';
terminalKind['YulHexKeyword'] = 'YulHexKeyword';
terminalKind['YulHexLiteral'] = 'YulHexLiteral';
terminalKind['YulIdentifier'] = 'YulIdentifier';
terminalKind['YulIfKeyword'] = 'YulIfKeyword';
terminalKind['YulLeaveKeyword'] = 'YulLeaveKeyword';
terminalKind['YulLetKeyword'] = 'YulLetKeyword';
terminalKind['YulSuperKeyword'] = 'YulSuperKeyword';
terminalKind['YulSwitchKeyword'] = 'YulSwitchKeyword';
terminalKind['YulThisKeyword'] = 'YulThisKeyword';
terminalKind['YulTrueKeyword'] = 'YulTrueKeyword';

var terminalKindCABI = {};
terminalKindCABI[terminalKindCABI['Unrecognized'] = 0] = 'Unrecognized';
terminalKindCABI[terminalKindCABI['Missing'] = 1] = 'Missing';
terminalKindCABI[terminalKindCABI['ABIEncoderV2Keyword'] = 2] = 'ABIEncoderV2Keyword';
terminalKindCABI[terminalKindCABI['AbicoderKeyword'] = 3] = 'AbicoderKeyword';
terminalKindCABI[terminalKindCABI['AbicoderV1Keyword'] = 4] = 'AbicoderV1Keyword';
terminalKindCABI[terminalKindCABI['AbicoderV2Keyword'] = 5] = 'AbicoderV2Keyword';
terminalKindCABI[terminalKindCABI['AbstractKeyword'] = 6] = 'AbstractKeyword';
terminalKindCABI[terminalKindCABI['AddressKeyword'] = 7] = 'AddressKeyword';
terminalKindCABI[terminalKindCABI['AddressLiteral'] = 8] = 'AddressLiteral';
terminalKindCABI[terminalKindCABI['AfterKeyword'] = 9] = 'AfterKeyword';
terminalKindCABI[terminalKindCABI['AliasKeyword'] = 10] = 'AliasKeyword';
terminalKindCABI[terminalKindCABI['Ampersand'] = 11] = 'Ampersand';
terminalKindCABI[terminalKindCABI['AmpersandAmpersand'] = 12] = 'AmpersandAmpersand';
terminalKindCABI[terminalKindCABI['AmpersandEqual'] = 13] = 'AmpersandEqual';
terminalKindCABI[terminalKindCABI['AnonymousKeyword'] = 14] = 'AnonymousKeyword';
terminalKindCABI[terminalKindCABI['ApplyKeyword'] = 15] = 'ApplyKeyword';
terminalKindCABI[terminalKindCABI['AsKeyword'] = 16] = 'AsKeyword';
terminalKindCABI[terminalKindCABI['AssemblyKeyword'] = 17] = 'AssemblyKeyword';
terminalKindCABI[terminalKindCABI['Asterisk'] = 18] = 'Asterisk';
terminalKindCABI[terminalKindCABI['AsteriskAsterisk'] = 19] = 'AsteriskAsterisk';
terminalKindCABI[terminalKindCABI['AsteriskEqual'] = 20] = 'AsteriskEqual';
terminalKindCABI[terminalKindCABI['AutoKeyword'] = 21] = 'AutoKeyword';
terminalKindCABI[terminalKindCABI['Bang'] = 22] = 'Bang';
terminalKindCABI[terminalKindCABI['BangEqual'] = 23] = 'BangEqual';
terminalKindCABI[terminalKindCABI['Bar'] = 24] = 'Bar';
terminalKindCABI[terminalKindCABI['BarBar'] = 25] = 'BarBar';
terminalKindCABI[terminalKindCABI['BarEqual'] = 26] = 'BarEqual';
terminalKindCABI[terminalKindCABI['BoolKeyword'] = 27] = 'BoolKeyword';
terminalKindCABI[terminalKindCABI['BreakKeyword'] = 28] = 'BreakKeyword';
terminalKindCABI[terminalKindCABI['ByteKeyword'] = 29] = 'ByteKeyword';
terminalKindCABI[terminalKindCABI['BytesKeyword'] = 30] = 'BytesKeyword';
terminalKindCABI[terminalKindCABI['CallDataKeyword'] = 31] = 'CallDataKeyword';
terminalKindCABI[terminalKindCABI['Caret'] = 32] = 'Caret';
terminalKindCABI[terminalKindCABI['CaretEqual'] = 33] = 'CaretEqual';
terminalKindCABI[terminalKindCABI['CaseKeyword'] = 34] = 'CaseKeyword';
terminalKindCABI[terminalKindCABI['CatchKeyword'] = 35] = 'CatchKeyword';
terminalKindCABI[terminalKindCABI['CloseBrace'] = 36] = 'CloseBrace';
terminalKindCABI[terminalKindCABI['CloseBracket'] = 37] = 'CloseBracket';
terminalKindCABI[terminalKindCABI['CloseParen'] = 38] = 'CloseParen';
terminalKindCABI[terminalKindCABI['Colon'] = 39] = 'Colon';
terminalKindCABI[terminalKindCABI['ColonEqual'] = 40] = 'ColonEqual';
terminalKindCABI[terminalKindCABI['Comma'] = 41] = 'Comma';
terminalKindCABI[terminalKindCABI['ConstantKeyword'] = 42] = 'ConstantKeyword';
terminalKindCABI[terminalKindCABI['ConstructorKeyword'] = 43] = 'ConstructorKeyword';
terminalKindCABI[terminalKindCABI['ContinueKeyword'] = 44] = 'ContinueKeyword';
terminalKindCABI[terminalKindCABI['ContractKeyword'] = 45] = 'ContractKeyword';
terminalKindCABI[terminalKindCABI['CopyOfKeyword'] = 46] = 'CopyOfKeyword';
terminalKindCABI[terminalKindCABI['DaysKeyword'] = 47] = 'DaysKeyword';
terminalKindCABI[terminalKindCABI['DecimalLiteral'] = 48] = 'DecimalLiteral';
terminalKindCABI[terminalKindCABI['DefaultKeyword'] = 49] = 'DefaultKeyword';
terminalKindCABI[terminalKindCABI['DefineKeyword'] = 50] = 'DefineKeyword';
terminalKindCABI[terminalKindCABI['DeleteKeyword'] = 51] = 'DeleteKeyword';
terminalKindCABI[terminalKindCABI['DoKeyword'] = 52] = 'DoKeyword';
terminalKindCABI[terminalKindCABI['DoubleQuotedHexStringLiteral'] = 53] = 'DoubleQuotedHexStringLiteral';
terminalKindCABI[terminalKindCABI['DoubleQuotedStringLiteral'] = 54] = 'DoubleQuotedStringLiteral';
terminalKindCABI[terminalKindCABI['DoubleQuotedUnicodeStringLiteral'] = 55] = 'DoubleQuotedUnicodeStringLiteral';
terminalKindCABI[terminalKindCABI['DoubleQuotedVersionLiteral'] = 56] = 'DoubleQuotedVersionLiteral';
terminalKindCABI[terminalKindCABI['ElseKeyword'] = 57] = 'ElseKeyword';
terminalKindCABI[terminalKindCABI['EmitKeyword'] = 58] = 'EmitKeyword';
terminalKindCABI[terminalKindCABI['EndOfLine'] = 59] = 'EndOfLine';
terminalKindCABI[terminalKindCABI['EnumKeyword'] = 60] = 'EnumKeyword';
terminalKindCABI[terminalKindCABI['Equal'] = 61] = 'Equal';
terminalKindCABI[terminalKindCABI['EqualEqual'] = 62] = 'EqualEqual';
terminalKindCABI[terminalKindCABI['EqualGreaterThan'] = 63] = 'EqualGreaterThan';
terminalKindCABI[terminalKindCABI['ErrorKeyword'] = 64] = 'ErrorKeyword';
terminalKindCABI[terminalKindCABI['EventKeyword'] = 65] = 'EventKeyword';
terminalKindCABI[terminalKindCABI['ExperimentalKeyword'] = 66] = 'ExperimentalKeyword';
terminalKindCABI[terminalKindCABI['ExternalKeyword'] = 67] = 'ExternalKeyword';
terminalKindCABI[terminalKindCABI['FallbackKeyword'] = 68] = 'FallbackKeyword';
terminalKindCABI[terminalKindCABI['FalseKeyword'] = 69] = 'FalseKeyword';
terminalKindCABI[terminalKindCABI['FinalKeyword'] = 70] = 'FinalKeyword';
terminalKindCABI[terminalKindCABI['FixedKeyword'] = 71] = 'FixedKeyword';
terminalKindCABI[terminalKindCABI['ForKeyword'] = 72] = 'ForKeyword';
terminalKindCABI[terminalKindCABI['FromKeyword'] = 73] = 'FromKeyword';
terminalKindCABI[terminalKindCABI['FunctionKeyword'] = 74] = 'FunctionKeyword';
terminalKindCABI[terminalKindCABI['GlobalKeyword'] = 75] = 'GlobalKeyword';
terminalKindCABI[terminalKindCABI['GreaterThan'] = 76] = 'GreaterThan';
terminalKindCABI[terminalKindCABI['GreaterThanEqual'] = 77] = 'GreaterThanEqual';
terminalKindCABI[terminalKindCABI['GreaterThanGreaterThan'] = 78] = 'GreaterThanGreaterThan';
terminalKindCABI[terminalKindCABI['GreaterThanGreaterThanEqual'] = 79] = 'GreaterThanGreaterThanEqual';
terminalKindCABI[terminalKindCABI['GreaterThanGreaterThanGreaterThan'] = 80] = 'GreaterThanGreaterThanGreaterThan';
terminalKindCABI[terminalKindCABI['GreaterThanGreaterThanGreaterThanEqual'] = 81] = 'GreaterThanGreaterThanGreaterThanEqual';
terminalKindCABI[terminalKindCABI['HexKeyword'] = 82] = 'HexKeyword';
terminalKindCABI[terminalKindCABI['HexLiteral'] = 83] = 'HexLiteral';
terminalKindCABI[terminalKindCABI['HoursKeyword'] = 84] = 'HoursKeyword';
terminalKindCABI[terminalKindCABI['HyperionKeyword'] = 85] = 'HyperionKeyword';
terminalKindCABI[terminalKindCABI['Identifier'] = 86] = 'Identifier';
terminalKindCABI[terminalKindCABI['IfKeyword'] = 87] = 'IfKeyword';
terminalKindCABI[terminalKindCABI['ImmutableKeyword'] = 88] = 'ImmutableKeyword';
terminalKindCABI[terminalKindCABI['ImplementsKeyword'] = 89] = 'ImplementsKeyword';
terminalKindCABI[terminalKindCABI['ImportKeyword'] = 90] = 'ImportKeyword';
terminalKindCABI[terminalKindCABI['InKeyword'] = 91] = 'InKeyword';
terminalKindCABI[terminalKindCABI['IndexedKeyword'] = 92] = 'IndexedKeyword';
terminalKindCABI[terminalKindCABI['InlineKeyword'] = 93] = 'InlineKeyword';
terminalKindCABI[terminalKindCABI['IntKeyword'] = 94] = 'IntKeyword';
terminalKindCABI[terminalKindCABI['InterfaceKeyword'] = 95] = 'InterfaceKeyword';
terminalKindCABI[terminalKindCABI['InternalKeyword'] = 96] = 'InternalKeyword';
terminalKindCABI[terminalKindCABI['IsKeyword'] = 97] = 'IsKeyword';
terminalKindCABI[terminalKindCABI['LessThan'] = 98] = 'LessThan';
terminalKindCABI[terminalKindCABI['LessThanEqual'] = 99] = 'LessThanEqual';
terminalKindCABI[terminalKindCABI['LessThanLessThan'] = 100] = 'LessThanLessThan';
terminalKindCABI[terminalKindCABI['LessThanLessThanEqual'] = 101] = 'LessThanLessThanEqual';
terminalKindCABI[terminalKindCABI['LetKeyword'] = 102] = 'LetKeyword';
terminalKindCABI[terminalKindCABI['LibraryKeyword'] = 103] = 'LibraryKeyword';
terminalKindCABI[terminalKindCABI['MacroKeyword'] = 104] = 'MacroKeyword';
terminalKindCABI[terminalKindCABI['MappingKeyword'] = 105] = 'MappingKeyword';
terminalKindCABI[terminalKindCABI['MatchKeyword'] = 106] = 'MatchKeyword';
terminalKindCABI[terminalKindCABI['MemoryKeyword'] = 107] = 'MemoryKeyword';
terminalKindCABI[terminalKindCABI['Minus'] = 108] = 'Minus';
terminalKindCABI[terminalKindCABI['MinusEqual'] = 109] = 'MinusEqual';
terminalKindCABI[terminalKindCABI['MinusGreaterThan'] = 110] = 'MinusGreaterThan';
terminalKindCABI[terminalKindCABI['MinusMinus'] = 111] = 'MinusMinus';
terminalKindCABI[terminalKindCABI['MinutesKeyword'] = 112] = 'MinutesKeyword';
terminalKindCABI[terminalKindCABI['ModifierKeyword'] = 113] = 'ModifierKeyword';
terminalKindCABI[terminalKindCABI['MultiLineComment'] = 114] = 'MultiLineComment';
terminalKindCABI[terminalKindCABI['MultiLineNatSpecComment'] = 115] = 'MultiLineNatSpecComment';
terminalKindCABI[terminalKindCABI['MutableKeyword'] = 116] = 'MutableKeyword';
terminalKindCABI[terminalKindCABI['NewKeyword'] = 117] = 'NewKeyword';
terminalKindCABI[terminalKindCABI['NullKeyword'] = 118] = 'NullKeyword';
terminalKindCABI[terminalKindCABI['OfKeyword'] = 119] = 'OfKeyword';
terminalKindCABI[terminalKindCABI['OpenBrace'] = 120] = 'OpenBrace';
terminalKindCABI[terminalKindCABI['OpenBracket'] = 121] = 'OpenBracket';
terminalKindCABI[terminalKindCABI['OpenParen'] = 122] = 'OpenParen';
terminalKindCABI[terminalKindCABI['OverrideKeyword'] = 123] = 'OverrideKeyword';
terminalKindCABI[terminalKindCABI['PartialKeyword'] = 124] = 'PartialKeyword';
terminalKindCABI[terminalKindCABI['PayableKeyword'] = 125] = 'PayableKeyword';
terminalKindCABI[terminalKindCABI['Percent'] = 126] = 'Percent';
terminalKindCABI[terminalKindCABI['PercentEqual'] = 127] = 'PercentEqual';
terminalKindCABI[terminalKindCABI['Period'] = 128] = 'Period';
terminalKindCABI[terminalKindCABI['PlanckKeyword'] = 129] = 'PlanckKeyword';
terminalKindCABI[terminalKindCABI['Plus'] = 130] = 'Plus';
terminalKindCABI[terminalKindCABI['PlusEqual'] = 131] = 'PlusEqual';
terminalKindCABI[terminalKindCABI['PlusPlus'] = 132] = 'PlusPlus';
terminalKindCABI[terminalKindCABI['PragmaKeyword'] = 133] = 'PragmaKeyword';
terminalKindCABI[terminalKindCABI['PrivateKeyword'] = 134] = 'PrivateKeyword';
terminalKindCABI[terminalKindCABI['PromiseKeyword'] = 135] = 'PromiseKeyword';
terminalKindCABI[terminalKindCABI['PublicKeyword'] = 136] = 'PublicKeyword';
terminalKindCABI[terminalKindCABI['PureKeyword'] = 137] = 'PureKeyword';
terminalKindCABI[terminalKindCABI['QuantaKeyword'] = 138] = 'QuantaKeyword';
terminalKindCABI[terminalKindCABI['QuestionMark'] = 139] = 'QuestionMark';
terminalKindCABI[terminalKindCABI['ReceiveKeyword'] = 140] = 'ReceiveKeyword';
terminalKindCABI[terminalKindCABI['ReferenceKeyword'] = 141] = 'ReferenceKeyword';
terminalKindCABI[terminalKindCABI['RelocatableKeyword'] = 142] = 'RelocatableKeyword';
terminalKindCABI[terminalKindCABI['ReturnKeyword'] = 143] = 'ReturnKeyword';
terminalKindCABI[terminalKindCABI['ReturnsKeyword'] = 144] = 'ReturnsKeyword';
terminalKindCABI[terminalKindCABI['RevertKeyword'] = 145] = 'RevertKeyword';
terminalKindCABI[terminalKindCABI['SMTCheckerKeyword'] = 146] = 'SMTCheckerKeyword';
terminalKindCABI[terminalKindCABI['SealedKeyword'] = 147] = 'SealedKeyword';
terminalKindCABI[terminalKindCABI['SecondsKeyword'] = 148] = 'SecondsKeyword';
terminalKindCABI[terminalKindCABI['Semicolon'] = 149] = 'Semicolon';
terminalKindCABI[terminalKindCABI['ShorKeyword'] = 150] = 'ShorKeyword';
terminalKindCABI[terminalKindCABI['SingleLineComment'] = 151] = 'SingleLineComment';
terminalKindCABI[terminalKindCABI['SingleLineNatSpecComment'] = 152] = 'SingleLineNatSpecComment';
terminalKindCABI[terminalKindCABI['SingleQuotedHexStringLiteral'] = 153] = 'SingleQuotedHexStringLiteral';
terminalKindCABI[terminalKindCABI['SingleQuotedStringLiteral'] = 154] = 'SingleQuotedStringLiteral';
terminalKindCABI[terminalKindCABI['SingleQuotedUnicodeStringLiteral'] = 155] = 'SingleQuotedUnicodeStringLiteral';
terminalKindCABI[terminalKindCABI['SingleQuotedVersionLiteral'] = 156] = 'SingleQuotedVersionLiteral';
terminalKindCABI[terminalKindCABI['SizeOfKeyword'] = 157] = 'SizeOfKeyword';
terminalKindCABI[terminalKindCABI['Slash'] = 158] = 'Slash';
terminalKindCABI[terminalKindCABI['SlashEqual'] = 159] = 'SlashEqual';
terminalKindCABI[terminalKindCABI['StaticKeyword'] = 160] = 'StaticKeyword';
terminalKindCABI[terminalKindCABI['StorageKeyword'] = 161] = 'StorageKeyword';
terminalKindCABI[terminalKindCABI['StringKeyword'] = 162] = 'StringKeyword';
terminalKindCABI[terminalKindCABI['StructKeyword'] = 163] = 'StructKeyword';
terminalKindCABI[terminalKindCABI['SuperKeyword'] = 164] = 'SuperKeyword';
terminalKindCABI[terminalKindCABI['SupportsKeyword'] = 165] = 'SupportsKeyword';
terminalKindCABI[terminalKindCABI['SwitchKeyword'] = 166] = 'SwitchKeyword';
terminalKindCABI[terminalKindCABI['ThisKeyword'] = 167] = 'ThisKeyword';
terminalKindCABI[terminalKindCABI['Tilde'] = 168] = 'Tilde';
terminalKindCABI[terminalKindCABI['TrueKeyword'] = 169] = 'TrueKeyword';
terminalKindCABI[terminalKindCABI['TryKeyword'] = 170] = 'TryKeyword';
terminalKindCABI[terminalKindCABI['TypeDefKeyword'] = 171] = 'TypeDefKeyword';
terminalKindCABI[terminalKindCABI['TypeKeyword'] = 172] = 'TypeKeyword';
terminalKindCABI[terminalKindCABI['TypeOfKeyword'] = 173] = 'TypeOfKeyword';
terminalKindCABI[terminalKindCABI['UfixedKeyword'] = 174] = 'UfixedKeyword';
terminalKindCABI[terminalKindCABI['UintKeyword'] = 175] = 'UintKeyword';
terminalKindCABI[terminalKindCABI['UncheckedKeyword'] = 176] = 'UncheckedKeyword';
terminalKindCABI[terminalKindCABI['UsingKeyword'] = 177] = 'UsingKeyword';
terminalKindCABI[terminalKindCABI['VarKeyword'] = 178] = 'VarKeyword';
terminalKindCABI[terminalKindCABI['VersionSpecifier'] = 179] = 'VersionSpecifier';
terminalKindCABI[terminalKindCABI['ViewKeyword'] = 180] = 'ViewKeyword';
terminalKindCABI[terminalKindCABI['VirtualKeyword'] = 181] = 'VirtualKeyword';
terminalKindCABI[terminalKindCABI['WeeksKeyword'] = 182] = 'WeeksKeyword';
terminalKindCABI[terminalKindCABI['WhileKeyword'] = 183] = 'WhileKeyword';
terminalKindCABI[terminalKindCABI['Whitespace'] = 184] = 'Whitespace';
terminalKindCABI[terminalKindCABI['YulBreakKeyword'] = 185] = 'YulBreakKeyword';
terminalKindCABI[terminalKindCABI['YulCaseKeyword'] = 186] = 'YulCaseKeyword';
terminalKindCABI[terminalKindCABI['YulContinueKeyword'] = 187] = 'YulContinueKeyword';
terminalKindCABI[terminalKindCABI['YulDecimalLiteral'] = 188] = 'YulDecimalLiteral';
terminalKindCABI[terminalKindCABI['YulDefaultKeyword'] = 189] = 'YulDefaultKeyword';
terminalKindCABI[terminalKindCABI['YulFalseKeyword'] = 190] = 'YulFalseKeyword';
terminalKindCABI[terminalKindCABI['YulForKeyword'] = 191] = 'YulForKeyword';
terminalKindCABI[terminalKindCABI['YulFunctionKeyword'] = 192] = 'YulFunctionKeyword';
terminalKindCABI[terminalKindCABI['YulHexKeyword'] = 193] = 'YulHexKeyword';
terminalKindCABI[terminalKindCABI['YulHexLiteral'] = 194] = 'YulHexLiteral';
terminalKindCABI[terminalKindCABI['YulIdentifier'] = 195] = 'YulIdentifier';
terminalKindCABI[terminalKindCABI['YulIfKeyword'] = 196] = 'YulIfKeyword';
terminalKindCABI[terminalKindCABI['YulLeaveKeyword'] = 197] = 'YulLeaveKeyword';
terminalKindCABI[terminalKindCABI['YulLetKeyword'] = 198] = 'YulLetKeyword';
terminalKindCABI[terminalKindCABI['YulSuperKeyword'] = 199] = 'YulSuperKeyword';
terminalKindCABI[terminalKindCABI['YulSwitchKeyword'] = 200] = 'YulSwitchKeyword';
terminalKindCABI[terminalKindCABI['YulThisKeyword'] = 201] = 'YulThisKeyword';
terminalKindCABI[terminalKindCABI['YulTrueKeyword'] = 202] = 'YulTrueKeyword';

var edgeLabel = {};
edgeLabel['Root'] = 'Root';
edgeLabel['Unrecognized'] = 'Unrecognized';
edgeLabel['Missing'] = 'Missing';
edgeLabel['Item'] = 'Item';
edgeLabel['Variant'] = 'Variant';
edgeLabel['Separator'] = 'Separator';
edgeLabel['Operand'] = 'Operand';
edgeLabel['LeftOperand'] = 'LeftOperand';
edgeLabel['RightOperand'] = 'RightOperand';
edgeLabel['LeadingTrivia'] = 'LeadingTrivia';
edgeLabel['TrailingTrivia'] = 'TrailingTrivia';
edgeLabel['AbicoderKeyword'] = 'AbicoderKeyword';
edgeLabel['AbstractKeyword'] = 'AbstractKeyword';
edgeLabel['AddressKeyword'] = 'AddressKeyword';
edgeLabel['Alias'] = 'Alias';
edgeLabel['AnonymousKeyword'] = 'AnonymousKeyword';
edgeLabel['Arguments'] = 'Arguments';
edgeLabel['AsKeyword'] = 'AsKeyword';
edgeLabel['AssemblyKeyword'] = 'AssemblyKeyword';
edgeLabel['Assignment'] = 'Assignment';
edgeLabel['Asterisk'] = 'Asterisk';
edgeLabel['Attributes'] = 'Attributes';
edgeLabel['Block'] = 'Block';
edgeLabel['Body'] = 'Body';
edgeLabel['BreakKeyword'] = 'BreakKeyword';
edgeLabel['CaseKeyword'] = 'CaseKeyword';
edgeLabel['Cases'] = 'Cases';
edgeLabel['CatchClauses'] = 'CatchClauses';
edgeLabel['CatchKeyword'] = 'CatchKeyword';
edgeLabel['Clause'] = 'Clause';
edgeLabel['CloseBrace'] = 'CloseBrace';
edgeLabel['CloseBracket'] = 'CloseBracket';
edgeLabel['CloseParen'] = 'CloseParen';
edgeLabel['Colon'] = 'Colon';
edgeLabel['Condition'] = 'Condition';
edgeLabel['ConstantKeyword'] = 'ConstantKeyword';
edgeLabel['ConstructorKeyword'] = 'ConstructorKeyword';
edgeLabel['ContinueKeyword'] = 'ContinueKeyword';
edgeLabel['ContractKeyword'] = 'ContractKeyword';
edgeLabel['DefaultKeyword'] = 'DefaultKeyword';
edgeLabel['DoKeyword'] = 'DoKeyword';
edgeLabel['Elements'] = 'Elements';
edgeLabel['ElseBranch'] = 'ElseBranch';
edgeLabel['ElseKeyword'] = 'ElseKeyword';
edgeLabel['EmitKeyword'] = 'EmitKeyword';
edgeLabel['End'] = 'End';
edgeLabel['EnumKeyword'] = 'EnumKeyword';
edgeLabel['Equal'] = 'Equal';
edgeLabel['EqualGreaterThan'] = 'EqualGreaterThan';
edgeLabel['Error'] = 'Error';
edgeLabel['ErrorKeyword'] = 'ErrorKeyword';
edgeLabel['Event'] = 'Event';
edgeLabel['EventKeyword'] = 'EventKeyword';
edgeLabel['ExperimentalKeyword'] = 'ExperimentalKeyword';
edgeLabel['Expression'] = 'Expression';
edgeLabel['FallbackKeyword'] = 'FallbackKeyword';
edgeLabel['FalseExpression'] = 'FalseExpression';
edgeLabel['Feature'] = 'Feature';
edgeLabel['Flags'] = 'Flags';
edgeLabel['ForKeyword'] = 'ForKeyword';
edgeLabel['FromKeyword'] = 'FromKeyword';
edgeLabel['FunctionKeyword'] = 'FunctionKeyword';
edgeLabel['GlobalKeyword'] = 'GlobalKeyword';
edgeLabel['HyperionKeyword'] = 'HyperionKeyword';
edgeLabel['Identifier'] = 'Identifier';
edgeLabel['IfKeyword'] = 'IfKeyword';
edgeLabel['ImportKeyword'] = 'ImportKeyword';
edgeLabel['Index'] = 'Index';
edgeLabel['IndexedKeyword'] = 'IndexedKeyword';
edgeLabel['Inheritance'] = 'Inheritance';
edgeLabel['Initialization'] = 'Initialization';
edgeLabel['InterfaceKeyword'] = 'InterfaceKeyword';
edgeLabel['IsKeyword'] = 'IsKeyword';
edgeLabel['Items'] = 'Items';
edgeLabel['Iterator'] = 'Iterator';
edgeLabel['KeyType'] = 'KeyType';
edgeLabel['Label'] = 'Label';
edgeLabel['LeaveKeyword'] = 'LeaveKeyword';
edgeLabel['LetKeyword'] = 'LetKeyword';
edgeLabel['LibraryKeyword'] = 'LibraryKeyword';
edgeLabel['Literal'] = 'Literal';
edgeLabel['MappingKeyword'] = 'MappingKeyword';
edgeLabel['Member'] = 'Member';
edgeLabel['Members'] = 'Members';
edgeLabel['Minus'] = 'Minus';
edgeLabel['MinusGreaterThan'] = 'MinusGreaterThan';
edgeLabel['ModifierKeyword'] = 'ModifierKeyword';
edgeLabel['Name'] = 'Name';
edgeLabel['NewKeyword'] = 'NewKeyword';
edgeLabel['OpenBrace'] = 'OpenBrace';
edgeLabel['OpenBracket'] = 'OpenBracket';
edgeLabel['OpenParen'] = 'OpenParen';
edgeLabel['Operator'] = 'Operator';
edgeLabel['Options'] = 'Options';
edgeLabel['Overridden'] = 'Overridden';
edgeLabel['OverrideKeyword'] = 'OverrideKeyword';
edgeLabel['Parameters'] = 'Parameters';
edgeLabel['Path'] = 'Path';
edgeLabel['Paths'] = 'Paths';
edgeLabel['PayableKeyword'] = 'PayableKeyword';
edgeLabel['Period'] = 'Period';
edgeLabel['Pragma'] = 'Pragma';
edgeLabel['PragmaKeyword'] = 'PragmaKeyword';
edgeLabel['QuestionMark'] = 'QuestionMark';
edgeLabel['ReceiveKeyword'] = 'ReceiveKeyword';
edgeLabel['ReturnKeyword'] = 'ReturnKeyword';
edgeLabel['Returns'] = 'Returns';
edgeLabel['ReturnsKeyword'] = 'ReturnsKeyword';
edgeLabel['RevertKeyword'] = 'RevertKeyword';
edgeLabel['Semicolon'] = 'Semicolon';
edgeLabel['Sets'] = 'Sets';
edgeLabel['Specifiers'] = 'Specifiers';
edgeLabel['Start'] = 'Start';
edgeLabel['Statements'] = 'Statements';
edgeLabel['StorageLocation'] = 'StorageLocation';
edgeLabel['StructKeyword'] = 'StructKeyword';
edgeLabel['SwitchKeyword'] = 'SwitchKeyword';
edgeLabel['Symbols'] = 'Symbols';
edgeLabel['Target'] = 'Target';
edgeLabel['TrueExpression'] = 'TrueExpression';
edgeLabel['TryKeyword'] = 'TryKeyword';
edgeLabel['TypeKeyword'] = 'TypeKeyword';
edgeLabel['TypeName'] = 'TypeName';
edgeLabel['Types'] = 'Types';
edgeLabel['UncheckedKeyword'] = 'UncheckedKeyword';
edgeLabel['Unit'] = 'Unit';
edgeLabel['UsingKeyword'] = 'UsingKeyword';
edgeLabel['Value'] = 'Value';
edgeLabel['ValueType'] = 'ValueType';
edgeLabel['VariableType'] = 'VariableType';
edgeLabel['Variables'] = 'Variables';
edgeLabel['Version'] = 'Version';
edgeLabel['WhileKeyword'] = 'WhileKeyword';

var edgeLabelCABI = {};
edgeLabelCABI[edgeLabelCABI['Root'] = 0] = 'Root';
edgeLabelCABI[edgeLabelCABI['Unrecognized'] = 1] = 'Unrecognized';
edgeLabelCABI[edgeLabelCABI['Missing'] = 2] = 'Missing';
edgeLabelCABI[edgeLabelCABI['Item'] = 3] = 'Item';
edgeLabelCABI[edgeLabelCABI['Variant'] = 4] = 'Variant';
edgeLabelCABI[edgeLabelCABI['Separator'] = 5] = 'Separator';
edgeLabelCABI[edgeLabelCABI['Operand'] = 6] = 'Operand';
edgeLabelCABI[edgeLabelCABI['LeftOperand'] = 7] = 'LeftOperand';
edgeLabelCABI[edgeLabelCABI['RightOperand'] = 8] = 'RightOperand';
edgeLabelCABI[edgeLabelCABI['LeadingTrivia'] = 9] = 'LeadingTrivia';
edgeLabelCABI[edgeLabelCABI['TrailingTrivia'] = 10] = 'TrailingTrivia';
edgeLabelCABI[edgeLabelCABI['AbicoderKeyword'] = 11] = 'AbicoderKeyword';
edgeLabelCABI[edgeLabelCABI['AbstractKeyword'] = 12] = 'AbstractKeyword';
edgeLabelCABI[edgeLabelCABI['AddressKeyword'] = 13] = 'AddressKeyword';
edgeLabelCABI[edgeLabelCABI['Alias'] = 14] = 'Alias';
edgeLabelCABI[edgeLabelCABI['AnonymousKeyword'] = 15] = 'AnonymousKeyword';
edgeLabelCABI[edgeLabelCABI['Arguments'] = 16] = 'Arguments';
edgeLabelCABI[edgeLabelCABI['AsKeyword'] = 17] = 'AsKeyword';
edgeLabelCABI[edgeLabelCABI['AssemblyKeyword'] = 18] = 'AssemblyKeyword';
edgeLabelCABI[edgeLabelCABI['Assignment'] = 19] = 'Assignment';
edgeLabelCABI[edgeLabelCABI['Asterisk'] = 20] = 'Asterisk';
edgeLabelCABI[edgeLabelCABI['Attributes'] = 21] = 'Attributes';
edgeLabelCABI[edgeLabelCABI['Block'] = 22] = 'Block';
edgeLabelCABI[edgeLabelCABI['Body'] = 23] = 'Body';
edgeLabelCABI[edgeLabelCABI['BreakKeyword'] = 24] = 'BreakKeyword';
edgeLabelCABI[edgeLabelCABI['CaseKeyword'] = 25] = 'CaseKeyword';
edgeLabelCABI[edgeLabelCABI['Cases'] = 26] = 'Cases';
edgeLabelCABI[edgeLabelCABI['CatchClauses'] = 27] = 'CatchClauses';
edgeLabelCABI[edgeLabelCABI['CatchKeyword'] = 28] = 'CatchKeyword';
edgeLabelCABI[edgeLabelCABI['Clause'] = 29] = 'Clause';
edgeLabelCABI[edgeLabelCABI['CloseBrace'] = 30] = 'CloseBrace';
edgeLabelCABI[edgeLabelCABI['CloseBracket'] = 31] = 'CloseBracket';
edgeLabelCABI[edgeLabelCABI['CloseParen'] = 32] = 'CloseParen';
edgeLabelCABI[edgeLabelCABI['Colon'] = 33] = 'Colon';
edgeLabelCABI[edgeLabelCABI['Condition'] = 34] = 'Condition';
edgeLabelCABI[edgeLabelCABI['ConstantKeyword'] = 35] = 'ConstantKeyword';
edgeLabelCABI[edgeLabelCABI['ConstructorKeyword'] = 36] = 'ConstructorKeyword';
edgeLabelCABI[edgeLabelCABI['ContinueKeyword'] = 37] = 'ContinueKeyword';
edgeLabelCABI[edgeLabelCABI['ContractKeyword'] = 38] = 'ContractKeyword';
edgeLabelCABI[edgeLabelCABI['DefaultKeyword'] = 39] = 'DefaultKeyword';
edgeLabelCABI[edgeLabelCABI['DoKeyword'] = 40] = 'DoKeyword';
edgeLabelCABI[edgeLabelCABI['Elements'] = 41] = 'Elements';
edgeLabelCABI[edgeLabelCABI['ElseBranch'] = 42] = 'ElseBranch';
edgeLabelCABI[edgeLabelCABI['ElseKeyword'] = 43] = 'ElseKeyword';
edgeLabelCABI[edgeLabelCABI['EmitKeyword'] = 44] = 'EmitKeyword';
edgeLabelCABI[edgeLabelCABI['End'] = 45] = 'End';
edgeLabelCABI[edgeLabelCABI['EnumKeyword'] = 46] = 'EnumKeyword';
edgeLabelCABI[edgeLabelCABI['Equal'] = 47] = 'Equal';
edgeLabelCABI[edgeLabelCABI['EqualGreaterThan'] = 48] = 'EqualGreaterThan';
edgeLabelCABI[edgeLabelCABI['Error'] = 49] = 'Error';
edgeLabelCABI[edgeLabelCABI['ErrorKeyword'] = 50] = 'ErrorKeyword';
edgeLabelCABI[edgeLabelCABI['Event'] = 51] = 'Event';
edgeLabelCABI[edgeLabelCABI['EventKeyword'] = 52] = 'EventKeyword';
edgeLabelCABI[edgeLabelCABI['ExperimentalKeyword'] = 53] = 'ExperimentalKeyword';
edgeLabelCABI[edgeLabelCABI['Expression'] = 54] = 'Expression';
edgeLabelCABI[edgeLabelCABI['FallbackKeyword'] = 55] = 'FallbackKeyword';
edgeLabelCABI[edgeLabelCABI['FalseExpression'] = 56] = 'FalseExpression';
edgeLabelCABI[edgeLabelCABI['Feature'] = 57] = 'Feature';
edgeLabelCABI[edgeLabelCABI['Flags'] = 58] = 'Flags';
edgeLabelCABI[edgeLabelCABI['ForKeyword'] = 59] = 'ForKeyword';
edgeLabelCABI[edgeLabelCABI['FromKeyword'] = 60] = 'FromKeyword';
edgeLabelCABI[edgeLabelCABI['FunctionKeyword'] = 61] = 'FunctionKeyword';
edgeLabelCABI[edgeLabelCABI['GlobalKeyword'] = 62] = 'GlobalKeyword';
edgeLabelCABI[edgeLabelCABI['HyperionKeyword'] = 63] = 'HyperionKeyword';
edgeLabelCABI[edgeLabelCABI['Identifier'] = 64] = 'Identifier';
edgeLabelCABI[edgeLabelCABI['IfKeyword'] = 65] = 'IfKeyword';
edgeLabelCABI[edgeLabelCABI['ImportKeyword'] = 66] = 'ImportKeyword';
edgeLabelCABI[edgeLabelCABI['Index'] = 67] = 'Index';
edgeLabelCABI[edgeLabelCABI['IndexedKeyword'] = 68] = 'IndexedKeyword';
edgeLabelCABI[edgeLabelCABI['Inheritance'] = 69] = 'Inheritance';
edgeLabelCABI[edgeLabelCABI['Initialization'] = 70] = 'Initialization';
edgeLabelCABI[edgeLabelCABI['InterfaceKeyword'] = 71] = 'InterfaceKeyword';
edgeLabelCABI[edgeLabelCABI['IsKeyword'] = 72] = 'IsKeyword';
edgeLabelCABI[edgeLabelCABI['Items'] = 73] = 'Items';
edgeLabelCABI[edgeLabelCABI['Iterator'] = 74] = 'Iterator';
edgeLabelCABI[edgeLabelCABI['KeyType'] = 75] = 'KeyType';
edgeLabelCABI[edgeLabelCABI['Label'] = 76] = 'Label';
edgeLabelCABI[edgeLabelCABI['LeaveKeyword'] = 77] = 'LeaveKeyword';
edgeLabelCABI[edgeLabelCABI['LetKeyword'] = 78] = 'LetKeyword';
edgeLabelCABI[edgeLabelCABI['LibraryKeyword'] = 79] = 'LibraryKeyword';
edgeLabelCABI[edgeLabelCABI['Literal'] = 80] = 'Literal';
edgeLabelCABI[edgeLabelCABI['MappingKeyword'] = 81] = 'MappingKeyword';
edgeLabelCABI[edgeLabelCABI['Member'] = 82] = 'Member';
edgeLabelCABI[edgeLabelCABI['Members'] = 83] = 'Members';
edgeLabelCABI[edgeLabelCABI['Minus'] = 84] = 'Minus';
edgeLabelCABI[edgeLabelCABI['MinusGreaterThan'] = 85] = 'MinusGreaterThan';
edgeLabelCABI[edgeLabelCABI['ModifierKeyword'] = 86] = 'ModifierKeyword';
edgeLabelCABI[edgeLabelCABI['Name'] = 87] = 'Name';
edgeLabelCABI[edgeLabelCABI['NewKeyword'] = 88] = 'NewKeyword';
edgeLabelCABI[edgeLabelCABI['OpenBrace'] = 89] = 'OpenBrace';
edgeLabelCABI[edgeLabelCABI['OpenBracket'] = 90] = 'OpenBracket';
edgeLabelCABI[edgeLabelCABI['OpenParen'] = 91] = 'OpenParen';
edgeLabelCABI[edgeLabelCABI['Operator'] = 92] = 'Operator';
edgeLabelCABI[edgeLabelCABI['Options'] = 93] = 'Options';
edgeLabelCABI[edgeLabelCABI['Overridden'] = 94] = 'Overridden';
edgeLabelCABI[edgeLabelCABI['OverrideKeyword'] = 95] = 'OverrideKeyword';
edgeLabelCABI[edgeLabelCABI['Parameters'] = 96] = 'Parameters';
edgeLabelCABI[edgeLabelCABI['Path'] = 97] = 'Path';
edgeLabelCABI[edgeLabelCABI['Paths'] = 98] = 'Paths';
edgeLabelCABI[edgeLabelCABI['PayableKeyword'] = 99] = 'PayableKeyword';
edgeLabelCABI[edgeLabelCABI['Period'] = 100] = 'Period';
edgeLabelCABI[edgeLabelCABI['Pragma'] = 101] = 'Pragma';
edgeLabelCABI[edgeLabelCABI['PragmaKeyword'] = 102] = 'PragmaKeyword';
edgeLabelCABI[edgeLabelCABI['QuestionMark'] = 103] = 'QuestionMark';
edgeLabelCABI[edgeLabelCABI['ReceiveKeyword'] = 104] = 'ReceiveKeyword';
edgeLabelCABI[edgeLabelCABI['ReturnKeyword'] = 105] = 'ReturnKeyword';
edgeLabelCABI[edgeLabelCABI['Returns'] = 106] = 'Returns';
edgeLabelCABI[edgeLabelCABI['ReturnsKeyword'] = 107] = 'ReturnsKeyword';
edgeLabelCABI[edgeLabelCABI['RevertKeyword'] = 108] = 'RevertKeyword';
edgeLabelCABI[edgeLabelCABI['Semicolon'] = 109] = 'Semicolon';
edgeLabelCABI[edgeLabelCABI['Sets'] = 110] = 'Sets';
edgeLabelCABI[edgeLabelCABI['Specifiers'] = 111] = 'Specifiers';
edgeLabelCABI[edgeLabelCABI['Start'] = 112] = 'Start';
edgeLabelCABI[edgeLabelCABI['Statements'] = 113] = 'Statements';
edgeLabelCABI[edgeLabelCABI['StorageLocation'] = 114] = 'StorageLocation';
edgeLabelCABI[edgeLabelCABI['StructKeyword'] = 115] = 'StructKeyword';
edgeLabelCABI[edgeLabelCABI['SwitchKeyword'] = 116] = 'SwitchKeyword';
edgeLabelCABI[edgeLabelCABI['Symbols'] = 117] = 'Symbols';
edgeLabelCABI[edgeLabelCABI['Target'] = 118] = 'Target';
edgeLabelCABI[edgeLabelCABI['TrueExpression'] = 119] = 'TrueExpression';
edgeLabelCABI[edgeLabelCABI['TryKeyword'] = 120] = 'TryKeyword';
edgeLabelCABI[edgeLabelCABI['TypeKeyword'] = 121] = 'TypeKeyword';
edgeLabelCABI[edgeLabelCABI['TypeName'] = 122] = 'TypeName';
edgeLabelCABI[edgeLabelCABI['Types'] = 123] = 'Types';
edgeLabelCABI[edgeLabelCABI['UncheckedKeyword'] = 124] = 'UncheckedKeyword';
edgeLabelCABI[edgeLabelCABI['Unit'] = 125] = 'Unit';
edgeLabelCABI[edgeLabelCABI['UsingKeyword'] = 126] = 'UsingKeyword';
edgeLabelCABI[edgeLabelCABI['Value'] = 127] = 'Value';
edgeLabelCABI[edgeLabelCABI['ValueType'] = 128] = 'ValueType';
edgeLabelCABI[edgeLabelCABI['VariableType'] = 129] = 'VariableType';
edgeLabelCABI[edgeLabelCABI['Variables'] = 130] = 'Variables';
edgeLabelCABI[edgeLabelCABI['Version'] = 131] = 'Version';
edgeLabelCABI[edgeLabelCABI['WhileKeyword'] = 132] = 'WhileKeyword';

var NodeType= {};

NodeType['NonterminalNode'] = 'NonterminalNode';

Object.defineProperty(NonterminalNode.prototype, "type", {
  get: function() { return NodeType['NonterminalNode']; }
});

NonterminalNode.prototype.asNonterminalNode= function() { return this; };
NonterminalNode.prototype.isNonterminalNode= function() { return true; };


NonterminalNode.prototype.asTerminalNode= function() { return undefined; };
NonterminalNode.prototype.isTerminalNode= function() { return false; };


NodeType['TerminalNode'] = 'TerminalNode';

Object.defineProperty(TerminalNode.prototype, "type", {
  get: function() { return NodeType['TerminalNode']; }
});

TerminalNode.prototype.asTerminalNode= function() { return this; };
TerminalNode.prototype.isTerminalNode= function() { return true; };


TerminalNode.prototype.asNonterminalNode= function() { return undefined; };
TerminalNode.prototype.isNonterminalNode= function() { return false; };


let astStaticSelectorsSequence;

class Selectors{
  constructor () {
    throw new Error('"Selectors" resource does not define a constructor');
  }
}

Selectors.sequence = function sequence(arg0) {
  var handle1 = arg0[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = astStaticSelectorsSequence(handle0);
  let variant10;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var ptr9 = dataView(memory0).getInt32(ret + 4, true);
    var len9 = dataView(memory0).getInt32(ret + 8, true);
    var result9 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr9, len9));
    variant10= {
      tag: 'err',
      val: result9
    };
  } else {
    var len8 = dataView(memory0).getInt32(ret + 8, true);
    var base8 = dataView(memory0).getInt32(ret + 4, true);
    var result8 = [];
    for (let i = 0; i < len8; i++) {
      const base = base8 + i * 12;
      let variant7;
      if (dataView(memory0).getUint8(base + 0, true)) {
        let variant6;
        switch (dataView(memory0).getUint8(base + 4, true)) {
          case 0: {
            var handle3 = dataView(memory0).getInt32(base + 8, true);
            var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
            Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
            finalizationRegistry4.register(rsc2, handle3, rsc2);
            Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
              finalizationRegistry4.unregister(rsc2);
              rscTableRemove(handleTable4, handle3);
              rsc2[symbolDispose] = emptyFunc;
              rsc2[symbolRscHandle] = undefined;
              exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
            }});
            variant6 = rsc2;
            break;
          }
          case 1: {
            var handle5 = dataView(memory0).getInt32(base + 8, true);
            var rsc4 = new.target === TerminalNode ? this : Object.create(TerminalNode.prototype);
            Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
            finalizationRegistry5.register(rsc4, handle5, rsc4);
            Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
              finalizationRegistry5.unregister(rsc4);
              rscTableRemove(handleTable5, handle5);
              rsc4[symbolDispose] = emptyFunc;
              rsc4[symbolRscHandle] = undefined;
              exports0['19'](handleTable5[(handle5 << 1) + 1] & ~T_FLAG);
            }});
            variant6 = rsc4;
            break;
          }
        }
        variant7 = variant6;
      } else {
        variant7 = undefined;
      }
      result8.push(variant7);
    }
    variant10= {
      tag: 'ok',
      val: result8
    };
  }
  const retVal = variant10;
  postReturn9(ret);
  if (typeof retVal === 'object' && retVal.tag === 'err') {
    throw retVal.val;
  }
  return retVal.val;
};
let astStaticSelectorsChoice;

Selectors.choice = function choice(arg0) {
  var handle1 = arg0[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = astStaticSelectorsChoice(handle0);
  let variant8;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var ptr7 = dataView(memory0).getInt32(ret + 4, true);
    var len7 = dataView(memory0).getInt32(ret + 8, true);
    var result7 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr7, len7));
    variant8= {
      tag: 'err',
      val: result7
    };
  } else {
    let variant6;
    switch (dataView(memory0).getUint8(ret + 4, true)) {
      case 0: {
        var handle3 = dataView(memory0).getInt32(ret + 8, true);
        var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
        Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
        finalizationRegistry4.register(rsc2, handle3, rsc2);
        Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
          finalizationRegistry4.unregister(rsc2);
          rscTableRemove(handleTable4, handle3);
          rsc2[symbolDispose] = emptyFunc;
          rsc2[symbolRscHandle] = undefined;
          exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
        }});
        variant6 = rsc2;
        break;
      }
      case 1: {
        var handle5 = dataView(memory0).getInt32(ret + 8, true);
        var rsc4 = new.target === TerminalNode ? this : Object.create(TerminalNode.prototype);
        Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
        finalizationRegistry5.register(rsc4, handle5, rsc4);
        Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
          finalizationRegistry5.unregister(rsc4);
          rscTableRemove(handleTable5, handle5);
          rsc4[symbolDispose] = emptyFunc;
          rsc4[symbolRscHandle] = undefined;
          exports0['19'](handleTable5[(handle5 << 1) + 1] & ~T_FLAG);
        }});
        variant6 = rsc4;
        break;
      }
    }
    variant8= {
      tag: 'ok',
      val: variant6
    };
  }
  const retVal = variant8;
  postReturn10(ret);
  if (typeof retVal === 'object' && retVal.tag === 'err') {
    throw retVal.val;
  }
  return retVal.val;
};
let astStaticSelectorsRepeated;

Selectors.repeated = function repeated(arg0) {
  var handle1 = arg0[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = astStaticSelectorsRepeated(handle0);
  let variant9;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var ptr8 = dataView(memory0).getInt32(ret + 4, true);
    var len8 = dataView(memory0).getInt32(ret + 8, true);
    var result8 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr8, len8));
    variant9= {
      tag: 'err',
      val: result8
    };
  } else {
    var len7 = dataView(memory0).getInt32(ret + 8, true);
    var base7 = dataView(memory0).getInt32(ret + 4, true);
    var result7 = [];
    for (let i = 0; i < len7; i++) {
      const base = base7 + i * 8;
      let variant6;
      switch (dataView(memory0).getUint8(base + 0, true)) {
        case 0: {
          var handle3 = dataView(memory0).getInt32(base + 4, true);
          var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
          Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
          finalizationRegistry4.register(rsc2, handle3, rsc2);
          Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
            finalizationRegistry4.unregister(rsc2);
            rscTableRemove(handleTable4, handle3);
            rsc2[symbolDispose] = emptyFunc;
            rsc2[symbolRscHandle] = undefined;
            exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
          }});
          variant6 = rsc2;
          break;
        }
        case 1: {
          var handle5 = dataView(memory0).getInt32(base + 4, true);
          var rsc4 = new.target === TerminalNode ? this : Object.create(TerminalNode.prototype);
          Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
          finalizationRegistry5.register(rsc4, handle5, rsc4);
          Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
            finalizationRegistry5.unregister(rsc4);
            rscTableRemove(handleTable5, handle5);
            rsc4[symbolDispose] = emptyFunc;
            rsc4[symbolRscHandle] = undefined;
            exports0['19'](handleTable5[(handle5 << 1) + 1] & ~T_FLAG);
          }});
          variant6 = rsc4;
          break;
        }
      }
      result7.push(variant6);
    }
    variant9= {
      tag: 'ok',
      val: result7
    };
  }
  const retVal = variant9;
  postReturn11(ret);
  if (typeof retVal === 'object' && retVal.tag === 'err') {
    throw retVal.val;
  }
  return retVal.val;
};
let astStaticSelectorsSeparated;

Selectors.separated = function separated(arg0) {
  var handle1 = arg0[symbolRscHandle];
  if (!handle1 || (handleTable4[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "NonterminalNode" resource.');
  }
  var handle0 = handleTable4[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = astStaticSelectorsSeparated(handle0);
  let variant10;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var ptr9 = dataView(memory0).getInt32(ret + 4, true);
    var len9 = dataView(memory0).getInt32(ret + 8, true);
    var result9 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr9, len9));
    variant10= {
      tag: 'err',
      val: result9
    };
  } else {
    var len8 = dataView(memory0).getInt32(ret + 8, true);
    var base8 = dataView(memory0).getInt32(ret + 4, true);
    var result8 = [];
    for (let i = 0; i < len8; i++) {
      const base = base8 + i * 8;
      var len7 = dataView(memory0).getInt32(base + 4, true);
      var base7 = dataView(memory0).getInt32(base + 0, true);
      var result7 = [];
      for (let i = 0; i < len7; i++) {
        const base = base7 + i * 8;
        let variant6;
        switch (dataView(memory0).getUint8(base + 0, true)) {
          case 0: {
            var handle3 = dataView(memory0).getInt32(base + 4, true);
            var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
            Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
            finalizationRegistry4.register(rsc2, handle3, rsc2);
            Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
              finalizationRegistry4.unregister(rsc2);
              rscTableRemove(handleTable4, handle3);
              rsc2[symbolDispose] = emptyFunc;
              rsc2[symbolRscHandle] = undefined;
              exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
            }});
            variant6 = rsc2;
            break;
          }
          case 1: {
            var handle5 = dataView(memory0).getInt32(base + 4, true);
            var rsc4 = new.target === TerminalNode ? this : Object.create(TerminalNode.prototype);
            Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
            finalizationRegistry5.register(rsc4, handle5, rsc4);
            Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
              finalizationRegistry5.unregister(rsc4);
              rscTableRemove(handleTable5, handle5);
              rsc4[symbolDispose] = emptyFunc;
              rsc4[symbolRscHandle] = undefined;
              exports0['19'](handleTable5[(handle5 << 1) + 1] & ~T_FLAG);
            }});
            variant6 = rsc4;
            break;
          }
        }
        result7.push(variant6);
      }
      result8.push(result7);
    }
    variant10= {
      tag: 'ok',
      val: result8
    };
  }
  const retVal = variant10;
  postReturn12(ret);
  if (typeof retVal === 'object' && retVal.tag === 'err') {
    throw retVal.val;
  }
  return retVal.val;
};
const handleTable12 = [T_FLAG, 0];
const finalizationRegistry12 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable12, handle);
  exports0['28'](rep);
});

handleTables[12] = handleTable12;
const handleTable13 = [T_FLAG, 0];
const finalizationRegistry13 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable13, handle);
  exports0['29'](rep);
});

handleTables[13] = handleTable13;
let bindingsMethodBindingGraphDefinitionAt;

class BindingGraph{
  constructor () {
    throw new Error('"BindingGraph" resource does not define a constructor');
  }
}

BindingGraph.prototype.definitionAt = function definitionAt(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable12[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "BindingGraph" resource.');
  }
  var handle0 = handleTable12[(handle1 << 1) + 1] & ~T_FLAG;
  var handle3 = arg1[symbolRscHandle];
  if (!handle3 || (handleTable7[(handle3 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle2 = handleTable7[(handle3 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodBindingGraphDefinitionAt(handle0, handle2);
  let variant6;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var handle5 = dataView(memory0).getInt32(ret + 4, true);
    var rsc4 = new.target === Definition ? this : Object.create(Definition.prototype);
    Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
    finalizationRegistry13.register(rsc4, handle5, rsc4);
    Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
      finalizationRegistry13.unregister(rsc4);
      rscTableRemove(handleTable13, handle5);
      rsc4[symbolDispose] = emptyFunc;
      rsc4[symbolRscHandle] = undefined;
      exports0['29'](handleTable13[(handle5 << 1) + 1] & ~T_FLAG);
    }});
    variant6 = rsc4;
  } else {
    variant6 = undefined;
  }
  return variant6;
};
const handleTable14 = [T_FLAG, 0];
const finalizationRegistry14 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable14, handle);
  exports0['30'](rep);
});

handleTables[14] = handleTable14;
let bindingsMethodBindingGraphReferenceAt;

BindingGraph.prototype.referenceAt = function referenceAt(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable12[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "BindingGraph" resource.');
  }
  var handle0 = handleTable12[(handle1 << 1) + 1] & ~T_FLAG;
  var handle3 = arg1[symbolRscHandle];
  if (!handle3 || (handleTable7[(handle3 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle2 = handleTable7[(handle3 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodBindingGraphReferenceAt(handle0, handle2);
  let variant6;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var handle5 = dataView(memory0).getInt32(ret + 4, true);
    var rsc4 = new.target === Reference ? this : Object.create(Reference.prototype);
    Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
    finalizationRegistry14.register(rsc4, handle5, rsc4);
    Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
      finalizationRegistry14.unregister(rsc4);
      rscTableRemove(handleTable14, handle5);
      rsc4[symbolDispose] = emptyFunc;
      rsc4[symbolRscHandle] = undefined;
      exports0['30'](handleTable14[(handle5 << 1) + 1] & ~T_FLAG);
    }});
    variant6 = rsc4;
  } else {
    variant6 = undefined;
  }
  return variant6;
};
let bindingsMethodDefinitionId;

class Definition{
  constructor () {
    throw new Error('"Definition" resource does not define a constructor');
  }
}

Object.defineProperty(Definition.prototype, "id", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable13[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Definition" resource.');
  }
  var handle0 = handleTable13[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodDefinitionId(handle0);
  return ret >>> 0;
}});
const handleTable15 = [T_FLAG, 0];
const finalizationRegistry15 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable15, handle);
  exports0['31'](rep);
});

handleTables[15] = handleTable15;
const handleTable16 = [T_FLAG, 0];
const finalizationRegistry16 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable16, handle);
  exports0['32'](rep);
});

handleTables[16] = handleTable16;
let bindingsMethodDefinitionNameLocation;

Object.defineProperty(Definition.prototype, "nameLocation", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable13[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Definition" resource.');
  }
  var handle0 = handleTable13[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodDefinitionNameLocation(handle0);
  let variant6;
  switch (dataView(memory0).getUint8(ret + 0, true)) {
    case 0: {
      var handle3 = dataView(memory0).getInt32(ret + 4, true);
      var rsc2 = new.target === UserFileLocation ? this : Object.create(UserFileLocation.prototype);
      Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
      finalizationRegistry15.register(rsc2, handle3, rsc2);
      Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
        finalizationRegistry15.unregister(rsc2);
        rscTableRemove(handleTable15, handle3);
        rsc2[symbolDispose] = emptyFunc;
        rsc2[symbolRscHandle] = undefined;
        exports0['31'](handleTable15[(handle3 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc2;
      break;
    }
    case 1: {
      var handle5 = dataView(memory0).getInt32(ret + 4, true);
      var rsc4 = new.target === BuiltInLocation ? this : Object.create(BuiltInLocation.prototype);
      Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
      finalizationRegistry16.register(rsc4, handle5, rsc4);
      Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
        finalizationRegistry16.unregister(rsc4);
        rscTableRemove(handleTable16, handle5);
        rsc4[symbolDispose] = emptyFunc;
        rsc4[symbolRscHandle] = undefined;
        exports0['32'](handleTable16[(handle5 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc4;
      break;
    }
  }
  return variant6;
}});
let bindingsMethodDefinitionDefiniensLocation;

Object.defineProperty(Definition.prototype, "definiensLocation", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable13[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Definition" resource.');
  }
  var handle0 = handleTable13[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodDefinitionDefiniensLocation(handle0);
  let variant6;
  switch (dataView(memory0).getUint8(ret + 0, true)) {
    case 0: {
      var handle3 = dataView(memory0).getInt32(ret + 4, true);
      var rsc2 = new.target === UserFileLocation ? this : Object.create(UserFileLocation.prototype);
      Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
      finalizationRegistry15.register(rsc2, handle3, rsc2);
      Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
        finalizationRegistry15.unregister(rsc2);
        rscTableRemove(handleTable15, handle3);
        rsc2[symbolDispose] = emptyFunc;
        rsc2[symbolRscHandle] = undefined;
        exports0['31'](handleTable15[(handle3 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc2;
      break;
    }
    case 1: {
      var handle5 = dataView(memory0).getInt32(ret + 4, true);
      var rsc4 = new.target === BuiltInLocation ? this : Object.create(BuiltInLocation.prototype);
      Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
      finalizationRegistry16.register(rsc4, handle5, rsc4);
      Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
        finalizationRegistry16.unregister(rsc4);
        rscTableRemove(handleTable16, handle5);
        rsc4[symbolDispose] = emptyFunc;
        rsc4[symbolRscHandle] = undefined;
        exports0['32'](handleTable16[(handle5 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc4;
      break;
    }
  }
  return variant6;
}});
let bindingsMethodDefinitionReferences;

Definition.prototype.references = function references() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable13[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Definition" resource.');
  }
  var handle0 = handleTable13[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodDefinitionReferences(handle0);
  var len4 = dataView(memory0).getInt32(ret + 4, true);
  var base4 = dataView(memory0).getInt32(ret + 0, true);
  var result4 = [];
  for (let i = 0; i < len4; i++) {
    const base = base4 + i * 4;
    var handle3 = dataView(memory0).getInt32(base + 0, true);
    var rsc2 = new.target === Reference ? this : Object.create(Reference.prototype);
    Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
    finalizationRegistry14.register(rsc2, handle3, rsc2);
    Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
      finalizationRegistry14.unregister(rsc2);
      rscTableRemove(handleTable14, handle3);
      rsc2[symbolDispose] = emptyFunc;
      rsc2[symbolRscHandle] = undefined;
      exports0['30'](handleTable14[(handle3 << 1) + 1] & ~T_FLAG);
    }});
    result4.push(rsc2);
  }
  const retVal = result4;
  postReturn13(ret);
  return retVal;
};
let bindingsMethodReferenceId;

class Reference{
  constructor () {
    throw new Error('"Reference" resource does not define a constructor');
  }
}

Object.defineProperty(Reference.prototype, "id", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable14[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Reference" resource.');
  }
  var handle0 = handleTable14[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodReferenceId(handle0);
  return ret >>> 0;
}});
let bindingsMethodReferenceLocation;

Object.defineProperty(Reference.prototype, "location", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable14[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Reference" resource.');
  }
  var handle0 = handleTable14[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodReferenceLocation(handle0);
  let variant6;
  switch (dataView(memory0).getUint8(ret + 0, true)) {
    case 0: {
      var handle3 = dataView(memory0).getInt32(ret + 4, true);
      var rsc2 = new.target === UserFileLocation ? this : Object.create(UserFileLocation.prototype);
      Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
      finalizationRegistry15.register(rsc2, handle3, rsc2);
      Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
        finalizationRegistry15.unregister(rsc2);
        rscTableRemove(handleTable15, handle3);
        rsc2[symbolDispose] = emptyFunc;
        rsc2[symbolRscHandle] = undefined;
        exports0['31'](handleTable15[(handle3 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc2;
      break;
    }
    case 1: {
      var handle5 = dataView(memory0).getInt32(ret + 4, true);
      var rsc4 = new.target === BuiltInLocation ? this : Object.create(BuiltInLocation.prototype);
      Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
      finalizationRegistry16.register(rsc4, handle5, rsc4);
      Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
        finalizationRegistry16.unregister(rsc4);
        rscTableRemove(handleTable16, handle5);
        rsc4[symbolDispose] = emptyFunc;
        rsc4[symbolRscHandle] = undefined;
        exports0['32'](handleTable16[(handle5 << 1) + 1] & ~T_FLAG);
      }});
      variant6 = rsc4;
      break;
    }
  }
  return variant6;
}});
let bindingsMethodReferenceDefinitions;

Reference.prototype.definitions = function definitions() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable14[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Reference" resource.');
  }
  var handle0 = handleTable14[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodReferenceDefinitions(handle0);
  var len4 = dataView(memory0).getInt32(ret + 4, true);
  var base4 = dataView(memory0).getInt32(ret + 0, true);
  var result4 = [];
  for (let i = 0; i < len4; i++) {
    const base = base4 + i * 4;
    var handle3 = dataView(memory0).getInt32(base + 0, true);
    var rsc2 = new.target === Definition ? this : Object.create(Definition.prototype);
    Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
    finalizationRegistry13.register(rsc2, handle3, rsc2);
    Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
      finalizationRegistry13.unregister(rsc2);
      rscTableRemove(handleTable13, handle3);
      rsc2[symbolDispose] = emptyFunc;
      rsc2[symbolRscHandle] = undefined;
      exports0['29'](handleTable13[(handle3 << 1) + 1] & ~T_FLAG);
    }});
    result4.push(rsc2);
  }
  const retVal = result4;
  postReturn14(ret);
  return retVal;
};
let bindingsMethodUserFileLocationFileId;

class UserFileLocation{
  constructor () {
    throw new Error('"UserFileLocation" resource does not define a constructor');
  }
}

Object.defineProperty(UserFileLocation.prototype, "fileId", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable15[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "UserFileLocation" resource.');
  }
  var handle0 = handleTable15[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodUserFileLocationFileId(handle0);
  var ptr2 = dataView(memory0).getInt32(ret + 0, true);
  var len2 = dataView(memory0).getInt32(ret + 4, true);
  var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
  const retVal = result2;
  postReturn15(ret);
  return retVal;
}});
let bindingsMethodUserFileLocationCursor;

Object.defineProperty(UserFileLocation.prototype, "cursor", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable15[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "UserFileLocation" resource.');
  }
  var handle0 = handleTable15[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = bindingsMethodUserFileLocationCursor(handle0);
  var handle3 = ret;
  var rsc2 = new.target === Cursor ? this : Object.create(Cursor.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry7.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry7.unregister(rsc2);
    rscTableRemove(handleTable7, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['21'](handleTable7[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
}});
var BindingLocationType= {};

BindingLocationType['UserFileLocation'] = 'UserFileLocation';

Object.defineProperty(UserFileLocation.prototype, "type", {
  get: function() { return BindingLocationType['UserFileLocation']; }
});

UserFileLocation.prototype.asUserFileLocation= function() { return this; };
UserFileLocation.prototype.isUserFileLocation= function() { return true; };


UserFileLocation.prototype.asBuiltInLocation= function() { return undefined; };
UserFileLocation.prototype.isBuiltInLocation= function() { return false; };



class BuiltInLocation{
  constructor () {
    throw new Error('"BuiltInLocation" resource does not define a constructor');
  }
}
BindingLocationType['BuiltInLocation'] = 'BuiltInLocation';

Object.defineProperty(BuiltInLocation.prototype, "type", {
  get: function() { return BindingLocationType['BuiltInLocation']; }
});

BuiltInLocation.prototype.asBuiltInLocation= function() { return this; };
BuiltInLocation.prototype.isBuiltInLocation= function() { return true; };


BuiltInLocation.prototype.asUserFileLocation= function() { return undefined; };
BuiltInLocation.prototype.isUserFileLocation= function() { return false; };


const handleTable17 = [T_FLAG, 0];
const finalizationRegistry17 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable17, handle);
  exports0['33'](rep);
});

handleTables[17] = handleTable17;
let parserStaticParserCreate;

class Parser{
  constructor () {
    throw new Error('"Parser" resource does not define a constructor');
  }
}

Parser.create = function create(arg0) {
  var ptr0 = utf8Encode(arg0, realloc1, memory0);
  var len0 = utf8EncodedLen;
  const ret = parserStaticParserCreate(ptr0, len0);
  let variant4;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var ptr3 = dataView(memory0).getInt32(ret + 4, true);
    var len3 = dataView(memory0).getInt32(ret + 8, true);
    var result3 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr3, len3));
    variant4= {
      tag: 'err',
      val: result3
    };
  } else {
    var handle2 = dataView(memory0).getInt32(ret + 4, true);
    var rsc1 = new.target === Parser ? this : Object.create(Parser.prototype);
    Object.defineProperty(rsc1, symbolRscHandle, { writable: true, value: handle2});
    finalizationRegistry17.register(rsc1, handle2, rsc1);
    Object.defineProperty(rsc1, symbolDispose, { writable: true, value: function () {
      finalizationRegistry17.unregister(rsc1);
      rscTableRemove(handleTable17, handle2);
      rsc1[symbolDispose] = emptyFunc;
      rsc1[symbolRscHandle] = undefined;
      exports0['33'](handleTable17[(handle2 << 1) + 1] & ~T_FLAG);
    }});
    variant4= {
      tag: 'ok',
      val: rsc1
    };
  }
  const retVal = variant4;
  postReturn16(ret);
  if (typeof retVal === 'object' && retVal.tag === 'err') {
    throw retVal.val;
  }
  return retVal.val;
};
let parserMethodParserLanguageVersion;

Object.defineProperty(Parser.prototype, "languageVersion", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable17[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Parser" resource.');
  }
  var handle0 = handleTable17[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = parserMethodParserLanguageVersion(handle0);
  var ptr2 = dataView(memory0).getInt32(ret + 0, true);
  var len2 = dataView(memory0).getInt32(ret + 4, true);
  var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
  const retVal = result2;
  postReturn17(ret);
  return retVal;
}});
const handleTable18 = [T_FLAG, 0];
const finalizationRegistry18 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable18, handle);
  exports0['34'](rep);
});

handleTables[18] = handleTable18;
let parserMethodParserParseFileContents;

Parser.prototype.parseFileContents = function parseFileContents(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable17[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Parser" resource.');
  }
  var handle0 = handleTable17[(handle1 << 1) + 1] & ~T_FLAG;
  var ptr2 = utf8Encode(arg1, realloc1, memory0);
  var len2 = utf8EncodedLen;
  const ret = parserMethodParserParseFileContents(handle0, ptr2, len2);
  var handle4 = ret;
  var rsc3 = new.target === ParseOutput ? this : Object.create(ParseOutput.prototype);
  Object.defineProperty(rsc3, symbolRscHandle, { writable: true, value: handle4});
  finalizationRegistry18.register(rsc3, handle4, rsc3);
  Object.defineProperty(rsc3, symbolDispose, { writable: true, value: function () {
    finalizationRegistry18.unregister(rsc3);
    rscTableRemove(handleTable18, handle4);
    rsc3[symbolDispose] = emptyFunc;
    rsc3[symbolRscHandle] = undefined;
    exports0['34'](handleTable18[(handle4 << 1) + 1] & ~T_FLAG);
  }});
  return rsc3;
};
let parserMethodParserParseNonterminal;

Parser.prototype.parseNonterminal = function parseNonterminal(arg1, arg2) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable17[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Parser" resource.');
  }
  var handle0 = handleTable17[(handle1 << 1) + 1] & ~T_FLAG;
  var ptr2 = utf8Encode(arg2, realloc1, memory0);
  var len2 = utf8EncodedLen;
  const ret = parserMethodParserParseNonterminal(handle0, nonterminalKindCABI[arg1], ptr2, len2);
  var handle4 = ret;
  var rsc3 = new.target === ParseOutput ? this : Object.create(ParseOutput.prototype);
  Object.defineProperty(rsc3, symbolRscHandle, { writable: true, value: handle4});
  finalizationRegistry18.register(rsc3, handle4, rsc3);
  Object.defineProperty(rsc3, symbolDispose, { writable: true, value: function () {
    finalizationRegistry18.unregister(rsc3);
    rscTableRemove(handleTable18, handle4);
    rsc3[symbolDispose] = emptyFunc;
    rsc3[symbolRscHandle] = undefined;
    exports0['34'](handleTable18[(handle4 << 1) + 1] & ~T_FLAG);
  }});
  return rsc3;
};
let parserMethodParseOutputTree;

class ParseOutput{
  constructor () {
    throw new Error('"ParseOutput" resource does not define a constructor');
  }
}

Object.defineProperty(ParseOutput.prototype, "tree", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable18[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "ParseOutput" resource.');
  }
  var handle0 = handleTable18[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = parserMethodParseOutputTree(handle0);
  var handle3 = ret;
  var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry4.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry4.unregister(rsc2);
    rscTableRemove(handleTable4, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
}});
let parserMethodParseOutputErrors;

ParseOutput.prototype.errors = function errors() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable18[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "ParseOutput" resource.');
  }
  var handle0 = handleTable18[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = parserMethodParseOutputErrors(handle0);
  var len3 = dataView(memory0).getInt32(ret + 4, true);
  var base3 = dataView(memory0).getInt32(ret + 0, true);
  var result3 = [];
  for (let i = 0; i < len3; i++) {
    const base = base3 + i * 40;
    var ptr2 = dataView(memory0).getInt32(base + 0, true);
    var len2 = dataView(memory0).getInt32(base + 4, true);
    var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
    result3.push({
      message: result2,
      textRange: {
        start: {
          utf8: dataView(memory0).getInt32(base + 8, true) >>> 0,
          utf16: dataView(memory0).getInt32(base + 12, true) >>> 0,
          line: dataView(memory0).getInt32(base + 16, true) >>> 0,
          column: dataView(memory0).getInt32(base + 20, true) >>> 0,
        },
        end: {
          utf8: dataView(memory0).getInt32(base + 24, true) >>> 0,
          utf16: dataView(memory0).getInt32(base + 28, true) >>> 0,
          line: dataView(memory0).getInt32(base + 32, true) >>> 0,
          column: dataView(memory0).getInt32(base + 36, true) >>> 0,
        },
      },
    });
  }
  const retVal = result3;
  postReturn18(ret);
  return retVal;
};
let parserMethodParseOutputIsValid;

ParseOutput.prototype.isValid = function isValid() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable18[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "ParseOutput" resource.');
  }
  var handle0 = handleTable18[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = parserMethodParseOutputIsValid(handle0);
  var bool2 = ret;
  return !!bool2;
};
let parserMethodParseOutputCreateTreeCursor;

ParseOutput.prototype.createTreeCursor = function createTreeCursor() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable18[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "ParseOutput" resource.');
  }
  var handle0 = handleTable18[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = parserMethodParseOutputCreateTreeCursor(handle0);
  var handle3 = ret;
  var rsc2 = new.target === Cursor ? this : Object.create(Cursor.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry7.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry7.unregister(rsc2);
    rscTableRemove(handleTable7, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['21'](handleTable7[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
const handleTable19 = [T_FLAG, 0];
const finalizationRegistry19 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable19, handle);
  exports0['35'](rep);
});

handleTables[19] = handleTable19;
let compilationStaticInternalCompilationBuilderCreate;

class InternalCompilationBuilder{
  constructor () {
    throw new Error('"InternalCompilationBuilder" resource does not define a constructor');
  }
}

InternalCompilationBuilder.create = function create(arg0) {
  var ptr0 = utf8Encode(arg0, realloc1, memory0);
  var len0 = utf8EncodedLen;
  const ret = compilationStaticInternalCompilationBuilderCreate(ptr0, len0);
  let variant4;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var ptr3 = dataView(memory0).getInt32(ret + 4, true);
    var len3 = dataView(memory0).getInt32(ret + 8, true);
    var result3 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr3, len3));
    variant4= {
      tag: 'err',
      val: result3
    };
  } else {
    var handle2 = dataView(memory0).getInt32(ret + 4, true);
    var rsc1 = new.target === InternalCompilationBuilder ? this : Object.create(InternalCompilationBuilder.prototype);
    Object.defineProperty(rsc1, symbolRscHandle, { writable: true, value: handle2});
    finalizationRegistry19.register(rsc1, handle2, rsc1);
    Object.defineProperty(rsc1, symbolDispose, { writable: true, value: function () {
      finalizationRegistry19.unregister(rsc1);
      rscTableRemove(handleTable19, handle2);
      rsc1[symbolDispose] = emptyFunc;
      rsc1[symbolRscHandle] = undefined;
      exports0['35'](handleTable19[(handle2 << 1) + 1] & ~T_FLAG);
    }});
    variant4= {
      tag: 'ok',
      val: rsc1
    };
  }
  const retVal = variant4;
  postReturn19(ret);
  if (typeof retVal === 'object' && retVal.tag === 'err') {
    throw retVal.val;
  }
  return retVal.val;
};
let compilationMethodInternalCompilationBuilderAddFile;

InternalCompilationBuilder.prototype.addFile = function addFile(arg1, arg2) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable19[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "InternalCompilationBuilder" resource.');
  }
  var handle0 = handleTable19[(handle1 << 1) + 1] & ~T_FLAG;
  var ptr2 = utf8Encode(arg1, realloc1, memory0);
  var len2 = utf8EncodedLen;
  var ptr3 = utf8Encode(arg2, realloc1, memory0);
  var len3 = utf8EncodedLen;
  const ret = compilationMethodInternalCompilationBuilderAddFile(handle0, ptr2, len2, ptr3, len3);
  var len6 = dataView(memory0).getInt32(ret + 4, true);
  var base6 = dataView(memory0).getInt32(ret + 0, true);
  var result6 = [];
  for (let i = 0; i < len6; i++) {
    const base = base6 + i * 4;
    var handle5 = dataView(memory0).getInt32(base + 0, true);
    var rsc4 = new.target === Cursor ? this : Object.create(Cursor.prototype);
    Object.defineProperty(rsc4, symbolRscHandle, { writable: true, value: handle5});
    finalizationRegistry7.register(rsc4, handle5, rsc4);
    Object.defineProperty(rsc4, symbolDispose, { writable: true, value: function () {
      finalizationRegistry7.unregister(rsc4);
      rscTableRemove(handleTable7, handle5);
      rsc4[symbolDispose] = emptyFunc;
      rsc4[symbolRscHandle] = undefined;
      exports0['21'](handleTable7[(handle5 << 1) + 1] & ~T_FLAG);
    }});
    result6.push(rsc4);
  }
  const retVal = {
    importPaths: result6,
  };
  postReturn20(ret);
  return retVal;
};
let compilationMethodInternalCompilationBuilderResolveImport;

InternalCompilationBuilder.prototype.resolveImport = function resolveImport(arg1, arg2, arg3) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable19[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "InternalCompilationBuilder" resource.');
  }
  var handle0 = handleTable19[(handle1 << 1) + 1] & ~T_FLAG;
  var ptr2 = utf8Encode(arg1, realloc1, memory0);
  var len2 = utf8EncodedLen;
  var handle4 = arg2[symbolRscHandle];
  if (!handle4 || (handleTable7[(handle4 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "Cursor" resource.');
  }
  var handle3 = handleTable7[(handle4 << 1) + 1] & ~T_FLAG;
  var ptr5 = utf8Encode(arg3, realloc1, memory0);
  var len5 = utf8EncodedLen;
  const ret = compilationMethodInternalCompilationBuilderResolveImport(handle0, ptr2, len2, handle3, ptr5, len5);
  let variant7;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var ptr6 = dataView(memory0).getInt32(ret + 4, true);
    var len6 = dataView(memory0).getInt32(ret + 8, true);
    var result6 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr6, len6));
    variant7= {
      tag: 'err',
      val: result6
    };
  } else {
    variant7= {
      tag: 'ok',
      val: undefined
    };
  }
  const retVal = variant7;
  postReturn21(ret);
  if (typeof retVal === 'object' && retVal.tag === 'err') {
    throw retVal.val;
  }
  return retVal.val;
};
const handleTable20 = [T_FLAG, 0];
const finalizationRegistry20 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable20, handle);
  exports0['36'](rep);
});

handleTables[20] = handleTable20;
let compilationMethodInternalCompilationBuilderBuild;

InternalCompilationBuilder.prototype.build = function build() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable19[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "InternalCompilationBuilder" resource.');
  }
  var handle0 = handleTable19[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = compilationMethodInternalCompilationBuilderBuild(handle0);
  var handle3 = ret;
  var rsc2 = new.target === CompilationUnit ? this : Object.create(CompilationUnit.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry20.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry20.unregister(rsc2);
    rscTableRemove(handleTable20, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['36'](handleTable20[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
let compilationMethodCompilationUnitLanguageVersion;

class CompilationUnit{
  constructor () {
    throw new Error('"CompilationUnit" resource does not define a constructor');
  }
}

Object.defineProperty(CompilationUnit.prototype, "languageVersion", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable20[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "CompilationUnit" resource.');
  }
  var handle0 = handleTable20[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = compilationMethodCompilationUnitLanguageVersion(handle0);
  var ptr2 = dataView(memory0).getInt32(ret + 0, true);
  var len2 = dataView(memory0).getInt32(ret + 4, true);
  var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
  const retVal = result2;
  postReturn22(ret);
  return retVal;
}});
const handleTable21 = [T_FLAG, 0];
const finalizationRegistry21 = finalizationRegistryCreate((handle) => {
  const { rep } = rscTableRemove(handleTable21, handle);
  exports0['37'](rep);
});

handleTables[21] = handleTable21;
let compilationMethodCompilationUnitFiles;

CompilationUnit.prototype.files = function files() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable20[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "CompilationUnit" resource.');
  }
  var handle0 = handleTable20[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = compilationMethodCompilationUnitFiles(handle0);
  var len4 = dataView(memory0).getInt32(ret + 4, true);
  var base4 = dataView(memory0).getInt32(ret + 0, true);
  var result4 = [];
  for (let i = 0; i < len4; i++) {
    const base = base4 + i * 4;
    var handle3 = dataView(memory0).getInt32(base + 0, true);
    var rsc2 = new.target === File ? this : Object.create(File.prototype);
    Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
    finalizationRegistry21.register(rsc2, handle3, rsc2);
    Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
      finalizationRegistry21.unregister(rsc2);
      rscTableRemove(handleTable21, handle3);
      rsc2[symbolDispose] = emptyFunc;
      rsc2[symbolRscHandle] = undefined;
      exports0['37'](handleTable21[(handle3 << 1) + 1] & ~T_FLAG);
    }});
    result4.push(rsc2);
  }
  const retVal = result4;
  postReturn23(ret);
  return retVal;
};
let compilationMethodCompilationUnitFile;

CompilationUnit.prototype.file = function file(arg1) {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable20[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "CompilationUnit" resource.');
  }
  var handle0 = handleTable20[(handle1 << 1) + 1] & ~T_FLAG;
  var ptr2 = utf8Encode(arg1, realloc1, memory0);
  var len2 = utf8EncodedLen;
  const ret = compilationMethodCompilationUnitFile(handle0, ptr2, len2);
  let variant5;
  if (dataView(memory0).getUint8(ret + 0, true)) {
    var handle4 = dataView(memory0).getInt32(ret + 4, true);
    var rsc3 = new.target === File ? this : Object.create(File.prototype);
    Object.defineProperty(rsc3, symbolRscHandle, { writable: true, value: handle4});
    finalizationRegistry21.register(rsc3, handle4, rsc3);
    Object.defineProperty(rsc3, symbolDispose, { writable: true, value: function () {
      finalizationRegistry21.unregister(rsc3);
      rscTableRemove(handleTable21, handle4);
      rsc3[symbolDispose] = emptyFunc;
      rsc3[symbolRscHandle] = undefined;
      exports0['37'](handleTable21[(handle4 << 1) + 1] & ~T_FLAG);
    }});
    variant5 = rsc3;
  } else {
    variant5 = undefined;
  }
  return variant5;
};
let compilationMethodCompilationUnitBindingGraph;

Object.defineProperty(CompilationUnit.prototype, "bindingGraph", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable20[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "CompilationUnit" resource.');
  }
  var handle0 = handleTable20[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = compilationMethodCompilationUnitBindingGraph(handle0);
  var handle3 = ret;
  var rsc2 = new.target === BindingGraph ? this : Object.create(BindingGraph.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry12.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry12.unregister(rsc2);
    rscTableRemove(handleTable12, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['28'](handleTable12[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
}});
let compilationMethodFileId;

class File{
  constructor () {
    throw new Error('"File" resource does not define a constructor');
  }
}

Object.defineProperty(File.prototype, "id", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable21[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "File" resource.');
  }
  var handle0 = handleTable21[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = compilationMethodFileId(handle0);
  var ptr2 = dataView(memory0).getInt32(ret + 0, true);
  var len2 = dataView(memory0).getInt32(ret + 4, true);
  var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
  const retVal = result2;
  postReturn24(ret);
  return retVal;
}});
let compilationMethodFileTree;

Object.defineProperty(File.prototype, "tree", { get: function() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable21[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "File" resource.');
  }
  var handle0 = handleTable21[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = compilationMethodFileTree(handle0);
  var handle3 = ret;
  var rsc2 = new.target === NonterminalNode ? this : Object.create(NonterminalNode.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry4.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry4.unregister(rsc2);
    rscTableRemove(handleTable4, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['18'](handleTable4[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
}});
let compilationMethodFileErrors;

File.prototype.errors = function errors() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable21[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "File" resource.');
  }
  var handle0 = handleTable21[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = compilationMethodFileErrors(handle0);
  var len3 = dataView(memory0).getInt32(ret + 4, true);
  var base3 = dataView(memory0).getInt32(ret + 0, true);
  var result3 = [];
  for (let i = 0; i < len3; i++) {
    const base = base3 + i * 40;
    var ptr2 = dataView(memory0).getInt32(base + 0, true);
    var len2 = dataView(memory0).getInt32(base + 4, true);
    var result2 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr2, len2));
    result3.push({
      message: result2,
      textRange: {
        start: {
          utf8: dataView(memory0).getInt32(base + 8, true) >>> 0,
          utf16: dataView(memory0).getInt32(base + 12, true) >>> 0,
          line: dataView(memory0).getInt32(base + 16, true) >>> 0,
          column: dataView(memory0).getInt32(base + 20, true) >>> 0,
        },
        end: {
          utf8: dataView(memory0).getInt32(base + 24, true) >>> 0,
          utf16: dataView(memory0).getInt32(base + 28, true) >>> 0,
          line: dataView(memory0).getInt32(base + 32, true) >>> 0,
          column: dataView(memory0).getInt32(base + 36, true) >>> 0,
        },
      },
    });
  }
  const retVal = result3;
  postReturn25(ret);
  return retVal;
};
let compilationMethodFileCreateTreeCursor;

File.prototype.createTreeCursor = function createTreeCursor() {
  var handle1 = this[symbolRscHandle];
  if (!handle1 || (handleTable21[(handle1 << 1) + 1] & T_FLAG) === 0) {
    throw new TypeError('Resource error: Not a valid "File" resource.');
  }
  var handle0 = handleTable21[(handle1 << 1) + 1] & ~T_FLAG;
  const ret = compilationMethodFileCreateTreeCursor(handle0);
  var handle3 = ret;
  var rsc2 = new.target === Cursor ? this : Object.create(Cursor.prototype);
  Object.defineProperty(rsc2, symbolRscHandle, { writable: true, value: handle3});
  finalizationRegistry7.register(rsc2, handle3, rsc2);
  Object.defineProperty(rsc2, symbolDispose, { writable: true, value: function () {
    finalizationRegistry7.unregister(rsc2);
    rscTableRemove(handleTable7, handle3);
    rsc2[symbolDispose] = emptyFunc;
    rsc2[symbolRscHandle] = undefined;
    exports0['21'](handleTable7[(handle3 << 1) + 1] & ~T_FLAG);
  }});
  return rsc2;
};
let utilsStaticLanguageFactsAllVersions;

class LanguageFacts{
  constructor () {
    throw new Error('"LanguageFacts" resource does not define a constructor');
  }
}

LanguageFacts.allVersions = function allVersions() {
  const ret = utilsStaticLanguageFactsAllVersions();
  var len1 = dataView(memory0).getInt32(ret + 4, true);
  var base1 = dataView(memory0).getInt32(ret + 0, true);
  var result1 = [];
  for (let i = 0; i < len1; i++) {
    const base = base1 + i * 8;
    var ptr0 = dataView(memory0).getInt32(base + 0, true);
    var len0 = dataView(memory0).getInt32(base + 4, true);
    var result0 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr0, len0));
    result1.push(result0);
  }
  const retVal = result1;
  postReturn26(ret);
  return retVal;
};
let utilsStaticLanguageFactsEarliestVersion;

LanguageFacts.earliestVersion = function earliestVersion() {
  const ret = utilsStaticLanguageFactsEarliestVersion();
  var ptr0 = dataView(memory0).getInt32(ret + 0, true);
  var len0 = dataView(memory0).getInt32(ret + 4, true);
  var result0 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr0, len0));
  const retVal = result0;
  postReturn27(ret);
  return retVal;
};
let utilsStaticLanguageFactsLatestVersion;

LanguageFacts.latestVersion = function latestVersion() {
  const ret = utilsStaticLanguageFactsLatestVersion();
  var ptr0 = dataView(memory0).getInt32(ret + 0, true);
  var len0 = dataView(memory0).getInt32(ret + 4, true);
  var result0 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr0, len0));
  const retVal = result0;
  postReturn28(ret);
  return retVal;
};
let utilsStaticLanguageFactsInferLanguageVersions;

LanguageFacts.inferLanguageVersions = function inferLanguageVersions(arg0) {
  var ptr0 = utf8Encode(arg0, realloc1, memory0);
  var len0 = utf8EncodedLen;
  const ret = utilsStaticLanguageFactsInferLanguageVersions(ptr0, len0);
  var len2 = dataView(memory0).getInt32(ret + 4, true);
  var base2 = dataView(memory0).getInt32(ret + 0, true);
  var result2 = [];
  for (let i = 0; i < len2; i++) {
    const base = base2 + i * 8;
    var ptr1 = dataView(memory0).getInt32(base + 0, true);
    var len1 = dataView(memory0).getInt32(base + 4, true);
    var result1 = utf8Decoder.decode(new Uint8Array(memory0.buffer, ptr1, len1));
    result2.push(result1);
  }
  const retVal = result2;
  postReturn29(ret);
  return retVal;
};
function trampoline0(handle) {
  const handleEntry = rscTableRemove(handleTable12, handle);
  if (handleEntry.own) {
    
    exports0['28'](handleEntry.rep);
  }
}
function trampoline1(handle) {
  const handleEntry = rscTableRemove(handleTable13, handle);
  if (handleEntry.own) {
    
    exports0['29'](handleEntry.rep);
  }
}
function trampoline2(handle) {
  const handleEntry = rscTableRemove(handleTable14, handle);
  if (handleEntry.own) {
    
    exports0['30'](handleEntry.rep);
  }
}
function trampoline3(handle) {
  const handleEntry = rscTableRemove(handleTable15, handle);
  if (handleEntry.own) {
    
    exports0['31'](handleEntry.rep);
  }
}
function trampoline4(handle) {
  const handleEntry = rscTableRemove(handleTable16, handle);
  if (handleEntry.own) {
    
    exports0['32'](handleEntry.rep);
  }
}
const trampoline5 = rscTableCreateOwn.bind(null, handleTable6);
function trampoline6(handle) {
  return handleTable6[(handle << 1) + 1] & ~T_FLAG;
}
const trampoline7 = rscTableCreateOwn.bind(null, handleTable10);
const trampoline8 = rscTableCreateOwn.bind(null, handleTable7);
const trampoline9 = rscTableCreateOwn.bind(null, handleTable5);
function trampoline10(handle) {
  return handleTable5[(handle << 1) + 1] & ~T_FLAG;
}
const trampoline11 = rscTableCreateOwn.bind(null, handleTable8);
const trampoline12 = rscTableCreateOwn.bind(null, handleTable4);
function trampoline13(handle) {
  return handleTable4[(handle << 1) + 1] & ~T_FLAG;
}
const trampoline14 = rscTableCreateOwn.bind(null, handleTable9);
const trampoline15 = rscTableCreateOwn.bind(null, handleTable11);
const trampoline16 = rscTableCreateOwn.bind(null, handleTable14);
const trampoline17 = rscTableCreateOwn.bind(null, handleTable13);
const trampoline18 = rscTableCreateOwn.bind(null, handleTable12);
const trampoline19 = rscTableCreateOwn.bind(null, handleTable16);
const trampoline20 = rscTableCreateOwn.bind(null, handleTable15);
function trampoline21(handle) {
  const handleEntry = rscTableRemove(handleTable17, handle);
  if (handleEntry.own) {
    
    exports0['33'](handleEntry.rep);
  }
}
function trampoline22(handle) {
  const handleEntry = rscTableRemove(handleTable18, handle);
  if (handleEntry.own) {
    
    exports0['34'](handleEntry.rep);
  }
}
const trampoline23 = rscTableCreateOwn.bind(null, handleTable17);
const trampoline24 = rscTableCreateOwn.bind(null, handleTable18);
function trampoline25(handle) {
  const handleEntry = rscTableRemove(handleTable4, handle);
  if (handleEntry.own) {
    
    exports0['18'](handleEntry.rep);
  }
}
function trampoline26(handle) {
  const handleEntry = rscTableRemove(handleTable5, handle);
  if (handleEntry.own) {
    
    exports0['19'](handleEntry.rep);
  }
}
function trampoline27(handle) {
  const handleEntry = rscTableRemove(handleTable6, handle);
  if (handleEntry.own) {
    
    exports0['20'](handleEntry.rep);
  }
}
function trampoline28(handle) {
  const handleEntry = rscTableRemove(handleTable7, handle);
  if (handleEntry.own) {
    
    exports0['21'](handleEntry.rep);
  }
}
function trampoline29(handle) {
  const handleEntry = rscTableRemove(handleTable8, handle);
  if (handleEntry.own) {
    
    exports0['22'](handleEntry.rep);
  }
}
function trampoline30(handle) {
  const handleEntry = rscTableRemove(handleTable9, handle);
  if (handleEntry.own) {
    
    exports0['23'](handleEntry.rep);
  }
}
function trampoline31(handle) {
  const handleEntry = rscTableRemove(handleTable10, handle);
  if (handleEntry.own) {
    
    exports0['24'](handleEntry.rep);
  }
}
function trampoline32(handle) {
  const handleEntry = rscTableRemove(handleTable11, handle);
  if (handleEntry.own) {
    
    exports0['25'](handleEntry.rep);
  }
}
function trampoline33(handle) {
  const handleEntry = rscTableRemove(handleTable19, handle);
  if (handleEntry.own) {
    
    exports0['35'](handleEntry.rep);
  }
}
function trampoline34(handle) {
  const handleEntry = rscTableRemove(handleTable20, handle);
  if (handleEntry.own) {
    
    exports0['36'](handleEntry.rep);
  }
}
function trampoline35(handle) {
  const handleEntry = rscTableRemove(handleTable21, handle);
  if (handleEntry.own) {
    
    exports0['37'](handleEntry.rep);
  }
}
const trampoline36 = rscTableCreateOwn.bind(null, handleTable21);
const trampoline37 = rscTableCreateOwn.bind(null, handleTable20);
const trampoline38 = rscTableCreateOwn.bind(null, handleTable19);
function trampoline39(handle) {
  const handleEntry = rscTableRemove(handleTable1, handle);
  if (handleEntry.own) {
    
    const rsc = captureTable1.get(handleEntry.rep);
    if (rsc) {
      if (rsc[symbolDispose]) rsc[symbolDispose]();
      captureTable1.delete(handleEntry.rep);
    } else if (OutputStream[symbolCabiDispose]) {
      OutputStream[symbolCabiDispose](handleEntry.rep);
    }
  }
}
function trampoline40(handle) {
  const handleEntry = rscTableRemove(handleTable0, handle);
  if (handleEntry.own) {
    
    const rsc = captureTable0.get(handleEntry.rep);
    if (rsc) {
      if (rsc[symbolDispose]) rsc[symbolDispose]();
      captureTable0.delete(handleEntry.rep);
    } else if (Error$1[symbolCabiDispose]) {
      Error$1[symbolCabiDispose](handleEntry.rep);
    }
  }
}
function trampoline41(handle) {
  const handleEntry = rscTableRemove(handleTable2, handle);
  if (handleEntry.own) {
    
    const rsc = captureTable2.get(handleEntry.rep);
    if (rsc) {
      if (rsc[symbolDispose]) rsc[symbolDispose]();
      captureTable2.delete(handleEntry.rep);
    } else if (InputStream[symbolCabiDispose]) {
      InputStream[symbolCabiDispose](handleEntry.rep);
    }
  }
}
function trampoline42(handle) {
  const handleEntry = rscTableRemove(handleTable3, handle);
  if (handleEntry.own) {
    
    const rsc = captureTable3.get(handleEntry.rep);
    if (rsc) {
      if (rsc[symbolDispose]) rsc[symbolDispose]();
      captureTable3.delete(handleEntry.rep);
    } else if (Descriptor[symbolCabiDispose]) {
      Descriptor[symbolCabiDispose](handleEntry.rep);
    }
  }
}

const $init = (() => {
  let gen = (function* init () {
    const module0 = fetchCompile(new URL('./hyperion_cargo_wasm.component.core.wasm', import.meta.url));
    const module1 = fetchCompile(new URL('./hyperion_cargo_wasm.component.core2.wasm', import.meta.url));
    const module2 = fetchCompile(new URL('./hyperion_cargo_wasm.component.core3.wasm', import.meta.url));
    const module3 = fetchCompile(new URL('./hyperion_cargo_wasm.component.core4.wasm', import.meta.url));
    ({ exports: exports0 } = yield instantiateCore(yield module2));
    ({ exports: exports1 } = yield instantiateCore(yield module0, {
      '[export]theqrl:slang/bindings': {
        '[resource-drop]binding-graph': trampoline0,
        '[resource-drop]built-in-location': trampoline4,
        '[resource-drop]definition': trampoline1,
        '[resource-drop]reference': trampoline2,
        '[resource-drop]user-file-location': trampoline3,
        '[resource-new]binding-graph': trampoline18,
        '[resource-new]built-in-location': trampoline19,
        '[resource-new]definition': trampoline17,
        '[resource-new]reference': trampoline16,
        '[resource-new]user-file-location': trampoline20,
      },
      '[export]theqrl:slang/compilation': {
        '[resource-drop]compilation-unit': trampoline34,
        '[resource-drop]file': trampoline35,
        '[resource-drop]internal-compilation-builder': trampoline33,
        '[resource-new]compilation-unit': trampoline37,
        '[resource-new]file': trampoline36,
        '[resource-new]internal-compilation-builder': trampoline38,
      },
      '[export]theqrl:slang/cst': {
        '[resource-drop]ancestors-iterator': trampoline30,
        '[resource-drop]cursor': trampoline28,
        '[resource-drop]cursor-iterator': trampoline29,
        '[resource-drop]edge': trampoline27,
        '[resource-drop]nonterminal-node': trampoline25,
        '[resource-drop]query': trampoline31,
        '[resource-drop]query-match-iterator': trampoline32,
        '[resource-drop]terminal-node': trampoline26,
        '[resource-new]ancestors-iterator': trampoline14,
        '[resource-new]cursor': trampoline8,
        '[resource-new]cursor-iterator': trampoline11,
        '[resource-new]edge': trampoline5,
        '[resource-new]nonterminal-node': trampoline12,
        '[resource-new]query': trampoline7,
        '[resource-new]query-match-iterator': trampoline15,
        '[resource-new]terminal-node': trampoline9,
        '[resource-rep]edge': trampoline6,
        '[resource-rep]nonterminal-node': trampoline13,
        '[resource-rep]terminal-node': trampoline10,
      },
      '[export]theqrl:slang/parser': {
        '[resource-drop]parse-output': trampoline22,
        '[resource-drop]parser': trampoline21,
        '[resource-new]parse-output': trampoline24,
        '[resource-new]parser': trampoline23,
      },
      wasi_snapshot_preview1: {
        environ_get: exports0['13'],
        environ_sizes_get: exports0['14'],
        fd_write: exports0['15'],
        proc_exit: exports0['16'],
        random_get: exports0['12'],
      },
    }));
    ({ exports: exports2 } = yield instantiateCore(yield module1, {
      __main_module__: {
        cabi_realloc: exports1.cabi_realloc,
      },
      env: {
        memory: exports1.memory,
      },
      'wasi:cli/environment@0.2.3': {
        'get-environment': exports0['0'],
      },
      'wasi:cli/exit@0.2.3': {
        exit: trampoline46,
      },
      'wasi:cli/stderr@0.2.3': {
        'get-stderr': trampoline43,
      },
      'wasi:cli/stdin@0.2.3': {
        'get-stdin': trampoline44,
      },
      'wasi:cli/stdout@0.2.3': {
        'get-stdout': trampoline45,
      },
      'wasi:filesystem/preopens@0.2.3': {
        'get-directories': exports0['11'],
      },
      'wasi:filesystem/types@0.2.3': {
        '[method]descriptor.append-via-stream': exports0['2'],
        '[method]descriptor.get-type': exports0['3'],
        '[method]descriptor.stat': exports0['4'],
        '[method]descriptor.write-via-stream': exports0['1'],
        '[resource-drop]descriptor': trampoline42,
        'filesystem-error-code': exports0['5'],
      },
      'wasi:io/error@0.2.3': {
        '[resource-drop]error': trampoline40,
      },
      'wasi:io/streams@0.2.3': {
        '[method]output-stream.blocking-flush': exports0['9'],
        '[method]output-stream.blocking-write-and-flush': exports0['8'],
        '[method]output-stream.check-write': exports0['6'],
        '[method]output-stream.write': exports0['7'],
        '[resource-drop]input-stream': trampoline41,
        '[resource-drop]output-stream': trampoline39,
      },
      'wasi:random/random@0.2.3': {
        'get-random-bytes': exports0['10'],
      },
    }));
    memory0 = exports1.memory;
    realloc0 = exports2.cabi_import_realloc;
    ({ exports: exports3 } = yield instantiateCore(yield module3, {
      '': {
        $imports: exports0.$imports,
        '0': trampoline47,
        '1': trampoline48,
        '10': trampoline57,
        '11': trampoline58,
        '12': exports2.random_get,
        '13': exports2.environ_get,
        '14': exports2.environ_sizes_get,
        '15': exports2.fd_write,
        '16': exports2.proc_exit,
        '17': exports1['theqrl:slang/cst#[dtor]terminal-kind-extensions'],
        '18': exports1['theqrl:slang/cst#[dtor]nonterminal-node'],
        '19': exports1['theqrl:slang/cst#[dtor]terminal-node'],
        '2': trampoline49,
        '20': exports1['theqrl:slang/cst#[dtor]edge'],
        '21': exports1['theqrl:slang/cst#[dtor]cursor'],
        '22': exports1['theqrl:slang/cst#[dtor]cursor-iterator'],
        '23': exports1['theqrl:slang/cst#[dtor]ancestors-iterator'],
        '24': exports1['theqrl:slang/cst#[dtor]query'],
        '25': exports1['theqrl:slang/cst#[dtor]query-match-iterator'],
        '26': exports1['theqrl:slang/cst#[dtor]text-index-extensions'],
        '27': exports1['theqrl:slang/ast#[dtor]selectors'],
        '28': exports1['theqrl:slang/bindings#[dtor]binding-graph'],
        '29': exports1['theqrl:slang/bindings#[dtor]definition'],
        '3': trampoline50,
        '30': exports1['theqrl:slang/bindings#[dtor]reference'],
        '31': exports1['theqrl:slang/bindings#[dtor]user-file-location'],
        '32': exports1['theqrl:slang/bindings#[dtor]built-in-location'],
        '33': exports1['theqrl:slang/parser#[dtor]parser'],
        '34': exports1['theqrl:slang/parser#[dtor]parse-output'],
        '35': exports1['theqrl:slang/compilation#[dtor]internal-compilation-builder'],
        '36': exports1['theqrl:slang/compilation#[dtor]compilation-unit'],
        '37': exports1['theqrl:slang/compilation#[dtor]file'],
        '38': exports1['theqrl:slang/utils#[dtor]language-facts'],
        '4': trampoline51,
        '5': trampoline52,
        '6': trampoline53,
        '7': trampoline54,
        '8': trampoline55,
        '9': trampoline56,
      },
    }));
    realloc1 = exports1.cabi_realloc;
    postReturn0 = exports1['cabi_post_theqrl:slang/cst#[method]nonterminal-node.children'];
    postReturn1 = exports1['cabi_post_theqrl:slang/cst#[method]nonterminal-node.unparse'];
    postReturn2 = exports1['cabi_post_theqrl:slang/cst#[method]nonterminal-node.to-json'];
    postReturn3 = exports1['cabi_post_theqrl:slang/cst#[method]terminal-node.children'];
    postReturn4 = exports1['cabi_post_theqrl:slang/cst#[method]terminal-node.unparse'];
    postReturn5 = exports1['cabi_post_theqrl:slang/cst#[method]terminal-node.to-json'];
    postReturn6 = exports1['cabi_post_theqrl:slang/cst#[method]cursor.children'];
    postReturn7 = exports1['cabi_post_theqrl:slang/cst#[static]query.create'];
    postReturn8 = exports1['cabi_post_theqrl:slang/cst#[method]query-match-iterator.next'];
    postReturn9 = exports1['cabi_post_theqrl:slang/ast#[static]selectors.sequence'];
    postReturn10 = exports1['cabi_post_theqrl:slang/ast#[static]selectors.choice'];
    postReturn11 = exports1['cabi_post_theqrl:slang/ast#[static]selectors.repeated'];
    postReturn12 = exports1['cabi_post_theqrl:slang/ast#[static]selectors.separated'];
    postReturn13 = exports1['cabi_post_theqrl:slang/bindings#[method]definition.references'];
    postReturn14 = exports1['cabi_post_theqrl:slang/bindings#[method]reference.definitions'];
    postReturn15 = exports1['cabi_post_theqrl:slang/bindings#[method]user-file-location.file-id'];
    postReturn16 = exports1['cabi_post_theqrl:slang/parser#[static]parser.create'];
    postReturn17 = exports1['cabi_post_theqrl:slang/parser#[method]parser.language-version'];
    postReturn18 = exports1['cabi_post_theqrl:slang/parser#[method]parse-output.errors'];
    postReturn19 = exports1['cabi_post_theqrl:slang/compilation#[static]internal-compilation-builder.create'];
    postReturn20 = exports1['cabi_post_theqrl:slang/compilation#[method]internal-compilation-builder.add-file'];
    postReturn21 = exports1['cabi_post_theqrl:slang/compilation#[method]internal-compilation-builder.resolve-import'];
    postReturn22 = exports1['cabi_post_theqrl:slang/compilation#[method]compilation-unit.language-version'];
    postReturn23 = exports1['cabi_post_theqrl:slang/compilation#[method]compilation-unit.files'];
    postReturn24 = exports1['cabi_post_theqrl:slang/compilation#[method]file.id'];
    postReturn25 = exports1['cabi_post_theqrl:slang/compilation#[method]file.errors'];
    postReturn26 = exports1['cabi_post_theqrl:slang/utils#[static]language-facts.all-versions'];
    postReturn27 = exports1['cabi_post_theqrl:slang/utils#[static]language-facts.earliest-version'];
    postReturn28 = exports1['cabi_post_theqrl:slang/utils#[static]language-facts.latest-version'];
    postReturn29 = exports1['cabi_post_theqrl:slang/utils#[static]language-facts.infer-language-versions'];
    cstStaticTerminalKindExtensionsIsIdentifier = exports1['theqrl:slang/cst#[static]terminal-kind-extensions.is-identifier'];
    cstStaticTerminalKindExtensionsIsTrivia = exports1['theqrl:slang/cst#[static]terminal-kind-extensions.is-trivia'];
    cstStaticTerminalKindExtensionsIsValid = exports1['theqrl:slang/cst#[static]terminal-kind-extensions.is-valid'];
    cstStaticNonterminalNodeCreate = exports1['theqrl:slang/cst#[static]nonterminal-node.create'];
    cstMethodNonterminalNodeId = exports1['theqrl:slang/cst#[method]nonterminal-node.id'];
    cstMethodNonterminalNodeKind = exports1['theqrl:slang/cst#[method]nonterminal-node.kind'];
    cstMethodNonterminalNodeTextLength = exports1['theqrl:slang/cst#[method]nonterminal-node.text-length'];
    cstMethodNonterminalNodeChildren = exports1['theqrl:slang/cst#[method]nonterminal-node.children'];
    cstMethodNonterminalNodeDescendants = exports1['theqrl:slang/cst#[method]nonterminal-node.descendants'];
    cstMethodNonterminalNodeUnparse = exports1['theqrl:slang/cst#[method]nonterminal-node.unparse'];
    cstMethodNonterminalNodeToJson = exports1['theqrl:slang/cst#[method]nonterminal-node.to-json'];
    cstMethodNonterminalNodeCreateCursor = exports1['theqrl:slang/cst#[method]nonterminal-node.create-cursor'];
    cstStaticTerminalNodeCreate = exports1['theqrl:slang/cst#[static]terminal-node.create'];
    cstMethodTerminalNodeId = exports1['theqrl:slang/cst#[method]terminal-node.id'];
    cstMethodTerminalNodeKind = exports1['theqrl:slang/cst#[method]terminal-node.kind'];
    cstMethodTerminalNodeTextLength = exports1['theqrl:slang/cst#[method]terminal-node.text-length'];
    cstMethodTerminalNodeChildren = exports1['theqrl:slang/cst#[method]terminal-node.children'];
    cstMethodTerminalNodeDescendants = exports1['theqrl:slang/cst#[method]terminal-node.descendants'];
    cstMethodTerminalNodeUnparse = exports1['theqrl:slang/cst#[method]terminal-node.unparse'];
    cstMethodTerminalNodeToJson = exports1['theqrl:slang/cst#[method]terminal-node.to-json'];
    cstStaticEdgeCreateWithTerminal = exports1['theqrl:slang/cst#[static]edge.create-with-terminal'];
    cstStaticEdgeCreateWithNonterminal = exports1['theqrl:slang/cst#[static]edge.create-with-nonterminal'];
    cstMethodEdgeLabel = exports1['theqrl:slang/cst#[method]edge.label'];
    cstMethodEdgeNode = exports1['theqrl:slang/cst#[method]edge.node'];
    cstMethodCursorReset = exports1['theqrl:slang/cst#[method]cursor.reset'];
    cstMethodCursorComplete = exports1['theqrl:slang/cst#[method]cursor.complete'];
    cstMethodCursorIsCompleted = exports1['theqrl:slang/cst#[method]cursor.is-completed'];
    cstMethodCursorClone = exports1['theqrl:slang/cst#[method]cursor.clone'];
    cstMethodCursorSpawn = exports1['theqrl:slang/cst#[method]cursor.spawn'];
    cstMethodCursorNode = exports1['theqrl:slang/cst#[method]cursor.node'];
    cstMethodCursorLabel = exports1['theqrl:slang/cst#[method]cursor.label'];
    cstMethodCursorTextOffset = exports1['theqrl:slang/cst#[method]cursor.text-offset'];
    cstMethodCursorTextRange = exports1['theqrl:slang/cst#[method]cursor.text-range'];
    cstMethodCursorDepth = exports1['theqrl:slang/cst#[method]cursor.depth'];
    cstMethodCursorChildren = exports1['theqrl:slang/cst#[method]cursor.children'];
    cstMethodCursorDescendants = exports1['theqrl:slang/cst#[method]cursor.descendants'];
    cstMethodCursorRemainingNodes = exports1['theqrl:slang/cst#[method]cursor.remaining-nodes'];
    cstMethodCursorAncestors = exports1['theqrl:slang/cst#[method]cursor.ancestors'];
    cstMethodCursorGoToNext = exports1['theqrl:slang/cst#[method]cursor.go-to-next'];
    cstMethodCursorGoToNextNonDescendant = exports1['theqrl:slang/cst#[method]cursor.go-to-next-non-descendant'];
    cstMethodCursorGoToPrevious = exports1['theqrl:slang/cst#[method]cursor.go-to-previous'];
    cstMethodCursorGoToParent = exports1['theqrl:slang/cst#[method]cursor.go-to-parent'];
    cstMethodCursorGoToFirstChild = exports1['theqrl:slang/cst#[method]cursor.go-to-first-child'];
    cstMethodCursorGoToLastChild = exports1['theqrl:slang/cst#[method]cursor.go-to-last-child'];
    cstMethodCursorGoToNthChild = exports1['theqrl:slang/cst#[method]cursor.go-to-nth-child'];
    cstMethodCursorGoToNextSibling = exports1['theqrl:slang/cst#[method]cursor.go-to-next-sibling'];
    cstMethodCursorGoToPreviousSibling = exports1['theqrl:slang/cst#[method]cursor.go-to-previous-sibling'];
    cstMethodCursorGoToNextTerminal = exports1['theqrl:slang/cst#[method]cursor.go-to-next-terminal'];
    cstMethodCursorGoToNextTerminalWithKind = exports1['theqrl:slang/cst#[method]cursor.go-to-next-terminal-with-kind'];
    cstMethodCursorGoToNextTerminalWithKinds = exports1['theqrl:slang/cst#[method]cursor.go-to-next-terminal-with-kinds'];
    cstMethodCursorGoToNextNonterminal = exports1['theqrl:slang/cst#[method]cursor.go-to-next-nonterminal'];
    cstMethodCursorGoToNextNonterminalWithKind = exports1['theqrl:slang/cst#[method]cursor.go-to-next-nonterminal-with-kind'];
    cstMethodCursorGoToNextNonterminalWithKinds = exports1['theqrl:slang/cst#[method]cursor.go-to-next-nonterminal-with-kinds'];
    cstMethodCursorQuery = exports1['theqrl:slang/cst#[method]cursor.query'];
    cstMethodCursorIteratorNext = exports1['theqrl:slang/cst#[method]cursor-iterator.next'];
    cstMethodAncestorsIteratorNext = exports1['theqrl:slang/cst#[method]ancestors-iterator.next'];
    cstStaticQueryCreate = exports1['theqrl:slang/cst#[static]query.create'];
    cstMethodQueryMatchIteratorNext = exports1['theqrl:slang/cst#[method]query-match-iterator.next'];
    cstStaticTextIndexExtensionsZero = exports1['theqrl:slang/cst#[static]text-index-extensions.zero'];
    astStaticSelectorsSequence = exports1['theqrl:slang/ast#[static]selectors.sequence'];
    astStaticSelectorsChoice = exports1['theqrl:slang/ast#[static]selectors.choice'];
    astStaticSelectorsRepeated = exports1['theqrl:slang/ast#[static]selectors.repeated'];
    astStaticSelectorsSeparated = exports1['theqrl:slang/ast#[static]selectors.separated'];
    bindingsMethodBindingGraphDefinitionAt = exports1['theqrl:slang/bindings#[method]binding-graph.definition-at'];
    bindingsMethodBindingGraphReferenceAt = exports1['theqrl:slang/bindings#[method]binding-graph.reference-at'];
    bindingsMethodDefinitionId = exports1['theqrl:slang/bindings#[method]definition.id'];
    bindingsMethodDefinitionNameLocation = exports1['theqrl:slang/bindings#[method]definition.name-location'];
    bindingsMethodDefinitionDefiniensLocation = exports1['theqrl:slang/bindings#[method]definition.definiens-location'];
    bindingsMethodDefinitionReferences = exports1['theqrl:slang/bindings#[method]definition.references'];
    bindingsMethodReferenceId = exports1['theqrl:slang/bindings#[method]reference.id'];
    bindingsMethodReferenceLocation = exports1['theqrl:slang/bindings#[method]reference.location'];
    bindingsMethodReferenceDefinitions = exports1['theqrl:slang/bindings#[method]reference.definitions'];
    bindingsMethodUserFileLocationFileId = exports1['theqrl:slang/bindings#[method]user-file-location.file-id'];
    bindingsMethodUserFileLocationCursor = exports1['theqrl:slang/bindings#[method]user-file-location.cursor'];
    parserStaticParserCreate = exports1['theqrl:slang/parser#[static]parser.create'];
    parserMethodParserLanguageVersion = exports1['theqrl:slang/parser#[method]parser.language-version'];
    parserMethodParserParseFileContents = exports1['theqrl:slang/parser#[method]parser.parse-file-contents'];
    parserMethodParserParseNonterminal = exports1['theqrl:slang/parser#[method]parser.parse-nonterminal'];
    parserMethodParseOutputTree = exports1['theqrl:slang/parser#[method]parse-output.tree'];
    parserMethodParseOutputErrors = exports1['theqrl:slang/parser#[method]parse-output.errors'];
    parserMethodParseOutputIsValid = exports1['theqrl:slang/parser#[method]parse-output.is-valid'];
    parserMethodParseOutputCreateTreeCursor = exports1['theqrl:slang/parser#[method]parse-output.create-tree-cursor'];
    compilationStaticInternalCompilationBuilderCreate = exports1['theqrl:slang/compilation#[static]internal-compilation-builder.create'];
    compilationMethodInternalCompilationBuilderAddFile = exports1['theqrl:slang/compilation#[method]internal-compilation-builder.add-file'];
    compilationMethodInternalCompilationBuilderResolveImport = exports1['theqrl:slang/compilation#[method]internal-compilation-builder.resolve-import'];
    compilationMethodInternalCompilationBuilderBuild = exports1['theqrl:slang/compilation#[method]internal-compilation-builder.build'];
    compilationMethodCompilationUnitLanguageVersion = exports1['theqrl:slang/compilation#[method]compilation-unit.language-version'];
    compilationMethodCompilationUnitFiles = exports1['theqrl:slang/compilation#[method]compilation-unit.files'];
    compilationMethodCompilationUnitFile = exports1['theqrl:slang/compilation#[method]compilation-unit.file'];
    compilationMethodCompilationUnitBindingGraph = exports1['theqrl:slang/compilation#[method]compilation-unit.binding-graph'];
    compilationMethodFileId = exports1['theqrl:slang/compilation#[method]file.id'];
    compilationMethodFileTree = exports1['theqrl:slang/compilation#[method]file.tree'];
    compilationMethodFileErrors = exports1['theqrl:slang/compilation#[method]file.errors'];
    compilationMethodFileCreateTreeCursor = exports1['theqrl:slang/compilation#[method]file.create-tree-cursor'];
    utilsStaticLanguageFactsAllVersions = exports1['theqrl:slang/utils#[static]language-facts.all-versions'];
    utilsStaticLanguageFactsEarliestVersion = exports1['theqrl:slang/utils#[static]language-facts.earliest-version'];
    utilsStaticLanguageFactsLatestVersion = exports1['theqrl:slang/utils#[static]language-facts.latest-version'];
    utilsStaticLanguageFactsInferLanguageVersions = exports1['theqrl:slang/utils#[static]language-facts.infer-language-versions'];
  })();
  let promise, resolve, reject;
  function runNext (value) {
    try {
      let done;
      do {
        ({ value, done } = gen.next(value));
      } while (!(value instanceof Promise) && !done);
      if (done) {
        if (resolve) resolve(value);
        else return value;
      }
      if (!promise) promise = new Promise((_resolve, _reject) => (resolve = _resolve, reject = _reject));
      value.then(runNext, reject);
    }
    catch (e) {
      if (reject) reject(e);
      else throw e;
    }
  }
  const maybeSyncReturn = runNext(null);
  return promise || maybeSyncReturn;
})();

await $init;
const ast = {
  Selectors: Selectors,
  
};
const bindings = {
  BindingGraph: BindingGraph,
  BindingLocationType: BindingLocationType,
  Definition: Definition,
  Reference: Reference,
  UserFileLocation: UserFileLocation,
  
};
const compilation = {
  CompilationUnit: CompilationUnit,
  File: File,
  InternalCompilationBuilder: InternalCompilationBuilder,
  
};
const cst = {
  AncestorsIterator: AncestorsIterator,
  Cursor: Cursor,
  CursorIterator: CursorIterator,
  Edge: Edge,
  EdgeLabel: edgeLabel,
  NodeType: NodeType,
  NonterminalKind: nonterminalKind,
  NonterminalNode: NonterminalNode,
  Query: Query,
  QueryMatchIterator: QueryMatchIterator,
  TerminalKind: terminalKind,
  TerminalKindExtensions: TerminalKindExtensions,
  TerminalNode: TerminalNode,
  TextIndexExtensions: TextIndexExtensions,
  
};
const parser = {
  ParseOutput: ParseOutput,
  Parser: Parser,
  
};
const utils = {
  LanguageFacts: LanguageFacts,
  
};

export { ast, bindings, compilation, cst, parser, utils,  }