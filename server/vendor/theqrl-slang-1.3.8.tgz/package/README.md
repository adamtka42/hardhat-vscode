# @theqrl/slang

<!-- _PRODUCT_README_ (keep in sync) -->

[![release](https://img.shields.io/github/v/tag/adamtka42/slang?label=GitHub%20Release&logo=github&sort=semver&logoColor=white)](https://github.com/adamtka42/slang/releases)
[![npm](https://img.shields.io/npm/v/@theqrl/slang?label=NPM%20Package&logo=npm&logoColor=white)](https://www.npmjs.com/package/@theqrl/slang)
[![cargo](https://img.shields.io/crates/v/slang_hyperion?label=Rust%20Crate&logo=rust&logoColor=white)](https://crates.io/crates/slang_hyperion)

## Hyperion compiler tooling for [QRL Zond](https://github.com/theQRL)

A port of [Slang](https://github.com/NomicFoundation/slang) by [@NomicFoundation](https://github.com/NomicFoundation) to the [Hyperion](https://github.com/theQRL/hyperion) language.

A modular set of compiler APIs empowering the next generation of Hyperion code analysis and developer tooling.
Written in Rust and distributed in multiple languages.

Slang analyzes Hyperion source code and generates a rich concrete syntax tree (CST) that can be reasoned about. This is a departure from the classic approach of "black-box" compilers, which are handed the input and only their output can be observed.

### Supporting Multiple Hyperion Versions

The Hyperion programming language has evolved quite a bit since its inception. Some features were introduced, some changed, while some eventually became obsolete and were removed altogether. Developer tooling must be able to understand and consume older contracts that are still being used on the blockchain, written in older versions of Hyperion.

Because of that, Slang must be able to reason about different versions of Hyperion; how the language grammar, name capture rules, and semantics have changed across different versions. One of our goals is to document differences as part of our [Hyperion Grammar](https://adamtka42.github.io/slang/latest/hyperion-grammar/).

This is why, instead of having to download separate versions of Slang for each Hyperion version, you specify the Hyperion version that you want to work with when you use the Slang language APIs.

- [See our supported versions.](https://adamtka42.github.io/slang/latest/hyperion-grammar/supported-versions/)

## Installation

You can install the [Slang NPM package](https://www.npmjs.com/package/@theqrl/slang) with the following `npm` command:

```sh
npm install "@theqrl/slang"
```

Or if you are using `yarn`:

```sh
yarn add "@theqrl/slang"
```

- [Learn more about how to get started with Slang.](https://adamtka42.github.io/slang/latest/user-guide/04-getting-started/01-installation/)

## Example

```ts
import assert from "node:assert";
import { ParseOutput, Parser } from "@theqrl/slang/parser";
import { NonterminalKind, TerminalKind } from "@theqrl/slang/cst";
import { LanguageFacts } from "@theqrl/slang/utils";

function createTree(): ParseOutput {
    const source = `
    contract Foo {}
    contract Bar {}
    contract Baz {}
  `;

    const parser = Parser.create(LanguageFacts.latestVersion());

    const parseOutput = parser.parseFileContents(source.trim());
    assert(parseOutput.isValid());

    return parseOutput;
}

test("Get contract names", () => {
    const tree = createTree();
    const cursor = tree.createTreeCursor();

    const contracts = [];

    while (cursor.goToNextNonterminalWithKind(NonterminalKind.ContractDefinition)) {
        assert(cursor.goToNextTerminalWithKind(TerminalKind.Identifier));
        contracts.push(cursor.node.unparse());
    }

    assert.deepStrictEqual(contracts, ["Foo", "Bar", "Baz"]);
});
```

Slang is not a replacement for hypc, the standard Hyperion compiler. We do not plan at the moment to support emitting optimized QRVM bytecode for use in production. It does not perform formal verification of contracts or Hyperion logic in general. However, it is designed to empower such tools to be built on top of it.

- [Slang User Guide](https://adamtka42.github.io/slang/latest/user-guide/01-introduction/)

## Using Slang

We have [several examples](https://adamtka42.github.io/slang/latest/user-guide/08-examples/) showing some of the ways that you can use Slang APIs to develop your own Hyperion tooling. For more detailed information about Slang concepts please check [our user guide](https://adamtka42.github.io/slang/latest/user-guide/).

## Core Concepts

### Concrete Syntax Trees

Slang is capable of parsing the source code into a Concrete Syntax Tree (CST), which is a tree structure representing the entire source code. It includes the contracts, functions, statements, and expressions within. It also includes things like comments, whitespace, and punctuation. This is sometimes called a "full-fidelity" CST, and it can be used to reconstruct the original source code when needed.

### Parser

The `Parser` API is used to produce a CST from Hyperion source code. Each `Parser` object is initialized with a specific Hyperion version.

With a `Parser` object, you can analyze any source text according to the grammar of that specific version. Therefore, providing an accurate language version is important as it affects the shape of the syntax tree and the set of possible errors.

- [Learn more about the Parser API.](https://adamtka42.github.io/slang/latest/user-guide/04-getting-started/01-installation/)

### Cursors

For many code analysis tasks it is useful to traverse the CST and visit each node. Slang provides this functionality through cursors. Cursors provide an efficient pre-order traversal API for both complete CSTs and arbitrary subtrees.

- [Learn more about using cursors.](https://adamtka42.github.io/slang/latest/user-guide/05-syntax-trees/03-navigating-with-cursors/)

### Queries

The `Cursor` API is a low-level API that allows you to traverse the CST in a procedural manner. However, it is often more convenient to use the declarative `Query` API. Queries allow you to express your intent more concisely, and also allows you to reuse the same query in multiple places. Queries can largely replace the need for both internal (cursor), and external (visitor) iterator patterns.

- [Learn more about using queries.](https://adamtka42.github.io/slang/latest/user-guide/06-query-language/01-query-syntax/)

### Compilation Units

Hyperion projects are usually composed of multiple files. Slang has the concept of a `CompilationUnit`, which is built from parsing Hyperion source files and their dependencies, transitively. This allows performing further analysis on the source code, such as semantic analysis.

- [Learn more about using compilation units.](https://adamtka42.github.io/slang/latest/user-guide/07-semantic-analysis/01-compilation-units/)

### Binding Graph

The binding graph is a structure that represents the relationships between identifiers across source files in a `CompilationUnit`. It stores `Cursor` objects to all Hyperion definitions (contracts, functions, state variables, etc.), the references to them, and can resolve the links between the two.

- [Learn more about using the binding graph.](https://adamtka42.github.io/slang/latest/user-guide/07-semantic-analysis/02-binding-graph/)

## Contributing

Please check our [contributors guide](https://github.com/adamtka42/slang/blob/main/CONTRIBUTING.md) to learn about how you can get started on Slang development.

## Built with Slang

Projects in the Hyperion ecosystem using (or intended to use) Slang:

- [Hardhat Hyperion VSCode Extension](https://github.com/theQRL/hardhat-vscode-qrl)

- [Learn more about projects using Slang.](https://adamtka42.github.io/slang/latest/user-guide/02-powered-by-slang/)

---

- [Slang NPM Package](https://www.npmjs.com/package/@theqrl/slang/)
- [Slang User Guide](https://adamtka42.github.io/slang/latest/user-guide/)
