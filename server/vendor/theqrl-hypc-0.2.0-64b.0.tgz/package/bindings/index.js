"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("./core");
const helpers_1 = require("./helpers");
const compile_1 = require("./compile");
function setupBindings(hypJson) {
    const coreBindings = (0, core_1.setupCore)(hypJson);
    const compileBindings = (0, compile_1.setupCompile)(hypJson, coreBindings);
    const methodFlags = (0, helpers_1.getSupportedMethods)(hypJson);
    return {
        methodFlags,
        coreBindings,
        compileBindings
    };
}
exports.default = setupBindings;
