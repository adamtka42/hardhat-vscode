"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSupportedMethods = exports.bindHypcMethodWithFallbackFunc = exports.bindHypcMethod = void 0;
const helpers_1 = require("../common/helpers");
function bindHypcMethod(hypJson, method, returnType, args, defaultValue) {
    if ((0, helpers_1.isNil)(hypJson[`_${method}`]) && defaultValue !== undefined) {
        return defaultValue;
    }
    return hypJson.cwrap(method, returnType, args);
}
exports.bindHypcMethod = bindHypcMethod;
function bindHypcMethodWithFallbackFunc(hypJson, method, returnType, args, fallbackMethod, finalFallback = undefined) {
    const methodFunc = bindHypcMethod(hypJson, method, returnType, args, null);
    if (!(0, helpers_1.isNil)(methodFunc)) {
        return methodFunc;
    }
    return bindHypcMethod(hypJson, fallbackMethod, returnType, args, finalFallback);
}
exports.bindHypcMethodWithFallbackFunc = bindHypcMethodWithFallbackFunc;
function getSupportedMethods(hypJson) {
    return {
        licenseSupported: anyMethodExists(hypJson, 'hyperion_license'),
        versionSupported: anyMethodExists(hypJson, 'hyperion_version'),
        allocSupported: anyMethodExists(hypJson, 'hyperion_alloc'),
        resetSupported: anyMethodExists(hypJson, 'hyperion_reset'),
        compileJsonSupported: anyMethodExists(hypJson, 'compileJSON'),
        compileJsonMultiSupported: anyMethodExists(hypJson, 'compileJSONMulti'),
        compileJsonCallbackSuppported: anyMethodExists(hypJson, 'compileJSONCallback'),
        compileJsonStandardSupported: anyMethodExists(hypJson, 'compileStandard', 'hyperion_compile')
    };
}
exports.getSupportedMethods = getSupportedMethods;
function anyMethodExists(hypJson, ...names) {
    return names.some(name => !(0, helpers_1.isNil)(hypJson[`_${name}`]));
}
