"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tape_1 = __importDefault(require("tape"));
const __1 = __importDefault(require("../"));
const smtchecker_1 = __importDefault(require("../smtchecker"));
const smtsolver_1 = __importDefault(require("../smtsolver"));
const preamble = 'pragma hyperion >=0.0.1;\n// SPDX-License-Identifier: GPL-3.0\n';
//
(0, tape_1.default)('SMTChecker', function (t) {
    // We use null for `solverFunction` and `solver` when calling `handleSMTQueries`
    // because these tests do not call a solver.
    t.test('smoke test with no axuiliaryInputRequested', function (st) {
        const input = {};
        const output = {};
        st.equal(smtchecker_1.default.handleSMTQueries(input, output, null, null), null);
        st.end();
    });
    t.test('smoke test with no smtlib2queries', function (st) {
        const input = {};
        const output = { auxiliaryInputRequested: {} };
        st.equal(smtchecker_1.default.handleSMTQueries(input, output, null, null), null);
        st.end();
    });
    t.test('smoke test with empty smtlib2queries', function (st) {
        const input = {};
        const output = { auxiliaryInputRequested: { smtlib2queries: {} } };
        st.equal(smtchecker_1.default.handleSMTQueries(input, output, null, null), null);
        st.end();
    });
    t.test('smtCallback should return type function', (st) => {
        const response = smtchecker_1.default.smtCallback(() => { });
        st.equal(typeof response, 'function');
        st.end();
    });
    t.test('smtCallback should error when passed parser fails', (st) => {
        const cbFun = smtchecker_1.default.smtCallback((content) => { throw new Error(content); });
        const response = cbFun('expected-error-message');
        st.deepEqual(response, { error: new Error('expected-error-message') });
        st.end();
    });
    t.test('smtCallback should return content when passed parser does not fail', (st) => {
        const cbFun = smtchecker_1.default.smtCallback((content) => { return content; });
        const response = cbFun('expected-content-message');
        st.deepEqual(response, { contents: 'expected-content-message' });
        st.end();
    });
});
(0, tape_1.default)('SMTCheckerWithSolver', function (t) {
    // In these tests we require z3 to actually run the solver.
    // This uses the SMT double run mechanism instead of the callback.
    t.test('Simple test with axuiliaryInputRequested', function (st) {
        const z3 = smtsolver_1.default.availableSolvers.filter(solver => solver.command === 'z3');
        if (z3.length === 0) {
            st.skip('Test requires z3.');
            st.end();
            return;
        }
        const settings = {
            modelChecker: {
                engine: 'chc',
                solvers: ['smtlib2']
            }
        };
        const source = { a: { content: preamble + '\ncontract C { function f(uint x) public pure { assert(x > 0); } }' } };
        const input = {
            language: 'Hyperion',
            sources: source,
            settings: settings
        };
        const output = JSON.parse(__1.default.compile(JSON.stringify(input)));
        st.ok(output);
        const newInput = smtchecker_1.default.handleSMTQueries(input, output, smtsolver_1.default.smtSolver, z3[0]);
        st.notEqual(newInput, null);
        const newOutput = JSON.parse(__1.default.compile(JSON.stringify(newInput)));
        st.ok(newOutput);
        const smtErrors = newOutput.errors.filter(e => e.errorCode === '6328');
        st.equal(smtErrors.length, 1);
        st.end();
    });
});
