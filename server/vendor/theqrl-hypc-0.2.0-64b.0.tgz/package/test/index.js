"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const semver = __importStar(require("semver"));
Promise.resolve().then(() => __importStar(require('./linker')));
Promise.resolve().then(() => __importStar(require('./translate')));
Promise.resolve().then(() => __importStar(require('./compiler')));
Promise.resolve().then(() => __importStar(require('./smtcallback')));
Promise.resolve().then(() => __importStar(require('./smtchecker')));
Promise.resolve().then(() => __importStar(require('./abi')));
// The CLI doesn't support Node 4
if (semver.gte(process.version, '5.0.0')) {
    Promise.resolve().then(() => __importStar(require('./cli')));
}
