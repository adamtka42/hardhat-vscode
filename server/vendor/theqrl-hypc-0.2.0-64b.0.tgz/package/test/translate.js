"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const tape_1 = __importDefault(require("tape"));
const translate_1 = __importDefault(require("../translate"));
const versionToSemver = translate_1.default.versionToSemver;
(0, tape_1.default)('Version string to Semver translator', function (t) {
    t.test('Only numbers', function (st) {
        st.equal(versionToSemver('0.1.0'), '0.1.0');
        st.end();
    });
    t.test('New style release (semver)', function (st) {
        st.equal(versionToSemver('0.4.5+commit.b318366e.Emscripten.clang'), '0.4.5+commit.b318366e.Emscripten.clang');
        st.end();
    });
    t.test('New style nightly (semver)', function (st) {
        st.equal(versionToSemver('0.4.20-nightly.2018.2.13+commit.27ef9794.Emscripten.clang'), '0.4.20-nightly.2018.2.13+commit.27ef9794.Emscripten.clang');
        st.end();
    });
    t.test('Old style 0.1.1', function (st) {
        st.equal(versionToSemver('0.1.1-6ff4cd6b/RelWithDebInfo-Emscripten/clang/int'), '0.1.1+commit.6ff4cd6b');
        st.end();
    });
    t.test('Old style 0.1.2', function (st) {
        st.equal(versionToSemver('0.1.2-5c3bfd4b*/.-/clang/int'), '0.1.2+commit.5c3bfd4b');
        st.end();
    });
    t.test('Broken 0.1.3', function (st) {
        st.equal(versionToSemver('0.1.3-0/.-/clang/int linked to libqrl-0.9.92-0/.-/clang/int'), '0.1.3');
        st.end();
    });
    t.test('Old style 0.2.0', function (st) {
        st.equal(versionToSemver('0.2.0-e7098958/.-Emscripten/clang/int linked to libqrl-1.1.1-bbb80ab0/.-Emscripten/clang/int'), '0.2.0+commit.e7098958');
        st.end();
    });
    t.test('Old style 0.3.5', function (st) {
        // The one in the hypc-bin list
        st.equal(versionToSemver('0.3.5-371690f0/Release-Emscripten/clang/Interpreter'), '0.3.5+commit.371690f0');
        // The actual one reported by the compiler
        st.equal(versionToSemver('0.3.5-0/Release-Emscripten/clang/Interpreter'), '0.3.5');
        st.end();
    });
    t.test('Old style 0.3.6', function (st) {
        st.equal(versionToSemver('0.3.6-3fc68da5/Release-Emscripten/clang'), '0.3.6+commit.3fc68da5');
        st.end();
    });
});
(0, tape_1.default)('prettyPrintLegacyAssemblyJSON', function (t) {
    t.test('Works properly', function (st) {
        const fixtureAsmJson = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'resources/fixtureAsmJson.json')).toString());
        const fixtureAsmJsonSource = fs.readFileSync(path.resolve(__dirname, 'resources/fixtureAsmJson.hyp')).toString();
        const fixtureAsmJsonOutput = fs.readFileSync(path.resolve(__dirname, 'resources/fixtureAsmJson.output')).toString();
        st.equal(translate_1.default.prettyPrintLegacyAssemblyJSON(fixtureAsmJson, fixtureAsmJsonSource), fixtureAsmJsonOutput);
        st.end();
    });
});
